#!/usr/bin/env bash
# =========================================================================
#   OfiGremio PRO — Actualizador de Sistema Seguro (Linux)
# =========================================================================

set -e

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

echo "========================================================================="
echo "  OfiGremio PRO — Actualizador de Sistema Seguro y Migración (Linux)"
echo "========================================================================="
echo ""

# 1. Copia preventiva
echo "[1/3] Creando copia de seguridad preventiva..."
mkdir -p backups
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
if [ -f "ofigremio.db" ]; then
    cp ofigremio.db "backups/ofigremio_backup_${TIMESTAMP}.db"
    echo "  [OK] Base de datos respaldada en backups/ofigremio_backup_${TIMESTAMP}.db"
else
    echo "  [INFO] No se detecta base de datos previa en este directorio."
fi

# 2. Entorno virtual y dependencias
echo ""
echo "[2/3] Comprobando entorno virtual y dependencias..."
if [ ! -d ".venv" ]; then
    echo "  [INFO] Creando entorno virtual aislado .venv..."
    python3 -m venv .venv 2>/dev/null || true
fi

if [ -f ".venv/bin/python" ]; then
    PYTHON_BIN=".venv/bin/python"
    $PYTHON_BIN -m pip install -r requirements.txt --quiet 2>/dev/null || true
    echo "  [OK] Entorno virtual (.venv) sincronizado."
else
    PYTHON_BIN="python3"
    pip install -r requirements.txt --quiet 2>/dev/null || true
    echo "  [OK] Entorno Python del sistema utilizado."
fi

# 3. Migración de base de datos
echo ""
echo "[3/3] Aplicando migraciones de base de datos..."
$PYTHON_BIN -c "import database; database.init_db(); print('  [OK] Esquema de datos y nuevas tablas verificadas.')"

# Asegurar permisos de ejecución
chmod +x *.sh 2>/dev/null || true

echo ""
echo "========================================================================="
echo "  [ÉXITO] ¡OfiGremio PRO ha sido actualizado a la última versión!"
echo "========================================================================="
echo ""
echo "Puedes iniciar OfiGremio ejecutando: ./2_abrir_ofigremio.sh"
echo ""
