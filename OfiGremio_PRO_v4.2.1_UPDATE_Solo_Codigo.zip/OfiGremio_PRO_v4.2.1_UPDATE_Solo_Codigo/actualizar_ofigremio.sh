#!/bin/bash
# =========================================================================
#   OfiGremio PRO — Actualizador de Sistema Seguro (Linux)
# =========================================================================

set -e

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

echo "========================================================================="
echo "  OfiGremio PRO — Actualizador de Sistema Seguro y Migración (Linux)"
echo "========================================================================="
echo ""

# 1. Copia preventiva
echo "[1/3] Creando copia de seguridad preventiva..."
mkdir -p backups
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
if [ -f "ofigremio.db" ]; then
    cp ofigremio.db "backups/ofigremio_backup_${TIMESTAMP}.db"
    echo "  [OK] Base de datos respaldada en backups/ofigremio_backup_${TIMESTAMP}.db"
fi

# 2. Entorno virtual
echo ""
echo "[2/3] Comprobando dependencias en .venv..."
if [ -f ".venv/bin/activate" ]; then
    source .venv/bin/activate
fi
pip install -r requirements.txt --quiet > /dev/null 2>&1 || true

# 3. Migración
echo ""
echo "[3/3] Aplicando migraciones de base de datos..."
python3 -c "import database; database.init_db(); print('  [OK] Esquema de datos y nuevas tablas verificadas.')"

echo ""
echo "========================================================================="
echo "  [ÉXITO] ¡OfiGremio PRO ha sido actualizado a la última versión!"
echo "========================================================================="
echo ""

