@echo off
chcp 65001 >nul
title OfiGremio PRO — Actualizador de Sistema Seguro
color 0A

echo =========================================================================
echo   OfiGremio PRO — Actualizador de Sistema Seguro y Migración
echo   Actualiza a la última versión SIN riesgo de perder tus datos.
echo =========================================================================
echo.

cd /d "%~dp0"

:: -------------------------------------------------------------------------
:: [1/3] Copia de Seguridad Preventiva Automática
:: -------------------------------------------------------------------------
echo [1/3] Creando copia de seguridad preventiva antes de actualizar...
if not exist "backups" mkdir "backups"

set TIMESTAMP=%date:~6,4%%date:~3,2%%date:~0,2%_%time:~0,2%%time:~3,2%%time:~6,2%
set TIMESTAMP=%TIMESTAMP: =0%

if exist "data\ofigremio.db" (
    copy "data\ofigremio.db" "backups\ofigremio_backup_%TIMESTAMP%.db" >nul
    echo   [OK] Base de datos (data\ofigremio.db) respaldada en: backups\ofigremio_backup_%TIMESTAMP%.db
) else if exist "ofigremio.db" (
    copy "ofigremio.db" "backups\ofigremio_backup_%TIMESTAMP%.db" >nul
    echo   [OK] Base de datos (ofigremio.db) respaldada en: backups\ofigremio_backup_%TIMESTAMP%.db
) else (
    echo   [AVISO] No se detecta base de datos previa en esta carpeta.
    echo   Si has extraido este paquete de actualizacion en 'Descargas', recuerda copiar
    echo   estos archivos dentro de tu carpeta habitual de OfiGremio para actualizarla.
)

:: -------------------------------------------------------------------------
:: [2/3] Verificación y Actualización de Dependencias en Entorno Virtual
:: -------------------------------------------------------------------------
echo.
echo [2/3] Comprobando dependencias y librerías...
if not exist ".venv" (
    python -m venv .venv >nul 2>&1
)

if exist ".venv\Scripts\python.exe" (
    set "PY_BIN=.venv\Scripts\python.exe"
    %PY_BIN% -m pip install -r requirements.txt --quiet >nul 2>&1
    echo   [OK] Entorno virtual (.venv) sincronizado.
) else (
    set "PY_BIN=python"
    python -m pip install -r requirements.txt --quiet >nul 2>&1
    echo   [OK] Entorno Python del sistema sincronizado.
)

:: -------------------------------------------------------------------------
:: [3/3] Migración Automática No Destructiva de Base de Datos
:: -------------------------------------------------------------------------
echo.
echo [3/3] Aplicando migraciones y nuevas capacidades (Asistente, Preferencias)...
%PY_BIN% -c "import database; database.init_db(); print('   [OK] Esquema de datos y nuevas tablas verificadas.')"

echo.
echo =========================================================================
echo   [ÉXITO] ¡OfiGremio PRO ha sido actualizado a la última versión!
echo   • Tus clientes, presupuestos, facturas y licencias siguen 100%% intactos.
echo   • Las nuevas funciones del Asistente y Memoria ya están disponibles.
echo =========================================================================
echo.
echo Puedes iniciar OfiGremio con el icono del Escritorio o ejecutando 2_ABRIR_OFIGREMIO.bat
echo.
pause
