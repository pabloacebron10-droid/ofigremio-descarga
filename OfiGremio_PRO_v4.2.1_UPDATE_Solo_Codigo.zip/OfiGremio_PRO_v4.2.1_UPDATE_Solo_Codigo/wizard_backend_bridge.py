# OfiGremio Pro v2.5 — Backend API Bridge para Onboarding Wizard
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, List, Optional
import database as db

router = APIRouter(prefix="/api/wizard", tags=["wizard"])

SECTOR_PRESETS = {
    "FONTANERIA": {
        "nombre": "Fontanería y Desatascos",
        "precio_hora": 38.0,
        "recargo_urgencia": 45.0,
        "iva_default": 0.21,
        "color_theme": "#2563eb",
        "kit_sugerido": "Kit desatasco mecánico + limpieza sifón"
    },
    "ELECTRICIDAD": {
        "nombre": "Electricidad y Boletines",
        "precio_hora": 42.0,
        "recargo_urgencia": 50.0,
        "iva_default": 0.21,
        "color_theme": "#d97706",
        "kit_sugerido": "Revisión cuadro eléctrico + diferencial 40A"
    },
    "CLIMATIZACION": {
        "nombre": "Climatización y Calderas",
        "precio_hora": 45.0,
        "recargo_urgencia": 55.0,
        "iva_default": 0.21,
        "color_theme": "#0284c7",
        "kit_sugerido": "Mantenimiento anual caldera gas + análisis combustión"
    },
    "REFORMAS": {
        "nombre": "Reformas Integrales y Albañilería",
        "precio_hora": 40.0,
        "recargo_urgencia": 60.0,
        "iva_default": 0.10,
        "color_theme": "#059669",
        "kit_sugerido": "Saneado de paramento + enfoscado maestreado"
    },
    "CERRAJERIA": {
        "nombre": "Cerrajería 24h y Seguridad",
        "precio_hora": 45.0,
        "recargo_urgencia": 60.0,
        "iva_default": 0.21,
        "color_theme": "#dc2626",
        "kit_sugerido": "Apertura puerta no bloqueada + bombín antibumping"
    },
    "PINTURA": {
        "nombre": "Pintura y Decoración",
        "precio_hora": 32.0,
        "recargo_urgencia": 40.0,
        "iva_default": 0.21,
        "color_theme": "#7c3aed",
        "kit_sugerido": "Plastecido de grietas + pintura plástica mate lavable"
    },
    "CARPINTERIA": {
        "nombre": "Carpintería y Ebanistería",
        "precio_hora": 38.0,
        "recargo_urgencia": 50.0,
        "iva_default": 0.21,
        "color_theme": "#b45309",
        "kit_sugerido": "Cepillado y ajuste puerta de paso + bisagras inox"
    },
    "ENERGIA_SOLAR": {
        "nombre": "Energía Solar y Fotovoltaica",
        "precio_hora": 44.0,
        "recargo_urgencia": 55.0,
        "iva_default": 0.21,
        "color_theme": "#ca8a04",
        "kit_sugerido": "Diagnosis inversor solar + limpieza paneles"
    },
    "TELECOMUNICACIONES": {
        "nombre": "Telecomunicaciones y Redes",
        "precio_hora": 40.0,
        "recargo_urgencia": 50.0,
        "iva_default": 0.21,
        "color_theme": "#4f46e5",
        "kit_sugerido": "Certificación punto de red Cat6 + conector RJ45"
    },
    "JARDINERIA": {
        "nombre": "Jardinería y Piscinas",
        "precio_hora": 30.0,
        "recargo_urgencia": 40.0,
        "iva_default": 0.21,
        "color_theme": "#16a34a",
        "kit_sugerido": "Puesta a punto clorador salino + filtrado arena"
    },
    "AISLAMIENTOS": {
        "nombre": "Pladur, Techos y Aislamientos",
        "precio_hora": 35.0,
        "recargo_urgencia": 45.0,
        "iva_default": 0.21,
        "color_theme": "#475569",
        "kit_sugerido": "Tabique pladur doble placa + lana de roca acústica"
    },
    "LIMPIEZA": {
        "nombre": "Limpieza y Mantenimiento Técnico",
        "precio_hora": 28.0,
        "recargo_urgencia": 35.0,
        "iva_default": 0.21,
        "color_theme": "#0d9488",
        "kit_sugerido": "Limpieza fin de obra con rotativa + abrillantado"
    },
    "OTRO": {
        "nombre": "Servicios Técnicos Especializados",
        "precio_hora": 35.0,
        "recargo_urgencia": 45.0,
        "iva_default": 0.21,
        "color_theme": "#6366f1",
        "kit_sugerido": "Intervención técnica general + desplazamiento y diagnosis"
    }
}


@router.get("/presets")
def get_wizard_presets():
    return {
        "status": "success",
        "sectors": SECTOR_PRESETS
    }


@router.get("/check-username")
def check_wizard_username(username: str = ""):
    norm = (username or "").strip().lower()
    if len(norm) < 3:
        return {"available": False, "username": norm, "reason": "El usuario debe tener al menos 3 caracteres"}
    available = db.is_username_available(norm, allow_replace_bootstrap=True)
    return {
        "available": available,
        "username": norm,
        "reason": "" if available else f"El usuario '{norm}' ya está registrado por otra cuenta o empresa"
    }


class WizardCompleteModel(BaseModel):
    empresa_nombre: str
    empresa_cif: str
    empresa_telefono: str
    empresa_email: Optional[str] = ""
    empresa_direccion: Optional[str] = ""
    empresa_poblacion: Optional[str] = ""
    empresa_iban: Optional[str] = ""
    sector: Optional[str] = "FONTANERIA"
    sector_custom_nombre: Optional[str] = ""
    color_theme: Optional[str] = "#2563eb"
    precio_hora_default: Optional[float] = 38.0
    recargo_urgencia_default: Optional[float] = 45.0
    iva_default: Optional[float] = 0.21
    irpf_default: Optional[float] = 0.0
    admin_username: Optional[str] = None
    admin_password: Optional[str] = None
    admin_nombre: Optional[str] = None


def complete_wizard(data: WizardCompleteModel):
    cfg_data = data.model_dump() if hasattr(data, 'model_dump') else data.dict()
    admin_username = cfg_data.pop("admin_username", None)
    admin_password = cfg_data.pop("admin_password", None)
    admin_nombre = cfg_data.pop("admin_nombre", None)

    created_admin = None
    auth_token = None
    if admin_username and admin_password:
        try:
            created_admin = db.setup_initial_admin_user(
                username=admin_username,
                password=admin_password,
                nombre=admin_nombre or "Administrador Principal",
                empresa_cif=cfg_data.get("empresa_cif", ""),
                empresa_nombre=cfg_data.get("empresa_nombre", "")
            )
            auth_token = db.create_auth_token(created_admin)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))

    cfg_data["primera_configuracion_pendiente"] = "0"
    if cfg_data.get("sector") == "OTRO" and cfg_data.get("sector_custom_nombre"):
        cfg_data["sector"] = cfg_data["sector_custom_nombre"]
    updated = db.update_config(cfg_data)
    result = {
        "status": "success",
        "message": "Configuración de Onboarding guardada con éxito",
        "config": updated
    }
    if created_admin and auth_token:
        result["user"] = created_admin
        result["token"] = auth_token
    return result
