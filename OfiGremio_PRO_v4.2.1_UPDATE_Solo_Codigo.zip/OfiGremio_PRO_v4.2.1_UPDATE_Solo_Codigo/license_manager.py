"""
OfiGremio PRO v4.2.1 — Módulo Central de Seguridad y Licencias por Hardware (HWID).
Protege la propiedad intelectual de la aplicación, vincula la ejecución a los
componentes físicos del equipo del cliente (Placa Base, CPU, Disco) e impide copias
no autorizadas.
"""

import os
import sys
import json
import base64
import hashlib
import hmac
import subprocess
from functools import lru_cache
from datetime import datetime
from typing import Dict, Any, Optional

# Ruta canónica del archivo de licencia
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(ROOT_DIR, "data")
LICENSE_FILE = os.path.join(DATA_DIR, "license.key")

# Secreto Maestro del Desarrollador para firma criptográfica
# (En producción binaria este secreto queda ofuscado y compilado)
MASTER_DEV_SECRET = "OFIGREMIO_PRO_MASTER_SEC_KEY_2026_EDF89A7B31094CB2"


def _run_cmd_clean(cmd: str) -> str:
    """Ejecuta un comando de consola y devuelve su salida limpia sin saltos."""
    try:
        res = subprocess.run(
            cmd,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=3.0,
            encoding="utf-8",
            errors="replace"
        )
        return (res.stdout or "").strip()
    except Exception:
        return ""


@lru_cache(maxsize=1)
def get_machine_hwid() -> str:
    """
    Calcula una huella digital única, determinista e inmutable del hardware
    físico del equipo (Placa Base, CPU y Disco del sistema).
    Formato de salida: OFG-XXXX-XXXX-XXXX-XXXX
    """
    raw_identifiers = []

    if sys.platform == "win32":
        # 1. UUID de Placa Base
        uuid_cmd = 'powershell -NoProfile -Command "(Get-CimInstance Win32_ComputerSystemProduct -ErrorAction SilentlyContinue).UUID"'
        uuid_val = _run_cmd_clean(uuid_cmd)
        if not uuid_val:
            uuid_val = _run_cmd_clean("wmic csproduct get uuid /value")
            if "=" in uuid_val:
                uuid_val = uuid_val.split("=", 1)[1].strip()
        raw_identifiers.append(uuid_val or "BASEBOARD-UNKNOWN-UUID")

        # 2. Número de Serie del Disco C:
        disk_cmd = 'powershell -NoProfile -Command "(Get-CimInstance Win32_LogicalDisk -Filter \\"DeviceID=\'C:\'\\" -ErrorAction SilentlyContinue).VolumeSerialNumber"'
        disk_val = _run_cmd_clean(disk_cmd)
        if not disk_val:
            disk_val = _run_cmd_clean('wmic logicaldisk where "DeviceID=\'C:\'" get VolumeSerialNumber /value')
            if "=" in disk_val:
                disk_val = disk_val.split("=", 1)[1].strip()
        raw_identifiers.append(disk_val or "SYS-VOL-DISK-0000")

        # 3. Identificador de CPU
        cpu_cmd = 'powershell -NoProfile -Command "(Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue).ProcessorId"'
        cpu_val = _run_cmd_clean(cpu_cmd)
        if not cpu_val:
            cpu_val = _run_cmd_clean("wmic cpu get ProcessorId /value")
            if "=" in cpu_val:
                cpu_val = cpu_val.split("=", 1)[1].strip()
        raw_identifiers.append(cpu_val or "CPU-GENERIC-ID")

    elif sys.platform == "darwin":
        # macOS: IOPlatformUUID
        raw_identifiers.append(_run_cmd_clean("ioreg -rd1 -c IOPlatformExpertDevice | awk '/IOPlatformUUID/ { print $3; }'") or "MAC-UUID")
    else:
        # Linux: /etc/machine-id
        if os.path.exists("/etc/machine-id"):
            try:
                with open("/etc/machine-id", "r") as f:
                    raw_identifiers.append(f.read().strip())
            except Exception:
                raw_identifiers.append("LINUX-DEV-MACHINE")
        else:
            raw_identifiers.append("LINUX-DEV-MACHINE")

    combined = "##".join(raw_identifiers)
    salt = "OFIGREMIO_HWID_SALT_V4_2026"
    h = hashlib.sha256(f"{salt}:{combined}".encode("utf-8")).hexdigest().upper()

    # Formatear como OFG-XXXX-XXXX-XXXX-XXXX (16 caracteres hex)
    chunk1 = h[0:4]
    chunk2 = h[4:8]
    chunk3 = h[8:12]
    chunk4 = h[12:16]
    return f"OFG-{chunk1}-{chunk2}-{chunk3}-{chunk4}"


def _sign_payload(payload: Dict[str, Any], secret: str = MASTER_DEV_SECRET) -> str:
    """Calcula firma criptográfica HMAC-SHA256 sobre los campos clave de la licencia."""
    data_str = (
        f"{payload.get('cliente', '')}|"
        f"{payload.get('cif', '')}|"
        f"{payload.get('hwid', '')}|"
        f"{payload.get('tipo', '')}|"
        f"{payload.get('expires_at', '')}|"
        f"{payload.get('updates_until', '')}|"
        f"{payload.get('issued_at', '')}"
    )
    return hmac.new(secret.encode("utf-8"), data_str.encode("utf-8"), hashlib.sha256).hexdigest()


def generate_license(
    cliente: str,
    hwid: str,
    cif: str = "B00000000",
    tipo: str = "LIFETIME",
    expires_at: str = "2099-12-31",
    updates_until: str = "2027-10-29",
    secret: str = MASTER_DEV_SECRET
) -> Dict[str, Any]:
    """Genera una licencia criptográfica firmada para un cliente y HWID específico."""
    issued_at = datetime.now().strftime("%Y-%m-%d")
    payload = {
        "cliente": cliente.strip(),
        "cif": cif.strip(),
        "hwid": hwid.strip().upper(),
        "tipo": tipo.strip().upper(),
        "expires_at": expires_at.strip(),
        "updates_until": updates_until.strip(),
        "issued_at": issued_at,
        "product": "OfiGremio PRO",
        "version_max": "4.x"
    }
    signature = _sign_payload(payload, secret)
    payload["signature"] = signature

    # Generar código de activación compacto en base64 para envío rápido por WhatsApp
    json_bytes = json.dumps(payload, separators=(',', ':')).encode("utf-8")
    raw_code = base64.b64encode(json_bytes).decode("ascii")
    payload["activation_code"] = raw_code
    return payload


def save_license_file(payload: Dict[str, Any], target_path: Optional[str] = None) -> bool:
    """Guarda el archivo de licencia en la ruta designada con codificación limpia."""
    if target_path is None:
        target_path = LICENSE_FILE
    try:
        os.makedirs(os.path.dirname(target_path), exist_ok=True)
        with open(target_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, ensure_ascii=False)
        return True
    except Exception:
        return False


def verify_license(license_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Verifica el estado de la licencia actual contra el hardware físico de esta máquina.
    Devuelve un diccionario con:
      - valid: bool
      - status: ACTIVE | UNLICENSED | HWID_MISMATCH | EXPIRED | INVALID_SIGNATURE
      - hwid: str (HWID de este ordenador)
      - message: str
      - payload: dict o None
    """
    current_hwid = get_machine_hwid()
    if license_path is None:
        license_path = LICENSE_FILE

    if not os.path.exists(license_path):
        return {
            "valid": False,
            "status": "UNLICENSED",
            "hwid": current_hwid,
            "message": "Este equipo no dispone de una licencia activa de OfiGremio PRO.",
            "payload": None
        }

    try:
        with open(license_path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read().strip()

        # Si el archivo contiene el código en base64 directamente
        if content.startswith("{"):
            payload = json.loads(content)
        else:
            decoded = base64.b64decode(content).decode("utf-8")
            payload = json.loads(decoded)
    except Exception:
        return {
            "valid": False,
            "status": "CORRUPT_LICENSE",
            "hwid": current_hwid,
            "message": "El archivo de licencia está dañado o no es válido.",
            "payload": None
        }

    # 1. Comprobar firma criptográfica
    expected_sig = _sign_payload(payload, MASTER_DEV_SECRET)
    actual_sig = payload.get("signature", "")
    if not hmac.compare_digest(expected_sig, actual_sig):
        return {
            "valid": False,
            "status": "INVALID_SIGNATURE",
            "hwid": current_hwid,
            "message": "Firma de licencia no válida o alterada.",
            "payload": payload
        }

    # 2. Comprobar Hardware ID (Candado anti-copia)
    lic_hwid = (payload.get("hwid") or "").strip().upper()
    if lic_hwid != current_hwid:
        return {
            "valid": False,
            "status": "HWID_MISMATCH",
            "hwid": current_hwid,
            "message": f"Esta licencia pertenece a otro equipo ({lic_hwid}). No está autorizada en este ordenador ({current_hwid}).",
            "payload": payload
        }

    # 3. Comprobar fecha de caducidad si aplica
    days_remaining = None
    is_subscription = payload.get("tipo") == "SUBSCRIPTION"
    expires_at_str = payload.get("expires_at", "2099-12-31")
    if expires_at_str and expires_at_str != "PERPETUA":
        try:
            exp_date = datetime.strptime(expires_at_str, "%Y-%m-%d").date()
            diff = (exp_date - datetime.now().date()).days
            days_remaining = max(0, diff)
            if datetime.now().date() > exp_date:
                return {
                    "valid": False,
                    "status": "EXPIRED",
                    "hwid": current_hwid,
                    "days_remaining": 0,
                    "is_subscription": is_subscription,
                    "expires_at": expires_at_str,
                    "message": f"El período de validez de esta licencia caducó el {expires_at_str}.",
                    "payload": payload
                }
        except Exception:
            pass

    # 4. Comprobar si la suscripción ha sido cancelada
    try:
        import database as db
        cfg_sub = db.get_config().get("subscription_status")
    except Exception:
        cfg_sub = None

    if payload.get("status") in ("CANCELLED", "CANCELADA") or (is_subscription and cfg_sub in ("CANCELLED", "CANCELADA")):
        return {
            "valid": False,
            "status": "CANCELLED",
            "is_cancelled": True,
            "hwid": current_hwid,
            "days_remaining": days_remaining or 0,
            "is_subscription": is_subscription,
            "expires_at": expires_at_str,
            "message": "Suscripción cancelada.",
            "payload": payload
        }

    return {
        "valid": True,
        "status": "ACTIVE",
        "hwid": current_hwid,
        "days_remaining": days_remaining,
        "is_subscription": is_subscription,
        "expires_at": expires_at_str,
        "message": "Licencia comercial activa y autorizada.",
        "payload": payload
    }


def cancel_subscription(target_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Cancela la suscripción activa actualizando el estado de la licencia a 'CANCELLED'
    y persistiendo el cambio en el archivo de licencia.
    """
    if target_path is None:
        target_path = LICENSE_FILE

    current_hwid = get_machine_hwid()
    payload = None
    if os.path.exists(target_path):
        try:
            with open(target_path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read().strip()
            if content.startswith("{"):
                payload = json.loads(content)
            else:
                decoded = base64.b64decode(content).decode("utf-8")
                payload = json.loads(decoded)
        except Exception:
            payload = None

    if payload is None:
        payload = generate_license(
            cliente="Suscripción Cancelada",
            hwid=current_hwid,
            tipo="SUBSCRIPTION",
            expires_at=datetime.now().strftime("%Y-%m-%d")
        )

    payload["status"] = "CANCELLED"
    save_license_file(payload, target_path)

    return {
        "success": True,
        "status": "CANCELLED",
        "message": "Suscripción cancelada correctamente",
        "payload": payload
    }


def activate_license(key_string_or_json: str, target_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Intenta activar el programa recibiendo un código en base64 o un JSON de licencia.
    Si es válida para esta máquina, guarda el archivo data/license.key.
    """
    current_hwid = get_machine_hwid()
    cleaned = key_string_or_json.strip()

    try:
        if cleaned.startswith("{"):
            payload = json.loads(cleaned)
        else:
            decoded = base64.b64decode(cleaned).decode("utf-8")
            payload = json.loads(decoded)
    except Exception:
        return {
            "success": False,
            "status": "MALFORMED_CODE",
            "message": "El código de activación introducido no tiene un formato válido."
        }

    # Validar firma
    expected_sig = _sign_payload(payload, MASTER_DEV_SECRET)
    if not hmac.compare_digest(expected_sig, payload.get("signature", "")):
        return {
            "success": False,
            "status": "INVALID_SIGNATURE",
            "message": "La clave de activación es incorrecta o ha sido modificada."
        }

    # Validar HWID
    if (payload.get("hwid") or "").strip().upper() != current_hwid:
        return {
            "success": False,
            "status": "HWID_MISMATCH",
            "message": f"Esta clave está generada para el equipo {payload.get('hwid')} y no coincide con este ordenador ({current_hwid})."
        }

    # Guardar en archivo
    saved = save_license_file(payload, target_path=target_path)
    if not saved:
        return {
            "success": False,
            "status": "SAVE_ERROR",
            "message": "No se pudo escribir el archivo de licencia en el disco."
        }

    return {
        "success": True,
        "status": "ACTIVE",
        "message": f"¡Licencia activada con éxito para {payload.get('cliente')}!",
        "payload": payload
    }


def sync_online_subscription(hwid: Optional[str] = None, relay_url: Optional[str] = None, timeout: float = 3.5) -> Dict[str, Any]:
    """
    Contacta con el relay/servidor de Stripe en la nube para auto-renovar la suscripción silenciosamente.
    Si se detecta una renovación activa válida para este equipo, actualiza data/license.key sin molestar al usuario.
    Si está offline o falla la conexión, devuelve estado OFFLINE y preserva la licencia local existente.
    """
    import urllib.request
    import urllib.error

    current_hwid = (hwid or get_machine_hwid()).strip().upper()

    if relay_url is None:
        config_file = os.path.join(DATA_DIR, "stripe_config.json")
        if os.path.exists(config_file):
            try:
                with open(config_file, "r", encoding="utf-8") as f:
                    cfg = json.load(f)
                    relay_url = cfg.get("licensing_relay_url")
            except Exception:
                pass

    if not relay_url:
        return {
            "success": False,
            "status": "NOT_CONFIGURED",
            "message": "Servidor de sincronización online no configurado."
        }

    sep = "&" if "?" in relay_url else "?"
    target_url = f"{relay_url}{sep}hwid={current_hwid}"

    try:
        req = urllib.request.Request(
            target_url,
            headers={"User-Agent": "OfiGremio-LicenseSync/4.2.1"}
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.status == 200:
                raw_body = resp.read().decode("utf-8")
                data = json.loads(raw_body)
                payload = data.get("payload") or data
                if payload and isinstance(payload, dict) and "signature" in payload:
                    # Validar firma y HWID
                    expected_sig = _sign_payload(payload, MASTER_DEV_SECRET)
                    if hmac.compare_digest(expected_sig, payload.get("signature", "")):
                        lic_hwid = (payload.get("hwid") or "").strip().upper()
                        if lic_hwid == current_hwid:
                            saved = save_license_file(payload)
                            return {
                                "success": True,
                                "status": "SYNCED",
                                "message": f"Suscripción sincronizada con éxito (+30 días para {payload.get('cliente')}).",
                                "payload": payload
                            }
                return {
                    "success": False,
                    "status": "NO_UPDATE",
                    "message": "No hay renovaciones pendientes en Stripe."
                }
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return {
                "success": False,
                "status": "NOT_FOUND",
                "message": "No hay suscripción activa registrada para este equipo en Stripe."
            }
        return {
            "success": False,
            "status": "OFFLINE",
            "message": f"Modo offline: no se pudo sincronizar online ({e})."
        }
    except Exception as e:
        return {
            "success": False,
            "status": "OFFLINE",
            "message": f"Modo offline: no se pudo sincronizar online ({e})."
        }

