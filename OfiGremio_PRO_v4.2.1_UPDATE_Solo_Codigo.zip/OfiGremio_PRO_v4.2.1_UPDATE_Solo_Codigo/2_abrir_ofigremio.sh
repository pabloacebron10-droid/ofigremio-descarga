#!/usr/bin/env bash
# =========================================================================
# OfiGremio PRO v4.2.1 — Lanzador de Uso Diario para Linux
# =========================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

if [ -f ".venv/bin/python" ]; then
    PYTHON_BIN=".venv/bin/python"
else
    PYTHON_BIN="python3"
fi

# Lanzar proceso en segundo plano que espera el arranque y abre el navegador
(
    PORT=8080
    for i in {1..30}; do
        sleep 0.4
        if [ -f "data/server_info.json" ]; then
            FILE_PORT=$(grep -o '"port": *[0-9]*' data/server_info.json | grep -o '[0-9]*' || true)
            [ -n "$FILE_PORT" ] && PORT=$FILE_PORT
        fi
        if command -v nc &>/dev/null && nc -z 127.0.0.1 "$PORT" &>/dev/null; then
            break
        fi
    done
    URL="http://localhost:$PORT"
    if command -v xdg-open &>/dev/null; then
        xdg-open "$URL" &>/dev/null &
    elif command -v sensible-browser &>/dev/null; then
        sensible-browser "$URL" &>/dev/null &
    elif command -v google-chrome &>/dev/null; then
        google-chrome "$URL" &>/dev/null &
    elif command -v firefox &>/dev/null; then
        firefox "$URL" &>/dev/null &
    fi
) &

echo "========================================================================="
echo "   OfiGremio PRO — Software Local-First para Gremios y Reformas"
echo "   [USO DIARIO] Iniciando servidor local en Linux..."
echo "   Privacidad Absoluta (0% Nube, 100% Local en tu Equipo)"
echo "========================================================================="
echo "Presione Ctrl+C en esta terminal para detener el servidor al terminar."
echo ""
exec "$PYTHON_BIN" server.py

