// OfiGremio v3.0 — Módulo Directorio Cliente 360° y Acciones Móviles en Obra

window.Client360Controller = {
    openGPS: function(direccion, poblacion) {
        const query = encodeURIComponent(`${direccion || ''} ${poblacion || ''}`.trim());
        if (!query) {
            showToast('El cliente no tiene dirección registrada', 'warning');
            return;
        }
        window.open(`https://www.google.com/maps/search/?api=1&query=${query}`, '_blank');
    },

    callPhone: function(tel) {
        if (!tel) {
            showToast('El cliente no tiene teléfono registrado', 'warning');
            return;
        }
        window.location.href = `tel:${tel}`;
    },

    chatWhatsApp: function(tel, clientId) {
        if (clientId && typeof openWhatsAppModalForClient === 'function') {
            openWhatsAppModalForClient(clientId);
            return;
        }
        if (!tel) {
            showToast('El cliente no tiene teléfono registrado', 'warning');
            return;
        }
        const clean = tel.replace(/\D/g, '');
        const full = (clean.length === 9) ? `34${clean}` : clean;
        window.open(`https://wa.me/${full}`, '_blank');
    },

    openDetailModal: async function(clientId) {
        try {
            const res = await fetch(`/api/clients`);
            if (!res.ok) return;
            const clients = await res.json();
            const c = clients.find(x => x.id === clientId);
            if (!c) return;

            // Filtrar presupuestos de este cliente
            const allQuotes = (window.state && window.state.quotes) || (typeof state !== 'undefined' ? state.quotes : []) || [];
            const clientQuotes = allQuotes.filter(q => q.cliente_id === clientId);
            const totalFacturado = clientQuotes
                .filter(q => q.estado === 'COBRADO')
                .reduce((acc, q) => acc + (q.total_factura || 0), 0);

            alert(
                `👤 FICHA CLIENTE 360°: ${c.nombre}\n\n` +
                `📞 Teléfono: ${c.telefono || '-'}\n` +
                `📍 Dirección: ${c.direccion || '-'} (${c.poblacion || '-'})
` +
                `🆔 CIF/NIF: ${c.nif_cif || '-'}\n\n` +
                `📊 Presupuestos emitidos: ${clientQuotes.length}\n` +
                `💰 Facturado y cobrado: ${totalFacturado.toFixed(2)} €`
            );
        } catch (e) {
            showToast('Error cargando ficha 360°', 'error');
        }
    }
};
