// OfiGremio Pro v4.2.1 — Wizard Paso 4: Inventario y Catálogo Personalizado
window.WizardStep4 = {
    onEnter: async function() {
        const pane = document.getElementById('wizard-step-4');
        if (!pane) return;

        const sec = window.WizardController.data.business.sector || 'FONTANERIA';

        pane.innerHTML = `
            <div style="margin-bottom:14px;">
                <h3 style="font-size:1.15rem; font-weight:700; margin-bottom:4px;">📦 Catálogo y Tarifas Personalizadas</h3>
                <p style="font-size:0.85rem; color:#64748b;">Añade tus propios materiales y precios habituales si lo deseas, o pulsa "Continuar" para empezar con un catálogo limpio.</p>
            </div>

            <div id="wiz-catalog-list" style="max-height:220px; overflow-y:auto; border:1px solid #e2e8f0; border-radius:8px; padding:10px; margin-bottom:14px; background:#ffffff;">
                <div style="text-align:center; padding:16px; color:#64748b;">Consultando catálogo...</div>
            </div>

            <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:10px;">
                <div style="font-size:0.8rem; font-weight:700; margin-bottom:6px;">+ Añadir tu Partida Personalizada</div>
                <div style="display:grid; grid-template-columns:1fr 120px auto; gap:8px;">
                    <input type="text" id="wiz-new-mat-desc" placeholder="Ej. Cambio de llave de corte / Tarifa hora" style="padding:8px; border-radius:6px; border:1px solid #cbd5e1; font-size:0.85rem;">
                    <div style="display:flex; align-items:center; background:#ffffff; border:1px solid #cbd5e1; border-radius:6px; padding-right:8px;">
                        <input type="number" id="wiz-new-mat-pu" placeholder="Precio" value="38" style="padding:8px; border:none; border-radius:6px; font-size:0.85rem; width:100%; text-align:right;">
                        <span style="font-size:0.85rem; font-weight:700; color:#64748b; margin-left:4px;">€</span>
                    </div>
                    <button type="button" class="btn btn-secondary" onclick="WizardStep4.addCustomPartida()" style="font-size:0.8rem;">+ Añadir</button>
                </div>
            </div>
        `;

        this.loadSectorCatalog(sec);
    },

    loadSectorCatalog: async function(sector) {
        const container = document.getElementById('wiz-catalog-list');
        if (!container) return;

        try {
            const res = await fetch(`/api/catalog?gremio=${sector}`);
            const items = await res.json();
            if (!Array.isArray(items) || items.length === 0) {
                // Catálogo limpio por defecto sin sugerencias genéricas
                container.innerHTML = `
                    <div style="text-align:center; padding:24px 12px; color:#64748b; font-size:0.9rem;">
                        <div style="font-size:1.3rem; margin-bottom:6px;">✨</div>
                        <b>Tu catálogo está completamente limpio.</b><br>
                        <span style="font-size:0.8rem; color:#94a3b8;">No se añadirán piezas ni herramientas genéricas. Puedes registrar tus materiales arriba o crearlos según presupuestes en tu día a día.</span>
                    </div>
                `;
                return;
            }

            container.innerHTML = items.map(it => `
                <div style="display:flex; justify-content:space-between; align-items:center; padding:8px 6px; border-bottom:1px solid #f1f5f9;">
                    <label style="display:flex; align-items:center; gap:8px; font-size:0.85rem; cursor:pointer; flex:1;">
                        <input type="checkbox" class="wiz-item-chk" data-id="${it.id}" data-desc="${it.descripcion}" checked>
                        <span>${it.descripcion}</span>
                    </label>
                    <div style="display:flex; align-items:center; gap:4px;">
                        <input type="number" class="wiz-item-pu" data-id="${it.id}" value="${it.precio_unitario}" style="width:70px; padding:4px 6px; border:1px solid #cbd5e1; border-radius:4px; text-align:right; font-size:0.85rem;">
                        <span style="font-size:0.8rem; color:#64748b;">€</span>
                    </div>
                </div>
            `).join('');
        } catch (e) {
            container.innerHTML = '<div style="color:red; text-align:center; padding:10px;">Error al consultar catálogo</div>';
        }
    },

    addCustomPartida: async function() {
        const desc = document.getElementById('wiz-new-mat-desc')?.value.trim();
        const pu = parseFloat(document.getElementById('wiz-new-mat-pu')?.value) || 0;
        const sec = window.WizardController.data.business.sector || 'FONTANERIA';

        if (!desc) {
            showToast('Escribe una descripción para la partida', 'warning');
            return;
        }

        try {
            const res = await fetch('/api/catalog', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    gremio: sec,
                    tipo: 'MATERIAL',
                    descripcion: desc,
                    cantidad_default: 1.0,
                    precio_unitario: pu,
                    stock_actual: 0.0,
                    stock_minimo_alerta: 0.0
                })
            });
            if (res.ok) {
                showToast(`Partida '${desc}' añadida`, 'success');
                document.getElementById('wiz-new-mat-desc').value = '';
                this.loadSectorCatalog(sec);
            }
        } catch (e) {
            showToast('Error al añadir partida', 'error');
        }
    },

    validate: async function() {
        const selected = [];
        const chks = Array.from(document.querySelectorAll('.wiz-item-chk:checked'));
        for (const chk of chks) {
            const id = chk.dataset.id;
            const desc = chk.dataset.desc;
            const puInput = document.querySelector(`.wiz-item-pu[data-id="${id}"]`);
            const pu = parseFloat(puInput?.value) || 0;
            selected.push({ id, descripcion: desc, precio_unitario: pu });
        }

        window.WizardController.data.inventory = selected;
        return true;
    }
};
