// OfiGremio Pro v4.2.1 — Wizard Paso 1: Negocio y Actividad Personalizada
window.WizardStep1 = {
    // Definiciones de compatibilidad interna
    sectors: [
        { id: 'GENERAL', name: 'Servicios Técnicos y Reformas', icon: '🛠️', color: '#2563eb', rate: 38, urg: 45 },
        { id: 'FONTANERIA', name: 'Fontanería', icon: '🚰', color: '#2563eb', rate: 38, urg: 45 },
        { id: 'ELECTRICIDAD', name: 'Electricidad', icon: '⚡', color: '#d97706', rate: 42, urg: 50 },
        { id: 'CLIMATIZACION', name: 'Climatización', icon: '❄️', color: '#0284c7', rate: 45, urg: 55 },
        { id: 'REFORMAS', name: 'Reformas', icon: '🔨', color: '#059669', rate: 40, urg: 60 }
    ],

    onEnter: function() {
        this.init();
    },

    setActivity: function(text) {
        const input = document.getElementById('wiz-business-activity');
        if (input) {
            input.value = text;
            input.focus();
        }
        if (window.WizardController?.data?.business) {
            window.WizardController.data.business.sector = text;
            window.WizardController.data.business.sector_custom_nombre = text;
        }
    },

    init: function() {
        const pane = document.getElementById('wizard-step-1');
        if (!pane) return;

        const b = window.WizardController?.data?.business || {};
        const adm = window.WizardController?.data?.admin || {};
        const currUser = window.state?.currentUser;
        const esc = (v) => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
        const defaultAdminUser = esc(adm.username || (currUser && currUser.username !== 'admin' ? currUser.username : ''));
        const defaultAdminNombre = esc(adm.nombre || (currUser ? currUser.nombre : 'Administrador Principal'));
        const currentActivity = esc(b.sector_custom_nombre || b.sector || 'Servicios Técnicos e Instalaciones');
        const defaultRate = b.precio_hora_default || 38;
        const defaultColor = b.color_theme || '#2563eb';

        pane.innerHTML = `
            <style>
                .btn-chip {
                    background: #f1f5f9;
                    border: 1px solid #cbd5e1;
                    border-radius: 999px;
                    padding: 3px 10px;
                    font-size: 0.73rem;
                    cursor: pointer;
                    color: #334155;
                    transition: all 0.15s ease;
                }
                .btn-chip:hover {
                    background: #e2e8f0;
                    border-color: #94a3b8;
                    color: #0f172a;
                }
            </style>
            <div style="background:linear-gradient(135deg, #eff6ff 0%, #f8fafc 100%); border:1px solid #bfdbfe; border-radius:10px; padding:12px 14px; margin-bottom:14px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px; flex-wrap:wrap; gap:6px;">
                    <h4 style="margin:0; font-size:0.95rem; font-weight:800; color:#1e3a8a;">🔐 1. Cuenta de Administrador Principal de tu Empresa</h4>
                    <span style="font-size:0.72rem; background:#dbeafe; color:#1d4ed8; padding:2px 8px; border-radius:999px; font-weight:700;">Rol: ADMIN (Control Total)</span>
                </div>
                <p style="font-size:0.78rem; color:#475569; margin:0 0 10px 0;">
                    Crea tu usuario único de Administrador. Quedará vinculado automáticamente a tu empresa y con él podrás gestionar usuarios y permisos.
                </p>
                <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:8px;">
                    <div>
                        <label style="font-size:0.76rem; font-weight:700; display:block; margin-bottom:3px; color:#1e293b;">Usuario Único (Login) *</label>
                        <input type="text" id="wiz-admin-username" value="${defaultAdminUser}" placeholder="Ej. admin_ramos" oninput="WizardStep1.checkUsernameLive(this.value)" style="width:100%; padding:8px; border-radius:6px; border:1px solid #93c5fd; font-size:0.85rem; background:#fff;">
                        <div id="wiz-username-status" style="font-size:0.72rem; margin-top:3px; color:#64748b;">Mín. 3 caracteres sin espacios</div>
                    </div>
                    <div>
                        <label style="font-size:0.76rem; font-weight:700; display:block; margin-bottom:3px; color:#1e293b;">Contraseña Admin *</label>
                        <div style="position:relative; display:flex; align-items:center;">
                            <input type="password" id="wiz-admin-password" value="${adm.password || ''}" placeholder="Mínimo 6 caracteres" style="width:100%; padding:8px 32px 8px 8px; border-radius:6px; border:1px solid #93c5fd; font-size:0.85rem; background:#fff;">
                            <button type="button" onclick="WizardStep1.toggleAdminPw()" title="Mostrar / Ocultar" style="position:absolute; right:6px; background:none; border:none; cursor:pointer; font-size:0.85rem;">👁️</button>
                        </div>
                    </div>
                    <div>
                        <label style="font-size:0.76rem; font-weight:700; display:block; margin-bottom:3px; color:#1e293b;">Tu Nombre / Cargo *</label>
                        <input type="text" id="wiz-admin-nombre" value="${defaultAdminNombre}" placeholder="Ej. Pablo (Gerente)" style="width:100%; padding:8px; border-radius:6px; border:1px solid #93c5fd; font-size:0.85rem; background:#fff;">
                    </div>
                </div>
            </div>

            <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:14px; margin-bottom:14px;">
                <div style="margin-bottom:10px;">
                    <h3 style="font-size:1.05rem; font-weight:700; margin-bottom:2px; color:#0f172a;">🛠️ 2. ¿En qué consiste tu negocio o actividad principal?</h3>
                    <p style="font-size:0.8rem; color:#64748b; margin:0;">Personaliza tu actividad libremente en lugar de elegir gremios cerrados.</p>
                </div>

                <div style="margin-bottom:10px;">
                    <label style="font-size:0.8rem; font-weight:700; display:block; margin-bottom:4px; color:#1e293b;">Actividad / Especialidad de tu Negocio *</label>
                    <input type="text" id="wiz-business-activity" list="activity-suggestions" value="${currentActivity}" placeholder="Ej. Climatización y Aerotermia, Reformas de Cocinas y Baños, Electricidad Industrial..." style="width:100%; padding:9px 12px; border-radius:8px; border:1px solid #94a3b8; font-size:0.9rem; background:#fff; font-weight:600; box-sizing:border-box;">
                    <datalist id="activity-suggestions">
                        <option value="Climatización, Aerotermia y Calefacción">
                        <option value="Reformas Integrales de Viviendas y Baños">
                        <option value="Instalaciones Eléctricas y Telecomunicaciones">
                        <option value="Fontanería, Gas y Calefacción">
                        <option value="Cerrajería y Seguridad Técnica 24h">
                        <option value="Pintura, Alta Decoración y Pladur">
                        <option value="Carpintería y Muebles a Medida">
                        <option value="Energía Solar Fotovoltaica y Baterías">
                        <option value="Mantenimiento Integral de Edificios y Locales">
                    </datalist>
                    <div style="display:flex; gap:6px; flex-wrap:wrap; margin-top:8px; align-items:center;">
                        <span style="font-size:0.73rem; color:#64748b; font-weight:600;">Sugerencias rápidas:</span>
                        <button type="button" class="btn-chip" onclick="WizardStep1.setActivity('Climatización y Frío')">❄️ Climatización</button>
                        <button type="button" class="btn-chip" onclick="WizardStep1.setActivity('Reformas Integrales')">🔨 Reformas</button>
                        <button type="button" class="btn-chip" onclick="WizardStep1.setActivity('Electricidad e Iluminación')">⚡ Electricidad</button>
                        <button type="button" class="btn-chip" onclick="WizardStep1.setActivity('Fontanería y Calefacción')">🚰 Fontanería</button>
                        <button type="button" class="btn-chip" onclick="WizardStep1.setActivity('Mantenimiento y Servicios')">🛠️ Servicios Técnicos</button>
                    </div>
                </div>

                <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-top:12px;">
                    <div>
                        <label style="font-size:0.78rem; font-weight:700; display:block; margin-bottom:3px; color:#1e293b;">Tarifa Hora Estándar (€/h)</label>
                        <div style="display:flex; align-items:center; background:#ffffff; border:1px solid #cbd5e1; border-radius:6px; padding-right:8px;">
                            <input type="number" id="wiz-custom-sec-rate" value="${defaultRate}" placeholder="38" style="padding:8px; border:none; border-radius:6px; font-size:0.85rem; width:100%; text-align:right;">
                            <span style="font-size:0.8rem; font-weight:700; color:#64748b; margin-left:4px;">€/h</span>
                        </div>
                    </div>
                    <div>
                        <label style="font-size:0.78rem; font-weight:700; display:block; margin-bottom:3px; color:#1e293b;">Color de Marca para Presupuestos</label>
                        <select id="wiz-custom-sec-color" onchange="WizardStep1.changeCustomColor(this.value)" style="width:100%; padding:8px; border-radius:6px; border:1px solid #cbd5e1; font-size:0.85rem; background:#fff;">
                            <option value="#2563eb" ${defaultColor === '#2563eb' ? 'selected' : ''}>Azul Profesional</option>
                            <option value="#059669" ${defaultColor === '#059669' ? 'selected' : ''}>Verde Sostenible</option>
                            <option value="#d97706" ${defaultColor === '#d97706' ? 'selected' : ''}>Ámbar Energía</option>
                            <option value="#dc2626" ${defaultColor === '#dc2626' ? 'selected' : ''}>Rojo Cerrajería / Seguridad</option>
                            <option value="#7c3aed" ${defaultColor === '#7c3aed' ? 'selected' : ''}>Violeta Creativo</option>
                            <option value="#0284c7" ${defaultColor === '#0284c7' ? 'selected' : ''}>Cian Climatización</option>
                        </select>
                    </div>
                </div>
            </div>

            <div style="display:flex; flex-direction:column; gap:8px;">
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                    <div>
                        <label style="font-size:0.8rem; font-weight:600; display:block; margin-bottom:3px;">Nombre Comercial / Empresa o Autónomo *</label>
                        <input type="text" id="wiz-empresa" value="${esc(b.empresa_nombre || 'Mi Empresa de Servicios Técnicos')}" placeholder="Ej. Instalaciones Ramos S.L." style="width:100%; padding:8px; border-radius:8px; border:1px solid #cbd5e1; font-size:0.88rem; box-sizing:border-box;">
                    </div>
                    <div>
                        <label style="font-size:0.8rem; font-weight:600; display:block; margin-bottom:3px;">Correo Electrónico de la Empresa *</label>
                        <input type="email" id="wiz-email" value="${esc(b.empresa_email || 'contacto@miempresa.es')}" placeholder="Ej. administracion@tuempresa.es" style="width:100%; padding:8px; border-radius:8px; border:1px solid #cbd5e1; font-size:0.88rem; box-sizing:border-box;">
                    </div>
                </div>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                    <div>
                        <label style="font-size:0.8rem; font-weight:600; display:block; margin-bottom:3px;">NIF / CIF de la Empresa *</label>
                        <input type="text" id="wiz-cif" value="${esc(b.empresa_cif || 'B-12345678')}" placeholder="Ej. B-88776655" style="width:100%; padding:8px; border-radius:8px; border:1px solid #cbd5e1; font-size:0.88rem; box-sizing:border-box;">
                    </div>
                    <div>
                        <label style="font-size:0.8rem; font-weight:600; display:block; margin-bottom:3px;">Teléfono WhatsApp *</label>
                        <input type="tel" id="wiz-telefono" value="${esc(b.empresa_telefono || '600123456')}" placeholder="Ej. 612 345 678" style="width:100%; padding:8px; border-radius:8px; border:1px solid #cbd5e1; font-size:0.88rem; box-sizing:border-box;">
                    </div>
                </div>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                    <div>
                        <label style="font-size:0.8rem; font-weight:600; display:block; margin-bottom:3px;">Ciudad / Población</label>
                        <input type="text" id="wiz-poblacion" value="${esc(b.empresa_poblacion || 'Madrid')}" placeholder="Ej. Madrid" style="width:100%; padding:8px; border-radius:8px; border:1px solid #cbd5e1; font-size:0.88rem; box-sizing:border-box;">
                    </div>
                    <div>
                        <label style="font-size:0.8rem; font-weight:600; display:block; margin-bottom:3px;">Dirección Fiscal</label>
                        <input type="text" id="wiz-direccion" value="${esc(b.empresa_direccion || '')}" placeholder="Ej. C/ Mayor 12" style="width:100%; padding:8px; border-radius:8px; border:1px solid #cbd5e1; font-size:0.88rem; box-sizing:border-box;">
                    </div>
                </div>
            </div>
        `;
    },

    toggleAdminPw: function() {
        const inp = document.getElementById('wiz-admin-password');
        if (!inp) return;
        inp.type = inp.type === 'password' ? 'text' : 'password';
    },

    checkUsernameLive: async function(val) {
        const statusEl = document.getElementById('wiz-username-status');
        if (!statusEl) return;
        const norm = (val || '').trim().toLowerCase();
        if (norm.length < 3) {
            statusEl.style.color = '#64748b';
            statusEl.textContent = 'Mín. 3 caracteres sin espacios';
            return;
        }
        const curr = window.state?.currentUser?.username || '';
        if (curr && curr.trim().toLowerCase() === norm) {
            statusEl.style.color = '#10b981';
            statusEl.textContent = `✓ Tu usuario actual ('${norm}')`;
            return;
        }
        try {
            const res = await fetch(`/api/wizard/check-username?username=${encodeURIComponent(norm)}`);
            if (res.ok) {
                const data = await res.json();
                if (data.available) {
                    statusEl.style.color = '#10b981';
                    statusEl.textContent = `✓ '${data.username}' disponible y único`;
                } else {
                    statusEl.style.color = '#ef4444';
                    statusEl.textContent = `⚠️ ${data.reason || 'Usuario no disponible'}`;
                }
            }
        } catch (_) {}
    },

    selectSector: function(secId) {
        // Compatibilidad para inicializaciones existentes
        if (window.WizardController?.data?.business) {
            window.WizardController.data.business.sector = secId;
        }
    },

    changeCustomColor: function(color) {
        if (window.WizardController) {
            window.WizardController.data.business.color_theme = color;
            document.documentElement.style.setProperty('--primary-color', color);
        }
    },

    validate: async function() {
        const emp = document.getElementById('wiz-empresa')?.value.trim() || 'Mi Empresa de Servicios';
        const cif = document.getElementById('wiz-cif')?.value.trim() || 'B-12345678';
        const tel = document.getElementById('wiz-telefono')?.value.trim() || '600123456';
        const email = document.getElementById('wiz-email')?.value.trim() || '';
        const dir = document.getElementById('wiz-direccion')?.value.trim() || '';
        const pob = document.getElementById('wiz-poblacion')?.value.trim() || 'Madrid';

        const activity = document.getElementById('wiz-business-activity')?.value.trim() || 'Servicios Técnicos e Instalaciones';
        const rate = parseFloat(document.getElementById('wiz-custom-sec-rate')?.value) || 38.0;
        const color = document.getElementById('wiz-custom-sec-color')?.value || '#2563eb';

        const adminUser = (document.getElementById('wiz-admin-username')?.value || '').trim().toLowerCase();
        const adminPass = document.getElementById('wiz-admin-password')?.value || '';
        const adminNom = (document.getElementById('wiz-admin-nombre')?.value || '').trim() || 'Administrador Principal';

        const isInitial = Boolean(window.WizardController?.isInitialSetup) && !window.state?.currentUser;

        if (isInitial || (adminPass && adminPass.length > 0)) {
            if (!adminUser || adminUser.length < 3 || /\s/.test(adminUser)) {
                if (typeof showToast === 'function') showToast('⚠️ Introduce un Usuario Administrador válido (mín. 3 caracteres, sin espacios)', 'error');
                document.getElementById('wiz-admin-username')?.focus();
                return false;
            }
            if (!adminPass || adminPass.length < 6) {
                if (typeof showToast === 'function') showToast('⚠️ La contraseña del Administrador debe tener al menos 6 caracteres', 'error');
                document.getElementById('wiz-admin-password')?.focus();
                return false;
            }
            try {
                const res = await fetch('/api/auth/bootstrap-admin', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        username: adminUser,
                        password: adminPass,
                        nombre: adminNom,
                        empresa_nombre: emp,
                        empresa_cif: cif
                    })
                });
                const data = await res.json().catch(() => ({}));
                if (!res.ok) {
                    if (typeof showToast === 'function') showToast(`❌ ${data.detail || 'Error al registrar Administrador'}`, 'error');
                    return false;
                }
                if (data.token) {
                    localStorage.setItem('ofigremio_token', data.token);
                    localStorage.setItem('ofigremio_auth_token', data.token);
                }
                if (data.user) {
                    if (window.state) window.state.currentUser = data.user;
                    document.body.classList.remove('auth-locked');
                    if (typeof applyRoleUI === 'function') applyRoleUI(data.user);
                }
                if (window.WizardController?.data) {
                    window.WizardController.data.admin = {
                        username: adminUser,
                        password: adminPass,
                        nombre: adminNom
                    };
                }
            } catch (e) {
                if (typeof showToast === 'function') showToast('❌ Error de red al crear el usuario Administrador', 'error');
                return false;
            }
        }

        window.WizardController.data.business.sector = activity;
        window.WizardController.data.business.sector_custom_nombre = activity;
        window.WizardController.data.business.precio_hora_default = rate;
        window.WizardController.data.business.recargo_urgencia_default = Math.round(rate * 1.25);
        window.WizardController.data.business.color_theme = color;
        document.documentElement.style.setProperty('--primary-color', color);

        window.WizardController.data.business.empresa_nombre = emp;
        window.WizardController.data.business.empresa_cif = cif;
        window.WizardController.data.business.empresa_telefono = tel;
        window.WizardController.data.business.empresa_email = email;
        window.WizardController.data.business.empresa_poblacion = pob;
        window.WizardController.data.business.empresa_direccion = dir;

        // Persistir inmediatamente los campos de negocio en SQLite vía POST /api/config
        try {
            const configPayload = {
                empresa_nombre: emp,
                empresa_cif: cif,
                empresa_telefono: tel,
                empresa_email: email,
                empresa_direccion: dir,
                empresa_poblacion: pob,
                sector: activity,
                sector_custom_nombre: activity,
                color_theme: color,
                precio_hora_default: rate,
                recargo_urgencia_default: Math.round(rate * 1.25)
            };
            await fetch('/api/config', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(configPayload)
            });
            if (window.state?.config) {
                Object.assign(window.state.config, configPayload);
            }
        } catch (e) {
            console.warn('[WizardStep1] Aviso al persistir configuración de negocio:', e);
        }

        return true;
    }
};

document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => { if (window.WizardStep1) window.WizardStep1.init(); }, 250);
});
