// Service Worker para OfiGremio PRO v3.7.1
// Proporciona experiencia PWA fluida, actualización inmediata (Network-First) y tolerancia a microcortes de red.

const CACHE_NAME = 'ofigremio-cache-v3.7.2';
const STATIC_ASSETS = [
    '/',
    '/static/index.html',
    '/static/styles.css',
    '/static/app.js',
    '/static/manifest.json',
    '/static/wizard.css',
    '/static/wizard_shell.js',
    '/static/wizard_step1_business.js',
    '/static/wizard_step2_payment.js',
    '/static/wizard_step3_client.js',
    '/static/wizard_step4_inventory.js',
    '/static/wizard_step5_tour.js',
    '/static/customer_view.js',
    '/static/omnichannel_share.js',
    '/static/client_360.js',
    '/static/omnibox_search.js',
    '/static/icon-192.png',
    '/static/icon-512.png'
];

self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => {
            return cache.addAll(STATIC_ASSETS).catch((err) => {
                console.warn('SW pre-cache warning:', err);
            });
        })
    );
    self.skipWaiting();
});

self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((keys) => {
            return Promise.all(
                keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
            );
        })
    );
    self.clients.claim();
});

self.addEventListener('fetch', (event) => {
    const request = event.request;
    // Peticiones de API o mutantes van directo a la red (Online-First)
    if (request.url.includes('/api/') || request.method !== 'GET') {
        event.respondWith(
            fetch(request).catch(() => {
                return new Response(
                    JSON.stringify({ detail: 'Sin conexión a internet momentáneamente. Reintentando...' }),
                    { headers: { 'Content-Type': 'application/json' }, status: 503 }
                );
            })
        );
        return;
    }

    // Para activos estáticos: Network-First con respaldo en caché para no servir código obsoleto
    event.respondWith(
        fetch(request)
            .then((networkResponse) => {
                if (networkResponse && networkResponse.status === 200) {
                    const responseClone = networkResponse.clone();
                    caches.open(CACHE_NAME).then((cache) => {
                        cache.put(request, responseClone);
                    });
                }
                return networkResponse;
            })
            .catch(() => caches.match(request))
    );
});
