// OfiGremio v3.0 — Módulo de Vista Cliente Editorial y Firma Digital Interactiva

window.CustomerViewController = {
    currentQuote: null,

    open: async function(quoteId) {
        try {
            const res = await fetch(`/api/quotes/${quoteId}`);
            if (!res.ok) throw new Error('No se pudo cargar el presupuesto');
            const q = await res.json();
            this.currentQuote = q;

            const modal = document.getElementById('modal-customer-view');
            if (!modal) {
                this._createModalDOM();
            }
            this._renderContent(q);
            document.getElementById('modal-customer-view').classList.add('active');
            
            // Inicializar canvas de firma si no está firmado
            const hasSig = q.firma_base64 && q.firma_base64.trim().length > 20;
            if (!hasSig) {
                setTimeout(() => {
                    initSignaturePad('customer-view-sig-canvas', () => {});
                }, 80);
            }
        } catch (err) {
            showToast('Error cargando Vista Cliente: ' + err.message, 'error');
        }
    },

    close: function() {
        const modal = document.getElementById('modal-customer-view');
        if (modal) modal.classList.remove('active');
    },

    saveSignature: async function() {
        if (!this.currentQuote) return;
        const canvas = document.getElementById('customer-view-sig-canvas');
        if (!canvas) return;
        const b64 = canvas.toDataURL('image/png');
        if (b64.length < 500) {
            showToast('Por favor, dibuje la firma del cliente antes de aceptar', 'warning');
            return;
        }

        try {
            const res = await fetch(`/api/quotes/${this.currentQuote.id}/signature`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ firma_base64: b64, aprobar: true })
            });
            if (!res.ok) throw new Error('Error al registrar firma');
            showToast('✅ Presupuesto aprobado y firmado por el cliente', 'success');
            this.close();
            if (typeof loadQuotes === 'function') loadQuotes();
            if (typeof loadAnalytics === 'function') loadAnalytics();
        } catch (e) {
            showToast('Error guardando firma: ' + e.message, 'error');
        }
    },

    _createModalDOM: function() {
        const div = document.createElement('div');
        div.id = 'modal-customer-view';
        div.className = 'modal-backdrop';
        div.innerHTML = `
            <div class="modal-card modal-lg" style="max-width:760px; max-height:92vh; display:flex; flex-direction:column; padding:0; overflow:hidden; border-radius:14px;">
                <div class="modal-header" style="background:var(--bg-subtle); padding:16px 24px; border-bottom:1px solid var(--border);">
                    <div style="display:flex; align-items:center; gap:10px;">
                        <span style="font-size:1.4rem;">👁️</span>
                        <div>
                            <h3 style="margin:0; font-size:1.15rem; font-weight:800;">Vista Formal del Cliente</h3>
                            <p style="margin:0; font-size:0.78rem; color:var(--text-muted);">Así visualiza y aprueba el cliente su presupuesto oficial</p>
                        </div>
                    </div>
                    <button class="btn-close" onclick="CustomerViewController.close()">&times;</button>
                </div>
                <div id="customer-view-body" style="padding:24px; overflow-y:auto; flex:1; background:var(--bg-card);">
                    <!-- Contenido dinámico -->
                </div>
                <div id="customer-view-footer" style="padding:14px 24px; background:var(--bg-subtle); border-top:1px solid var(--border); display:flex; justify-content:space-between; align-items:center;">
                    <!-- Botones de acción rápida -->
                </div>
            </div>
        `;
        document.body.appendChild(div);
    },

    _renderContent: function(q) {
        const body = document.getElementById('customer-view-body');
        const footer = document.getElementById('customer-view-footer');
        const cfg = (window.state && window.state.config) || (typeof state !== 'undefined' ? state.config : {});
        const hasSig = q.firma_base64 && q.firma_base64.trim().length > 20;

        const itemsList = q.partidas || q.items || [];
        const itemsRows = itemsList.map((it, idx) => `
            <tr style="border-bottom:1px solid var(--border);">
                <td style="padding:10px 8px; font-weight:600;">${it.descripcion}</td>
                <td style="padding:10px 8px; text-align:center;">${it.cantidad}</td>
                <td style="padding:10px 8px; text-align:right;">${(it.precio_unitario || 0).toFixed(2)} €</td>
                <td style="padding:10px 8px; text-align:right; font-weight:700;">${((it.cantidad || 1) * (it.precio_unitario || 0)).toFixed(2)} €</td>
            </tr>
        `).join('');

        const ibanFormatted = (cfg.empresa_iban || '').replace(/(.{4})/g, '$1 ').trim();

        body.innerHTML = `
            <!-- Cabecera Empresa y Cliente -->
            <div style="display:flex; justify-content:space-between; flex-wrap:wrap; gap:16px; margin-bottom:20px; padding-bottom:16px; border-bottom:1px solid var(--border);">
                <div>
                    <h2 style="font-size:1.3rem; font-weight:800; color:var(--primary);">${cfg.empresa_nombre || 'Servicio Técnico Especializado'}</h2>
                    <div style="font-size:0.84rem; color:var(--text-muted); line-height:1.4;">
                        CIF: <b>${cfg.empresa_cif || '-'}</b> · Tel: <b>${cfg.empresa_telefono || '-'}</b><br>
                        ${cfg.empresa_direccion || ''} (${cfg.empresa_poblacion || ''})
                    </div>
                </div>
                <div style="text-align:right;">
                    <div style="font-size:1.15rem; font-weight:800;">PRESUPUESTO ${q.numero}</div>
                    <div style="font-size:0.82rem; color:var(--text-muted);">Fecha: ${q.fecha || '-'}</div>
                    <span class="badge-status status-${q.estado}" style="display:inline-block; margin-top:6px;">${q.estado}</span>
                </div>
            </div>

            <!-- Datos del Cliente e Intervención -->
            <div style="background:var(--bg-subtle); padding:14px; border-radius:10px; margin-bottom:20px; font-size:0.88rem;">
                <div style="font-weight:700; margin-bottom:4px;">👤 Destinatario: ${q.cliente_nombre} ${q.cliente_nif_cif ? '(' + q.cliente_nif_cif + ')' : ''}</div>
                <div style="color:var(--text-muted);">📍 Intervención en: ${q.cliente_direccion || 'A domicilio'} (${q.cliente_poblacion || ''})</div>
                <div style="margin-top:6px; font-weight:600;">🔧 Concepto: ${q.concepto_averia}</div>
            </div>

            <!-- Tabla de Partidas -->
            <table style="width:100%; border-collapse:collapse; margin-bottom:20px; font-size:0.88rem;">
                <thead>
                    <tr style="background:var(--bg-subtle); border-bottom:2px solid var(--border); text-align:left;">
                        <th style="padding:10px 8px;">Concepto / Material</th>
                        <th style="padding:10px 8px; text-align:center;">Cant.</th>
                        <th style="padding:10px 8px; text-align:right;">Precio</th>
                        <th style="padding:10px 8px; text-align:right;">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <tr style="border-bottom:1px solid var(--border);">
                        <td style="padding:10px 8px; font-weight:600;">Mano de Obra Especializada y Desplazamiento</td>
                        <td style="padding:10px 8px; text-align:center;">${q.horas_mano_obra} h</td>
                        <td style="padding:10px 8px; text-align:right;">${(q.precio_hora || 0).toFixed(2)} €</td>
                        <td style="padding:10px 8px; text-align:right; font-weight:700;">${((q.horas_mano_obra || 1) * (q.precio_hora || 0)).toFixed(2)} €</td>
                    </tr>
                    ${itemsRows}
                </tbody>
            </table>

            <!-- Resumen Financiero y Medios de Pago -->
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:20px;">
                <div style="background:var(--bg-subtle); padding:14px; border-radius:10px; font-size:0.84rem;">
                    <div style="font-weight:700; margin-bottom:6px;">💳 Formas de Pago Aceptadas:</div>
                    ${cfg.empresa_telefono ? `<div style="margin-bottom:4px;">📱 <b>Bizum al instante:</b> <span style="font-family:monospace; background:var(--bg-card); padding:2px 6px; border-radius:4px;">${cfg.empresa_telefono}</span></div>` : ''}
                    ${ibanFormatted ? `<div>🏦 <b>Transferencia Bancaria:</b><br><span style="font-family:monospace; font-size:0.8rem; background:var(--bg-card); padding:2px 6px; border-radius:4px; display:inline-block; margin-top:3px;">${ibanFormatted}</span></div>` : ''}
                    <div style="margin-top:8px; font-size:0.78rem; color:var(--text-muted);">🛡️ Garantía oficial de la intervención: <b>${q.garantia_meses || 6} meses</b>.</div>
                </div>
                <div style="background:var(--bg-subtle); padding:14px; border-radius:10px; font-size:0.88rem; display:flex; flex-direction:column; justify-content:center; gap:6px;">
                    <div style="display:flex; justify-content:space-between;"><span>Base Imponible:</span><b>${(q.base_imponible || 0).toFixed(2)} €</b></div>
                    <div style="display:flex; justify-content:space-between;"><span>IVA (${Math.round((((q.iva_porcentaje > 1 ? q.iva_porcentaje / 100 : q.iva_porcentaje) ?? 0.21) * 100))}%):</span><b>+${(q.total_iva || 0).toFixed(2)} €</b></div>
                    <div style="display:flex; justify-content:space-between;"><span>Retención IRPF (${Math.round((((q.irpf_porcentaje > 1 ? q.irpf_porcentaje / 100 : q.irpf_porcentaje) ?? 0) * 100))}%):</span><b>${(q.total_irpf || 0) > 0 ? `-${(q.total_irpf).toFixed(2)} €` : '0.00 €'}</b></div>
                    ${(q.total_descuento || 0) > 0 ? `<div style="display:flex; justify-content:space-between; color:var(--success);"><span>Descuento (${q.descuento_porcentaje || 0}%):</span><b>-${(q.total_descuento).toFixed(2)} €</b></div>` : ''}
                    <div style="border-top:2px solid var(--border); padding-top:6px; display:flex; justify-content:space-between; font-size:1.15rem; font-weight:800; color:var(--primary);">
                        <span>TOTAL OFICIAL:</span><span>${(q.total_factura || 0).toFixed(2)} €</span>
                    </div>
                </div>
            </div>

            <!-- Bloque de Firma Digital -->
            <div style="border:1px dashed var(--border); border-radius:10px; padding:16px; text-align:center;">
                <div style="font-weight:700; margin-bottom:8px;">✍️ Aceptación y Firma Digital del Cliente</div>
                ${hasSig ? `
                    <div style="color:var(--success); font-weight:700; margin-bottom:8px;">✅ Documento formalmente firmado y aceptado</div>
                    <img src="${q.firma_base64}" style="max-height:80px; border:1px solid var(--border); border-radius:6px; background:#FFFFFF; padding:4px;">
                ` : `
                    <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:8px;">Dibuje su firma con el dedo o ratón para autorizar el presupuesto y dar comienzo al trabajo:</p>
                    <canvas id="customer-view-sig-canvas" width="480" height="110" style="border:1px solid var(--border); border-radius:8px; background:#FFFFFF; max-width:100%; touch-action:none;"></canvas>
                    <div style="margin-top:8px;">
                        <button type="button" class="btn btn-sm btn-secondary" onclick="clearSignaturePad('customer-view-sig-canvas')">Borrar Firma</button>
                        <button type="button" class="btn btn-sm btn-primary" onclick="CustomerViewController.saveSignature()">✅ Aprobar y Guardar Firma</button>
                    </div>
                `}
            </div>
        `;

        footer.innerHTML = `
            <div>
                <button type="button" class="btn btn-secondary" onclick="CustomerViewController.close()">Cerrar</button>
            </div>
            <div style="display:flex; gap:8px;">
                <button type="button" class="btn btn-action-wa" onclick="OmnichannelShare.shareWhatsApp(${q.id})">💬 Enviar WhatsApp</button>
                <button type="button" class="btn btn-secondary" onclick="OmnichannelShare.shareEmail(${q.id})">✉️ Enviar Email</button>
                <a href="/api/quotes/${q.id}/pdf" target="_blank" class="btn btn-primary">📄 Descargar PDF</a>
            </div>
        `;
    }
};
