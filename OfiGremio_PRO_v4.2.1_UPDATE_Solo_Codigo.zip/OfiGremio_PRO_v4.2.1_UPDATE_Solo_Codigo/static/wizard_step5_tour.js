// OfiGremio Pro v3.1 — Wizard Paso 5: Resumen y Entrada al Panel
window.WizardStep5 = {
    onEnter: function() {
        const pane = document.getElementById('wizard-step-5');
        if (!pane) return;

        const b = window.WizardController.data.business;
        const p = window.WizardController.data.payment;
        const adm = window.WizardController.data.admin || {};
        const adminUser = adm.username || window.state?.currentUser?.username || 'admin';

        pane.innerHTML = `
            <div style="text-align:center; margin-bottom:16px;">
                <div style="font-size:2.6rem; margin-bottom:6px;">🎉</div>
                <h3 style="font-size:1.25rem; font-weight:800; color:#10b981; margin-bottom:4px;">¡Tu Negocio y Cuenta Admin Están Listos!</h3>
                <p style="font-size:0.86rem; color:#64748b;">Todo guardado en tu base de datos transaccional. Ya puedes presupuestar, facturar y crear usuarios para tu equipo.</p>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:14px;">
                <div style="background:#eff6ff; border:1px solid #bfdbfe; border-radius:10px; padding:12px; grid-column:1 / -1;">
                    <div style="font-size:0.74rem; color:#1e40af; font-weight:700;">🔐 ADMINISTRADOR VINCULADO A LA EMPRESA</div>
                    <div style="font-size:0.92rem; font-weight:800; color:#1e3a8a; margin-top:2px;">Usuario único: <code>${adminUser}</code> (Rol: ADMIN)</div>
                    <div style="font-size:0.78rem; color:#475569;">Asociado a: <b>${b.empresa_nombre || 'Mi Empresa'}</b> (${b.empresa_cif || 'B-12345678'}) — Desde ⚙️ Ajustes o 👥 Usuarios podrás crear cuentas para tus operarios técnicos.</div>
                </div>
                <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:12px;">
                    <div style="font-size:0.75rem; color:#64748b; font-weight:600;">EMPRESA Y SECTOR</div>
                    <div style="font-size:0.9rem; font-weight:700; margin-top:2px;">${b.empresa_nombre || 'Mi Empresa'}</div>
                    <div style="font-size:0.8rem; color:#475569;">NIF: ${b.empresa_cif} | ${b.sector}</div>
                </div>
                <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:12px;">
                    <div style="font-size:0.75rem; color:#64748b; font-weight:600;">COBRO POR BIZUM / IBAN</div>
                    <div style="font-size:0.9rem; font-weight:700; margin-top:2px;">${p.empresa_iban || b.empresa_telefono || 'Bizum Activo'}</div>
                    <div style="font-size:0.8rem; color:#475569;">IVA: ${Math.round(p.iva_default * 100)}% | Tarifa: ${b.precio_hora_default} €/h</div>
                </div>
            </div>

            <div style="background:#f0fdf4; border:1px solid #bbf7d0; border-radius:10px; padding:12px; text-align:center;">
                <p style="font-size:0.86rem; color:#166534; margin:0; font-weight:600;">
                    Pulsa 'Finalizar y Entrar al Panel' para acceder de inmediato con tu sesión de Administrador iniciada.
                </p>
            </div>
        `;
    },

    finish: async function() {
        await window.WizardController.completeAndClose();
    }
};
