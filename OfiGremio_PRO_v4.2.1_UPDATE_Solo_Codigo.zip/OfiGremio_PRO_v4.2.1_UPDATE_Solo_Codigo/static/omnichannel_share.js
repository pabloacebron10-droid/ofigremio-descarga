// OfiGremio v3.0 — Módulo de Comunicaciones Omnicanal y Compartición en 1-Clic

window.OmnichannelShare = {
    shareWhatsApp: async function(quoteId) {
        try {
            const res = await fetch(`/api/quotes/${quoteId}/whatsapp`);
            if (!res.ok) throw new Error('Error al generar enlace de WhatsApp');
            const data = await res.json();
            if (data.whatsapp_url) {
                window.open(data.whatsapp_url, '_blank');
            }
        } catch (e) {
            showToast('Error abriendo WhatsApp: ' + e.message, 'error');
        }
    },

    shareEmail: async function(quoteId) {
        try {
            const res = await fetch(`/api/quotes/${quoteId}/email-template`);
            if (!res.ok) throw new Error('Error al preparar plantilla de email');
            const data = await res.json();
            if (data.mailto_url) {
                window.location.href = data.mailto_url;
            }
        } catch (e) {
            showToast('Error abriendo cliente de correo: ' + e.message, 'error');
        }
    },

    copySummary: async function(quoteId) {
        try {
            const res = await fetch(`/api/quotes/${quoteId}`);
            if (!res.ok) throw new Error('Presupuesto no encontrado');
            const q = await res.json();
            const cfg = (window.state && window.state.config) || (typeof state !== 'undefined' ? state.config : {});
            const text = `📋 PRESUPUESTO ${q.numero} · ${cfg.empresa_nombre || 'Servicio Técnico'}\n` +
                         `👤 Cliente: ${q.cliente_nombre}\n` +
                         `🔧 Intervención: ${q.concepto_averia}\n` +
                         `💵 Total: ${(q.total_factura || 0).toFixed(2)} € (IVA incluido)\n` +
                         `🛡️ Garantía: ${q.garantia_meses || 6} meses.`;
            
            await navigator.clipboard.writeText(text);
            showToast('📋 Resumen del presupuesto copiado al portapapeles', 'success');
        } catch (e) {
            showToast('No se pudo copiar el resumen: ' + e.message, 'warning');
        }
    }
};
