// OfiGremio v3.0 — Stepper Visual de Pipeline y Buscador Global Omnibox (Ctrl + K)

window.OmniboxController = {
    isOpen: false,

    init: function() {
        document.addEventListener('keydown', (e) => {
            if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) {
                e.preventDefault();
                this.toggle();
            } else if (e.key === 'Escape' && this.isOpen) {
                this.close();
            }
        });
        this._injectModalDOM();
    },

    toggle: function() {
        if (this.isOpen) this.close();
        else this.open();
    },

    open: function() {
        const modal = document.getElementById('modal-omnibox');
        if (modal) {
            modal.classList.add('active');
            this.isOpen = true;
            const input = document.getElementById('omnibox-input');
            if (input) {
                input.value = '';
                input.focus();
                this.search('');
            }
        }
    },

    close: function() {
        const modal = document.getElementById('modal-omnibox');
        if (modal) modal.classList.remove('active');
        this.isOpen = false;
    },

    search: function(query) {
        const resultsContainer = document.getElementById('omnibox-results');
        if (!resultsContainer) return;
        const q = (query || '').toLowerCase().trim();

        const allQuotes = (window.state && window.state.quotes) || (typeof state !== 'undefined' ? state.quotes : []) || [];
        const quotes = allQuotes.filter(item => 
            (item.numero || '').toLowerCase().includes(q) ||
            (item.cliente_nombre || '').toLowerCase().includes(q) ||
            (item.concepto_averia || '').toLowerCase().includes(q)
        ).slice(0, 5);

        const allClients = (window.state && window.state.clients) || (typeof state !== 'undefined' ? state.clients : []) || [];
        const clients = allClients.filter(item =>
            (item.nombre || '').toLowerCase().includes(q) ||
            (item.telefono || '').includes(q) ||
            (item.poblacion || '').toLowerCase().includes(q)
        ).slice(0, 4);

        let html = '';

        if (quotes.length > 0) {
            html += `<div style="font-size:0.75rem; font-weight:700; color:var(--text-muted); margin-bottom:6px;">📋 PRESUPUESTOS Y FACTURAS</div>`;
            quotes.forEach(quote => {
                html += `
                    <div class="omnibox-item" onclick="CustomerViewController.open(${quote.id}); OmniboxController.close();" style="padding:8px 12px; border-radius:6px; cursor:pointer; display:flex; justify-content:space-between; align-items:center; margin-bottom:4px; background:var(--bg-subtle);">
                        <div>
                            <b>${quote.numero}</b> · ${quote.cliente_nombre}
                            <div style="font-size:0.78rem; color:var(--text-muted);">${quote.concepto_averia}</div>
                        </div>
                        <div style="font-weight:700;">${(quote.total_factura || 0).toFixed(2)} €</div>
                    </div>
                `;
            });
        }

        if (clients.length > 0) {
            html += `<div style="font-size:0.75rem; font-weight:700; color:var(--text-muted); margin:12px 0 6px 0;">👥 CLIENTES</div>`;
            clients.forEach(c => {
                html += `
                    <div class="omnibox-item" onclick="switchTab('tab-clients'); OmniboxController.close();" style="padding:8px 12px; border-radius:6px; cursor:pointer; display:flex; justify-content:space-between; align-items:center; margin-bottom:4px; background:var(--bg-subtle);">
                        <div>
                            <b>👤 ${c.nombre}</b>
                            <div style="font-size:0.78rem; color:var(--text-muted);">${c.telefono || '-'} · ${c.poblacion || '-'}</div>
                        </div>
                    </div>
                `;
            });
        }

        if (!html) {
            html = `<div style="text-align:center; padding:20px; color:var(--text-muted); font-size:0.88rem;">No se encontraron resultados para "${query}"</div>`;
        }

        resultsContainer.innerHTML = html;
    },

    _injectModalDOM: function() {
        if (document.getElementById('modal-omnibox')) return;
        const div = document.createElement('div');
        div.id = 'modal-omnibox';
        div.className = 'modal-backdrop';
        div.innerHTML = `
            <div class="modal-card" style="max-width:560px; padding:0; overflow:hidden; border-radius:12px; margin-top:10vh;">
                <div style="padding:14px 18px; border-bottom:1px solid var(--border); display:flex; align-items:center; gap:10px; background:var(--bg-card);">
                    <span style="font-size:1.2rem;">🔍</span>
                    <input type="text" id="omnibox-input" placeholder="Buscar presupuestos, clientes, averías... (Escribe o pulsa Esc para salir)" style="border:none; outline:none; background:transparent; width:100%; font-size:1rem; font-family:inherit; color:var(--text-main);" oninput="OmniboxController.search(this.value)">
                    <span class="kbd-shortcut" onclick="OmniboxController.close()" style="cursor:pointer;">ESC</span>
                </div>
                <div id="omnibox-results" style="padding:14px 18px; max-height:360px; overflow-y:auto; background:var(--bg-card);">
                    <!-- Resultados predictivos -->
                </div>
            </div>
        `;
        document.body.appendChild(div);
    }
};

document.addEventListener('DOMContentLoaded', () => {
    OmniboxController.init();
});
