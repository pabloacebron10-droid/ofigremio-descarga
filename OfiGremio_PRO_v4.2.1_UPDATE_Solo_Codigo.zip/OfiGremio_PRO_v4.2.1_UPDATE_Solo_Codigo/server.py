"""

Servidor Backend FastAPI Local-First para OfiGremio Pro v2.0.

Consumo ultra-bajo de memoria (<40 MB RAM), respuesta instantánea (<15 ms).

"""



import os

import sys



# Forzar codificacion UTF-8 en stdout/stderr para Windows

if hasattr(sys.stdout, 'reconfigure'):

    try:

        sys.stdout.reconfigure(encoding='utf-8', errors='replace')

    except Exception:

        pass

if hasattr(sys.stderr, 'reconfigure'):

    try:

        sys.stderr.reconfigure(encoding='utf-8', errors='replace')

    except Exception:

        pass

import re
import json

from datetime import datetime

import urllib.parse

import shutil

from fastapi import FastAPI, HTTPException, Request, Response, Depends, Query, UploadFile, File, Form
import verifactu_engine

from fastapi.staticfiles import StaticFiles

from fastapi.responses import FileResponse, JSONResponse

from pydantic import BaseModel, Field

from typing import List, Optional

import ipaddress



import database as db

from local_assistant import OfiGremioLocalAssistant



local_ai_assistant = OfiGremioLocalAssistant()

import wizard_backend_bridge

import pdf_engine
import license_manager

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
STATIC_DIR = os.path.join(BASE_DIR, "static")
os.makedirs(DATA_DIR, exist_ok=True)
if hasattr(os, "chmod") and sys.platform != "win32":
    try:
        os.chmod(DATA_DIR, 0o755)
    except Exception:
        pass

# Inicializar Base de Datos SQLite al arrancar y crear punto de respaldo automático

db.init_db()

try:

    db.ensure_auto_backup(reason="startup")

except Exception:

    pass



app = FastAPI(title="OfiGremio Express API", version="3.7.0")



# -------------------------------------------------------------

# Middleware Defensivo: Cabeceras de Seguridad y Control Anti-CSRF

# -------------------------------------------------------------

def is_allowed_origin(hostname: str | None, host_header: str | None) -> bool:

    if not hostname:

        return False

    hostname_lower = hostname.lower()

    if hostname_lower in ("127.0.0.1", "localhost", "testserver"):

        return True

    if host_header:

        expected_host = host_header.split(":")[0].lower()

        if hostname_lower == expected_host:

            return True

    try:

        ip = ipaddress.ip_address(hostname_lower)

        if ip.is_private or ip.is_loopback:

            return True

    except ValueError:

        pass

    return False





@app.middleware("http")

async def security_defense_middleware(request: Request, call_next):

    # 1. Mitigación Anti-CSRF para métodos de mutación

    if request.method in ("POST", "PUT", "DELETE", "PATCH"):

        origin = request.headers.get("origin")

        referer = request.headers.get("referer")

        host_header = request.headers.get("host")

        for h_val in (origin, referer):

            if h_val:

                parsed = urllib.parse.urlparse(h_val)

                if not is_allowed_origin(parsed.hostname, host_header):

                    return JSONResponse(

                        status_code=403,

                        content={"detail": "Origen no autorizado (Protección Anti-CSRF activa)"}

                    )



    response = await call_next(request)



    # 2. Inyección de Cabeceras Defensivas HTTP (OWASP Top 10)

    response.headers["Content-Security-Policy"] = (

        "default-src 'self'; "

        "script-src 'self' 'unsafe-inline'; "

        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "

        "font-src 'self' https://fonts.gstatic.com data:; "

        "img-src 'self' data:; "

        "connect-src 'self';"

    )

    if request.url.path in ("/", "/sw.js") or request.url.path.endswith((".html", ".js", ".css")):

        response.headers["Cache-Control"] = "no-cache, must-revalidate"

    response.headers["X-Content-Type-Options"] = "nosniff"

    response.headers["X-Frame-Options"] = "SAMEORIGIN"

    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"

    response.headers["Permissions-Policy"] = "geolocation=(), microphone=self, camera=self"

    if "server" in response.headers:

        del response.headers["server"]



    return response





# -------------------------------------------------------------

# Autenticación y Control de Acceso Basado en Roles (RBAC)

# -------------------------------------------------------------

def get_current_user(request: Request) -> dict:

    auth_header = request.headers.get("authorization")



    # 1. Cabecera Authorization: Bearer <token>

    if auth_header is not None:

        auth_str = auth_header.strip()

        if not auth_str:

            raise HTTPException(status_code=401, detail="No autenticado")

        if auth_str.lower().startswith("bearer "):

            token = auth_str[7:].strip()

        else:

            token = auth_str

        user = db.verify_auth_token(token)

        if not user:

            raise HTTPException(status_code=401, detail="Token de autorización inválido o expirado")

        return user



    # 2. Cookie de sesión HttpOnly

    cookie_token = request.cookies.get("session_token")

    if cookie_token:

        user = db.verify_auth_token(cookie_token)

        if user:

            return user



    # 3. Cabecera personalizada de sesión

    x_token = request.headers.get("x-auth-token") or request.headers.get("x-session-token")

    if x_token:

        user = db.verify_auth_token(x_token)

        if user:

            return user

        raise HTTPException(status_code=401, detail="Token de autorización inválido o expirado")



    # 4. Solicitud sin credenciales válidas

    raise HTTPException(status_code=401, detail="No autenticado")





def require_admin(user: dict = Depends(get_current_user)) -> dict:

    if user.get("rol") != "ADMIN":

        raise HTTPException(

            status_code=403,

            detail="Acceso denegado: se requieren permisos de Administrador"

        )

    return user





def require_user(user: dict = Depends(get_current_user)) -> dict:

    return user





@app.post("/api/wizard/complete")

def complete_wizard_route(data: wizard_backend_bridge.WizardCompleteModel, request: Request, response: Response):

    cfg = db.get_config()

    is_pending = str(cfg.get("primera_configuracion_pendiente", "0")) == "1"

    if not (is_pending and data.admin_username and data.admin_password):

        user = get_current_user(request)

        if user.get("rol") != "ADMIN":

            raise HTTPException(status_code=403, detail="Acceso denegado: se requieren permisos de Administrador")

    res = wizard_backend_bridge.complete_wizard(data)

    if res.get("token"):

        response.set_cookie(

            key="session_token",

            value=res["token"],

            httponly=True,

            samesite="lax",

            path="/"

        )

    return res



app.include_router(wizard_backend_bridge.router)



BASE_DIR = os.path.dirname(os.path.abspath(__file__))

STATIC_DIR = os.path.join(BASE_DIR, "static")

DATA_DIR = os.path.join(BASE_DIR, "data")





# Modelos Pydantic



class BootstrapAdminRequest(BaseModel):

    username: str = Field(..., min_length=3, max_length=64)

    password: str = Field(..., min_length=6, max_length=128)

    nombre: Optional[str] = "Administrador Principal"

    empresa_nombre: Optional[str] = ""

    empresa_cif: Optional[str] = ""





class LoginRequest(BaseModel):

    username: str = Field(..., min_length=1, max_length=64)

    password: str = Field(..., min_length=1, max_length=128)





class PasswordChangeRequest(BaseModel):

    current_password: str = Field(..., min_length=1, max_length=128)

    new_password: str = Field(..., min_length=6, max_length=128)





class UserCreateRequest(BaseModel):

    username: str = Field(..., min_length=1, max_length=64)

    password: str = Field(..., min_length=4, max_length=128)

    nombre: str = Field(..., min_length=1, max_length=120)

    rol: Optional[str] = "TECNICO"



class ClientModel(BaseModel):

    nombre: str

    telefono: Optional[str] = ""

    email: Optional[str] = ""

    direccion: Optional[str] = ""

    poblacion: Optional[str] = ""

    notas: Optional[str] = ""

    nif_cif: Optional[str] = ""





class ClientUpdateModel(BaseModel):

    nombre: Optional[str] = None

    telefono: Optional[str] = None

    email: Optional[str] = None

    direccion: Optional[str] = None

    poblacion: Optional[str] = None

    notas: Optional[str] = None

    nif_cif: Optional[str] = None







class AssistantChatModel(BaseModel):

    message: str = Field(..., min_length=1, max_length=1000)

    context: Optional[dict] = None





class AssistantMemoryModel(BaseModel):

    key: str

    value: str

    category: Optional[str] = "general"



class ItemModel(BaseModel):

    tipo: Optional[str] = "MATERIAL"

    descripcion: Optional[str] = "Material"

    cantidad: Optional[float] = 1.0

    precio_unitario: Optional[float] = 0.0

    catalogo_id: Optional[int] = None





class QuoteCreateModel(BaseModel):

    cliente_id: int

    concepto_averia: str

    es_urgencia: Optional[bool] = False

    recargo_urgencia: Optional[float] = 0.0

    horas_mano_obra: Optional[float] = 1.0

    precio_hora: Optional[float] = 38.0

    descuento_porcentaje: Optional[float] = 0.0

    iva_porcentaje: Optional[float] = 0.21

    irpf_porcentaje: Optional[float] = 0.0

    anticipo_importe: Optional[float] = 0.0

    garantia_meses: Optional[int] = 6

    notas_tecnicas: Optional[str] = ""

    firma_base64: Optional[str] = ""

    foto_base64: Optional[str] = ""

    items: Optional[List[ItemModel]] = []

    partidas: Optional[List[ItemModel]] = []





class QuoteUpdateModel(BaseModel):

    cliente_id: Optional[int] = None

    concepto_averia: Optional[str] = None

    es_urgencia: Optional[bool] = None

    recargo_urgencia: Optional[float] = None

    horas_mano_obra: Optional[float] = None

    precio_hora: Optional[float] = None

    descuento_porcentaje: Optional[float] = None

    iva_porcentaje: Optional[float] = None

    irpf_porcentaje: Optional[float] = None

    anticipo_importe: Optional[float] = None

    garantia_meses: Optional[int] = None

    notas_tecnicas: Optional[str] = None

    firma_base64: Optional[str] = None

    foto_base64: Optional[str] = None

    items: Optional[List[ItemModel]] = None





class StatusUpdateModel(BaseModel):

    estado: str





class QuoteAdvanceModel(BaseModel):

    anticipo_importe: float = Field(..., ge=0.0)





class QuoteRectifyModel(BaseModel):

    motivo: Optional[str] = "Rectificación contable / Abono de factura"





class SendEmailModel(BaseModel):

    to_email: Optional[str] = None

    email_destino: Optional[str] = None





class RestoreBackupModel(BaseModel):

    filename: str





class SignatureModel(BaseModel):

    firma_base64: str

    aprobar: Optional[bool] = True





class LicenseActivationRequest(BaseModel):

    key: str



class CatalogItemModel(BaseModel):

    gremio: str

    tipo: Optional[str] = "MATERIAL"

    descripcion: str

    cantidad_default: Optional[float] = 1.0

    precio_unitario: float

    stock_actual: Optional[float] = 0.0

    stock_minimo_alerta: Optional[float] = 5.0

    precio_coste: Optional[float] = 0.0

    proveedor_id: Optional[int] = None

    controla_stock: Optional[int] = 1





class SupplierModel(BaseModel):

    nombre: str

    cif: Optional[str] = None

    cif_nif: Optional[str] = None

    telefono: Optional[str] = ""

    email: Optional[str] = ""

    contacto: Optional[str] = ""

    direccion: Optional[str] = ""

    poblacion: Optional[str] = ""

    notas: Optional[str] = ""





class SupplierUpdateModel(BaseModel):

    nombre: Optional[str] = None

    cif: Optional[str] = None

    cif_nif: Optional[str] = None

    telefono: Optional[str] = None

    email: Optional[str] = None

    contacto: Optional[str] = None

    direccion: Optional[str] = None

    poblacion: Optional[str] = None

    notas: Optional[str] = None





class ExpenseItemModel(BaseModel):

    catalogo_id: Optional[int] = None

    descripcion: Optional[str] = ""

    cantidad: float = 1.0

    precio_coste: Optional[float] = 0.0

    precio_coste_unitario: Optional[float] = None





class ExpenseCreateModel(BaseModel):

    numero_factura: str

    proveedor_id: Optional[int] = None

    fecha: Optional[str] = None

    concepto: str

    base_imponible: float

    iva_porcentaje: Optional[float] = 0.21

    forma_pago: Optional[str] = "TRANSFERENCIA"

    estado: Optional[str] = "PAGADO"

    notas: Optional[str] = ""

    items: Optional[List[ExpenseItemModel]] = []





class StockAdjustModel(BaseModel):

    catalogo_id: int

    cantidad_cambio: float

    motivo: Optional[str] = "Ajuste manual"





def _get_client_ip(request: Request) -> str:

    if not request or not request.client:

        return "127.0.0.1"

    return str(request.client.host or "127.0.0.1")





def _validate_base64_image(data_uri: Optional[str], field_name: str = "imagen"):

    """

    Prevención de inyección de URIs arbitrarios y denegación de servicio por tamaño (CWE-400 / CWE-434):

    Valida que el payload Base64 sea una imagen raster válida (png, jpeg, jpg, webp) y <= 3.5M chars (~2.5 MB).

    """

    if not data_uri:

        return

    val = str(data_uri).strip()

    if not val:

        return

    if len(val) > 3_500_000:

        raise HTTPException(status_code=400, detail=f"El campo {field_name} supera el tamaño máximo permitido (2.5 MB)")

    if not re.match(r"^data:image/(png|jpeg|jpg|webp);base64,[A-Za-z0-9+/=\s]+$", val, re.IGNORECASE):

        raise HTTPException(status_code=400, detail=f"Formato de {field_name} no válido. Debe ser una imagen PNG, JPEG o WEBP en Base64.")





def _mask_config_secrets(cfg: dict, user: dict) -> dict:

    """Enmascara secretos sensibles (como contraseñas SMTP) antes de enviarlos al cliente."""

    safe_cfg = dict(cfg or {})

    has_smtp_pw = bool((safe_cfg.get("smtp_password") or safe_cfg.get("smtp_pass") or "").strip())

    safe_cfg["smtp_password_configured"] = "1" if has_smtp_pw else "0"

    if user and user.get("rol") == "TECNICO":

        for secret_k in ("smtp_password", "smtp_pass", "smtp_user", "smtp_host", "smtp_port"):

            safe_cfg.pop(secret_k, None)

    else:

        masked_val = "********" if has_smtp_pw else ""

        safe_cfg["smtp_password"] = masked_val

        safe_cfg["smtp_pass"] = masked_val

    return safe_cfg





# Endpoints API

@app.get("/api/health")

def health():

    return {"status": "ok", "app": "OfiGremio Express", "version": "4.1.0"}





@app.get("/api/config")

def get_config(user: dict = Depends(require_user)):

    return _mask_config_secrets(db.get_config(), user)





@app.put("/api/config")

@app.post("/api/config")

def update_config(config_data: dict, request: Request, user: dict = Depends(require_admin)):

    updated = db.update_config(config_data)

    db.log_security_event(

        usuario=user.get("username", "admin"),

        rol=user.get("rol", "ADMIN"),

        accion="CONFIG_UPDATE",

        detalle="Actualización de configuración fiscal/SMTP",

        ip=_get_client_ip(request)

    )

    return _mask_config_secrets(updated, user)





@app.get("/api/clients")

def list_clients(q: Optional[str] = None, user: dict = Depends(require_user)):

    return db.list_clients(search=q)





@app.post("/api/clients")

def create_client(client: ClientModel, user: dict = Depends(require_user)):

    cid = db.create_client(

        nombre=client.nombre,

        telefono=client.telefono,

        email=client.email,

        direccion=client.direccion,

        poblacion=client.poblacion,

        notas=client.notas,

        nif_cif=client.nif_cif

    )

    return db.get_client(cid)





@app.put("/api/clients/{client_id}")

def update_client(client_id: int, client: ClientUpdateModel, user: dict = Depends(require_user)):

    payload = {k: v for k, v in client.model_dump().items() if v is not None}

    updated = db.update_client(client_id, payload)

    if not updated:

        raise HTTPException(status_code=404, detail="Cliente no encontrado")

    return updated





@app.delete("/api/clients/{client_id}")

def delete_client(client_id: int, user: dict = Depends(require_admin)):

    client = db.get_client(client_id)

    if not client:

        raise HTTPException(status_code=404, detail="Cliente no encontrado")

    try:

        deleted = db.delete_client(client_id)

        if not deleted:

            raise HTTPException(status_code=404, detail="Cliente no encontrado")

        return {"status": "deleted", "id": client_id}

    except ValueError as e:

        raise HTTPException(status_code=400, detail=str(e))





@app.get("/api/clients/{client_id}/gdpr-export")

def export_client_gdpr(client_id: int, request: Request, user: dict = Depends(require_admin)):

    try:

        data = db.export_client_gdpr_data(client_id)

        db.log_security_event(

            usuario=user.get("username", "admin"),

            rol=user.get("rol", "ADMIN"),

            accion="GDPR_EXPORT",

            detalle=f"Exportación de portabilidad RGPD para cliente ID {client_id}",

            ip=_get_client_ip(request)

        )

        return data

    except ValueError as e:

        raise HTTPException(status_code=404, detail=str(e))





@app.post("/api/clients/{client_id}/gdpr-anonymize")

def anonymize_client_gdpr(client_id: int, request: Request, user: dict = Depends(require_admin)):

    try:

        res = db.anonymize_client_gdpr(client_id)

        db.log_security_event(

            usuario=user.get("username", "admin"),

            rol=user.get("rol", "ADMIN"),

            accion="GDPR_ANONYMIZE",

            detalle=f"Anonimización RGPD cliente ID {client_id} (modo: {res.get('mode')})",

            ip=_get_client_ip(request)

        )

        return res

    except ValueError as e:

        raise HTTPException(status_code=404, detail=str(e))





@app.get("/api/security/audit-log")

def get_security_audit_log(limit: int = 80, user: dict = Depends(require_admin)):

    return {"logs": db.list_security_audit_logs(limit=limit)}





@app.get("/api/catalog")

def list_catalog(gremio: Optional[str] = None, user: dict = Depends(require_user)):

    return db.list_catalog(gremio=gremio)





@app.post("/api/catalog")

def create_catalog_item(item: CatalogItemModel, user: dict = Depends(require_user)):

    return db.create_catalog_item(item.model_dump())





@app.delete("/api/catalog/{item_id}")

def delete_catalog_item(item_id: int, user: dict = Depends(require_admin)):

    db.delete_catalog_item(item_id)

    return {"status": "deleted", "id": item_id}





@app.get("/api/analytics")

def get_analytics(user: dict = Depends(require_admin)):

    return db.get_analytics_summary()





@app.get("/api/quotes")

def list_quotes(user: dict = Depends(require_user)):

    return db.list_quotes()





@app.post("/api/quotes")

def create_quote(quote: QuoteCreateModel, user: dict = Depends(require_user)):

    _validate_base64_image(quote.firma_base64, "firma_base64")

    _validate_base64_image(quote.foto_base64, "foto_base64")

    data = quote.model_dump()

    created = db.create_quote(data)



    # Generar automáticamente el PDF del presupuesto

    cfg = db.get_config()

    pdf_path = pdf_engine.generate_quote_pdf(created, cfg)



    # Actualizar ruta de PDF en BD

    with db.get_connection() as conn:

        conn.cursor().execute("UPDATE presupuestos SET pdf_path = ? WHERE id = ?;", (pdf_path, created["id"]))
        conn.commit()

    # Disparo automático no bloqueante de email si el cliente tiene correo registrado
    try:
        full_quote = db.get_quote(created["id"])
        if full_quote and (full_quote.get("cliente_email") or "").strip():
            send_quote_email_service(created["id"], auto_trigger=True)
    except Exception as ex:
        print(f"[Email Trigger] create_quote auto-dispatch warning: {ex}")

    return db.get_quote(created["id"])





@app.get("/api/quotes/{quote_id}")

def get_quote(quote_id: int, user: dict = Depends(require_user)):

    q = db.get_quote(quote_id)

    if not q:

        raise HTTPException(status_code=404, detail="Presupuesto no encontrado")

    return q





@app.put("/api/quotes/{quote_id}")

def update_quote(quote_id: int, quote: QuoteUpdateModel, user: dict = Depends(require_user)):

    _validate_base64_image(quote.firma_base64, "firma_base64")

    _validate_base64_image(quote.foto_base64, "foto_base64")

    payload = {k: v for k, v in quote.model_dump().items() if v is not None}

    updated = db.update_quote(quote_id, payload)

    if not updated:

        raise HTTPException(status_code=404, detail="Presupuesto no encontrado")



    cfg = db.get_config()

    pdf_path = pdf_engine.generate_quote_pdf(updated, cfg)

    with db.get_connection() as conn:

        conn.cursor().execute("UPDATE presupuestos SET pdf_path = ? WHERE id = ?;", (pdf_path, quote_id))

        conn.commit()



    return db.get_quote(quote_id)





@app.delete("/api/quotes/{quote_id}")

def delete_quote(quote_id: int, user: dict = Depends(require_admin)):

    try:

        deleted = db.delete_quote(quote_id)

        if not deleted:

            raise HTTPException(status_code=404, detail="Presupuesto no encontrado")

        return {"status": "deleted", "id": quote_id}

    except ValueError as e:

        raise HTTPException(status_code=400, detail=str(e))





@app.post("/api/quotes/{quote_id}/duplicate")

def duplicate_quote(quote_id: int, user: dict = Depends(require_user)):

    duplicated = db.duplicate_quote(quote_id)

    if not duplicated:

        raise HTTPException(status_code=404, detail="Presupuesto no encontrado")



    cfg = db.get_config()

    pdf_path = pdf_engine.generate_quote_pdf(duplicated, cfg)

    with db.get_connection() as conn:

        conn.cursor().execute("UPDATE presupuestos SET pdf_path = ? WHERE id = ?;", (pdf_path, duplicated["id"]))

        conn.commit()



    return db.get_quote(duplicated["id"])





@app.post("/api/quotes/{quote_id}/signature")

def save_signature(quote_id: int, sig: SignatureModel, user: dict = Depends(require_user)):

    _validate_base64_image(sig.firma_base64, "firma_base64")

    updated = db.save_quote_signature(quote_id, sig.firma_base64, aprobar=bool(sig.aprobar))

    if not updated:

        raise HTTPException(status_code=404, detail="Presupuesto no encontrado")



    cfg = db.get_config()

    pdf_path = pdf_engine.generate_quote_pdf(updated, cfg)

    with db.get_connection() as conn:

        conn.cursor().execute("UPDATE presupuestos SET pdf_path = ? WHERE id = ?;", (pdf_path, quote_id))

        conn.commit()



    return db.get_quote(quote_id)





@app.patch("/api/quotes/{quote_id}/status")

@app.put("/api/quotes/{quote_id}/status")

def update_status(quote_id: int, status_update: StatusUpdateModel, user: dict = Depends(require_user)):

    try:

        updated = db.update_quote_status(quote_id, status_update.estado)

        if not updated:

            raise HTTPException(status_code=404, detail="Presupuesto no encontrado")

        # Descuento de stock automatico si pasa a APROBADO o COBRADO

        if status_update.estado.upper() in ("APROBADO", "EN_PROCESO", "COBRADO"):

            try:

                db.deduct_quote_stock(quote_id)

            except Exception as ex:

                print(f"[Stock] Warning deduciendo stock: {ex}")



        # Regenerar PDF (si pasa a COBRADO se emite como FACTURA OFICIAL con FAC-YYYY-XXXX)
        cfg = db.get_config()
        pdf_engine.generate_quote_pdf(updated, cfg)

        # Disparo automático no bloqueante de email al cliente con PDF adjunto
        if status_update.estado.upper() in ("APROBADO", "COBRADO"):
            try:
                if updated and (updated.get("cliente_email") or "").strip():
                    send_quote_email_service(quote_id, auto_trigger=True)
            except Exception as ex:
                print(f"[Email Trigger] update_status auto-dispatch warning: {ex}")

        return updated

    except ValueError as e:

        raise HTTPException(status_code=400, detail=str(e))





@app.post("/api/quotes/{quote_id}/advance")

def update_quote_advance(quote_id: int, payload: QuoteAdvanceModel, user: dict = Depends(require_user)):

    updated = db.record_quote_advance(quote_id, payload.anticipo_importe)

    if not updated:

        raise HTTPException(status_code=404, detail="Presupuesto no encontrado")

    cfg = db.get_config()

    pdf_path = pdf_engine.generate_quote_pdf(updated, cfg)

    with db.get_connection() as conn:

        conn.cursor().execute("UPDATE presupuestos SET pdf_path = ? WHERE id = ?;", (pdf_path, quote_id))

        conn.commit()

    return db.get_quote(quote_id)





@app.post("/api/quotes/{quote_id}/rectify")

def rectify_paid_invoice(quote_id: int, payload: QuoteRectifyModel, request: Request, user: dict = Depends(require_admin)):

    try:

        rectified = db.create_rectifying_invoice(quote_id, motivo=payload.motivo or "Rectificación contable / Abono de factura")

        cfg = db.get_config()

        pdf_path = pdf_engine.generate_quote_pdf(rectified, cfg)

        with db.get_connection() as conn:

            conn.cursor().execute("UPDATE presupuestos SET pdf_path = ? WHERE id = ?;", (pdf_path, rectified["id"]))

            conn.commit()

        db.log_security_event(

            usuario=user.get("username", "admin"),

            rol=user.get("rol", "ADMIN"),

            accion="INVOICE_RECTIFIED",

            detalle=f"Emitida factura rectificativa {rectified.get('numero_factura')} sobre ID {quote_id}",
            ip=_get_client_ip(request)
        )

        # Disparo automático no bloqueante de email con factura rectificativa adjunta
        try:
            if rectified and (rectified.get("cliente_email") or "").strip():
                send_quote_email_service(rectified["id"], auto_trigger=True)
        except Exception as ex:
            print(f"[Email Trigger] rectify_paid_invoice auto-dispatch warning: {ex}")

        return db.get_quote(rectified["id"])

    except ValueError as e:

        raise HTTPException(status_code=400, detail=str(e))





@app.get("/api/quotes/{quote_id}/pdf")
def download_pdf(
    quote_id: int,
    doc_type: Optional[str] = Query(None, pattern="^(presupuesto|factura|auto)?$"),
    user: dict = Depends(require_user)
):
    q = db.get_quote(quote_id)
    if not q:
        raise HTTPException(status_code=404, detail="Presupuesto no encontrado")

    cfg = db.get_config()
    q_pdf = dict(q)
    if doc_type == "presupuesto":
        if q_pdf.get("estado") == "COBRADO":
            q_pdf["estado"] = "APROBADO"
        q_pdf["numero_factura"] = None
        q_pdf["es_rectificativa"] = False
    elif doc_type == "factura":
        if q_pdf.get("estado") != "COBRADO" and not q_pdf.get("es_rectificativa"):
            q_pdf["estado"] = "COBRADO"

    try:
        pdf_path = pdf_engine.generate_quote_pdf(q_pdf, cfg, doc_type=doc_type)
    except TypeError:
        pdf_path = pdf_engine.generate_quote_pdf(q_pdf, cfg)

    safe_path = os.path.abspath(pdf_path)
    if not safe_path.startswith(os.path.abspath(pdf_engine.PDF_DIR)):
        raise HTTPException(status_code=403, detail="Ruta de PDF no autorizada")

    if doc_type == "presupuesto":
        raw_doc_num = q.get("numero", "presupuesto")
    elif doc_type == "factura":
        raw_doc_num = q.get("numero_factura") or q.get("numero", "factura")
    else:
        raw_doc_num = q.get("numero_factura") if q.get("estado") == "COBRADO" and q.get("numero_factura") else q.get("numero", "presupuesto")
    safe_filename = f"{re.sub(r'[^A-Za-z0-9_\-]', '_', str(raw_doc_num))}.pdf"
    return FileResponse(safe_path, media_type="application/pdf", filename=safe_filename)


@app.get("/api/quotes/{quote_id}/whatsapp")
def get_whatsapp_url(
    quote_id: int,
    request: Request,
    doc_type: Optional[str] = Query(None, pattern="^(presupuesto|factura|auto)?$"),
    user: dict = Depends(require_user)
):
    """
    Genera el enlace directo para enviar el presupuesto o factura oficial por WhatsApp con selección conjunta y PDF pre-generado.
    """
    q = db.get_quote(quote_id)
    if not q:
        raise HTTPException(status_code=404, detail="Presupuesto no encontrado")

    cfg = db.get_config()
    cliente = q.get("cliente_nombre", "Estimado cliente")
    numero = q.get("numero", "PRE-0000")
    numero_factura = q.get("numero_factura")
    estado = (q.get("estado") or "BORRADOR").upper()
    total = float(q.get("total_factura") or 0.0)
    anticipo = float(q.get("anticipo_importe") or 0.0)
    pendiente = float(q.get("pendiente_cobro") if q.get("pendiente_cobro") is not None else max(0.0, total - anticipo))
    total_desc = float(q.get("total_descuento") or 0.0)
    total_irpf = float(q.get("total_irpf") or 0.0)
    concepto = q.get("concepto_averia", "Reparación")
    empresa = cfg.get("empresa_nombre", "Servicio Técnico")
    raw_tel = re.sub(r'\D', '', str(q.get("cliente_telefono") or ""))
    if len(raw_tel) == 9 and raw_tel[0] in ('6', '7', '8', '9'):
        telefono = f"34{raw_tel}"
    else:
        telefono = raw_tel

    desglose_extra = ""
    if total_desc > 0:
        desglose_extra += f"🏷️ *Descuento aplicado:* -{total_desc:.2f} €\n"
    if total_irpf > 0:
        desglose_extra += f"📑 *Retención IRPF:* -{total_irpf:.2f} €\n"
    if anticipo > 0 and estado != "COBRADO":
        desglose_extra += f"💶 *Anticipo entregado:* -{anticipo:.2f} €\n"
        desglose_extra += f"⏳ *Pendiente de abonar:* {pendiente:.2f} €\n"

    # Determinar tipo de documento solicitado
    if doc_type == "factura":
        chosen_type = "factura"
    elif doc_type == "presupuesto":
        chosen_type = "presupuesto"
    else:
        if (estado == "COBRADO" or q.get("es_rectificativa")) and numero_factura:
            chosen_type = "factura"
        else:
            chosen_type = "presupuesto"

    if chosen_type == "factura" and not numero_factura and estado != "COBRADO":
        chosen_type = "presupuesto"

    # Pre-generar PDF en disco
    q_pdf = dict(q)
    if chosen_type == "presupuesto":
        if q_pdf.get("estado") == "COBRADO":
            q_pdf["estado"] = "APROBADO"
        q_pdf["numero_factura"] = None
        q_pdf["es_rectificativa"] = False
    elif chosen_type == "factura":
        if q_pdf.get("estado") != "COBRADO" and not q_pdf.get("es_rectificativa"):
            q_pdf["estado"] = "COBRADO"

    try:
        pdf_engine.generate_quote_pdf(q_pdf, cfg, doc_type=chosen_type)
    except TypeError:
        pdf_engine.generate_quote_pdf(q_pdf, cfg)

    # Determinar enlace oficial del PDF
    tunnel_file = os.path.join(DATA_DIR, "remote_tunnel.json")
    tunnel_url = ""
    if os.path.exists(tunnel_file):
        try:
            with open(tunnel_file, "r", encoding="utf-8") as f:
                tdata = json.load(f)
                tunnel_url = (tdata.get("tunnel_url") or "").strip()
        except Exception:
            pass
    base_url = tunnel_url.rstrip("/") if tunnel_url else str(request.base_url).rstrip("/")
    doc_url = f"{base_url}/api/quotes/{quote_id}/pdf?doc_type={chosen_type}"

    if chosen_type == "factura":
        doc_label = "FACTURA RECTIFICATIVA" if q.get("es_rectificativa") else "FACTURA OFICIAL"
        num_doc = numero_factura or numero
        mensaje = (
            f"Hola {cliente}, le saluda {empresa}.\n\n"
            f"Le adjuntamos su *{doc_label} {num_doc}* (Ref. {numero}) correspondiente a:\n"
            f"🔧 _{concepto}_\n\n"
            f"{desglose_extra}"
            f"✅ *Importe total:* {total:.2f} €\n\n"
            f"Muchas gracias por su confianza."
        )
    else:
        mensaje = (
            f"Hola {cliente}, le saluda {empresa}.\n\n"
            f"Le enviamos el presupuesto *{numero}* correspondiente a la intervención de:\n"
            f"🔧 _{concepto}_\n\n"
            f"{desglose_extra}"
            f"💵 *Total presupuesto (impuestos incluidos):* {total:.2f} €\n\n"
            f"Puede solicitar su documento en PDF o confirmar la intervención respondiendo a este mensaje.\n\n"
            f"Muchas gracias por su confianza."
        )

    encoded_msg = urllib.parse.quote(mensaje)
    whatsapp_url = f"https://wa.me/{telefono}?text={encoded_msg}" if telefono else f"https://wa.me/?text={encoded_msg}"

    return {
        "status": "success",
        "whatsapp_url": whatsapp_url,
        "preformatted_message": mensaje,
        "pdf_url": doc_url,
        "doc_type": chosen_type
    }





@app.get("/api/backup/download")

def download_backup_database(user: dict = Depends(require_admin)):

    """Descarga una copia de seguridad directa, atómica y segura de SQLite."""

    try:

        backup_path = db.create_backup_copy()

        safe_path = os.path.abspath(backup_path)

        # Validación defensiva path traversal

        if not safe_path.startswith(os.path.abspath(DATA_DIR)):

            raise HTTPException(status_code=403, detail="Acceso denegado a ruta no autorizada")

        filename = os.path.basename(safe_path)

        return FileResponse(

            safe_path,

            media_type="application/x-sqlite3",

            filename=filename,

            headers={"Cache-Control": "no-store, no-cache"}

        )

    except HTTPException:

        raise

    except Exception as e:

        raise HTTPException(status_code=500, detail=f"Error al generar copia de seguridad: {str(e)}")





@app.get("/api/backup/list")

def list_database_backups(user: dict = Depends(require_admin)):

    """Lista las copias de seguridad automáticas y el estado de integridad de SQLite."""

    return db.list_backups()





@app.post("/api/backup/create")

def create_manual_backup_point(user: dict = Depends(require_admin)):

    """Crea un nuevo punto de restauración atómico en el servidor."""

    try:

        path = db.ensure_auto_backup(reason="manual")

        return {

            "status": "success",

            "filename": os.path.basename(path),

            "summary": db.list_backups()

        }

    except Exception as e:

        raise HTTPException(status_code=500, detail=f"Error al crear copia de seguridad: {str(e)}")





@app.post("/api/backup/restore")

def restore_database_backup(payload: RestoreBackupModel, user: dict = Depends(require_admin)):

    """Restaura una copia de seguridad verificando antes su integridad y creando resguardo previo."""

    try:

        res = db.restore_backup_from_file(payload.filename)

        return res

    except ValueError as e:

        raise HTTPException(status_code=400, detail=str(e))

    except Exception as e:

        raise HTTPException(status_code=500, detail=f"Error al restaurar copia de seguridad: {str(e)}")







@app.get("/api/export/sales-excel")

def export_sales_excel(user: dict = Depends(require_admin)):

    excel_path = db.export_sales_to_excel("data/export_facturas_clientes.xlsx")

    return FileResponse(

        excel_path,

        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",

        filename="facturas_emitidas_clientes.xlsx"

    )





@app.get("/api/export/expenses-excel")

def export_expenses_excel(user: dict = Depends(require_admin)):

    excel_path = db.export_expenses_to_excel("data/export_facturas_proveedores.xlsx")

    return FileResponse(

        excel_path,

        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",

        filename="facturas_compras_proveedores.xlsx"

    )





# -------------------------------------------------------------

# Escudo Anti-Fuerza Bruta (Rate Limiting & Account Lockout)

# -------------------------------------------------------------

LOGIN_MAX_ATTEMPTS = 5

LOGIN_WINDOW_SECONDS = 300

LOGIN_LOCKOUT_SECONDS = 60

LOGIN_FAILED_ATTEMPTS: dict[str, dict] = {}





def clear_login_attempts(key: str = None):

    if key is None:

        LOGIN_FAILED_ATTEMPTS.clear()

    else:

        LOGIN_FAILED_ATTEMPTS.pop(key, None)





def _check_and_record_login_attempt(client_ip: str, username: str) -> int:

    """

    Devuelve 0 si se permite el intento, o los segundos restantes de bloqueo (>0) si está bloqueado.

    """

    now_ts = int(datetime.now().timestamp())

    norm_user = (username or "").strip().lower()[:64]

    key = f"{client_ip}:{norm_user}"



    if len(LOGIN_FAILED_ATTEMPTS) > 2000:

        stale = [k for k, v in LOGIN_FAILED_ATTEMPTS.items() if now_ts - v.get("first_ts", 0) > LOGIN_WINDOW_SECONDS]

        for k in stale:

            LOGIN_FAILED_ATTEMPTS.pop(k, None)



    entry = LOGIN_FAILED_ATTEMPTS.get(key)

    if not entry:

        return 0



    locked_until = entry.get("locked_until", 0)

    if locked_until > now_ts:

        return locked_until - now_ts



    if now_ts - entry.get("first_ts", 0) > LOGIN_WINDOW_SECONDS:

        LOGIN_FAILED_ATTEMPTS.pop(key, None)

        return 0



    return 0





def _register_failed_login(client_ip: str, username: str) -> tuple[int, int]:

    """

    Registra un fallo de login. Devuelve (intentos_actuales, segundos_bloqueado).

    """

    now_ts = int(datetime.now().timestamp())

    norm_user = (username or "").strip().lower()[:64]

    key = f"{client_ip}:{norm_user}"

    entry = LOGIN_FAILED_ATTEMPTS.get(key)



    if not entry or (now_ts - entry.get("first_ts", 0) > LOGIN_WINDOW_SECONDS):

        entry = {"count": 1, "first_ts": now_ts, "locked_until": 0}

    else:

        entry["count"] = entry.get("count", 0) + 1



    if entry["count"] >= LOGIN_MAX_ATTEMPTS:

        entry["locked_until"] = now_ts + LOGIN_LOCKOUT_SECONDS



    LOGIN_FAILED_ATTEMPTS[key] = entry

    rem_lock = max(0, entry["locked_until"] - now_ts)

    return entry["count"], rem_lock





@app.post("/api/auth/login")

def login(req: LoginRequest, request: Request, response: Response):

    client_ip = request.client.host if request.client else "127.0.0.1"

    norm_user = (req.username or "").strip().lower()

    rate_key = f"{client_ip}:{norm_user}"



    wait_seconds = _check_and_record_login_attempt(client_ip, norm_user)

    if wait_seconds > 0:

        return JSONResponse(

            status_code=429,

            headers={"Retry-After": str(wait_seconds)},

            content={

                "detail": f"Demasiados intentos fallidos. Acceso bloqueado temporalmente por seguridad durante {wait_seconds} segundos.",

                "retry_after_seconds": wait_seconds

            }

        )



    user = db.verify_user_credentials(req.username, req.password)

    if not user:

        attempts, lock_secs = _register_failed_login(client_ip, norm_user)

        db.log_security_event(

            usuario=norm_user,

            rol="UNKNOWN",

            accion="LOGIN_FAILED",

            detalle=f"Intento fallido ({attempts}/{LOGIN_MAX_ATTEMPTS})",

            ip=client_ip

        )

        if lock_secs > 0:

            return JSONResponse(

                status_code=429,

                headers={"Retry-After": str(lock_secs)},

                content={

                    "detail": f"Has superado los {LOGIN_MAX_ATTEMPTS} intentos permitidos. Cuenta protegida durante {lock_secs} segundos.",

                    "retry_after_seconds": lock_secs

                }

            )

        remaining = max(0, LOGIN_MAX_ATTEMPTS - attempts)

        raise HTTPException(

            status_code=401,

            detail=f"Usuario o contraseña incorrectos ({remaining} intentos restantes antes del bloqueo temporal)"

        )



    clear_login_attempts(rate_key)

    token = db.create_auth_token(user)

    db.log_security_event(

        usuario=user.get("username", norm_user),

        rol=user.get("rol", "ADMIN"),

        accion="LOGIN_SUCCESS",

        detalle="Inicio de sesión autenticado",

        ip=client_ip

    )

    response.set_cookie(

        key="session_token",

        value=token,

        httponly=True,

        samesite="lax",

        path="/"

    )

    return {

        "success": True,

        "token": token,

        "user": user

    }





@app.get("/api/auth/bootstrap-status")

def get_bootstrap_status():

    cfg = db.get_config()

    is_pending = str(cfg.get("primera_configuracion_pendiente", "0")) == "1"

    return {

        "needs_initial_setup": is_pending,

        "primera_configuracion_pendiente": cfg.get("primera_configuracion_pendiente", "0"),

        "empresa_nombre": cfg.get("empresa_nombre", "")

    }





@app.post("/api/auth/bootstrap-admin")

def bootstrap_initial_admin(req: BootstrapAdminRequest, request: Request, response: Response):

    cfg = db.get_config()

    is_pending = str(cfg.get("primera_configuracion_pendiente", "0")) == "1"

    if not is_pending:

        # Si ya se completó la puesta en marcha inicial, exigir sesión ADMIN activa

        try:

            curr = get_current_user(request)

            if curr.get("rol") != "ADMIN":

                raise HTTPException(status_code=403, detail="Se requieren permisos de Administrador")

        except HTTPException:

            raise HTTPException(

                status_code=403,

                detail="La puesta en marcha inicial ya fue completada. Inicia sesión con tu usuario Administrador."

            )

    try:

        admin_user = db.setup_initial_admin_user(

            username=req.username,

            password=req.password,

            nombre=req.nombre or "Administrador Principal",

            empresa_cif=req.empresa_cif or "",

            empresa_nombre=req.empresa_nombre or ""

        )

        token = db.create_auth_token(admin_user)

        response.set_cookie(

            key="session_token",

            value=token,

            httponly=True,

            samesite="lax",

            path="/"

        )

        return {

            "success": True,

            "token": token,

            "user": admin_user

        }

    except ValueError as e:

        raise HTTPException(status_code=400, detail=str(e))





@app.get("/api/auth/me")

def get_current_user_profile(user: dict = Depends(get_current_user)):

    return user





@app.post("/api/auth/logout")

def logout(request: Request, response: Response):

    auth_header = request.headers.get("authorization")

    if auth_header:

        a_str = auth_header.strip()

        tok = a_str[7:].strip() if a_str.lower().startswith("bearer ") else a_str

        db.revoke_auth_token(tok)

    cookie_token = request.cookies.get("session_token")

    if cookie_token:

        db.revoke_auth_token(cookie_token)

    x_token = request.headers.get("x-auth-token") or request.headers.get("x-session-token")

    if x_token:

        db.revoke_auth_token(x_token)

    response.delete_cookie(key="session_token", path="/")

    return {"success": True, "message": "Sesión cerrada y revocada correctamente"}





@app.post("/api/auth/change-password")

def change_password(req: PasswordChangeRequest, user: dict = Depends(require_user)):

    try:

        db.change_user_password(user["id"], req.current_password, req.new_password)

        return {"success": True, "message": "Contraseña actualizada con éxito"}

    except ValueError as e:

        raise HTTPException(status_code=400, detail=str(e))





@app.get("/api/users")

def get_users(user: dict = Depends(require_admin)):

    return db.list_users(empresa_cif=user.get("empresa_cif") or None)





@app.post("/api/users")

def create_new_user(req: UserCreateRequest, user: dict = Depends(require_admin)):

    try:

        new_u = db.create_user(

            username=req.username,

            password=req.password,

            nombre=req.nombre,

            rol=req.rol or "TECNICO",

            empresa_cif=user.get("empresa_cif"),

            empresa_nombre=user.get("empresa_nombre")

        )

        return {"success": True, "user": new_u}

    except ValueError as e:

        raise HTTPException(status_code=400, detail=str(e))

    except Exception as e:

        raise HTTPException(status_code=500, detail=f"Error al crear usuario: {str(e)}")





@app.delete("/api/users/{user_id}")

def delete_existing_user(user_id: int, user: dict = Depends(require_admin)):

    try:

        deleted = db.delete_user(user_id, acting_user_id=user["id"])

        if not deleted:

            raise HTTPException(status_code=404, detail="Usuario no encontrado")

        return {"success": True, "deleted_id": user_id}

    except ValueError as e:

        raise HTTPException(status_code=400, detail=str(e))





@app.get("/api/export/excel")

def export_excel(user: dict = Depends(require_admin)):

    excel_path = db.export_to_excel("data/export_facturacion.xlsx")

    return FileResponse(

        excel_path,

        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",

        filename="export_facturacion.xlsx"

    )





# Servir Frontend Estático

if os.path.exists(STATIC_DIR):

    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")



# =========================================================================

# CONTROL DE LICENCIA HWID Y PROTECCIÓN ANTI-PIRATERÍA

# =========================================================================

@app.middleware("http")

async def license_enforcement_middleware(request: Request, call_next):

    path = request.url.path

    if (

        path.startswith("/static")

        or path.startswith("/api/license")

        or path.startswith("/api/health")

        or path.startswith("/api/system")

        or path.startswith("/api/auth")

        or path in ["/activacion", "/favicon.ico", "/apple-touch-icon.png", "/sw.js", "/"]

    ):

        return await call_next(request)



    lic = license_manager.verify_license()

    if not lic.get("valid"):

        return JSONResponse(

            status_code=403,

            content={

                "detail": "LICENSE_REQUIRED",

                "status": lic.get("status"),

                "message": lic.get("message"),

                "hwid": lic.get("hwid")

            }

        )

    return await call_next(request)





@app.get("/api/license/status")
def get_license_status():
    """Devuelve el estado de licencia y el HWID del equipo actual."""
    lic = license_manager.verify_license()
    if not lic.get("valid"):
        try:
            sync_res = license_manager.sync_online_subscription(timeout=2.0)
            if sync_res.get("success"):
                lic = license_manager.verify_license()
        except Exception:
            pass
    return lic





@app.post("/api/license/activate")

def activate_app_license(body: LicenseActivationRequest):

    """Activa la licencia del equipo mediante clave criptográfica firmada."""

    res = license_manager.activate_license(body.key)

    if not res.get("success"):

        raise HTTPException(status_code=400, detail=res.get("message", "Clave no válida"))

    return res


@app.get("/api/license/stripe-config")
def get_stripe_subscription_config():
    """Devuelve la configuración de suscripción mensual con Stripe y la URL con el HWID pre-vinculado."""
    current_hwid = license_manager.get_machine_hwid()
    config_file = os.path.join(DATA_DIR, "stripe_config.json")
    cfg = {
        "enabled": True,
        "payment_link_monthly": "https://buy.stripe.com/test_ofigremio_15eur_monthly",
        "customer_portal_link": "https://billing.stripe.com/p/login/test_ofigremio",
        "monthly_price_eur": 15.00,
        "currency": "EUR"
    }
    if os.path.exists(config_file):
        try:
            with open(config_file, "r", encoding="utf-8") as f:
                loaded = json.load(f)
                if isinstance(loaded, dict):
                    cfg.update(loaded)
        except Exception:
            pass

    base_link = cfg.get("payment_link_monthly", "").strip()
    sep = "&" if "?" in base_link else "?"
    checkout_url = f"{base_link}{sep}client_reference_id={current_hwid}" if base_link else ""

    return {
        "enabled": bool(cfg.get("enabled", True)),
        "hwid": current_hwid,
        "monthly_price_eur": float(cfg.get("monthly_price_eur", 15.0)),
        "currency": cfg.get("currency", "EUR"),
        "checkout_url": checkout_url,
        "customer_portal_url": cfg.get("customer_portal_link", "")
    }


@app.post("/api/license/sync-now")
def trigger_license_online_sync():
    """Sincroniza manualmente la suscripción con el relay online de Stripe."""
    sync_res = license_manager.sync_online_subscription()
    current_status = license_manager.verify_license()
    return {
        "sync_result": sync_res,
        "current_license": current_status
    }


def _generate_stripe_subscription_invoice(pdf_path: str, period_str: str, client_info: dict, hwid: str):
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib import colors

    os.makedirs(os.path.dirname(pdf_path), exist_ok=True)
    doc = SimpleDocTemplate(
        pdf_path,
        pagesize=A4,
        leftMargin=36,
        rightMargin=36,
        topMargin=36,
        bottomMargin=36
    )

    styles = getSampleStyleSheet()

    title_style = ParagraphStyle(
        'StripeInvTitle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=18,
        leading=22,
        textColor=colors.HexColor('#0f172a')
    )
    subtitle_style = ParagraphStyle(
        'StripeInvSubTitle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=10,
        leading=14,
        textColor=colors.HexColor('#64748b')
    )
    header_style = ParagraphStyle(
        'StripeInvHeader',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=9,
        leading=12,
        textColor=colors.HexColor('#334155')
    )
    body_style = ParagraphStyle(
        'StripeInvBody',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9,
        leading=13,
        textColor=colors.HexColor('#1e293b')
    )
    bold_style = ParagraphStyle(
        'StripeInvBold',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=9,
        leading=13,
        textColor=colors.HexColor('#0f172a')
    )
    total_style = ParagraphStyle(
        'StripeInvTotal',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=12,
        leading=16,
        textColor=colors.HexColor('#0f172a')
    )

    elements = []

    # 1. Cabecera y Título
    inv_number = f"STRIPE-{period_str.replace('-', '')}"
    today_str = datetime.now().strftime("%d/%m/%Y")

    header_data = [
        [
            Paragraph("<b>OfiGremio PRO — Suscripción Oficial</b>", title_style),
            Paragraph(f"<b>FACTURA RECURRENTE</b><br/>Nº: {inv_number}<br/>Fecha: {today_str}", subtitle_style)
        ]
    ]
    header_table = Table(header_data, colWidths=[320, 200])
    header_table.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('ALIGN', (1,0), (1,0), 'RIGHT'),
    ]))
    elements.append(header_table)
    elements.append(Spacer(1, 18))

    # 2. Datos de Emisor y Receptor
    empresa_nombre = client_info.get("empresa_nombre") or "Titular de Licencia OfiGremio PRO"
    empresa_cif = client_info.get("empresa_cif") or "B-00000000"
    empresa_direccion = client_info.get("empresa_direccion") or "Instalación Local"
    empresa_poblacion = client_info.get("empresa_poblacion") or ""

    emisor_text = (
        "<b>EMISOR:</b><br/>"
        "OfiGremio Software & Cloud Services S.L.<br/>"
        "NIF: B-89234501<br/>"
        "Plataforma de Cobro: Stripe Payments Europe, Ltd.<br/>"
        "support@ofigremio.com"
    )
    receptor_text = (
        "<b>CLIENTE / SUSCRIPTOR:</b><br/>"
        f"<b>{empresa_nombre}</b><br/>"
        f"CIF/NIF: {empresa_cif}<br/>"
        f"{empresa_direccion} {empresa_poblacion}<br/>"
        f"HWID: <font face='Courier'>{hwid}</font>"
    )

    parties_data = [
        [
            Paragraph(emisor_text, body_style),
            Paragraph(receptor_text, body_style)
        ]
    ]
    parties_table = Table(parties_data, colWidths=[260, 260])
    parties_table.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#f8fafc')),
        ('PADDING', (0,0), (-1,-1), 10),
        ('BOX', (0,0), (-1,-1), 0.5, colors.HexColor('#cbd5e1')),
        ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor('#cbd5e1')),
    ]))
    elements.append(parties_table)
    elements.append(Spacer(1, 20))

    # 3. Líneas de Factura (Desglose Oficial)
    items_header = [
        Paragraph("<b>Concepto</b>", header_style),
        Paragraph("<b>Período</b>", header_style),
        Paragraph("<b>Base Imp.</b>", header_style),
        Paragraph("<b>IVA (21%)</b>", header_style),
        Paragraph("<b>Total</b>", header_style)
    ]
    item_row = [
        Paragraph("Suscripción Mensual OfiGremio PRO (Mantenimiento, Actualizaciones y Soporte en la Nube)", body_style),
        Paragraph(period_str, body_style),
        Paragraph("12,40 €", body_style),
        Paragraph("2,60 €", body_style),
        Paragraph("15,00 €", bold_style)
    ]

    items_table = Table([items_header, item_row], colWidths=[230, 70, 70, 70, 80])
    items_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#f1f5f9')),
        ('BOTTOMPADDING', (0,0), (-1,-1), 8),
        ('TOPPADDING', (0,0), (-1,-1), 8),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#cbd5e1')),
        ('ALIGN', (2,0), (-1,-1), 'RIGHT'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    elements.append(items_table)
    elements.append(Spacer(1, 16))

    # 4. Cuadro Resumen de Totales y Estado
    totals_data = [
        [Paragraph("Base Imponible (Subtotal):", body_style), Paragraph("12,40 €", body_style)],
        [Paragraph("IVA Repercutido (21%):", body_style), Paragraph("2,60 €", body_style)],
        [Paragraph("<b>TOTAL FACTURA:</b>", total_style), Paragraph("<b>15,00 €</b>", total_style)],
        [Paragraph("<b>Estado:</b>", bold_style), Paragraph("<font color='#16a34a'><b>PAGADO (Stripe Subscription)</b></font>", body_style)]
    ]
    totals_table = Table(totals_data, colWidths=[160, 100])
    totals_table.setStyle(TableStyle([
        ('ALIGN', (0,0), (-1,-1), 'RIGHT'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('LINEABOVE', (0,2), (1,2), 1, colors.HexColor('#0f172a')),
    ]))

    wrapper_data = [[Paragraph("", body_style), totals_table]]
    wrapper_table = Table(wrapper_data, colWidths=[260, 260])
    wrapper_table.setStyle(TableStyle([
        ('ALIGN', (1,0), (1,0), 'RIGHT'),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ]))
    elements.append(wrapper_table)
    elements.append(Spacer(1, 24))

    # 5. Pie de Página Legal
    footer_text = (
        "Factura emitida de conformidad con el Real Decreto 1619/2012 por el que se aprueba el Reglamento por el que se regulan "
        "las obligaciones de facturación. Cobrado automáticamente mediante pasarela de pago seguro Stripe. "
        "Documento con plena validez contable y deducible en Modelo 303 y Modelo 390 de la AEAT."
    )
    elements.append(Paragraph(footer_text, subtitle_style))

    doc.build(elements)


@app.get("/api/license/stripe-invoice")
@app.get("/api/license/stripe/invoice")
def download_stripe_subscription_invoice(user: dict = Depends(require_user)):
    """Genera y descarga la factura oficial de la suscripción mensual de Stripe en PDF (15 €/mes)."""
    current_hwid = license_manager.get_machine_hwid()
    cfg = db.get_config()
    period = datetime.now().strftime("%Y-%m")
    safe_filename = f"Factura_Stripe_OfiGremio_{period}.pdf"

    pdf_dir = os.path.join(DATA_DIR, "pdfs")
    os.makedirs(pdf_dir, exist_ok=True)
    pdf_path = os.path.join(pdf_dir, safe_filename)

    _generate_stripe_subscription_invoice(pdf_path, period, cfg, current_hwid)

    return FileResponse(
        pdf_path,
        media_type="application/pdf",
        filename=safe_filename
    )


@app.post("/api/license/cancel-subscription")
@app.post("/api/license/stripe/cancel")
def cancel_stripe_subscription(user: dict = Depends(require_user)):
    """Cancela la suscripción mensual activa de Stripe y actualiza el estado local."""
    cancel_res = license_manager.cancel_subscription()
    try:
        db.update_config({"subscription_status": "CANCELLED"})
    except Exception:
        pass
    current_status = license_manager.verify_license()
    return {
        "success": True,
        "status": "CANCELLED",
        "message": "Suscripción cancelada correctamente",
        "license": current_status
    }





@app.get("/activacion", response_class=FileResponse)

def get_activation_page():

    act_file = os.path.join(STATIC_DIR, "activacion.html")

    if os.path.exists(act_file):

        return FileResponse(act_file)

    raise HTTPException(status_code=404, detail="Página de activación no encontrada")





@app.get("/api/system/check-updates")

def check_system_updates():

    """Comprueba versión actual y elegibilidad de actualizaciones según licencia."""

    lic = license_manager.verify_license()

    updates_until = lic.get("payload", {}).get("updates_until", "2027-10-29") if lic.get("payload") else "2027-10-29"

    return {

        "current_version": "4.2.1",

        "latest_version": "4.2.1",

        "update_available": False,

        "updates_until": updates_until,

        "eligible_for_updates": True

    }







@app.get("/")

def serve_index():

    lic = license_manager.verify_license()

    if not lic.get("valid"):

        act_file = os.path.join(STATIC_DIR, "activacion.html")

        if os.path.exists(act_file):

            return FileResponse(act_file)

    index_file = os.path.join(STATIC_DIR, "index.html")

    if os.path.exists(index_file):

        return FileResponse(index_file)

    return {"message": "OfiGremio Express API activa. Frontend en /static/index.html"}





@app.get("/sw.js")

def serve_service_worker():

    sw_file = os.path.join(STATIC_DIR, "sw.js")

    if os.path.exists(sw_file):

        return FileResponse(

            sw_file,

            media_type="application/javascript",

            headers={"Service-Worker-Allowed": "/"}

        )

    raise HTTPException(status_code=404, detail="sw.js no encontrado")





@app.get("/api/quotes/{quote_id}/client-view")

def get_quote_client_view(quote_id: int):

    q = db.get_quote(quote_id)

    if not q:

        raise HTTPException(status_code=404, detail="Presupuesto no encontrado")

    cfg = db.get_config()

    return {

        "quote": q,

        "company": {

            "nombre": cfg.get("empresa_nombre", ""),

            "cif": cfg.get("empresa_cif", ""),

            "telefono": cfg.get("empresa_telefono", ""),

            "direccion": cfg.get("empresa_direccion", ""),

            "poblacion": cfg.get("empresa_poblacion", ""),

            "iban": cfg.get("empresa_iban", "")

        }

    }





def _build_quote_email_payload(q: dict, cfg: dict, override_to: str = None) -> dict:

    empresa = cfg.get("empresa_nombre", "Servicio Técnico")

    empresa_email = (cfg.get("empresa_email") or "").strip()

    empresa_tel = (cfg.get("empresa_telefono") or "").strip()

    cliente = q.get("cliente_nombre", "Estimado/a cliente")

    to_email = (override_to if override_to is not None else (q.get("cliente_email") or "")).strip()

    numero = q.get("numero", "PRE-0000")

    numero_factura = (q.get("numero_factura") or "").strip()

    estado = (q.get("estado") or "BORRADOR").upper()

    es_rect = bool(q.get("es_rectificativa")) or numero_factura.startswith("REC-")

    total = float(q.get("total_factura") or 0.0)

    base_imp = float(q.get("base_imponible") or 0.0)

    total_iva = float(q.get("total_iva") or 0.0)

    anticipo = float(q.get("anticipo_importe") or 0.0)

    pendiente = float(q.get("pendiente_cobro") if q.get("pendiente_cobro") is not None else max(0.0, total - anticipo))

    concepto = q.get("concepto_averia", "Intervención técnica")

    huella = (q.get("huella_verifactu") or "").strip()



    if es_rect:

        doc_title = f"Factura Rectificativa {numero_factura or numero}"

        intro = f"Le remitimos la Factura Rectificativa oficial {numero_factura or numero} (Rectifica a: {q.get('numero_factura_origen') or 'Factura original'})."

    elif estado == "COBRADO" and numero_factura:

        doc_title = f"Factura Oficial {numero_factura}"

        intro = f"Le remitimos su Factura Oficial {numero_factura} (Ref. Presupuesto {numero})."

    else:

        doc_title = f"Presupuesto {numero}"

        intro = f"Le remitimos el presupuesto oficial {numero} correspondiente a los trabajos solicitados."



    subject = f"{doc_title} — {empresa}"

    desglose_lines = [

        f"• Intervención: {concepto}",

        f"• Base Imponible: {base_imp:.2f} €",

        f"• IVA aplicable: {total_iva:.2f} €",

        f"• Total Oficial: {total:.2f} €"

    ]

    if anticipo > 0 and not es_rect and estado != "COBRADO":

        desglose_lines.append(f"• Anticipo a cuenta: -{anticipo:.2f} €")

        desglose_lines.append(f"• Importe pendiente de abonar: {pendiente:.2f} €")

    if huella:

        desglose_lines.append(f"• Huella Veri*Factu SHA-256: {huella[:16]}...{huella[-8:]}")



    desglose_str = "\n".join(desglose_lines)
    contacto_footer = f"Tel: {empresa_tel}" + (f" | Correo: {empresa_email}" if empresa_email else "")

    tunnel_file = os.path.join(DATA_DIR, "remote_tunnel.json")
    tunnel_url = ""
    if os.path.exists(tunnel_file):
        try:
            with open(tunnel_file, "r", encoding="utf-8") as f:
                tdata = json.load(f)
                tunnel_url = (tdata.get("tunnel_url") or "").strip()
        except Exception:
            pass
    active_port = os.environ.get("OFIGREMIO_ACTIVE_PORT", "8080")
    base_url = tunnel_url.rstrip("/") if tunnel_url else f"http://localhost:{active_port}"
    doc_url = f"{base_url}/api/quotes/{q.get('id')}/pdf"

    body = (
        f"Hola {cliente},\n\n"
        f"{intro}\n\n"
        f"{desglose_str}\n\n"
        f"📄 Enlace oficial para ver/descargar el documento en PDF:\n{doc_url}\n\n"
        f"Para cualquier consulta o confirmación puede responder directamente a este correo electrónico.\n\n"
        f"Atentamente,\n{empresa}\n{contacto_footer}"
    )
    cc_param = f"&cc={urllib.parse.quote(empresa_email)}" if empresa_email else ""
    mailto_url = f"mailto:{to_email}?subject={urllib.parse.quote(subject)}&body={urllib.parse.quote(body)}{cc_param}"
    return {
        "subject": subject,
        "body": body,
        "to_email": to_email,
        "from_email": empresa_email,
        "empresa_email": empresa_email,
        "mailto_url": mailto_url,
        "pdf_download_url": f"/api/quotes/{q.get('id')}/pdf"
    }





@app.get("/api/quotes/{quote_id}/email-template")

def get_email_template(quote_id: int, user: dict = Depends(require_user)):

    q = db.get_quote(quote_id)

    if not q:

        raise HTTPException(status_code=404, detail="Presupuesto no encontrado")

    cfg = db.get_config()

    return _build_quote_email_payload(q, cfg)





def send_quote_email_service(quote_id: int, target_email: str = None, auto_trigger: bool = False) -> dict:
    """
    Servicio centralizado y robusto de envío de presupuestos y facturas por correo electrónico con adjunto PDF.
    Soporta disparos manuales y automáticos con adjunto PDF.
    En caso de fallos SMTP durante disparos automáticos, no eleva excepciones para no abortar transacciones financieras.
    """
    q = db.get_quote(quote_id)
    if not q:
        if not auto_trigger:
            raise HTTPException(status_code=404, detail="Presupuesto no encontrado")
        return {"status": "error", "message": "Presupuesto no encontrado", "sent_via_smtp": False}

    cfg = db.get_config()
    raw_target = (target_email if target_email is not None else (q.get("cliente_email") or "")).strip()

    if not raw_target:
        email_data = _build_quote_email_payload(q, cfg, override_to="")
        return {
            "status": "mailto_fallback",
            "sent_via_smtp": False,
            **email_data
        }

    if "\r" in raw_target or "\n" in raw_target:
        if not auto_trigger:
            raise HTTPException(status_code=400, detail="Dirección de correo electrónico no válida (caracteres de control detectados)")
        return {"status": "error", "message": "Caracteres de control en email", "sent_via_smtp": False}

    if not re.match(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$", raw_target):
        if not auto_trigger:
            raise HTTPException(status_code=400, detail="El formato del correo electrónico del destinatario no es válido")
        return {"status": "error", "message": "Formato de email inválido", "sent_via_smtp": False}

    # Si el usuario indicó el correo del cliente y no estaba guardado en la ficha, enlazarlo automáticamente
    if raw_target and raw_target != (q.get("cliente_email") or "").strip():
        try:
            db.update_client(int(q["cliente_id"]), {"email": raw_target})
            q = db.get_quote(quote_id)
        except Exception:
            pass

    email_data = _build_quote_email_payload(q, cfg, override_to=raw_target)
    smtp_host = (cfg.get("smtp_host") or "").strip()
    smtp_port = int(cfg.get("smtp_port") or 587)
    smtp_user = (cfg.get("smtp_user") or cfg.get("empresa_email") or "").strip()
    smtp_pass = (cfg.get("smtp_pass") or cfg.get("smtp_password") or "").strip()

    # Prevención SSRF en smtp_host: permitir localhost / 127.0.0.1 solo con bandera de entorno
    allow_local_smtp = os.environ.get("OFIGREMIO_ALLOW_LOCAL_SMTP") == "1"
    if smtp_host and (
        smtp_host.startswith("169.254.")
        or (not allow_local_smtp and smtp_host in ("0.0.0.0", "127.0.0.1", "localhost", "::1"))
        or "\r" in smtp_host
        or "\n" in smtp_host
    ):
        smtp_host = ""

    if smtp_host and raw_target:
        import smtplib
        from email.message import EmailMessage

        try:
            pdf_path = pdf_engine.generate_quote_pdf(q, cfg)
        except Exception:
            pdf_path = ""

        msg = EmailMessage()
        msg["Subject"] = email_data["subject"]
        sender_email = smtp_user or cfg.get("empresa_email") or "notificaciones@ofigremio.es"
        msg["From"] = f"{cfg.get('empresa_nombre', 'OfiGremio')} <{sender_email}>"
        msg["To"] = raw_target
        if email_data.get("from_email"):
            msg["Reply-To"] = email_data["from_email"]
        msg.set_content(email_data["body"])

        if pdf_path and os.path.isfile(pdf_path):
            try:
                with open(pdf_path, "rb") as f:
                    pdf_bytes = f.read()
                doc_num = q.get("numero_factura") if q.get("estado") == "COBRADO" and q.get("numero_factura") else q.get("numero", "documento")
                safe_fname = f"{re.sub(r'[^A-Za-z0-9_\-]', '_', str(doc_num))}.pdf"
                msg.add_attachment(pdf_bytes, maintype="application", subtype="pdf", filename=safe_fname)
            except Exception:
                pass

        try:
            if smtp_port == 465:
                with smtplib.SMTP_SSL(smtp_host, smtp_port, timeout=10) as server:
                    if smtp_user and smtp_pass:
                        server.login(smtp_user, smtp_pass)
                    server.send_message(msg)
            else:
                with smtplib.SMTP(smtp_host, smtp_port, timeout=10) as server:
                    if hasattr(server, "has_extn") and server.has_extn("starttls"):
                        server.starttls()
                    elif not hasattr(server, "has_extn"):
                        try:
                            server.starttls()
                        except Exception:
                            pass
                    if smtp_user and smtp_pass:
                        server.login(smtp_user, smtp_pass)
                    server.send_message(msg)

            return {
                "status": "sent_smtp",
                "sent_via_smtp": True,
                "message": f"Correo enviado automáticamente con PDF adjunto a {raw_target}",
                **email_data
            }
        except Exception as smtp_err:
            return {
                "status": "mailto_fallback",
                "sent_via_smtp": False,
                "smtp_warning": str(smtp_err),
                **email_data
            }

    return {
        "status": "mailto_fallback",
        "sent_via_smtp": False,
        **email_data
    }


@app.post("/api/quotes/{quote_id}/send-email")
def send_quote_email(quote_id: int, payload: SendEmailModel, user: dict = Depends(require_user)):
    raw_target = payload.to_email or payload.email_destino or None
    return send_quote_email_service(quote_id, target_email=raw_target, auto_trigger=False)







# -------------------------------------------------------------

# Endpoints: Proveedores (Suppliers)

# -------------------------------------------------------------

@app.get("/api/suppliers")

def list_suppliers(q: Optional[str] = None, user: dict = Depends(require_user)):

    return db.list_suppliers(search=q)





@app.post("/api/suppliers")

def create_supplier(supplier: SupplierModel, user: dict = Depends(require_user)):

    cif_val = supplier.cif_nif or supplier.cif or ""

    sid = db.create_supplier(

        nombre=supplier.nombre,

        cif_nif=cif_val,

        telefono=supplier.telefono,

        email=supplier.email,

        contacto=supplier.contacto,

        direccion=supplier.direccion,

        poblacion=supplier.poblacion,

        notas=supplier.notas

    )

    return db.get_supplier(sid)





@app.get("/api/suppliers/{supplier_id}")

def get_supplier(supplier_id: int, user: dict = Depends(require_user)):

    sup = db.get_supplier(supplier_id)

    if not sup:

        raise HTTPException(status_code=404, detail="Proveedor no encontrado")

    return sup





@app.put("/api/suppliers/{supplier_id}")

def update_supplier(supplier_id: int, supplier: SupplierUpdateModel, user: dict = Depends(require_user)):

    dumped = supplier.model_dump()

    if dumped.get("cif") and not dumped.get("cif_nif"):

        dumped["cif_nif"] = dumped["cif"]

    payload = {k: v for k, v in dumped.items() if v is not None and k != "cif"}

    updated = db.update_supplier(supplier_id, payload)

    if not updated:

        raise HTTPException(status_code=404, detail="Proveedor no encontrado")

    return updated





@app.delete("/api/suppliers/{supplier_id}")

def delete_supplier(supplier_id: int, user: dict = Depends(require_admin)):

    sup = db.get_supplier(supplier_id)

    if not sup:

        raise HTTPException(status_code=404, detail="Proveedor no encontrado")

    try:

        deleted = db.delete_supplier(supplier_id)

        if not deleted:

            raise HTTPException(status_code=404, detail="Proveedor no encontrado")

        return {"status": "deleted", "id": supplier_id}

    except ValueError as e:

        raise HTTPException(status_code=400, detail=str(e))





# -------------------------------------------------------------

# Endpoints: Compras y Gastos de Material

# -------------------------------------------------------------

@app.get("/api/expenses")

def list_expenses(gremio: Optional[str] = None, user: dict = Depends(require_user)):

    return db.list_expenses(gremio=gremio)





@app.post("/api/expenses")

def create_expense(expense: ExpenseCreateModel, user: dict = Depends(require_user)):

    try:

        exp_data = {

            "numero_factura": expense.numero_factura,

            "proveedor_id": expense.proveedor_id,

            "fecha": expense.fecha or datetime.now().strftime("%Y-%m-%d"),

            "concepto": expense.concepto,

            "base_imponible": expense.base_imponible,

            "iva_porcentaje": expense.iva_porcentaje or 0.21,

            "forma_pago": expense.forma_pago or "TRANSFERENCIA",

            "estado": expense.estado or "PAGADO",

            "notas": expense.notas or ""

        }

        items = [it.model_dump() for it in expense.items] if expense.items else []

        created = db.create_expense(exp_data, items=items)

        return created

    except Exception as e:

        raise HTTPException(status_code=400, detail=str(e))





@app.get("/api/expenses/{expense_id}")

def get_expense(expense_id: int, user: dict = Depends(require_user)):

    exp = db.get_expense(expense_id)

    if not exp:

        raise HTTPException(status_code=404, detail="Gasto no encontrado")

    return exp





@app.delete("/api/expenses/{expense_id}")

def delete_expense(expense_id: int, user: dict = Depends(require_admin)):

    exp = db.get_expense(expense_id)

    if not exp:

        raise HTTPException(status_code=404, detail="Gasto no encontrado")

    db.delete_expense(expense_id)

    return {"status": "deleted", "id": expense_id}





# -------------------------------------------------------------

# Endpoints: Stock, Almacén y Alertas

# -------------------------------------------------------------

@app.get("/api/stock")

def get_stock(gremio: Optional[str] = None, user: dict = Depends(require_user)):

    return db.list_catalog(gremio=gremio)





@app.get("/api/stock/alerts")

def get_stock_alerts(user: dict = Depends(require_user)):

    return db.list_stock_alerts()





@app.get("/api/stock/summary")

def get_stock_summary(user: dict = Depends(require_user)):

    return db.get_stock_summary()





@app.post("/api/stock/adjust")

def adjust_stock(adj: StockAdjustModel, user: dict = Depends(require_user)):

    try:

        res = db.adjust_stock(adj.catalogo_id, adj.cantidad_cambio, motivo=adj.motivo or "Ajuste manual")

        return res

    except ValueError as e:

        raise HTTPException(status_code=404, detail=str(e))







# -------------------------------------------------------------

# Endpoints: Asistente Tecnico Chatbot Local y Memoria de Negocio

# -------------------------------------------------------------

@app.post("/api/assistant/chat")

def assistant_chat(payload: AssistantChatModel, user: dict = Depends(require_user)):

    try:

        return local_ai_assistant.chat(payload.message, payload.context, user=user)

    except Exception as e:

        raise HTTPException(status_code=500, detail=f"Error en motor asistente: {str(e)}")





@app.get("/api/assistant/llm-status")

def get_assistant_llm_status(user: dict = Depends(require_user)):

    return local_ai_assistant.get_llm_status()





@app.post("/api/assistant/setup-llm")

def setup_assistant_local_llm(user: dict = Depends(require_user)):

    return local_ai_assistant.start_llm_setup_background()





@app.post("/api/assistant/reset-session")

def reset_assistant_session(user: dict = Depends(require_user)):

    local_ai_assistant.reset_session(user=user)

    return {"status": "ok"}





@app.get("/api/assistant/memory")

def get_assistant_memory(key: Optional[str] = None, user: dict = Depends(require_user)):

    return db.get_assistant_memory(key=key)





@app.post("/api/assistant/memory")

def set_assistant_memory(item: AssistantMemoryModel, user: dict = Depends(require_user)):

    try:

        return db.set_assistant_memory(item.key, item.value, item.category)

    except Exception as e:

        raise HTTPException(status_code=400, detail=str(e))





@app.delete("/api/assistant/memory/{key}")

def delete_assistant_memory(key: str, user: dict = Depends(require_user)):

    ok = db.delete_assistant_memory(key)

    if not ok:

        raise HTTPException(status_code=404, detail="Clave no encontrada")

    return {"status": "deleted", "key": key}







# -------------------------------------------------------------

# Endpoints: Iconos Oficiales y Conexión Móvil en Red Local

# -------------------------------------------------------------

@app.get("/favicon.ico", include_in_schema=False)

def get_favicon():

    fav = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "favicon.ico")

    if os.path.exists(fav):

        return FileResponse(fav, media_type="image/x-icon")

    return Response(status_code=404)





@app.get("/apple-touch-icon.png", include_in_schema=False)

def get_apple_touch_icon():

    ico = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "apple-touch-icon.png")

    if os.path.exists(ico):

        return FileResponse(ico, media_type="image/png")

    return Response(status_code=404)





def _get_local_ip() -> str:

    import socket

    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    try:

        s.connect(("10.255.255.255", 1))

        ip = s.getsockname()[0]

    except Exception:

        ip = "127.0.0.1"

    finally:

        s.close()

    return ip





@app.get("/api/system/network-info")

def get_system_network_info():

    """Devuelve la IP de red local, puerto activo y estado del túnel remoto 4G para conectar móviles por código QR."""

    local_ip = _get_local_ip()

    port = int(os.environ.get("OFIGREMIO_ACTIVE_PORT") or os.environ.get("OFIGREMIO_PORT") or 8080)

    local_url = f"http://{local_ip}:{port}"



    local_qr_b64 = ""

    try:

        import io

        import base64

        import qrcode

        qr = qrcode.QRCode(box_size=6, border=2)

        qr.add_data(local_url)

        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white")

        buf = io.BytesIO()

        img.save(buf, format="PNG")

        local_qr_b64 = f"data:image/png;base64,{base64.b64encode(buf.getvalue()).decode('ascii')}"

    except Exception:

        pass



    tunnel_data = {}

    tunnel_file = os.path.join(DATA_DIR, "remote_tunnel.json")

    if os.path.exists(tunnel_file):

        try:

            with open(tunnel_file, "r", encoding="utf-8") as f:

                tunnel_data = json.load(f)

        except Exception:

            pass



    return {

        "local_ip": local_ip,

        "port": port,

        "local_url": local_url,

        "local_qr_b64": local_qr_b64,

        "loopback_url": f"http://127.0.0.1:{port}",

        "remote_tunnel_active": bool(tunnel_data.get("tunnel_url")),

        "remote_tunnel_url": tunnel_data.get("tunnel_url", ""),

        "remote_qr_b64": tunnel_data.get("qr_data_uri", ""),

        "remote_created_at": tunnel_data.get("created_at", "")

    }





def find_available_port(preferred_port: int = 8080, max_attempts: int = 50) -> int:

    """Busca el primer puerto libre a partir del preferido para evitar bloqueos por colisión."""

    import socket

    for p in range(preferred_port, preferred_port + max_attempts):

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:

            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

            try:

                s.bind(("0.0.0.0", p))

                return p

            except OSError:

                continue

    return preferred_port







# =========================================================================
# ENDPOINTS OFICIALES VERI*FACTU & AGENCIA TRIBUTARIA (AEAT RD 1007/2023)
# =========================================================================
@app.get("/api/verifactu/status")
def get_verifactu_status(user: dict = Depends(require_user)):
    """Devuelve métricas e informe de cumplimiento oficial Veri*Factu (RD 1007/2023)."""
    return db.get_verifactu_summary()


@app.post("/api/verifactu/upload-cert")
async def upload_verifactu_certificate(
    file: UploadFile = File(...),
    password: str = Form(""),
    user: dict = Depends(require_admin)
):
    """Sube y almacena de forma segura el certificado digital (.p12/.pfx) para la AEAT."""
    fn = file.filename.lower()
    if not (fn.endswith(".p12") or fn.endswith(".pfx") or fn.endswith(".pem")):
        raise HTTPException(status_code=400, detail="El archivo debe ser un certificado digital válido (.p12, .pfx o .pem)")

    contents = await file.read()
    res = verifactu_engine.save_aeat_certificate(contents, file.filename, password)
    if res.get("success"):
        db.update_config({
            "verifactu_cert_path": res["path"],
            "verifactu_cert_pass": password
        })
    return res


@app.get("/api/quotes/{quote_id}/verifactu-xml")
def get_quote_verifactu_xml(quote_id: int, user: dict = Depends(require_user)):
    """Devuelve el XML oficial de RegistroFacturacionAlta (AEAT) para inspección o auditoría."""
    q = db.get_quote(quote_id)
    if not q or not q.get("numero_factura"):
        raise HTTPException(status_code=404, detail="Factura no encontrada o no emitida")
    cfg = db.get_config()
    xml_str = verifactu_engine.build_verifactu_xml(
        q, cfg, q.get("huella_verifactu", ""), q.get("huella_anterior", "GENESIS")
    )
    return Response(
        content=xml_str,
        media_type="application/xml",
        headers={"Content-Disposition": f"attachment; filename=VeriFactu_{q.get('numero_factura')}.xml"}
    )


@app.post("/api/quotes/{quote_id}/verifactu-retry")
def retry_quote_verifactu(quote_id: int, user: dict = Depends(require_admin)):
    """Reintenta el envío de la factura a la AEAT y actualiza el estado y CSV."""
    q = db.get_quote(quote_id)
    if not q or not q.get("numero_factura"):
        raise HTTPException(status_code=404, detail="Factura no encontrada o no emitida")
    cfg = db.get_config()
    res_aeat = verifactu_engine.send_invoice_to_aeat(
        q, cfg, q.get("huella_verifactu", ""), q.get("huella_anterior", "GENESIS")
    )
    vf_status = res_aeat.get("status", "ACEPTADO")
    vf_csv = res_aeat.get("csv_aeat") or ""
    vf_fecha = res_aeat.get("fecha_envio") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE presupuestos
            SET verifactu_estado = ?, verifactu_csv = ?,
                verifactu_fecha_envio = ?, verifactu_respuesta_aeat = ?
            WHERE id = ?;
        """, (vf_status, vf_csv, vf_fecha, json.dumps(res_aeat, ensure_ascii=False), quote_id))
        conn.commit()
    return db.get_quote(quote_id)


if __name__ == "__main__":

    import uvicorn

    import json



    preferred_port = int(os.environ.get("OFIGREMIO_PORT", 8080))

    host = os.environ.get("OFIGREMIO_HOST", "0.0.0.0")

    port = find_available_port(preferred_port=preferred_port)



    os.environ["OFIGREMIO_ACTIVE_PORT"] = str(port)



    # Guardar estado activo en data/server_info.json

    try:

        data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

        os.makedirs(data_dir, exist_ok=True)

        info_file = os.path.join(data_dir, "server_info.json")

        with open(info_file, "w", encoding="utf-8") as f:

            json.dump({

                "host": host,

                "port": port,

                "local_ip": _get_local_ip(),

                "url": f"http://localhost:{port}",

                "network_url": f"http://{_get_local_ip()}:{port}",

                "started_at": datetime.now().isoformat()

            }, f, indent=2)

    except Exception:

        pass



    if port != preferred_port:

        print(f"[AVISO] DE SEGURIDAD] Puerto {preferred_port} ocupado por otro programa. Asignado puerto dinámico libre: {port}")

    else:

        print(f"[OK] OfiGremio PRO enlazado correctamente en puerto: {port}")



    uvicorn.run(app, host=host, port=port)

