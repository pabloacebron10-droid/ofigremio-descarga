#!/usr/bin/env bash
# =========================================================================
# OfiGremio PRO v4.2.1 — Instalador Automatizado para Linux (Solo 1a Vez)
# Configura Python 3, entorno virtual aislado, dependencias y accesos directos.
# =========================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "========================================================================="
echo "   OfiGremio PRO v4.2.1 — Instalador para Linux"
echo "   Software Local-First para Gremios, Instaladores y Reformas"
echo "========================================================================="
echo ""

# 1. Comprobar Python 3
echo "[1/4] Comprobando entorno de ejecución Python 3..."
if ! command -v python3 &>/dev/null; then
    echo ""
    echo "========================================================================="
    echo "[ERROR] Python 3 no está instalado en este equipo."
    echo "Instálelo en su terminal ejecutando:"
    echo "  sudo apt update && sudo apt install -y python3 python3-venv python3-pip"
    echo "========================================================================="
    exit 1
fi
echo "[OK] Python 3 detectado: $(python3 --version)"

# 2. Comprobar / Crear entorno virtual .venv
echo ""
echo "[2/4] Configurando Entorno Virtual Aislado (.venv)..."
if [ ! -d ".venv" ]; then
    if ! python3 -m venv .venv 2>/dev/null; then
        echo ""
        echo "========================================================================="
        echo "[AVISO] En Ubuntu/Debian se requiere el paquete 'python3-venv'."
        echo "Por favor ejecute en su terminal este comando para solucionarlo:"
        echo ""
        echo "  sudo apt update && sudo apt install -y python3-venv python3-pip"
        echo ""
        echo "Y a continuación vuelva a ejecutar: bash 1_instalar_primera_vez.sh"
        echo "========================================================================="
        exit 1
    fi
    echo "[OK] Entorno virtual privado creado con éxito."
else
    echo "[OK] Entorno virtual existente detectado."
fi

# 3. Instalar dependencias oficiales en el entorno virtual
echo ""
echo "[3/4] Instalando dependencias oficiales (FastAPI, ReportLab, etc.)..."
.venv/bin/python -m pip install --upgrade pip --quiet 2>/dev/null || true
.venv/bin/python -m pip install -r requirements.txt --quiet
echo "[OK] Todas las dependencias han quedado instaladas y verificadas."

# 4. Crear acceso directo en el Menú de Aplicaciones y Escritorio
echo ""
echo "[4/4] Creando lanzadores de escritorio y menú..."

# Asegurar permisos de ejecución en scripts
chmod +x "$SCRIPT_DIR/2_abrir_ofigremio.sh" 2>/dev/null || true

ICON_PATH="$SCRIPT_DIR/static/icon-192.png"
DESKTOP_ENTRY_CONTENT="[Desktop Entry]
Version=1.0
Type=Application
Name=OfiGremio PRO
Comment=Gestión Integral para Gremios, Presupuestos y Facturación
Path=$SCRIPT_DIR
Exec=/bin/bash \"$SCRIPT_DIR/2_abrir_ofigremio.sh\"
Icon=$ICON_PATH
Terminal=false
Categories=Office;Finance;
StartupNotify=true"

# A) Registrar en el menú de aplicaciones del sistema (~/.local/share/applications)
MENU_DIR="$HOME/.local/share/applications"
mkdir -p "$MENU_DIR" 2>/dev/null || true
echo "$DESKTOP_ENTRY_CONTENT" > "$MENU_DIR/OfiGremio.desktop"
chmod +x "$MENU_DIR/OfiGremio.desktop" 2>/dev/null || true
echo "[OK] Añadido al menú de aplicaciones del sistema (busca 'OfiGremio' en tu menú)."

# B) Copiar al Escritorio si existe
for d in "$HOME/Desktop" "$HOME/Escritorio"; do
    if [ -d "$d" ]; then
        echo "$DESKTOP_ENTRY_CONTENT" > "$d/OfiGremio.desktop"
        chmod +x "$d/OfiGremio.desktop" 2>/dev/null || true
        # Si es GNOME, marcar como ejecutable de confianza si gio está presente
        if command -v gio &>/dev/null; then
            gio set "$d/OfiGremio.desktop" metadata::trusted true 2>/dev/null || true
        fi
        echo "[OK] Acceso directo creado en: $d/OfiGremio.desktop"
    fi
done

echo ""
echo "========================================================================="
echo "   [INSTALACIÓN COMPLETADA CON ÉXITO]"
echo "   OfiGremio PRO está 100% configurado y listo para usar en Linux."
echo "========================================================================="
echo ""
echo "Iniciando OfiGremio PRO ahora mismo..."
exec /bin/bash "$SCRIPT_DIR/2_abrir_ofigremio.sh"
