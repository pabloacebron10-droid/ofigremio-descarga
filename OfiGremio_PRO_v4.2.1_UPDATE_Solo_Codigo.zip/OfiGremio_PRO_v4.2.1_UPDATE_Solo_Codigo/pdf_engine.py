"""
Motor de Generación de Presupuestos y Facturas Profesionales en PDF con ReportLab (OfiGremio PRO v3.7.0).
Diseñado para instaladores, fontaneros y profesionales de gremios técnicos.
Incluye soporte para Factura Oficial correlativa, Descuentos, Retención IRPF,
Código QR vectorial VeriFactu/Pago, Firma Digital manuscrita Base64 y Foto de Evidencia.
"""

import os
import io
import re
import base64
import html
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.graphics.barcode.qr import QrCodeWidget
from reportlab.graphics.shapes import Drawing

PDF_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "pdfs")


def _decode_base64_image(b64_str: str, max_width: float = 120.0, max_height: float = 55.0):
    """
    Decodifica de forma segura una imagen Base64 (con o sin prefijo data:image/...;base64,)
    y devuelve un objeto reportlab.platypus.Image listo para incrustar, o None si no es válido.
    """
    if not b64_str or not isinstance(b64_str, str) or not b64_str.strip():
        return None
    try:
        clean_b64 = b64_str.strip()
        if "," in clean_b64:
            clean_b64 = clean_b64.split(",", 1)[1]
        raw_bytes = base64.b64decode(clean_b64)
        if not raw_bytes or len(raw_bytes) < 16:
            return None
        img_buffer = io.BytesIO(raw_bytes)
        img = Image(img_buffer, width=max_width, height=max_height, kind="proportional")
        return img
    except Exception:
        return None



def _safe_wrap_text(text: str, max_chunk: int = 30) -> str:
    """Inserta espacios suaves en cadenas continuas muy largas para que ReportLab siempre pueda ajustarlas a las celdas sin desbordar."""
    if not text:
        return ""
    words = str(text).split(" ")
    safe_words = []
    for w in words:
        if len(w) > max_chunk:
            chunks = [w[i:i+max_chunk] for i in range(0, len(w), max_chunk)]
            safe_words.append(" ".join(chunks))
        else:
            safe_words.append(w)
    return " ".join(safe_words)


def _safe_chunk_text(text: str, max_chunk_len: int = 350) -> list:
    """
    Divide un texto largo en bloques de tamaño seguro respetando límites de palabras,
    permitiendo que ReportLab pagine subfilas sin desbordar el alto de página (LayoutError).
    """
    if not text:
        return [""]
    words = str(text).split(" ")
    chunks = []
    current_chunk = []
    current_len = 0
    for w in words:
        if current_len + len(w) + 1 > max_chunk_len and current_chunk:
            chunks.append(" ".join(current_chunk))
            current_chunk = [w]
            current_len = len(w)
        else:
            current_chunk.append(w)
            current_len += len(w) + 1
    if current_chunk:
        chunks.append(" ".join(current_chunk))
    return chunks


def _build_qr_drawing(qr_payload: str, size: float = 64.0) -> Drawing:
    """
    Genera un código QR vectorial nativo en ReportLab sin dependencias externas de imágenes.
    """
    qr_widget = QrCodeWidget(qr_payload)
    bounds = qr_widget.getBounds()
    width = max(bounds[2] - bounds[0], 1.0)
    height = max(bounds[3] - bounds[1], 1.0)
    drawing = Drawing(size, size, transform=[size / width, 0, 0, size / height, 0, 0])
    drawing.add(qr_widget)
    return drawing


def generate_quote_pdf(quote_data: dict, company_config: dict) -> str:
    """
    Genera un documento PDF formal y limpio para un presupuesto o factura oficial OfiGremio PRO v3.7.0.
    """
    os.makedirs(PDF_DIR, exist_ok=True)
    raw_num = str(quote_data.get("numero", "PRE-0001"))
    num_safe = re.sub(r'[^A-Za-z0-9_\-]', '_', raw_num)
    output_path = os.path.abspath(os.path.join(PDF_DIR, f"{num_safe}.pdf"))
    if not output_path.startswith(os.path.abspath(PDF_DIR)):
        raise ValueError("Ruta de archivo no autorizada (Path Traversal prevenido)")

    doc = SimpleDocTemplate(
        output_path,
        pagesize=A4,
        rightMargin=27,
        leftMargin=27,
        topMargin=30,
        bottomMargin=30
    )
    styles = getSampleStyleSheet()
    story = []

    # Paleta de colores profesionales
    PRIMARY_COLOR = colors.HexColor("#0F172A")
    ACCENT_COLOR = colors.HexColor("#2563EB")   # Azul marino profesional
    SECONDARY_COLOR = colors.HexColor("#2B6CB0") # Azul acero
    TEXT_MUTED = colors.HexColor("#4A5568")      # Gris oscuro legible
    BG_LIGHT = colors.HexColor("#F7FAFC")        # Gris tenue

    estado = (quote_data.get("estado") or "BORRADOR").upper()
    es_rectificativa = bool(quote_data.get("es_rectificativa")) or str(quote_data.get("numero_factura") or "").startswith("REC-")
    is_factura = estado in ("COBRADO", "FACTURADO") or es_rectificativa
    numero_presupuesto = quote_data.get("numero", "PRE-0001")
    numero_factura = quote_data.get("numero_factura")
    fecha_factura = quote_data.get("fecha_factura") or quote_data.get("fecha", "")

    # Configuración del badge según estado
    badge_map = {
        "COBRADO": ("PAGADO / FACTURA OFICIAL", "#22543D", "#C6F6D5"),
        "APROBADO": ("PRESUPUESTO APROBADO", "#2A4365", "#BEE3F8"),
        "ENVIADO": ("ENVIADO AL CLIENTE", "#744210", "#FEFCBF"),
        "CANCELADO": ("PRESUPUESTO CANCELADO", "#742A2A", "#FED7D7"),
        "BORRADOR": ("BORRADOR PROVISIONAL", "#4A5568", "#EDF2F7"),
    }
    if es_rectificativa:
        badge_label, badge_fg, badge_bg = ("FACTURA RECTIFICATIVA / ABONO", "#9B2C2C", "#FED7D7")
    else:
        badge_label, badge_fg, badge_bg = badge_map.get(estado, badge_map["BORRADOR"])

    # Estilos tipográficos
    title_style = ParagraphStyle(
        "DocTitle",
        parent=styles["Heading1"],
        fontName="Helvetica-Bold",
        fontSize=16,
        leading=20,
        textColor=PRIMARY_COLOR,
        alignment=2,
        spaceAfter=2
    )
    doc_meta_style = ParagraphStyle(
        "DocMeta",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=8.5,
        leading=12,
        textColor=TEXT_MUTED,
        alignment=2
    )
    badge_style = ParagraphStyle(
        "StatusBadge",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=8,
        leading=10,
        textColor=colors.HexColor(badge_fg),
        alignment=1
    )
    bold_label = ParagraphStyle(
        "BoldLabel",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=9,
        textColor=PRIMARY_COLOR
    )
    regular_text = ParagraphStyle(
        "RegularText",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=8.5,
        leading=12,
        textColor=TEXT_MUTED,
        wordWrap="CJK"
    )
    item_desc_style = ParagraphStyle(
        "ItemDesc",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=8.5,
        leading=11,
        textColor=PRIMARY_COLOR,
        wordWrap="CJK"
    )
    item_tipo_style = ParagraphStyle(
        "ItemTipo",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=7.5,
        leading=9.5,
        textColor=TEXT_MUTED
    )
    item_num_style = ParagraphStyle(
        "ItemNum",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=8.5,
        leading=11,
        textColor=PRIMARY_COLOR,
        alignment=2
    )
    item_hdr_left = ParagraphStyle(
        "ItemHdrLeft",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=8.5,
        leading=11,
        textColor=colors.whitesmoke,
        alignment=0
    )
    item_hdr_right = ParagraphStyle(
        "ItemHdrRight",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=8.5,
        leading=11,
        textColor=colors.whitesmoke,
        alignment=2
    )
    small_muted = ParagraphStyle(
        "SmallMuted",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=7.5,
        leading=10,
        textColor=colors.HexColor("#718096")
    )

    # 1. ENCABEZADO: Datos de la Empresa y Datos del Documento
    empresa_nombre = html.escape(str(company_config.get("empresa_nombre", "Servicios Profesionales")))
    empresa_cif = html.escape(str(company_config.get("empresa_cif", "B-00000000")))
    empresa_tel = html.escape(str(company_config.get("empresa_telefono", "+34 600 000 000")))
    empresa_email = html.escape(str(company_config.get("empresa_email", "contacto@empresa.com")))
    empresa_dir = html.escape(str(company_config.get("empresa_direccion", "Dirección Fiscal")))
    empresa_pob = html.escape(str(company_config.get("empresa_poblacion", "Madrid")))

    esc_numero_presupuesto = html.escape(str(numero_presupuesto))
    esc_badge_label = html.escape(str(badge_label))

    if es_rectificativa:
        display_factura_num = numero_factura or numero_presupuesto
        esc_display_factura_num = html.escape(str(display_factura_num))
        esc_fecha_factura = html.escape(str(fecha_factura))
        orig_ref = html.escape(str(quote_data.get("numero_factura_origen") or "Factura Original"))
        doc_title_html = f"<b>FACTURA RECTIFICATIVA Nº: {esc_display_factura_num}</b>"
        doc_meta_html = (
            f"Rectifica a Factura: {orig_ref} | Fecha: {esc_fecha_factura}<br/>"
            f"<b>Estado:</b> {esc_badge_label}"
        )
        doc_num_for_qr = display_factura_num
    elif is_factura:
        display_factura_num = numero_factura or f"FAC-{numero_presupuesto}"
        esc_display_factura_num = html.escape(str(display_factura_num))
        esc_fecha_factura = html.escape(str(fecha_factura))
        doc_title_html = f"<b>FACTURA OFICIAL Nº: {esc_display_factura_num}</b>"
        doc_meta_html = (
            f"Ref. Presupuesto: {esc_numero_presupuesto} | Fecha Factura: {esc_fecha_factura}<br/>"
            f"<b>Estado:</b> {esc_badge_label}"
        )
        doc_num_for_qr = numero_factura
    else:
        doc_type = "FACTURA" if is_factura else "PRESUPUESTO"
        doc_title_html = f"<b>{html.escape(str(doc_type))} Nº: {esc_numero_presupuesto}</b>"
        doc_meta_html = (
            f"<b>Fecha:</b> {html.escape(str(quote_data.get('fecha', '')))}<br/>"
            f"<b>Estado:</b> {esc_badge_label}"
        )
        doc_num_for_qr = numero_presupuesto

    badge_box = Table([[Paragraph(esc_badge_label, badge_style)]], colWidths=[165])
    badge_box.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor(badge_bg)),
        ("BOX", (0, 0), (-1, -1), 0.75, colors.HexColor(badge_fg)),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))

    right_header_stack = [
        Paragraph(doc_title_html, title_style),
        Paragraph(doc_meta_html, doc_meta_style),
        Spacer(1, 4),
        badge_box
    ]

    header_table_data = [
        [
            Paragraph(
                f"<b>{empresa_nombre}</b><br/>"
                f"CIF/NIF: {empresa_cif}<br/>"
                f"{empresa_dir} - {empresa_pob}<br/>"
                f"Tel: {empresa_tel} | {empresa_email}",
                regular_text
            ),
            right_header_stack
        ]
    ]
    header_table = Table(header_table_data, colWidths=[310, 230])
    header_table.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("ALIGN", (1, 0), (1, 0), "RIGHT"),
    ]))
    story.append(header_table)
    story.append(Spacer(1, 12))

    # 2. DATOS DEL CLIENTE Y TRABAJO
    cliente_nombre = _safe_wrap_text(quote_data.get("cliente_nombre", "Cliente General"), max_chunk=32)
    cliente_nif = quote_data.get("cliente_nif_cif") or "-"
    cliente_tel = quote_data.get("cliente_telefono") or "-"
    cliente_dir = _safe_wrap_text(quote_data.get("cliente_direccion") or "-", max_chunk=35)
    cliente_pob = _safe_wrap_text(quote_data.get("cliente_poblacion") or "-", max_chunk=25)
    raw_concepto = quote_data.get("concepto_averia", "Reparación y mantenimiento")
    concepto = _safe_wrap_text(raw_concepto, max_chunk=35)
    garantia_meses = int(quote_data.get("garantia_meses") if quote_data.get("garantia_meses") is not None else 6)

    is_long_concepto = len(concepto) > 280
    if is_long_concepto:
        concepto_cell_html = f"<b>Concepto:</b> {html.escape(str(concepto[:240]))}... <i>(continúa en detalle ampliado)</i>"
    else:
        concepto_cell_html = f"<b>Concepto:</b> {html.escape(str(concepto))}"

    client_box_data = [
        [
            Paragraph("<b>DATOS DEL CLIENTE / INSTALACIÓN</b>", bold_label),
            Paragraph("<b>DETALLE DEL PARTE / INTERVENCIÓN</b>", bold_label)
        ],
        [
            Paragraph(
                f"<b>Nombre / Razón Social:</b> {html.escape(str(cliente_nombre))}<br/>"
                f"<b>NIF / CIF:</b> {html.escape(str(cliente_nif))} &nbsp;&nbsp;|&nbsp;&nbsp; <b>Tel:</b> {html.escape(str(cliente_tel))}<br/>"
                f"<b>Ubicación:</b> {html.escape(str(cliente_dir))}, {html.escape(str(cliente_pob))}",
                regular_text
            ),
            Paragraph(
                f"{concepto_cell_html}<br/>"
                f"<b>Tarifa Aplicada:</b> {'URGENCIA 24H / FESTIVO' if quote_data.get('es_urgencia') else 'Servicio Estándar'}<br/>"
                f"<b>Garantía escrita:</b> {garantia_meses} meses",
                regular_text
            )
        ]
    ]
    client_table = Table(client_box_data, colWidths=[270, 270])
    client_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), BG_LIGHT),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E0")),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#E2E8F0")),
        ("PADDING", (0, 0), (-1, -1), 6),
        ("VALIGN", (0, 0), (-1, -1), "TOP")
    ]))
    story.append(client_table)
    story.append(Spacer(1, 8))

    if is_long_concepto:
        story.append(Paragraph(f"<b>Detalle Ampliado de la Avería / Intervención:</b><br/>{html.escape(str(concepto))}", regular_text))
        story.append(Spacer(1, 10))

    # 3. TABLA DE CONCEPTOS, MATERIALES Y MANO DE OBRA
    table_headers = [[
        Paragraph("Concepto / Partida Técnica", item_hdr_left),
        Paragraph("Tipo", item_hdr_left),
        Paragraph("Cant.", item_hdr_right),
        Paragraph("Precio Unit.", item_hdr_right),
        Paragraph("Total", item_hdr_right)
    ]]
    items_rows = []

    horas_mo = float(quote_data.get("horas_mano_obra") if quote_data.get("horas_mano_obra") is not None else 1.0)
    precio_hora = float(quote_data.get("precio_hora") if quote_data.get("precio_hora") is not None else 38.0)
    tot_mo = horas_mo * precio_hora
    items_rows.append([
        Paragraph("Mano de obra técnica cualificada", item_desc_style),
        Paragraph("TRABAJO", item_tipo_style),
        Paragraph(f"{horas_mo:.1f} h", item_num_style),
        Paragraph(f"{precio_hora:.2f} €", item_num_style),
        Paragraph(f"{tot_mo:.2f} €", item_num_style)
    ])

    if quote_data.get("es_urgencia") and float(quote_data.get("recargo_urgencia") or 0) > 0:
        rec = float(quote_data.get("recargo_urgencia"))
        items_rows.append([
            Paragraph("Recargo por intervención de urgencia / festivo", item_desc_style),
            Paragraph("URGENCIA", item_tipo_style),
            Paragraph("1.0 u", item_num_style),
            Paragraph(f"{rec:.2f} €", item_num_style),
            Paragraph(f"{rec:.2f} €", item_num_style)
        ])

    for p in quote_data.get("partidas", []):
        desc = _safe_wrap_text(p.get("descripcion", "Material"), max_chunk=28)
        tipo = _safe_wrap_text(p.get("tipo", "MATERIAL"), max_chunk=12)
        cant = float(p.get("cantidad", 1.0))
        pu = float(p.get("precio_unitario", 0.0))
        sub = float(p.get("subtotal", cant * pu))

        chunks = _safe_chunk_text(desc, max_chunk_len=350)
        # Primera fila con detalles financieros y primer chunk de descripción
        items_rows.append([
            Paragraph(html.escape(str(chunks[0])), item_desc_style),
            Paragraph(html.escape(str(tipo)), item_tipo_style),
            Paragraph(f"{cant:.1f}", item_num_style),
            Paragraph(f"{pu:.2f} €", item_num_style),
            Paragraph(f"{sub:.2f} €", item_num_style)
        ])
        # Subfilas de continuación para descripciones ultra-largas (hasta 5000 chars)
        for c in chunks[1:]:
            items_rows.append([
                Paragraph(html.escape(str(c)), item_desc_style),
                "", "", "", ""
            ])

    full_items_data = table_headers + items_rows
    items_table = Table(full_items_data, colWidths=[240, 65, 45, 95, 95], repeatRows=1, splitByRow=1)
    items_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), PRIMARY_COLOR),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E0")),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(items_table)
    story.append(Spacer(1, 10))

    # 4. TOTALES, DESCUENTOS, IVA, IRPF Y CÓDIGO QR VERIFACTU/PAGO
    subtotal = float(quote_data.get("subtotal_general") or 0.0)
    desc_pct = float(quote_data.get("descuento_porcentaje") or 0.0)
    total_desc = float(quote_data.get("total_descuento") or 0.0)
    base_imponible = float(quote_data.get("base_imponible") or (subtotal - total_desc))
    iva_pct = float(quote_data.get("iva_porcentaje") if quote_data.get("iva_porcentaje") is not None else 0.21)
    iva_rate = iva_pct / 100.0 if iva_pct > 1 else iva_pct
    total_iva = float(quote_data.get("total_iva") if quote_data.get("total_iva") is not None else round(base_imponible * iva_rate, 2))
    irpf_pct = float(quote_data.get("irpf_porcentaje") or 0.0)
    irpf_rate = irpf_pct / 100.0 if irpf_pct > 1 else irpf_pct
    total_irpf = float(quote_data.get("total_irpf") or 0.0)
    total_factura = float(quote_data.get("total_factura") or (base_imponible + total_iva - total_irpf))
    anticipo_importe = float(quote_data.get("anticipo_importe") or 0.0)
    pendiente_cobro = float(quote_data.get("pendiente_cobro") if quote_data.get("pendiente_cobro") is not None else max(0.0, total_factura - anticipo_importe))
    huella_verifactu = str(quote_data.get("huella_verifactu") or "").strip()
    iban = company_config.get("empresa_iban", "ES00 0000 0000 0000 0000")

    # Generar Código QR vectorial VeriFactu / Pago
    huella_short = f"{huella_verifactu[:12]}...{huella_verifactu[-8:]}" if len(huella_verifactu) > 20 else huella_verifactu
    qr_payload = f"OFIGREMIO|{doc_num_for_qr}|CIF:{empresa_cif}|TOTAL:{total_factura:.2f}EUR|IBAN:{iban}"
    if huella_verifactu:
        qr_payload += f"|SHA256:{huella_verifactu[:16]}"
    qr_drawing = _build_qr_drawing(qr_payload, size=62.0)

    verifactu_line_html = (
        f"<br/><font size='6.8' color='#334155'><b>Huella Veri*Factu SHA-256:</b> {html.escape(huella_short)}</font>"
        if huella_verifactu else ""
    )

    payment_and_qr = Table(
        [
            [
                qr_drawing,
                Paragraph(
                    f"<b>Condiciones de Pago:</b><br/>"
                    f"Transferencia / Bizum / Efectivo<br/>"
                    f"<b>IBAN:</b> {html.escape(str(iban))}<br/>"
                    f"<font size='7' color='#718096'>Código QR de verificación digital VeriFactu / OfiGremio PRO</font>"
                    f"{verifactu_line_html}",
                    regular_text
                )
            ]
        ],
        colWidths=[70, 230]
    )
    payment_and_qr.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
    ]))

    right_totals_rows = [
        ["Subtotal Bruto:", f"{subtotal:.2f} €"]
    ]
    if total_desc != 0:
        right_totals_rows.append([f"Descuento ({desc_pct:.0f}%):", f"-{abs(total_desc):.2f} €"])
    right_totals_rows.append(["Base Imponible:", f"{base_imponible:.2f} €"])
    right_totals_rows.append([f"IVA ({int(round(iva_rate * 100))}%):", f"{total_iva:.2f} €"])
    if total_irpf != 0:
        right_totals_rows.append([f"Retención IRPF ({int(round(irpf_rate * 100))}%):", f"-{abs(total_irpf):.2f} €"])

    label_total = "TOTAL RECTIFICADO:" if es_rectificativa else ("TOTAL FACTURA:" if is_factura else "TOTAL OFICIAL:")
    right_totals_rows.append([label_total, f"{total_factura:.2f} €"])
    total_row_idx = len(right_totals_rows) - 1

    if anticipo_importe > 0 and not es_rectificativa:
        right_totals_rows.append(["Anticipo a cuenta:", f"-{anticipo_importe:.2f} €"])
        right_totals_rows.append(["Pendiente de abonar:", f"{pendiente_cobro:.2f} €"])

    last_idx = len(right_totals_rows) - 1
    right_totals_table = Table(right_totals_rows, colWidths=[145, 95])
    right_totals_table.setStyle(TableStyle([
        ("ALIGN", (0, 0), (-1, -1), "RIGHT"),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("FONTSIZE", (0, total_row_idx), (-1, total_row_idx), 11),
        ("TEXTCOLOR", (0, total_row_idx), (-1, total_row_idx), SECONDARY_COLOR),
        ("LINEABOVE", (0, total_row_idx), (-1, total_row_idx), 1.5, PRIMARY_COLOR),
        ("PADDING", (0, 0), (-1, -1), 3),
    ]))

    totals_wrapper = Table([[payment_and_qr, right_totals_table]], colWidths=[300, 240])
    totals_wrapper.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
    ]))
    story.append(totals_wrapper)
    story.append(Spacer(1, 12))

    raw_notas = (quote_data.get("notas_tecnicas") or "").strip()
    notas_tecnicas = _safe_wrap_text(raw_notas, max_chunk=35)
    firma_img = _decode_base64_image(quote_data.get("firma_base64", ""), max_width=150.0, max_height=50.0)
    foto_img = _decode_base64_image(quote_data.get("foto_base64", ""), max_width=95.0, max_height=55.0)

    is_long_notas = len(notas_tecnicas) > 280
    if is_long_notas:
        story.append(Paragraph(f"<b>Observaciones Técnicas y Diagnóstico Detallado:</b><br/>{html.escape(str(notas_tecnicas))}", regular_text))
        story.append(Spacer(1, 8))

    notas_content = []
    if is_long_notas:
        notas_content.append(Paragraph(f"<b>Observaciones / Diagnóstico:</b><br/>{html.escape(str(notas_tecnicas[:220]))}... <i>(ver detalle ampliado arriba)</i>", regular_text))
    elif notas_tecnicas:
        notas_content.append(Paragraph(f"<b>Observaciones / Diagnóstico:</b><br/>{html.escape(str(notas_tecnicas))}", regular_text))
    else:
        notas_content.append(Paragraph(
            "<b>Observaciones técnicas:</b><br/>"
            "Trabajos presupuestados según inspección técnica en el domicilio/instalación.",
            regular_text
        ))

    if foto_img is not None:
        notas_content.append(Spacer(1, 4))
        notas_content.append(Paragraph("<b>Evidencia fotográfica adjunta:</b>", small_muted))
        notas_content.append(foto_img)

    esc_cliente_nombre = html.escape(str(cliente_nombre))
    esc_cliente_nif = html.escape(str(cliente_nif))

    if firma_img is not None:
        firma_cell_content = [
            Paragraph("<b>CONFORMIDAD Y ACEPTACIÓN DEL CLIENTE (FIRMADO DIGITALMENTE)</b>", bold_label),
            Spacer(1, 4),
            firma_img,
            Paragraph(f"Firmado por: {esc_cliente_nombre} ({esc_cliente_nif})", small_muted)
        ]
    else:
        firma_cell_content = [
            Paragraph("<b>CONFORMIDAD Y ACEPTACIÓN DEL CLIENTE</b>", bold_label),
            Spacer(1, 22),
            Paragraph("Fdo.: _______________________________", regular_text),
            Paragraph(f"Nombre/NIF: {esc_cliente_nombre} ({esc_cliente_nif})", small_muted)
        ]

    bottom_box = Table(
        [
            [
                notas_content,
                firma_cell_content
            ]
        ],
        colWidths=[270, 270]
    )
    bottom_box.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), BG_LIGHT),
        ("BOX", (0, 0), (-1, -1), 0.75, colors.HexColor("#CBD5E0")),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E0")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("PADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(bottom_box)
    story.append(Spacer(1, 10))

    # 6. PIE DE PÁGINA LEGAL, GARANTÍA Y CLÁUSULA INFORMATIVA RGPD / LOPDGDD
    esc_emp_nom = html.escape(str(empresa_nombre))
    esc_emp_cif = html.escape(str(empresa_cif))
    esc_emp_email = html.escape(str(company_config.get("empresa_email") or empresa_tel or ""))
    legal_text = (
        f"<i>Garantía de reparación e instalación de {garantia_meses} meses según normativa vigente (RDL 1/2007). "
        "Las piezas y equipos nuevos sustituidos cuentan con la garantía oficial del fabricante. "
        "Documento emitido electrónicamente mediante OfiGremio PRO v4.1.0.</i><br/>"
        f"<b>PROTECCIÓN DE DATOS (RGPD UE 2016/679 y LOPDGDD 3/2018):</b> Responsable del tratamiento: {esc_emp_nom} ({esc_emp_cif}). "
        "Finalidad: Gestión del presupuesto, ejecución del parte de trabajo y facturación legal. "
        "Legitimación: Ejecución de contrato y obligación tributaria (Ley 58/2003). "
        f"Derechos: Puede ejercer sus derechos de acceso, rectificación, supresión, limitación y portabilidad en {esc_emp_email}."
    )
    story.append(Paragraph(legal_text, ParagraphStyle("LegalNotice", parent=styles["Normal"], fontSize=6.8, leading=8.5, textColor=colors.HexColor("#718096"))))

    doc.build(story)
    return output_path


def generar_qr_cobro_bizum(iban: str, concepto: str, importe: float) -> str:
    """Genera texto estructurado para QR de pago directo por transferencia / Bizum."""
    return f"BIZUM/PAGO|IBAN:{iban}|CONCEPTO:{concepto}|TOTAL:{importe:.2f}EUR"
