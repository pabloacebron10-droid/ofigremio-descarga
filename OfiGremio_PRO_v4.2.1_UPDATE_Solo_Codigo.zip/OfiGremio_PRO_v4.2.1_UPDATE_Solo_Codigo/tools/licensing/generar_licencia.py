#!/usr/bin/env python3
"""
OfiGremio PRO v4.2.1 — Herramienta Privada del Desarrollador: Generador de Licencias Criptográficas HWID.
Uso interno exclusivo para emitir licencias comerciales atadas al hardware del cliente.
"""

import os
import sys
import argparse
from datetime import datetime, timedelta

# UTF-8 stdout en Windows
if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

# Asegurar import de license_manager desde la raíz del proyecto
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

import license_manager


def main():
    parser = argparse.ArgumentParser(description="Generador Oficial de Licencias para OfiGremio PRO")
    parser.add_argument("--cliente", type=str, help="Nombre del autónomo o empresa titular")
    parser.add_argument("--hwid", type=str, help="Código de hardware del equipo (ej. OFG-XXXX-XXXX-XXXX-XXXX)")
    parser.add_argument("--cif", type=str, default="B00000000", help="CIF o NIF del titular")
    parser.add_argument("--tipo", type=str, default="LIFETIME", choices=["LIFETIME", "SUBSCRIPTION"], help="Tipo de licencia")
    parser.add_argument("--expira", type=str, default="2099-12-31", help="Fecha de expiración (YYYY-MM-DD)")
    parser.add_argument("--actualizaciones_anos", type=int, default=1, help="Años de actualizaciones incluidas")
    parser.add_argument("--guardar", action="store_true", help="Guardar directamente en data/license.key")

    args = parser.parse_args()

    # Si se ejecuta sin argumentos, modo interactivo asistido
    if not args.cliente or not args.hwid:
        print("=" * 75)
        print("  🔑 GENERADOR OFICIAL DE LICENCIAS COMERCIALES — OFIGREMIO PRO v4.2.1")
        print("=" * 75)
        print("")
        cliente = input("1. Nombre del Cliente / Empresa: ").strip()
        while not cliente:
            cliente = input("   [Requerido] Nombre del Cliente: ").strip()

        hwid = input("2. Código de Máquina (HWID proporcionado por el cliente): ").strip().upper()
        while not hwid:
            hwid = input("   [Requerido] Introduce el HWID (ej. OFG-XXXX-...): ").strip().upper()

        cif = input("3. CIF / NIF del cliente (opcional, Enter para omitir): ").strip() or "B00000000"

        tipo_input = input("4. ¿Tipo de Licencia? [1 = Vitalicia (Recomendada) / 2 = Suscripción Anual]: ").strip()
        if tipo_input == "2":
            tipo = "SUBSCRIPTION"
            exp_date = (datetime.now() + timedelta(days=365)).strftime("%Y-%m-%d")
        else:
            tipo = "LIFETIME"
            exp_date = "2099-12-31"

        try:
            anos_act = int(input("5. Años de actualizaciones incluidas [1]: ").strip() or "1")
        except ValueError:
            anos_act = 1

        guardar_input = input("6. ¿Guardar directamente en data/license.key de este equipo de pruebas? (s/N): ").strip().lower()
        guardar = guardar_input == "s"
    else:
        cliente = args.cliente
        hwid = args.hwid
        cif = args.cif
        tipo = args.tipo
        exp_date = args.expira
        anos_act = args.actualizaciones_anos
        guardar = args.guardar

    updates_until = (datetime.now() + timedelta(days=365 * anos_act)).strftime("%Y-%m-%d")

    # Generar la licencia firmada
    lic = license_manager.generate_license(
        cliente=cliente,
        hwid=hwid,
        cif=cif,
        tipo=tipo,
        expires_at=exp_date,
        updates_until=updates_until
    )

    print("\n" + "=" * 75)
    print("  ✅ [LICENCIA GENERADA CON ÉXITO]")
    print("=" * 75)
    print(f"  - Titular:               {lic['cliente']} ({lic['cif']})")
    print(f"  - Hardware ID:           {lic['hwid']}")
    print(f"  - Modalidad:             {lic['tipo']}")
    print(f"  - Caducidad de uso:      {lic['expires_at']}")
    print(f"  - Actualizaciones hasta: {lic['updates_until']}")
    print(f"  - Firma SHA-256:         {lic['signature'][:16]}...")
    print("-" * 75)
    print("  📋 CÓDIGO DE ACTIVACIÓN PARA ENVIAR AL CLIENTE (COPIAR Y PEGAR):")
    print("-" * 75)
    print(lic['activation_code'])
    print("-" * 75)

    if guardar:
        license_manager.save_license_file(lic)
        print("  💾 Licencia guardada correctamente en data/license.key")

    print("\nPuedes enviar el código superior por WhatsApp o correo al cliente.")
    print("El cliente solo debe pegarlo en la pantalla de activación de su equipo.")


if __name__ == "__main__":
    main()
