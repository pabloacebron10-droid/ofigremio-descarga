/**
 * OfiGremio PRO — Microservicio Serverless Cloudflare Worker para Suscripciones Stripe (15 €/mes).
 * 
 * Funcionalidades:
 * 1. POST /webhook: Escucha los eventos de cobro recurrente de Stripe (invoice.payment_succeeded)
 *    y checkout completado (checkout.session.completed).
 * 2. Genera y firma la licencia criptográfica HMAC-SHA256 para el HWID del cliente (+30 días).
 * 3. GET /api/sync?hwid=OFG-XXXX: Endpoint al que consulta silenciosamente la app de escritorio
 *    para auto-renovarse sin intervención humana.
 * 
 * Coste de hosting: 0,00 € (Nivel gratuito de Cloudflare Workers: 100.000 peticiones/día).
 */

// Secreto de Desarrollador para firmar las licencias (idéntico a license_manager.py)
const MASTER_DEV_SECRET = "OFIGREMIO_PRO_MASTER_SEC_KEY_2026_EDF89A7B31094CB2";

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    // 1. ENDPOINT DE CONSULTA DE OFIGREMIO: GET /api/sync?hwid=OFG-XXXX
    if (request.method === "GET" && (url.pathname === "/api/sync" || url.pathname === "/sync")) {
      const hwid = (url.searchParams.get("hwid") || "").trim().toUpperCase();
      if (!hwid || !hwid.startsWith("OFG-")) {
        return jsonResponse({ error: "Parámetro hwid no válido" }, 400);
      }

      // Si se tiene KV conectado (env.LICENSES_KV) buscar la licencia almacenada
      let storedLic = null;
      if (env.LICENSES_KV) {
        const raw = await env.LICENSES_KV.get(hwid);
        if (raw) {
          try { storedLic = JSON.parse(raw); } catch (_) {}
        }
      }

      if (storedLic) {
        return jsonResponse({ valid: true, payload: storedLic });
      }

      return jsonResponse({ valid: false, message: "No hay suscripción activa para este HWID" }, 404);
    }

    // 2. ENDPOINT DE WEBHOOK DE STRIPE: POST /webhook
    if (request.method === "POST" && url.pathname === "/webhook") {
      let event;
      try {
        event = await request.json();
      } catch (err) {
        return new Response("Webhook payload inválido", { status: 400 });
      }

      const eventType = event.type;

      // Eventos de pago exitoso
      if (eventType === "checkout.session.completed" || eventType === "invoice.payment_succeeded") {
        const obj = event.data.object;
        
        // Obtener HWID desde client_reference_id o metadata
        let hwid = (obj.client_reference_id || obj.metadata?.hwid || "").trim().toUpperCase();
        let customerEmail = obj.customer_email || obj.customer_details?.email || "cliente@ofigremio.es";
        let customerName = obj.customer_details?.name || "Cliente OfiGremio PRO";

        if (hwid && hwid.startsWith("OFG-")) {
          // Calcular nueva fecha de expiración (+32 días para margen de gracia bancario)
          const now = new Date();
          now.setDate(now.getDate() + 32);
          const expiresAt = now.toISOString().split("T")[0];
          const issuedAt = new Date().toISOString().split("T")[0];

          // Construir payload
          const payload = {
            cliente: customerName,
            cif: "B00000000",
            hwid: hwid,
            tipo: "SUBSCRIPTION",
            expires_at: expiresAt,
            updates_until: expiresAt,
            issued_at: issuedAt,
            product: "OfiGremio PRO",
            version_max: "4.x"
          };

          // Firmar criptográficamente HMAC-SHA256
          const signature = await hmacSha256(MASTER_DEV_SECRET, 
            `${payload.cliente}|${payload.cif}|${payload.hwid}|${payload.tipo}|${payload.expires_at}|${payload.updates_until}|${payload.issued_at}`
          );
          payload.signature = signature;

          // Generar activation_code en base64
          const jsonBytes = new TextEncoder().encode(JSON.stringify(payload));
          payload.activation_code = btoa(String.fromCharCode(...jsonBytes));

          // Guardar en KV
          if (env.LICENSES_KV) {
            await env.LICENSES_KV.put(hwid, JSON.stringify(payload));
          }

          console.log(`[+] Suscripción renovada con éxito para HWID: ${hwid} hasta ${expiresAt}`);
          return jsonResponse({ received: true, hwid: hwid, expires_at: expiresAt });
        }
      }

      return jsonResponse({ received: true });
    }

    // Ruta de bienvenida / status
    return jsonResponse({
      service: "OfiGremio PRO — Stripe Licensing Relay",
      version: "4.2.1",
      status: "ONLINE",
      timestamp: new Date().toISOString()
    });
  }
};

// Función criptográfica WebCrypto nativa para HMAC-SHA256
async function hmacSha256(secret, message) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(message));
  return Array.from(new Uint8Array(sig)).map(b => b.toString(16).padStart(2, "0")).join("");
}

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status: status,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*"
    }
  });
}

