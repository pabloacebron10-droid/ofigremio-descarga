# 💳 Guía de Configuración Rápida de Stripe (Cobro Automático 15 €/mes)

Esta guía te explica en 4 sencillos pasos cómo dejar tu Stripe conectado a OfiGremio PRO para cobrar 15 €/mes a tus clientes directamente a tu cuenta bancaria y sin enviar claves manuales.

---

## Paso 1: Crear tu Cuenta Gratuita en Stripe (2 minutos)
1. Entra en [https://dashboard.stripe.com/register](https://dashboard.stripe.com/register).
2. Regístrate con tu email y contraseña.
3. Activa tu cuenta introduciendo tus datos fiscales (autónomo o empresa) y **tu cuenta bancaria (IBAN)**.
   *(Aquí es donde Stripe te transferirá el dinero de las suscripciones).*

---

## Paso 2: Crear el Producto de 15 €/mes en Stripe (1 minuto)
1. En tu panel de Stripe, ve a la izquierda a **"Catálogo de productos"** -> **"+ Añadir producto"**.
2. Rellena:
   - **Nombre:** `OfiGremio PRO — Suscripción Mensual`
   - **Precio:** `15,00 EUR`
   - **Período de facturación:** Selecciona **"Mensual" (Recurrente)**.
3. Pulsa **Guardar producto**.

---

## Paso 3: Crear el Enlace de Pago (Payment Link) en 1 Clic (1 minuto)
1. Junto al producto que acabas de crear, haz clic en **"Crear enlace de pago"** (Create payment link).
2. Stripe te dará una URL como esta:
   `https://buy.stripe.com/test_123456789abcdef`
3. Abre el archivo de tu proyecto:
   `data/stripe_config.json`
4. Pega tu enlace en la clave `"payment_link_monthly"`:
   ```json
   {
     "enabled": true,
     "payment_link_monthly": "https://buy.stripe.com/test_123456789abcdef",
     "monthly_price_eur": 15.00
   }
   ```
5. ¡Listo! A partir de ese momento, cuando un cliente pulse *"💳 Suscribirme por 15 €/mes"*, se abrirá tu enlace de cobro con su equipo pre-vinculado.

---

## Paso 4 (Opcional): Desplegar el Relay de Renovación Automática Silenciosa
Para que las aplicaciones se auto-renueven solas sin que nadie toque nada:
1. Entra gratis en [dash.cloudflare.com](https://dash.cloudflare.com) -> **Workers & Pages** -> **Create Application**.
2. Pega el código de `tools/licensing/stripe_cloud_relay/worker.js`.
3. Ve a tu panel de Stripe -> **Desarrolladores** -> **Webhooks** -> **Añadir endpoint**:
   - URL: `https://tu-worker.workers.dev/webhook`
   - Eventos a escuchar: `checkout.session.completed` y `invoice.payment_succeeded`.
4. En `data/stripe_config.json`, pon la URL de tu worker:
   `"licensing_relay_url": "https://tu-worker.workers.dev/api/sync"`

---

## ¿Cómo recibe el cliente su acceso?
- El cliente entra en OfiGremio, pulsa el botón *"💳 Suscribirme por 15 €/mes"*, mete su tarjeta en Stripe y en 3 segundos la app se desbloquea sola en directo.
- Stripe te transfiere los 15 € a tu banco cada mes.

