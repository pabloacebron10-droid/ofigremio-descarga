@echo off
chcp 65001 >nul
title OfiGremio PRO - Conexion Remota Movil 4G

echo =========================================================
echo    OFIGREMIO PRO — ACCESO REMOTO SEGURO DESDE EL MOVIL
echo =========================================================
echo.

cd /d "%~dp0\..\.."

REM Comprobar si Python está disponible
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python no se detecto en el sistema.
    echo Asegurate de haber ejecutado 1_INSTALAR_PRIMERA_VEZ.bat primero.
    echo.
    pause
    exit /b 1
)

python tools\remote\tunnel_manager.py

pause

