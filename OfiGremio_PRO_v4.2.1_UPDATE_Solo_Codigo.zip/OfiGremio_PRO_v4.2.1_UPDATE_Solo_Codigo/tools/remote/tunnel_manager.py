"""
OfiGremio PRO — Módulo de Acceso Remoto Seguro (4G/5G / WiFi Exterior).
Crea un túnel cifrado HTTPS de extremo a extremo mediante Cloudflare Tunnel (sin necesidad
de abrir puertos en el router, sin IP fija y totalmente compatible con redes móviles 4G).
"""

import os
import sys
import re
import json
import time
import urllib.request
import subprocess
from typing import Optional

# Configuración de rutas
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DATA_DIR = os.path.join(ROOT_DIR, "data")
SERVER_INFO_PATH = os.path.join(DATA_DIR, "server_info.json")
REMOTE_TUNNEL_PATH = os.path.join(DATA_DIR, "remote_tunnel.json")
TOOLS_REMOTE_DIR = os.path.join(ROOT_DIR, "tools", "remote")
BIN_DIR = os.path.join(TOOLS_REMOTE_DIR, "bin")

IS_WIN = sys.platform == "win32"
IS_DARWIN = sys.platform == "darwin"
BIN_NAME = "cloudflared.exe" if IS_WIN else "cloudflared"
CLOUDFLARED_BIN = os.path.join(BIN_DIR, BIN_NAME)
CLOUDFLARED_EXE = CLOUDFLARED_BIN  # Alias de compatibilidad

if IS_WIN:
    CLOUDFLARED_DOWNLOAD_URL = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"
elif IS_DARWIN:
    CLOUDFLARED_DOWNLOAD_URL = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-darwin-amd64"
else:
    CLOUDFLARED_DOWNLOAD_URL = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64"


def get_active_server_port() -> int:
    """Detecta el puerto activo de OfiGremio desde server_info.json."""
    if os.path.exists(SERVER_INFO_PATH):
        try:
            with open(SERVER_INFO_PATH, "r", encoding="utf-8") as f:
                info = json.load(f)
                port = int(info.get("port", 8080))
                if port > 0:
                    return port
        except Exception:
            pass
    return 8080


def ensure_cloudflared_binary() -> bool:
    """Verifica si el binario cloudflared existe; si no, lo descarga automáticamente y asigna permisos de ejecución."""
    if os.path.exists(CLOUDFLARED_BIN) and os.path.getsize(CLOUDFLARED_BIN) > 5_000_000:
        if not IS_WIN:
            try:
                os.chmod(CLOUDFLARED_BIN, 0o755)
            except Exception:
                pass
        return True

    os.makedirs(BIN_DIR, exist_ok=True)
    print("\n[+] Descargando conector seguro Cloudflare Tunnel (solo la primera vez)...")
    print(f"    Destino: {CLOUDFLARED_BIN}")
    try:
        urllib.request.urlretrieve(CLOUDFLARED_DOWNLOAD_URL, CLOUDFLARED_BIN)
        if not IS_WIN:
            try:
                os.chmod(CLOUDFLARED_BIN, 0o755)
            except Exception:
                pass
        print("[+] Conector descargado y listo para usar.\n")
        return True
    except Exception as e:
        print(f"[-] Error descargando el conector: {e}")
        print("    Puedes descargarlo manualmente desde https://github.com/cloudflare/cloudflared/releases")
        return False


def generate_qr_base64(url: str) -> str:
    """Genera una imagen QR en Base64 Data URI para incrustación directa en HTML."""
    try:
        import io
        import base64
        import qrcode
        qr = qrcode.QRCode(box_size=6, border=2)
        qr.add_data(url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        buffered = io.BytesIO()
        img.save(buffered, format="PNG")
        img_b64 = base64.b64encode(buffered.getvalue()).decode("ascii")
        return f"data:image/png;base64,{img_b64}"
    except Exception:
        return ""


def print_ascii_qr(url: str):
    """Genera y muestra código QR en consola y guarda imagen PNG."""
    try:
        import qrcode
        qr = qrcode.QRCode(box_size=1, border=2)
        qr.add_data(url)
        qr.make(fit=True)
        print("\n================ ESCANEA CON EL MOVIL ================")
        qr.print_ascii(invert=True)
        print("=====================================================\n")
        
        # Guardar imagen en data para visualización directa
        img_path = os.path.join(DATA_DIR, "acceso_remoto_qr.png")
        img = qr.make_image(fill_color="black", back_color="white")
        img.save(img_path)
    except Exception as e:
        print(f"[-] No se pudo dibujar QR en consola: {e}")


def start_remote_tunnel():
    """Inicia el túnel y expone la URL segura."""
    if not ensure_cloudflared_binary():
        print("[-] No se pudo iniciar el conector de acceso remoto.")
        input("\nPresione Enter para salir...")
        return

    port = get_active_server_port()
    local_target = f"http://127.0.0.1:{port}"
    print("=" * 60)
    print("      OFIGREMIO PRO — CONEXION REMOTA CIFRADA (4G / MOVIL)")
    print("=" * 60)
    print(f"[+] Vinculando con servidor local en puerto: {port}")
    print("[+] Negociando túnel HTTPS seguro de alta velocidad...")

    cmd = [
        CLOUDFLARED_EXE,
        "tunnel",
        "--url", local_target,
        "--no-autoupdate"
    ]

    process = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace"
    )

    tunnel_url = None
    url_pattern = re.compile(r"https://[a-zA-Z0-9-]+\.trycloudflare\.com")

    start_wait = time.time()
    while time.time() - start_wait < 30:
        line = process.stdout.readline()
        if not line:
            time.sleep(0.1)
            continue
        
        match = url_pattern.search(line)
        if match:
            tunnel_url = match.group(0)
            break

    if not tunnel_url:
        print("[-] No se pudo obtener la URL del túnel en 30 segundos.")
        process.terminate()
        input("\nPresione Enter para salir...")
        return

    qr_data_uri = generate_qr_base64(tunnel_url)

    # Guardar en archivo JSON para consultas del sistema
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(REMOTE_TUNNEL_PATH, "w", encoding="utf-8") as f:
            json.dump({
                "tunnel_url": tunnel_url,
                "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "local_port": port,
                "qr_data_uri": qr_data_uri
            }, f, indent=2)
    except Exception:
        pass

    print("\n" + "=" * 60)
    print(" [OK] ENLACE REMOTO CIFRADO ACTIVO")
    print("=" * 60)
    print(f"\n >>> URL PARA EL MOVIL (4G / 5G / EXTERIOR):")
    print(f"     {tunnel_url}\n")
    print(" [+] Abre este enlace en el navegador de tu móvil o tablet.")
    print(" [+] No consume datos de hosting ni requiere abrir puertos.")
    print("=" * 60)

    print_ascii_qr(tunnel_url)

    print("\nPresiona CTRL+C en esta ventana cuando termines la jornada para cerrar el enlace remoto.\n")

    try:
        while True:
            line = process.stdout.readline()
            if not line and process.poll() is not None:
                break
    except KeyboardInterrupt:
        print("\n[+] Cerrando túnel remoto...")
        process.terminate()
        try:
            if os.path.exists(REMOTE_TUNNEL_PATH):
                os.remove(REMOTE_TUNNEL_PATH)
        except Exception:
            pass
        print("[+] Túnel cerrado con éxito. Hasta pronto.")


if __name__ == "__main__":
    start_remote_tunnel()

