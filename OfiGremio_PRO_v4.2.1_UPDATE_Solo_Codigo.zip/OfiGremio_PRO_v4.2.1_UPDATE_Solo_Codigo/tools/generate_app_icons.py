"""
Generador de Iconos Oficiales para OfiGremio PRO.
Produce static/app_icon.ico (con resoluciones de 16 a 256 píxeles para Windows Explorer),
static/favicon.ico, static/icon-192.png, static/icon-512.png y static/apple-touch-icon.png.
Diseño: Escudo de fondo azul zafiro oscuro (#0F172A), bisel tecnológico azul cobalto (#2563EB),
borde interior cyan (#38BDF8) y rayo / herramienta estilizada en gradiente dorado (#F59E0B a #FBBF24).
"""

import os
from PIL import Image, ImageDraw

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATIC_DIR = os.path.join(ROOT_DIR, "static")
os.makedirs(STATIC_DIR, exist_ok=True)


def draw_ofigremio_badge(size: int) -> Image.Image:
    # Render at 4x for clean supersampling
    scale = 4
    canvas_size = size * scale
    img = Image.new("RGBA", (canvas_size, canvas_size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    pad = int(canvas_size * 0.06)
    r = int(canvas_size * 0.22)  # border radius

    # 1. Sombra sutil exterior
    shadow_box = [pad + 4, pad + 8, canvas_size - pad + 4, canvas_size - pad + 8]
    draw.rounded_rectangle(shadow_box, radius=r, fill=(0, 0, 0, 60))

    # 2. Fondo principal: Azul oscuro zafiro (#0F172A)
    main_box = [pad, pad, canvas_size - pad, canvas_size - pad]
    draw.rounded_rectangle(main_box, radius=r, fill=(15, 23, 42, 255))

    # 3. Bisel exterior tecnológico (#2563EB)
    border_w = max(2, int(canvas_size * 0.035))
    draw.rounded_rectangle(main_box, radius=r, outline=(37, 99, 235, 255), width=border_w)

    # 4. Marco interior brillante fino (#38BDF8)
    inner_pad = pad + border_w + max(1, int(canvas_size * 0.015))
    inner_r = max(2, r - border_w)
    draw.rounded_rectangle([inner_pad, inner_pad, canvas_size - inner_pad, canvas_size - inner_pad],
                           radius=inner_r, outline=(56, 189, 248, 140), width=max(1, int(canvas_size * 0.015)))

    # 5. Rayo estilizado central (representa velocidad, potencia eléctrica y técnicos profesionales)
    cx = canvas_size / 2.0
    cy = canvas_size / 2.0
    h = canvas_size * 0.60
    w = canvas_size * 0.38

    # Coordenadas relativas del rayo
    # Top-right -> Mid-left -> Mid-right -> Bottom-tip -> Mid-right-lower -> Mid-left-upper
    pts = [
        (cx + w * 0.28, cy - h * 0.44),   # Vértice superior
        (cx - w * 0.45, cy - h * 0.02),   # Quiebro superior izquierda
        (cx - w * 0.02, cy - h * 0.02),   # Entrada centro
        (cx - w * 0.35, cy + h * 0.46),   # Punta inferior
        (cx + w * 0.45, cy + h * 0.02),   # Quiebro inferior derecha
        (cx + w * 0.02, cy + h * 0.02),   # Retorno centro
    ]

    # Sombra del rayo
    shadow_pts = [(x + int(canvas_size * 0.015), y + int(canvas_size * 0.025)) for x, y in pts]
    draw.polygon(shadow_pts, fill=(2, 6, 23, 180))

    # Rayo principal: Oro vivo (#F59E0B)
    draw.polygon(pts, fill=(245, 158, 11, 255))

    # Resalte superior del rayo: Amarillo radiante (#FDE047)
    highlight_pts = [
        (cx + w * 0.28, cy - h * 0.44),
        (cx - w * 0.45, cy - h * 0.02),
        (cx - w * 0.02, cy - h * 0.02),
        (cx + w * 0.02, cy + h * 0.02),
    ]
    draw.polygon(highlight_pts, fill=(253, 224, 71, 220))

    # Redimensionar con filtro antialiasing Lanczos
    return img.resize((size, size), Image.Resampling.LANCZOS)


def generate_all_icons():
    print("Generando iconos oficiales de OfiGremio PRO...")

    # 1. Generar PNGs de alta definición
    icon_512 = draw_ofigremio_badge(512)
    icon_512_path = os.path.join(STATIC_DIR, "icon-512.png")
    icon_512.save(icon_512_path, format="PNG")
    print(f"  [OK] {icon_512_path}")

    icon_192 = draw_ofigremio_badge(192)
    icon_192_path = os.path.join(STATIC_DIR, "icon-192.png")
    icon_192.save(icon_192_path, format="PNG")
    print(f"  [OK] {icon_192_path}")

    apple_icon = draw_ofigremio_badge(180)
    apple_path = os.path.join(STATIC_DIR, "apple-touch-icon.png")
    apple_icon.save(apple_path, format="PNG")
    print(f"  [OK] {apple_path}")

    # 2. Generar ICO multipropósito para Windows Explorer (16, 24, 32, 48, 64, 128, 256 px)
    ico_sizes = [(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
    ico_images = [draw_ofigremio_badge(s[0]) for s in ico_sizes]

    app_ico_path = os.path.join(STATIC_DIR, "app_icon.ico")
    ico_images[-1].save(
        app_ico_path,
        format="ICO",
        sizes=ico_sizes,
        append_images=ico_images[:-1]
    )
    print(f"  [OK] {app_ico_path} (Windows Desktop Icon con 7 resoluciones)")

    favicon_path = os.path.join(STATIC_DIR, "favicon.ico")
    ico_images[-1].save(
        favicon_path,
        format="ICO",
        sizes=[(16, 16), (32, 32), (48, 48)],
        append_images=ico_images[:2]
    )
    print(f"  [OK] {favicon_path} (Navegador Favicon)")


if __name__ == "__main__":
    generate_all_icons()

