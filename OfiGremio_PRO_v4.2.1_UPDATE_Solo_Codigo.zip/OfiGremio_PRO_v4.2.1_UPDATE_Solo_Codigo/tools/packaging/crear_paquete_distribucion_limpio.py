"""
OfiGremio PRO v4.2.1 — Generador Automatizado de Paquetes de Entrega Limpios (Windows y Linux).

Construye 2 paquetes separados y 100% limpios de desarrollo en dist/:
1. OfiGremio_PRO_v4.2.1_Windows.zip  (Con launchers .bat y acceso directo Windows)
2. OfiGremio_PRO_v4.2.1_Linux.zip    (Con launchers .sh, permisos 0755 y lanzador .desktop Linux)

En ambos paquetes:
- Elimina cualquier licencia residual (data/license.key) para forzar la activación en la máquina del cliente.
- Inicializa una base de datos SQLite limpia de fábrica con tablas listas (sin clientes ni presupuestos de prueba).
- Excluye carpetas de desarrollo (.git, tests, .pytest_cache, __pycache__, dist, spec).
- Incluye herramientas de acceso remoto 4G, manuales y archivos estáticos.
"""

import os
import sys
import shutil
import zipfile
import sqlite3

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DIST_DIR = os.path.join(ROOT_DIR, "dist")

WIN_PACKAGE_NAME = "OfiGremio_PRO_v4.2.1_Windows"
LINUX_PACKAGE_NAME = "OfiGremio_PRO_v4.2.1_Linux"
WIN_TARGET_DIR = os.path.join(DIST_DIR, WIN_PACKAGE_NAME)
WIN_ZIP_FILE_PATH = os.path.join(DIST_DIR, f"{WIN_PACKAGE_NAME}.zip")
LINUX_TARGET_DIR = os.path.join(DIST_DIR, LINUX_PACKAGE_NAME)
LINUX_ZIP_FILE_PATH = os.path.join(DIST_DIR, f"{LINUX_PACKAGE_NAME}.zip")

# Alias de compatibilidad para tests existentes
PACKAGE_NAME = WIN_PACKAGE_NAME
TARGET_DIR = WIN_TARGET_DIR
ZIP_FILE_PATH = WIN_ZIP_FILE_PATH


def create_factory_clean_db(target_db_path: str):
    """Crea una base de datos SQLite limpia de fábrica con todas las tablas pero sin datos de prueba."""
    os.makedirs(os.path.dirname(target_db_path), exist_ok=True)
    if os.path.exists(target_db_path):
        try:
            os.remove(target_db_path)
        except OSError:
            pass

    # Usar el módulo database oficial para inicializar el esquema completo
    sys.path.insert(0, ROOT_DIR)
    import database as db
    orig_path = db.DB_PATH
    try:
        db.set_db_path(target_db_path)
        db.init_db()
        print(f"    [+] Base de datos de fábrica inicializada en: {os.path.basename(target_db_path)}")
    finally:
        db.set_db_path(orig_path)


def build_single_os_package(os_type: str = "windows"):
    """
    Construye un paquete de entrega limpio para el sistema operativo especificado:
    - os_type="windows" -> OfiGremio_PRO_v4.2.1_Windows
    - os_type="linux"   -> OfiGremio_PRO_v4.2.1_Linux
    """
    is_windows = os_type.lower() == "windows"
    pkg_name = WIN_PACKAGE_NAME if is_windows else LINUX_PACKAGE_NAME
    target_dir = WIN_TARGET_DIR if is_windows else LINUX_TARGET_DIR
    zip_path = WIN_ZIP_FILE_PATH if is_windows else LINUX_ZIP_FILE_PATH

    print(f"\n[*] Generando paquete para {pkg_name}...")

    # 1. Limpiar directorio previo
    if os.path.exists(target_dir):
        shutil.rmtree(target_dir, ignore_errors=True)
    if os.path.exists(zip_path):
        try:
            os.remove(zip_path)
        except OSError:
            pass

    os.makedirs(target_dir, exist_ok=True)

    # 2. Archivos raíz comunes
    common_files = [
        "requirements.txt",
        "COMMERCIAL_VERSION.json",
        "MANUAL_USUARIO.md",
        "GUIA_INSTALACION.md",
        "server.py",
        "database.py",
        "license_manager.py",
        "pdf_engine.py",
        "local_assistant.py",
        "verifactu_engine.py",
        "wizard_backend_bridge.py"
    ]

    # Archivos específicos por SO
    if is_windows:
        os_specific_files = [
            "1_INSTALAR_PRIMERA_VEZ.bat",
            "2_ABRIR_OFIGREMIO.bat",
            "ACTUALIZAR_OFIGREMIO.bat"
        ]
    else:
        os_specific_files = [
            "1_instalar_primera_vez.sh",
            "2_abrir_ofigremio.sh",
            "actualizar_ofigremio.sh"
        ]

    for fname in common_files + os_specific_files:
        src = os.path.join(ROOT_DIR, fname)
        if os.path.exists(src):
            dst = os.path.join(target_dir, fname)
            shutil.copy2(src, dst)
        else:
            print(f"    [!] Advertencia: archivo no encontrado: {fname}")

    # 3. Copiar static/
    static_src = os.path.join(ROOT_DIR, "static")
    static_dst = os.path.join(target_dir, "static")
    shutil.copytree(static_src, static_dst, ignore=shutil.ignore_patterns("__pycache__", "*.tmp"))

    # 4. Copiar tools/remote/
    remote_src = os.path.join(ROOT_DIR, "tools", "remote")
    remote_dst = os.path.join(target_dir, "tools", "remote")
    os.makedirs(os.path.dirname(remote_dst), exist_ok=True)
    shutil.copytree(remote_src, remote_dst, ignore=shutil.ignore_patterns("__pycache__", "*.tmp", "*.log"))

    # 5. Generar carpeta data limpia
    data_dst = os.path.join(target_dir, "data")
    os.makedirs(data_dst, exist_ok=True)
    os.makedirs(os.path.join(data_dst, "backups"), exist_ok=True)
    os.makedirs(os.path.join(data_dst, "exports"), exist_ok=True)

    clean_db_path = os.path.join(data_dst, "ofigremio.db")
    create_factory_clean_db(clean_db_path)

    # Copiar configuración de Stripe
    src_stripe = os.path.join(ROOT_DIR, "data", "stripe_config.json")
    if os.path.exists(src_stripe):
        shutil.copy2(src_stripe, os.path.join(data_dst, "stripe_config.json"))

    # 6. LEEME_PRIMERO.txt adaptado por SO
    if is_windows:
        readme_content = """=============================================================
           OFIGREMIO PRO v4.2.1 (WINDOWS) — PUESTA EN MARCHA
=============================================================

¡Gracias por elegir OfiGremio PRO!

PASOS PARA COMENZAR EN WINDOWS:
1. Haz doble clic en:
   "1_INSTALAR_PRIMERA_VEZ.bat"
   (Configura el entorno e instala dependencias automáticamente).

2. Al terminar la verificación se abrirá la aplicación en tu navegador:
   - Puedes activar tu suscripción mensual en 1 clic pulsando:
     "💳 Suscribirme con Tarjeta (15 € / mes)".
   - O si dispones de una clave manual facilitada por tu proveedor,
     introdúcela en el recuadro inferior.

3. Para el uso diario, utiliza el acceso directo creado en tu Escritorio
   o haz doble clic en:
   "2_ABRIR_OFIGREMIO.bat"

Para más información, consulta GUIA_INSTALACION.md o MANUAL_USUARIO.md
=============================================================
"""
    else:
        readme_content = """=============================================================
           OFIGREMIO PRO v4.2.1 (LINUX) — PUESTA EN MARCHA
=============================================================

¡Gracias por elegir OfiGremio PRO!

PASOS PARA COMENZAR EN LINUX (Ubuntu, Debian, Mint, Fedora, Arch...):

1. Abre una terminal dentro de esta carpeta (clic derecho -> Abrir en una terminal)
   y ejecuta:
   
   bash 1_instalar_primera_vez.sh

   (Nota: Si tu sistema es Ubuntu o Debian, asegúrate de tener instalado python3-venv:
   sudo apt update && sudo apt install -y python3-venv python3-pip)

2. El instalador configurará el entorno virtual, instalará librerías
   y añadirá OfiGremio PRO a tu menú de aplicaciones y a tu Escritorio.

3. Al terminar se abrirá la aplicación en tu navegador:
   - Puedes activar tu suscripción mensual en 1 clic pulsando:
     "💳 Suscribirme con Tarjeta (15 € / mes)".
   - O si dispones de una clave manual, introdúcela en el recuadro inferior.

4. Para el uso diario:
   - Búscalo en tu menú de aplicaciones como "OfiGremio PRO"
   - O ejecuta en la terminal: bash 2_abrir_ofigremio.sh

Para más información, consulta GUIA_INSTALACION.md o MANUAL_USUARIO.md
=============================================================
"""

    with open(os.path.join(target_dir, "LEEME_PRIMERO.txt"), "w", encoding="utf-8") as f:
        f.write(readme_content)

    # 7. Comprimir ZIP preservando permisos Unix y saltos de línea LF
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(target_dir):
            for file in files:
                abs_file = os.path.join(root, file)
                rel_file = os.path.relpath(abs_file, target_dir)
                arcname = os.path.join(pkg_name, rel_file).replace("\\", "/")

                with open(abs_file, "rb") as fh:
                    data = fh.read()

                # En Linux forzar terminaciones LF puras
                if not is_windows and (file.endswith(".sh") or file.endswith(".txt") or file.endswith(".md")):
                    data = data.replace(b"\r\n", b"\n")

                zinfo = zipfile.ZipInfo(arcname)
                # Otorgar permisos rwxr-xr-x (0o755) a scripts ejecutables de Linux
                if not is_windows and (file.endswith(".sh") or file.endswith(".desktop")):
                    zinfo.external_attr = (0o755 << 16) | 0x20
                else:
                    zinfo.external_attr = (0o644 << 16) | 0x20
                zinfo.compress_type = zipfile.ZIP_DEFLATED
                zipf.writestr(zinfo, data)

    zip_size_mb = os.path.getsize(zip_path) / (1024 * 1024)
    print(f"    [OK] {pkg_name}.zip creado ({zip_size_mb:.2f} MB)")
    return target_dir, zip_path


def build_update_package():
    """
    Construye un paquete de actualización segura 'OfiGremio_PRO_v4.2.1_UPDATE_Solo_Codigo.zip'.
    Contiene exclusivamente los archivos de código actualizados, launchers y estáticos,
    sin incluir nunca 'ofigremio.db' ni la carpeta 'data/' para proteger los datos de clientes existentes.
    """
    pkg_name = "OfiGremio_PRO_v4.2.1_UPDATE_Solo_Codigo"
    target_dir = os.path.join(DIST_DIR, pkg_name)
    zip_path = os.path.join(DIST_DIR, f"{pkg_name}.zip")

    print(f"\n[*] Generando paquete de actualización segura: {pkg_name}...")

    if os.path.exists(target_dir):
        shutil.rmtree(target_dir, ignore_errors=True)
    if os.path.exists(zip_path):
        try:
            os.remove(zip_path)
        except OSError:
            pass

    os.makedirs(target_dir, exist_ok=True)

    files_to_copy = [
        "requirements.txt",
        "COMMERCIAL_VERSION.json",
        "server.py",
        "database.py",
        "license_manager.py",
        "pdf_engine.py",
        "local_assistant.py",
        "verifactu_engine.py",
        "wizard_backend_bridge.py",
        "1_INSTALAR_PRIMERA_VEZ.bat",
        "2_ABRIR_OFIGREMIO.bat",
        "ACTUALIZAR_OFIGREMIO.bat",
        "1_instalar_primera_vez.sh",
        "2_abrir_ofigremio.sh",
        "actualizar_ofigremio.sh"
    ]

    for fname in files_to_copy:
        src = os.path.join(ROOT_DIR, fname)
        if os.path.exists(src):
            shutil.copy2(src, os.path.join(target_dir, fname))

    for dname in ["static", "tools"]:
        src_d = os.path.join(ROOT_DIR, dname)
        if os.path.exists(src_d):
            shutil.copytree(src_d, os.path.join(target_dir, dname), ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))

    instr = """=============================================================
   OFIGREMIO PRO — ACTUALIZACIÓN SEGURA DE VERSIÓN v4.2.1
=============================================================

Este paquete actualiza el software a la última versión SIN TOCAR
tu base de datos (ofigremio.db) ni tu licencia (carpeta data/).

PASOS PARA ACTUALIZAR EN 1 MINUTO:
1. Asegúrate de tener OfiGremio cerrado.
2. Copia todo el contenido de esta carpeta dentro de tu carpeta
   habitual de OfiGremio (normalmente C:\\OfiGremio).
3. Cuando Windows te pregunte si deseas reemplazar los archivos,
   selecciona: "Reemplazar los archivos en el destino".
4. Haz doble clic en:
   "ACTUALIZAR_OFIGREMIO.bat" (Windows) o ./actualizar_ofigremio.sh (Linux)
   (Creará un backup de seguridad y aplicará las nuevas funciones).
5. Abre OfiGremio como siempre con "2_ABRIR_OFIGREMIO.bat" o tu acceso directo.
=============================================================
"""
    with open(os.path.join(target_dir, "INSTRUCCIONES_ACTUALIZACION.txt"), "w", encoding="utf-8") as f:
        f.write(instr)

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(target_dir):
            for file in files:
                abs_file = os.path.join(root, file)
                rel_file = os.path.relpath(abs_file, target_dir)
                arcname = os.path.join(pkg_name, rel_file).replace("\\", "/")

                with open(abs_file, "rb") as fh:
                    data = fh.read()

                if file.endswith(".sh"):
                    data = data.replace(b"\r\n", b"\n")

                zinfo = zipfile.ZipInfo(arcname)
                if file.endswith(".sh"):
                    zinfo.external_attr = (0o755 << 16) | 0x20
                else:
                    zinfo.external_attr = (0o644 << 16) | 0x20
                zinfo.compress_type = zipfile.ZIP_DEFLATED
                zipf.writestr(zinfo, data)

    zip_size_mb = os.path.getsize(zip_path) / (1024 * 1024)
    print(f"    [OK] {pkg_name}.zip creado ({zip_size_mb:.2f} MB)")
    return target_dir, zip_path


def build_clean_package():
    """Genera exclusivamente los 2 paquetes limpios: Windows y Linux."""
    print("=" * 70)
    print("   OFIGREMIO PRO — GENERADOR MULTIPLATAFORMA DE PAQUETES LIMPIOS")
    print("=" * 70)
    os.makedirs(DIST_DIR, exist_ok=True)

    # 1. Construir paquete Windows
    win_dir, win_zip = build_single_os_package("windows")

    # 2. Construir paquete Linux
    lin_dir, lin_zip = build_single_os_package("linux")
    upd_dir, upd_zip = build_update_package()

    # 3. Eliminar cualquier residuo obsoleto o duplicado en dist/
    old_target = os.path.join(DIST_DIR, "OfiGremio_PRO_v4.2.1_Para_Cliente")
    old_zip = os.path.join(DIST_DIR, "OfiGremio_PRO_v4.2.1_Para_Cliente.zip")
    if os.path.exists(old_target):
        shutil.rmtree(old_target, ignore_errors=True)
    if os.path.exists(old_zip):
        try:
            os.remove(old_zip)
        except OSError:
            pass

    print("\n" + "=" * 70)
    print(" [OK] DISTRIBUCIÓN LIMPIA: 2 PAQUETES OFICIALES GENERADOS")
    print("=" * 70)
    print(f" 1. Windows: {win_zip}")
    print(f" 2. Linux:   {lin_zip}")
    print(f" 3. Update:  {upd_zip}")
    print("=" * 70)
    return True


if __name__ == "__main__":
    success = build_clean_package()
    sys.exit(0 if success else 1)
