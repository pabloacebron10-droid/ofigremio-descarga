"""
OfiGremio PRO — Script de Compilación a Binario Protegido (PyInstaller).
Convierte la aplicación en un paquete de binarios compilados en C/bytecode (.exe/.pyd/.dll)
impidiendo que el cliente o terceros tengan acceso al código fuente (.py).
"""

import os
import sys
import shutil
import subprocess

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DIST_DIR = os.path.join(ROOT_DIR, "dist")
BUILD_DIR = os.path.join(ROOT_DIR, "build")
APP_NAME = "OfiGremio_PRO"
ENTRY_POINT = os.path.join(ROOT_DIR, "server.py")
ICON_PATH = os.path.join(ROOT_DIR, "static", "favicon.ico")

def clean_previous_builds():
    """Limpia compilaciones previas si existen."""
    for p in [DIST_DIR, BUILD_DIR]:
        if os.path.exists(p):
            print(f"[*] Limpiando carpeta anterior: {os.path.basename(p)}...")
            try:
                shutil.rmtree(p, ignore_errors=True)
            except Exception:
                pass

def build():
    print("=" * 65)
    print("   OFIGREMIO PRO — COMPILADOR DE BINARIO PROTEGIDO")
    print("=" * 65)
    
    clean_previous_builds()
    
    os.chdir(ROOT_DIR)
    
    # Argumentos de PyInstaller
    cmd = [
        sys.executable,
        "-m", "PyInstaller",
        "--noconfirm",
        "--clean",
        "--name", APP_NAME,
        "--onedir",
        # Ocultar consola para usuario final o dejarla según configuración
        "--console", 
        # Incluir archivos estáticos web (HTML, JS, CSS)
        f"--add-data={os.path.join(ROOT_DIR, 'static')}{os.pathsep}static",
        # Incluir módulos ocultos requeridos dinámicamente por FastAPI y Uvicorn
        "--hidden-import=uvicorn.logging",
        "--hidden-import=uvicorn.loops",
        "--hidden-import=uvicorn.loops.auto",
        "--hidden-import=uvicorn.protocols",
        "--hidden-import=uvicorn.protocols.http",
        "--hidden-import=uvicorn.protocols.http.auto",
        "--hidden-import=uvicorn.protocols.websockets",
        "--hidden-import=uvicorn.protocols.websockets.auto",
        "--hidden-import=uvicorn.lifespan",
        "--hidden-import=uvicorn.lifespan.on",
        "--hidden-import=fastapi",
        "--hidden-import=openpyxl",
        "--hidden-import=reportlab",
        "--hidden-import=reportlab.pdfgen",
        "--hidden-import=reportlab.lib.pagesizes",
        "--hidden-import=reportlab.platypus",
        "--hidden-import=license_manager",
        "--hidden-import=db",
        "--hidden-import=wizard_backend_bridge",
        "--hidden-import=pdf_engine",
    ]
    
    if os.path.exists(ICON_PATH):
        cmd.append(f"--icon={ICON_PATH}")
        
    cmd.append(ENTRY_POINT)
    
    print(f"\n[+] Compilando {APP_NAME} a binario protegido...")
    res = subprocess.run(cmd)
    
    if res.returncode == 0:
        print("\n" + "=" * 65)
        print(" [OK] COMPILACIÓN COMPLETADA EXITOSAMENTE")
        print("=" * 65)
        print(f" Binarios generados en: {os.path.join(DIST_DIR, APP_NAME)}")
        print(" El código fuente .py ha sido completamente protegido y empaquetado.")
        print("=" * 65)
        return True
    else:
        print("\n[-] Error durante la compilación con PyInstaller.")
        return False

if __name__ == "__main__":
    success = build()
    sys.exit(0 if success else 1)

