@echo off
chcp 65001 >nul
title OfiGremio PRO - Generador de Paquete Limpio para Clientes

echo =========================================================
echo   OFIGREMIO PRO — GENERADOR DE PAQUETE LIMPIO DE ENTREGA
echo =========================================================
echo.

cd /d "%~dp0\..\.."

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python no encontrado en el sistema.
    pause
    exit /b 1
)

python tools\packaging\crear_paquete_distribucion_limpio.py

echo.
pause

