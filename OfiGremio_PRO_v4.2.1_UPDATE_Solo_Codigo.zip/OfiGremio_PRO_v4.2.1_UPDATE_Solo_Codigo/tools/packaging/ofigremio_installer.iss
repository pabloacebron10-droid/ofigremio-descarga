; =========================================================================
; OfiGremio PRO v4.2.1 — Script Oficial de Compilación Inno Setup
; Produce el instalador único "dist\OfiGremio_Setup_v4.2.1.exe"
; =========================================================================

#define MyAppName "OfiGremio PRO"
#define MyAppVersion "4.2.1"
#define MyAppPublisher "OfiGremio Systems"
#define MyAppURL "https://ofigremio.es"
#define MyAppExeName "2_ABRIR_OFIGREMIO.bat"

[Setup]
AppId={{E72F99A1-30D8-4C82-8E31-7B090F84CB12}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
DefaultDirName=C:\OfiGremio
DisableDirPage=no
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputDir=..\..\dist
OutputBaseFilename=OfiGremio_Setup_v4.2.1
SetupIconFile=..\..\static\app_icon.ico
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
CloseApplications=force

[Languages]
Name: "spanish"; MessagesFile: "compiler:Languages\Spanish.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"

[Files]
; Archivos raíz del programa (Se actualizan en cada versión)
Source: "..\..\1_INSTALAR_PRIMERA_VEZ.bat"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\2_ABRIR_OFIGREMIO.bat"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\requirements.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\MANUAL_USUARIO.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\COMMERCIAL_VERSION.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\license_manager.py"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\server.py"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\database.py"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\local_assistant.py"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\pdf_engine.py"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\wizard_backend_bridge.py"; DestDir: "{app}"; Flags: ignoreversion

; Carpetas estáticas y de herramientas
Source: "..\..\static\*"; DestDir: "{app}\static"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\..\tools\*"; DestDir: "{app}\tools"; Flags: ignoreversion recursesubdirs createallsubdirs

; 🛡️ PROTECCIÓN SAGRADA DE DATOS Y LICENCIA DEL CLIENTE:
; 'onlyifdestdoesntexist' garantiza que si el cliente ya tiene facturas o licencia activa,
; NUNCA se sobreescribirá al actualizar el software.
Source: "..\..\data\*"; DestDir: "{app}\data"; Flags: onlyifdestdoesntexist recursesubdirs createallsubdirs

[Icons]
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\static\app_icon.ico"; Tasks: desktopicon
Name: "{autoprograms}\{#MyAppName}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\static\app_icon.ico"
Name: "{autoprograms}\{#MyAppName}\Desinstalar {#MyAppName}"; Filename: "{uninstallexe}"

[Run]
Filename: "{app}\1_INSTALAR_PRIMERA_VEZ.bat"; Description: "Completar instalación y arrancar OfiGremio PRO"; Flags: postinstall skipifsilent nowait

