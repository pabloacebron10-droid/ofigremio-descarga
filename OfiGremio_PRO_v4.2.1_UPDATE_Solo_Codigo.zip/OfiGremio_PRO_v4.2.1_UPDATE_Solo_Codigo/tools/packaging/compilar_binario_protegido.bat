@echo off
chcp 65001 >nul
title OfiGremio PRO - Compilar Binario Protegido

echo =========================================================
echo    OFIGREMIO PRO — COMPILACION DE BINARIO PROTEGIDO
echo =========================================================
echo.

cd /d "%~dp0\..\.."

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python no encontrado en el sistema.
    pause
    exit /b 1
)

python tools\packaging\build_binary.py

echo.
pause

