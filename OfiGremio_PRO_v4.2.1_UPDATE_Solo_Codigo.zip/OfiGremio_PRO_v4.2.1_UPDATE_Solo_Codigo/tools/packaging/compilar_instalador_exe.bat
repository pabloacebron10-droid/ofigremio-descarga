@echo off
chcp 65001 >nul
title OfiGremio PRO - Compilar Instalador Setup.exe

echo =========================================================
echo    OFIGREMIO PRO — GENERADOR DE INSTALADOR OFICIAL .EXE
echo =========================================================
echo.

cd /d "%~dp0\..\.."

REM 1. Buscar ISCC.exe (Inno Setup Compiler)
set "ISCC_PATH="
where iscc.exe >nul 2>&1
if %errorlevel% equ 0 (
    set "ISCC_PATH=iscc.exe"
) else if exist "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" (
    set "ISCC_PATH=C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
) else if exist "C:\Program Files\Inno Setup 6\ISCC.exe" (
    set "ISCC_PATH=C:\Program Files\Inno Setup 6\ISCC.exe"
)

if "%ISCC_PATH%"=="" (
    echo [!] No se encontro el compilador de Inno Setup (ISCC.exe).
    echo.
    echo Puedes instalarlo rapidamente de forma gratuita con winget ejecutando:
    echo     winget install JRSoftware.InnoSetup
    echo.
    echo O descargarlo directamente desde:
    echo     https://jrsoftware.org/isdl.php
    echo.
    pause
    exit /b 1
)

echo [+] Compilador Inno Setup detectado en: "%ISCC_PATH%"
echo [+] Generando instalador comercial Setup_OfiGremio_PRO_v4.2.1.exe...
echo.

"%ISCC_PATH%" "tools\packaging\ofigremio_installer.iss"

if %errorlevel% equ 0 (
    echo.
    echo =========================================================
    echo  [OK] INSTALADOR GENERADO EXITOSAMENTE
    echo =========================================================
    echo  El instalador listo para entregar al cliente esta en:
    echo  dist\Setup_OfiGremio_PRO_v4.2.1.exe
    echo =========================================================
) else (
    echo [ERROR] Ocurrio un fallo durante la compilacion del instalador.
)

echo.
pause

