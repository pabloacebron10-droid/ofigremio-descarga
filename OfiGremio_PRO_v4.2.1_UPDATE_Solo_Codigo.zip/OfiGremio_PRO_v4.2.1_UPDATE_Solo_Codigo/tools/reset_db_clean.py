"""
Certificación de Estado Limpio Kilómetro Cero para OfiGremio PRO v3.7.0.
Sanea a fondo el directorio de datos, elimina archivos temporales, backups,
hojas de cálculo de pruebas y PDFs históricos, e inicializa la base de datos
en estado virgen lista para producción y comercialización.
"""

import os
import sys
import glob
import gc

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

# Configure stdout for utf-8 on Windows
if sys.stdout.encoding and sys.stdout.encoding.lower() != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

import database
import sqlite3


def _truncate_tables_fallback(db_path: str):
    """
    Fallback de truncado SQL para entornos Windows cuando el archivo SQLite
    está bloqueado por un proceso concurrente activo (server.py en ejecución).
    Limpia todas las tablas de negocio, preserva al administrador predeterminado
    y reinicia los contadores autoincrementales sin necesidad de reiniciar el servidor.
    """
    print(f"[Kilómetro Cero] Archivo bloqueado por proceso activo. Ejecutando truncado SQL fallback: {db_path}")
    conn = sqlite3.connect(db_path, timeout=10.0)
    try:
        cur = conn.cursor()
        cur.execute("PRAGMA busy_timeout = 10000;")
        cur.execute("PRAGMA foreign_keys = OFF;")

        # Tablas de datos de negocio y catálogo a truncar
        tables_to_truncate = [
            "partidas",
            "presupuestos",
            "clientes",
            "compras_items",
            "compras_gastos",
            "proveedores",
            "stock_movimientos",
            "asistente_memoria",
            "config",
            "configuracion",
            "catalogo_partidas",
            "registro_identidades_globales",
            "usuarios"
        ]

        cur.execute("SELECT name FROM sqlite_master WHERE type='table';")
        existing_tables = {row[0] for row in cur.fetchall()}

        for tbl in tables_to_truncate:
            if tbl in existing_tables:
                cur.execute(f"DELETE FROM {tbl};")

        # Reiniciar contadores de clave primaria autoincremental
        if "sqlite_sequence" in existing_tables:
            cur.execute("DELETE FROM sqlite_sequence;")

        conn.commit()

        # Checkpoint WAL para truncar el journal concurrente a 0 bytes
        try:
            cur.execute("PRAGMA wal_checkpoint(TRUNCATE);")
        except Exception:
            pass

        cur.execute("PRAGMA foreign_keys = ON;")
    finally:
        conn.close()


def sanitize_data_directory(data_dir: str):
    """
    Sanea a fondo el directorio persistente data/:
    - Elimina archivos temporales SQLite WAL y SHM.
    - Elimina copias de seguridad de desarrollo (*backup*.db).
    - Elimina hojas de cálculo temporales (*.xlsx).
    - Elimina todos los PDFs históricos de clientes y pruebas.
    - Asegura que el subdirectorio pdfs/ exista y esté completamente limpio.
    """
    gc.collect()
    if not os.path.exists(data_dir):
        os.makedirs(data_dir, exist_ok=True)

    # 1. Eliminar archivos temporales de BD (-wal, -shm)
    for pattern in ("*.db-wal", "*.db-shm", "*-wal", "*-shm"):
        for f in glob.glob(os.path.join(data_dir, pattern)):
            try:
                os.remove(f)
            except OSError:
                pass

    # 2. Eliminar backups antiguos
    for f in os.listdir(data_dir):
        if "backup" in f and f.endswith(".db"):
            fpath = os.path.join(data_dir, f)
            try:
                os.remove(fpath)
            except OSError:
                pass

    # 3. Eliminar hojas de calculo temporales de pruebas y exportaciones
    for f in os.listdir(data_dir):
        if f.endswith(".xlsx"):
            fpath = os.path.join(data_dir, f)
            try:
                os.remove(fpath)
            except OSError:
                pass

    # 4. Limpiar directorio de PDFs historicos
    pdfs_dir = os.path.join(data_dir, "pdfs")
    if os.path.exists(pdfs_dir):
        for item in os.listdir(pdfs_dir):
            if item == ".gitkeep":
                continue
            item_path = os.path.join(pdfs_dir, item)
            if os.path.isfile(item_path):
                try:
                    os.remove(item_path)
                except OSError:
                    pass
    else:
        os.makedirs(pdfs_dir, exist_ok=True)


def reset_to_clean_production():
    gc.collect()
    db_path = os.path.abspath(database.DB_PATH)
    data_dir = os.path.dirname(db_path)
    canonical_data_dir = os.path.abspath(os.path.join(ROOT_DIR, "data"))
    is_canonical = (data_dir == canonical_data_dir) or (os.path.basename(data_dir) == "data")

    print(f"[Kilómetro Cero] Saneando e inicializando entorno de producción: {db_path}")

    # 1. Intentar eliminar físicamente el archivo de BD y sus journals WAL/SHM
    file_deleted = True
    for target in (db_path, f"{db_path}-wal", f"{db_path}-shm"):
        if os.path.exists(target):
            try:
                os.remove(target)
            except OSError:
                file_deleted = False

    # 2. Si el archivo no pudo eliminarse debido a bloqueos de Windows (server.py activo),
    # ejecutar el truncado explícito vía SQL para garantizar el estado Kilómetro Cero
    if os.path.exists(db_path):
        _truncate_tables_fallback(db_path)

    # 3. Sanitizar directorio de datos si corresponde
    if is_canonical and os.path.exists(data_dir):
        sanitize_data_directory(data_dir)
    elif os.path.exists(canonical_data_dir):
        sanitize_data_directory(canonical_data_dir)

    # 4. Inicializar la base de datos limpia sin seed de catálogo demo
    database.init_db(seed_catalog=False)

    # 4. Verificación de integridad de la base de datos
    cfg = database.get_config()
    clients = database.list_clients()
    quotes = database.list_quotes()
    catalog = database.list_catalog()
    suppliers = database.list_suppliers()
    expenses = database.list_expenses()
    users = database.list_users()

    print("[OK] Base de datos reseteada con éxito a Kilómetro Cero:")
    print(f"  - primera_configuracion_pendiente: {cfg.get('primera_configuracion_pendiente')} (debe ser '1')")
    print(f"  - Clientes: {len(clients)} (debe ser 0)")
    print(f"  - Presupuestos: {len(quotes)} (debe ser 0)")
    print(f"  - Partidas de catálogo: {len(catalog)} (debe ser 0)")
    print(f"  - Proveedores: {len(suppliers)} (debe ser 0)")
    print(f"  - Compras y Gastos: {len(expenses)} (debe ser 0)")
    print(f"  - Usuarios administradores preparados: {len(users)} (usuario 'admin' disponible)")

    assert cfg.get("primera_configuracion_pendiente") == "1", "Error: primera_configuracion_pendiente debe ser '1'"
    assert len(clients) == 0, "Error: clientes no está vacío"
    assert len(quotes) == 0, "Error: presupuestos no está vacío"
    assert len(catalog) == 0, "Error: catálogo de stock debe estar 100% limpio (0)"
    assert len(suppliers) == 0, "Error: proveedores debe estar 100% limpio (0)"
    assert len(expenses) == 0, "Error: compras debe estar 100% limpio (0)"
    assert len(users) >= 1, "Error: debe existir al menos el usuario administrador predeterminado"

    # 5. Verificación física del directorio data/ (en modo producción canonical)
    target_check_dir = data_dir if is_canonical else canonical_data_dir
    if is_canonical and os.path.exists(target_check_dir):
        pdfs_dir = os.path.join(target_check_dir, "pdfs")
        assert os.path.exists(pdfs_dir), "Error: carpeta data/pdfs no existe"
        pdf_files = [f for f in os.listdir(pdfs_dir) if f.endswith(".pdf")]
        assert len(pdf_files) == 0, f"Error: la carpeta data/pdfs contiene {len(pdf_files)} PDFs residuales"

        xlsx_files = [f for f in os.listdir(target_check_dir) if f.endswith(".xlsx")]
        assert len(xlsx_files) == 0, f"Error: quedan archivos Excel residuales en data/: {xlsx_files}"

        backup_files = [f for f in os.listdir(target_check_dir) if "backup" in f and f.endswith(".db")]
        assert len(backup_files) == 0, f"Error: quedan copias de seguridad residuales en data/: {backup_files}"

    print("[ÉXITO] [OfiGremio PRO v3.7.0] Certificación Kilómetro Cero 100% verificada y lista para entrega comercial.")


if __name__ == "__main__":
    reset_to_clean_production()
