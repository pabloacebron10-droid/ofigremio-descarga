@echo off
chcp 65001 >nul
title OfiGremio PRO — Sistema de Gestion para Instaladores y Gremios
color 0A

cd /d "%~dp0"

echo =========================================================================
echo   OfiGremio PRO — Software Local-First para Gremios y Reformas
echo   [USO DIARIO] Iniciando aplicacion local (o use el icono del Escritorio)
echo   Privacidad Absoluta (0%% Nube, 100%% Local en tu Equipo)
echo =========================================================================
echo.

:: 1. Activar entorno virtual si existe
if exist ".venv\Scripts\python.exe" (
    set "PYTHON_EXE=.venv\Scripts\python.exe"
) else (
    set "PYTHON_EXE=python"
)

:: 2. Lanzador en segundo plano que espera el arranque y abre el navegador en el puerto exacto
start "" powershell -NoProfile -ExecutionPolicy Bypass -Command "$port = 8080; for ($i=0; $i -lt 30; $i++) { Start-Sleep -Milliseconds 400; if (Test-Path 'data\server_info.json') { try { $info = Get-Content 'data\server_info.json' -Raw | ConvertFrom-Json; if ($info.port) { $port = $info.port; break } } catch {} }; try { $con = Test-NetConnection -ComputerName '127.0.0.1' -Port $port -WarningAction SilentlyContinue; if ($con.TcpTestSucceeded) { break } } catch {} }; Start-Process ('http://localhost:' + $port)"

echo Iniciando servidor local OfiGremio PRO...
echo (Presione Ctrl+C en esta ventana para detener el servidor cuando termine su jornada de trabajo)
echo.
"%PYTHON_EXE%" server.py

pause
