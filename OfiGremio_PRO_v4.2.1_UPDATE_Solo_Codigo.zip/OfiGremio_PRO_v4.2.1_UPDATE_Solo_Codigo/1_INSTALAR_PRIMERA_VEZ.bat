@echo off
chcp 65001 >nul
title OfiGremio PRO v4.2.1 — Instalador Automatizado (Solo 1a Vez)
color 0B

echo =========================================================================
echo   OfiGremio PRO — Instalador Automatizado "Todo en Uno"
echo   [PASO 1] Ejecutar este archivo SOLO LA PRIMERA VEZ en este equipo.
echo   Configura Python, dependencias, firewall y crea el icono en el Escritorio.
echo =========================================================================
echo.

cd /d "%~dp0"

:: -------------------------------------------------------------------------
:: [1/5] Verificación e Instalación Automática de Python
:: -------------------------------------------------------------------------
echo [1/5] Comprobando entorno de ejecucion Python en el equipo...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [AVISO] Python no esta presente en el sistema.
    echo Instalando Python 3.12 automaticamente mediante el gestor oficial de Windows (winget)...
    winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements --silent
    if %errorlevel% neq 0 (
        echo [ERROR] No se pudo instalar Python automaticamente mediante winget.
        echo Por favor instale Python 3.10+ desde https://www.python.org/downloads/
        echo Marcando la casilla: 'Add python.exe to PATH'
        pause
        exit /b 1
    )
    echo [OK] Python instalado con exito. Actualizando variables de entorno...
    set "PATH=%LOCALAPPDATA%\Programs\Python\Python312;%LOCALAPPDATA%\Programs\Python\Python312\Scripts;%PATH%"
) else (
    echo [OK] Python detectado correctamente.
)

:: -------------------------------------------------------------------------
:: [2/5] Creación de Entorno Virtual Aislado (.venv)
:: -------------------------------------------------------------------------
echo.
echo [2/5] Configurando Entorno Virtual Aislado (.venv)...
if not exist ".venv" (
    python -m venv .venv
    if %errorlevel% neq 0 (
        echo [ERROR] No se pudo crear el entorno virtual.
        pause
        exit /b 1
    )
    echo [OK] Entorno virtual privado creado con exito.
) else (
    echo [OK] Entorno virtual existente detectado.
)

:: -------------------------------------------------------------------------
:: [3/5] Instalación de Dependencias Oficiales en .venv
:: -------------------------------------------------------------------------
echo.
echo [3/5] Instalando dependencias oficiales (FastAPI, ReportLab, OpenPyXL, etc.)...
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip --quiet
python -m pip install -r requirements.txt --quiet
if %errorlevel% neq 0 (
    echo [AVISO] Hubo un problema al instalar las dependencias. Reintentando...
    python -m pip install -r requirements.txt
)
echo [OK] Todas las dependencias han quedado instaladas y verificadas.

:: -------------------------------------------------------------------------
:: [4/5] Generación de Icono Oficial y Acceso Directo en el Escritorio
:: -------------------------------------------------------------------------
echo.
echo [4/5] Generando Icono Oficial y Acceso Directo en el Escritorio...
if not exist "static\app_icon.ico" (
    if exist "tools\generate_app_icons.py" (
        python tools\generate_app_icons.py >nul 2>&1
    )
)

set "SHORTCUT_PATH=%USERPROFILE%\Desktop\OfiGremio PRO.lnk"
set "TARGET_BAT=%~dp02_ABRIR_OFIGREMIO.bat"
set "ICON_FILE=%~dp0static\app_icon.ico"
set "WORKDIR=%~dp0"

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%SHORTCUT_PATH%'); $s.TargetPath = '%TARGET_BAT%'; $s.WorkingDirectory = '%WORKDIR%'; if (Test-Path '%ICON_FILE%') { $s.IconLocation = '%ICON_FILE%' }; $s.Description = 'OfiGremio PRO — Sistema de Gestion para Instaladores y Gremios'; $s.Save()"

if exist "%SHORTCUT_PATH%" (
    echo [OK] Acceso directo 'OfiGremio PRO' creado con exito en el Escritorio.
) else (
    echo [AVISO] No se pudo crear el acceso directo en el escritorio automaticamente.
)

:: -------------------------------------------------------------------------
:: [5/5] Regla de Firewall Local para el Puerto de la Aplicación
:: -------------------------------------------------------------------------
echo.
echo [5/5] Configurando regla de firewall local para conectar movil/tablet en obra...
powershell -NoProfile -ExecutionPolicy Bypass -Command "if ([bool](([System.Security.Principal.WindowsIdentity]::GetCurrent()).groups -match 'S-1-5-32-544')) { New-NetFirewallRule -DisplayName 'OfiGremio PRO Local' -Direction Inbound -LocalPort 8080,8081,8765 -Protocol TCP -Action Allow -ErrorAction SilentlyContinue | Out-Null }" >nul 2>&1
echo [OK] Configuracion de red verificada.

echo.
echo =========================================================================
echo   [INSTALACION COMPLETADA CON EXITO]
echo   OfiGremio PRO esta 100%% configurado y listo para usar en este equipo.
echo   Puede arrancarlo en cualquier momento desde el acceso directo del Escritorio.
echo =========================================================================
echo.
echo Presione cualquier tecla para iniciar OfiGremio PRO ahora mismo...
pause >nul
start "" "%TARGET_BAT%"
exit /b 0

