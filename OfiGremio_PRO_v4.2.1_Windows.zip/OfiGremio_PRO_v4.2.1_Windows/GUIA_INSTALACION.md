# 📘 Guía Oficial de Instalación, Activación y Despliegue — OfiGremio PRO v4.2.1

Bienvenido a la guía oficial de instalación y puesta en marcha de **OfiGremio PRO v4.2.1**. Este documento cubre tanto los pasos para el **cliente final (autónomo o empresa)** como los procedimientos para el **desarrollador (distribución, licencias y compilación)**.

---

## Índice Rápido
1. [Para el Cliente Final: Instalación y Primer Uso](#1-para-el-cliente-final-instalación-y-primer-uso)
2. [Activación de Licencia por Hardware (HWID)](#2-activación-de-licencia-por-hardware-hwid)
3. [Conexión desde el Móvil o Tablet (Código QR)](#3-conexión-desde-el-móvil-o-tablet-código-qr)
4. [¿Cómo funcionan las Actualizaciones sin perder Facturas?](#4-cómo-funcionan-las-actualizaciones-sin-perder-facturas)
5. [Para el Desarrollador: Generación de Licencias y Compilación de `.exe`](#5-para-el-desarrollador-generación-de-licencias-y-compilación-de-exe)
6. [Preguntas Frecuentes](#6-preguntas-frecuentes)

---

## 1. Para el Cliente Final: Instalación y Primer Uso

OfiGremio PRO está diseñado para instalarse en menos de 2 minutos sin complicaciones técnicas.

### Opción A: Mediante el Instalador Oficial `.exe` (Recomendado para Clientes)
1. Haz doble clic sobre el archivo descargado:  
   `Setup_OfiGremio_PRO_v4.2.1.exe`
2. Sigue el asistente de instalación (instala en `C:\OfiGremio` por defecto).
3. Marca la casilla **"Crear acceso directo en el Escritorio"** y pulsa **Instalar**.
4. Al terminar, el programa se iniciará automáticamente.

### Opción B: Mediante la Carpeta del Programa (Modo Portátil)
Si has recibido la carpeta de OfiGremio PRO descomprimida:
1. Abre la carpeta principal.
2. Ejecuta una sola vez el archivo:  
   `1_INSTALAR_PRIMERA_VEZ.bat`  
   *(Verifica los componentes y crea la base de datos limpia).*
3. Para el uso diario, ejecuta:  
   `2_ABRIR_OFIGREMIO.bat`  
   *(Abre la aplicación en tu navegador web habitual).*

---

## 2. Activación de Licencia por Hardware (HWID)

OfiGremio PRO incluye un sistema de protección vinculado al equipo físico que garantiza la exclusividad de tu copia:

```
+-----------------------------------------------------------+
|               PANTALLA DE ACTIVACIÓN                      |
|                                                           |
|  Tu identificador de equipo (HWID):                       |
|  [ OFG-DA3A-03E8-3905-75A0 ]  [ 📋 Copiar ] [ 💬 WhatsApp ]|
|                                                           |
|  Introduce tu clave de licencia recibida:                 |
|  [                                                     ]  |
|  [ 🚀 ACTIVAR OFIGREMIO PRO ]                             |
+-----------------------------------------------------------+
```

1. Al abrir la app por primera vez, verás la pantalla de activación con tu **Hardware ID** (ejemplo: `OFG-DA3A-03E8-3905-75A0`).
2. Pulsa en **"Copiar"** o **"WhatsApp"** para enviar ese identificador al proveedor/desarrollador.
3. El desarrollador te entregará tu **Clave de Activación Comercial**.
4. Pégala en el recuadro y pulsa **"Activar OfiGremio PRO"**.
5. ¡Listo! El programa queda desbloqueado de por vida en ese ordenador.

---

## 3. Conexión desde el Móvil o Tablet (Código QR)

No necesitas instalar nada en el móvil ni descargar apps de Google Play o App Store. Todo funciona mediante la aplicación web progresiva (PWA):

### ¿Cómo abrir el Código QR en la pantalla de tu ordenador?
1. En OfiGremio, abre el **Menú Lateral Desplegable** (icono ☰ en la esquina superior izquierda).
2. Pulsa en:  
   **"📱 Conectar Móvil / Tablet (Código QR)"**
3. Se abrirá una ventana emergente con dos opciones:

#### A) 🏠 Modo Taller / Oficina (Mismo WiFi)
- Para usar tablets o móviles mientras estés dentro del taller o tu casa.
- Ambos dispositivos deben estar conectados al mismo WiFi.
- Escanea el código QR que aparece en pantalla con la cámara del móvil y pulsa el enlace.

#### B) 🚗 Modo Calle / Obra (Conexión 4G / 5G desde cualquier lugar)
- Para consultar o emitir facturas en la furgoneta, en casa del cliente o en la obra.
- **Paso único:** En tu ordenador, abre la carpeta `tools\remote` y haz doble clic en:  
  `conectar_acceso_remoto_4g.bat`
- Se activará una conexión cifrada de alta seguridad (Cloudflare Tunnel con HTTPS).
- En la pestaña "En la Calle (4G)" del menú de OfiGremio aparecerá de inmediato el nuevo código QR y la dirección segura.

> [!TIP]
> **En el móvil:** En cuanto se abra la página en Chrome (Android) o Safari (iPhone), pulsa en los 3 puntos del navegador y elige **"Añadir a la pantalla de inicio"** o **"Instalar aplicación"**. Te creará un icono como cualquier app nativa a pantalla completa.

---

## 4. ¿Cómo funcionan las Actualizaciones sin perder Facturas?

> [!IMPORTANT]
> **GARANTÍA SAGRADA DE DATOS:**  
> Instalar una nueva versión de OfiGremio PRO jamás sobrescribirá tus facturas, tus clientes, tus gastos ni tu licencia activa.

El instalador y las actualizaciones utilizan la regla de protección:
- **Archivos que se renuevan:** Motor del programa, diseño de pantallas, nuevas funcionalidades y mejoras.
- **Archivos sagrados que se conservan intactos:**
  - `data/ofigremio.db` (Toda tu contabilidad, facturas, presupuestos e histórico).
  - `data/license.key` (Tu licencia comercial activa, no tendrás que volver a pedirla).
  - `data/backups/` (Tus copias de seguridad automáticas de seguridad).

---

## 5. Para el Desarrollador: Generación de Licencias y Compilación de `.exe`

Esta sección es exclusiva para el administrador del software para emitir claves a clientes y preparar los paquetes de venta.

### 5.1. Generar una Licencia Comercial para un Cliente
Abre una terminal o haz doble clic en `tools\licensing\generar_licencia.py`:
```bash
python tools/licensing/generar_licencia.py --cliente "Fontanería Hermanos Pérez S.L." --hwid "OFG-DA3A-03E8-3905-75A0" --tipo LIFETIME
```
- **Salida:** Imprime el código en Base64 firmado con tu clave maestra privada HMAC-SHA256.
- Cópialo y envíaselo al cliente por WhatsApp o email.

### 5.2. Compilar el Binario Protegido (PyInstaller)
Para empaquetar el código Python en ejecutables binarios `.exe` y librerías `.dll`/`.pyd` (sin dejar archivos `.py` abiertos):
1. Ejecuta:  
   `tools\packaging\compilar_binario_protegido.bat`
2. Generará la carpeta distribuible en `dist\OfiGremio_PRO\`.

### 5.3. Generar el Instalador Oficial Comercial `.exe` (Inno Setup)
1. Ejecuta:  
   `tools\packaging\compilar_instalador_exe.bat`
2. Si tienes Inno Setup instalado, generará en 1 minuto el instalador:  
   `dist\OfiGremio_Setup_v4.2.1.exe`
3. Este es el único archivo que envías al cliente final para su venta.

---

## 6. Preguntas Frecuentes

### ¿Al hacer cambios en el código hay que volver a compilar el `.exe` cada vez?
**No, en absoluto.**
- **En tu equipo de desarrollo:** Puedes seguir trabajando directamente con el código fuente. Cualquier mejora que hagas en `server.py`, `static/index.html` o la base de datos se refleja inmediatamente en el navegador al recargar.
- **¿Cuándo se compila el `.exe`?:** Solo debes compilar el `.exe` cuando hayas terminado un lote de trabajo y quieras **empaquetar una nueva versión final para entregar a tus clientes** (por ejemplo, al lanzar la versión oficial v4.2.1 o una futura v4.3).

### ¿Qué pasa si un cliente intenta copiar la carpeta a otro ordenador?
El sistema calcula el HWID en cada arranque. Si detecta que la Placa Base, el procesador o el disco no coinciden con la licencia (`HWID_MISMATCH`), la aplicación se bloquea de inmediato y le pide activar una nueva licencia autorizada.

### ¿El acceso 4G desde el móvil cuesta dinero o consume servidores?
No cuesta nada. Utiliza la tecnología **Cloudflare Zero Trust / Tunnel**, que ofrece túneles cifrados HTTPS de alta velocidad gratuitos de extremo a extremo sin necesidad de contratar servidores VPS, ni pagar dominios ni abrir puertos en el router del taller.

