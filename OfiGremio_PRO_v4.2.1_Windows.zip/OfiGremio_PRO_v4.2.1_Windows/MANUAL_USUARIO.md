# 📖 Manual de Usuario y Puesta en Marcha — OfiGremio PRO v4.2.1

Bienvenido a **OfiGremio PRO**, la solución integral y 100% local de gestión técnica y comercial para autónomos y empresas de fontanería, electricidad, climatización, cerrajería y reformas integrales.

---

## ⚡ 1. Instalación en el Equipo del Cliente (Menos de 2 minutos)

OfiGremio PRO incluye un sistema de instalación automatizado de 1 solo clic. No se requieren conocimientos técnicos.

### Paso 1: Copiar la carpeta
1. Conecte su memoria USB o descargue la carpeta del programa en el ordenador del cliente.
2. Cópiela en una ruta de fácil acceso (ejemplo recomendado: `C:\OfiGremio` o en la carpeta personal del usuario).

### Paso 2: Ejecutar el instalador
1. Abra la carpeta y haga doble clic sobre:  
   **`1_INSTALAR_PRIMERA_VEZ.bat`**
2. El sistema realizará automáticamente:
   - Detección e instalación desatendida de Python si no estuviera presente.
   - Creación de un entorno virtual aislado (`.venv`) para no interferir con otros programas.
   - Instalación y verificación de dependencias oficiales (`FastAPI`, `ReportLab`, `OpenPyXL`, etc.).
   - Configuración de reglas de red local (Firewall) para enlazar teléfonos móviles o tablets.
   - **Creación automática del acceso directo "OfiGremio PRO" con icono oficial en el Escritorio**.
   - Apertura inmediata del navegador web en el sistema.

> [!NOTE]  
> Este instalador (`1_INSTALAR_PRIMERA_VEZ.bat`) solo se ejecuta **una única vez** por equipo.

---

## 🚀 2. Uso Diario: Cómo Abrir la Aplicación

Para abrir OfiGremio PRO en el día a día, el cliente tiene dos opciones:
1. **Acceso Directo del Escritorio (Recomendado):**  
   Haga doble clic en el icono **`OfiGremio PRO`** situado en su Escritorio de Windows.
2. **Desde la carpeta:**  
   Haga doble clic en **`2_ABRIR_OFIGREMIO.bat`**.

La aplicación detectará automáticamente el puerto disponible (8080, 8081, etc.) sin entrar en conflicto con ningún otro programa y abrirá la ventana de trabajo. Para cerrar el programa al finalizar la jornada, basta con cerrar la ventana de consola negra.

---

## 📲 3. Conexión de Móvil o Tablet en Obra / Taller

Puede utilizar OfiGremio desde cualquier teléfono móvil o tablet conectado a la misma red Wi-Fi:

1. En la aplicación del ordenador, pulse el botón de menú lateral **`☰ Menú`** (esquina superior izquierda).
2. Seleccione la opción **`📲 Conectar Móvil / Tablet`**.
3. Apunte la cámara de su móvil o tablet al **Código QR** que aparecerá en pantalla.
4. **Instalar como App Nativa (PWA):**
   - **En Android:** Pulse el mensaje emergente *"Añadir OfiGremio a la pantalla de inicio"*.
   - **En iPhone / iPad:** Pulse el botón de *"Compartir"* de Safari (cuadrado con flecha) y seleccione *"Añadir a pantalla de inicio"*.
5. Tendrá OfiGremio funcionando a pantalla completa en el móvil para tomar medidas, dictar por voz y recoger firmas de clientes en obra.

---

## 🏢 4. Asistente Inicial de Configuración (Wizard)

La primera vez que abra la aplicación se iniciará el **Asistente de Bienvenida**:

1. **Datos de su Empresa:** Introduzca su Nombre Comercial, CIF/NIF y Dirección fiscal.
2. **Contacto Directo:** Teléfono y WhatsApp para enviar facturas con un clic.
3. **Cobro Inmediato (Bizum / IBAN):** Escriba su cuenta bancaria o teléfono Bizum. Se estampará automáticamente un código QR de pago en sus presupuestos y facturas en PDF.
4. **Logotipo Oficial:** Suba la imagen del logo de su empresa para personalizar los documentos.

---

## 📋 5. Creación de Presupuestos y Facturación Rápida

1. Pulse el botón verde **`+ Nuevo Presupuesto`**.
2. Seleccione un cliente o cree uno nuevo en el momento.
3. **Mano de obra y materiales:**
   - Puede usar los **Kits Rápidos** organizados por gremio (ej. Kit Desatasco, Cuadro Eléctrico, Climatización).
   - Añada conceptos personalizados con indicación de IVA (10% o 21%) y retención IRPF (si aplica).
4. **Dictado por Voz:** Pulse el micrófono para transcribir notas tomadas a pie de obra.
5. **Firma Digital en Pantalla:** Si el cliente está presente, pulse **`✍️ Firma Digital`** para que firme con el dedo o lápiz táctil.
6. **Anticipos y Entregas a Cuenta:** Registre fácilmente pagos a cuenta (ej. 30% o 50%) que se descontarán automáticamente del total pendiente.
7. **Emisión y Envío:**  
   - Pulse **`📄 Ver PDF`** para obtener el documento oficial con pie legal y cláusula RGPD.
   - Pulse **`📱 WhatsApp`** para enviar el desglose y PDF directamente al móvil del cliente.
   - Pulse **`💶 Cobrar`** para convertir el presupuesto en **Factura Oficial** numerada (`FAC-YYYY-NNNN`).

---

## 🛡️ 6. Copias de Seguridad y Seguridad de Datos

- **100% Local y Privado:** Sus datos nunca viajan a servidores externos ni a la nube de terceros.
- **Auto-Backup Atómico:** Cada vez que realiza una modificación crítica, el sistema genera copias de seguridad automáticas en la carpeta `data/backups/`.
- **Copia Externa (USB / Disco Externo):**  
  En el menú lateral, pulse **`💾 Copia de Seguridad`** para descargar un duplicado exacto de su base de datos (`.db`).
- **Exportación Contable a Excel:**  
  Descargue en cualquier momento el libro oficial de **Facturas Emitidas Cobradas** y **Gastos Pagados** listo para su gestoría.
