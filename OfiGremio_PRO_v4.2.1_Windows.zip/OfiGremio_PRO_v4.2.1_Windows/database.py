"""
Módulo de Base de Datos SQLite Local-First para OfiGremio PRO v3.7.0.
Garantiza persistencia offline, cero fuga de datos, migración automática y exportación a Excel.
"""

import sqlite3
import os
import json
import hashlib
import secrets
import base64
import hmac
from datetime import datetime, timezone
from contextlib import contextmanager
import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

DB_PATH = os.environ.get(
    "OFIGREMIO_DB_PATH",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "ofigremio.db")
)

def set_db_path(new_path: str):
    """Establece dinámicamente la ruta de la base de datos (usado en tests y entornos aislados)."""
    global DB_PATH
    DB_PATH = os.path.realpath(new_path)
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    return DB_PATH


DEFAULT_CATALOG_ITEMS = [
    {"gremio": "FONTANERIA", "tipo": "KIT", "descripcion": "Kit desatasco mecánico + limpieza sifón y juntas", "cantidad_default": 1.0, "precio_unitario": 65.0},
    {"gremio": "FONTANERIA", "tipo": "MATERIAL", "descripcion": "Grifo monomando cromado alta eficiencia + latiguillos", "cantidad_default": 1.0, "precio_unitario": 78.0},
    {"gremio": "FONTANERIA", "tipo": "KIT", "descripcion": "Sustitución mecanismo cisterna universal doble descarga", "cantidad_default": 1.0, "precio_unitario": 48.0},
    {"gremio": "FONTANERIA", "tipo": "MATERIAL", "descripcion": "Termo eléctrico vertical 80L bajo consumo + válvula seguridad", "cantidad_default": 1.0, "precio_unitario": 210.0},
    {"gremio": "FONTANERIA", "tipo": "MATERIAL", "descripcion": "Válvula reductora de presión 3/4 con manómetro de control", "cantidad_default": 1.0, "precio_unitario": 72.5},
    {"gremio": "FONTANERIA", "tipo": "TRABAJO", "descripcion": "Sustitución de llave de paso general y contador", "cantidad_default": 1.0, "precio_unitario": 45.0},
    {"gremio": "FONTANERIA", "tipo": "TRABAJO", "descripcion": "Desatasco con hidrolimpiadora a presión y tobera rotativa", "cantidad_default": 1.0, "precio_unitario": 120.0},
    {"gremio": "FONTANERIA", "tipo": "TRABAJO", "descripcion": "Sustitución tramo bajante PVC 110mm en vivienda", "cantidad_default": 1.0, "precio_unitario": 95.0},
    {"gremio": "FONTANERIA", "tipo": "MATERIAL", "descripcion": "Conjunto desagüe sifónico y válvula clic-clac para lavabo", "cantidad_default": 1.0, "precio_unitario": 32.0},
    {"gremio": "FONTANERIA", "tipo": "MATERIAL", "descripcion": "Bomba centrífuga grupo de presión 1.5CV", "cantidad_default": 1.0, "precio_unitario": 480.0},
    {"gremio": "FONTANERIA", "tipo": "TRABAJO", "descripcion": "Reparación de fuga en tubería de cobre mediante soldadura", "cantidad_default": 1.0, "precio_unitario": 65.0},
    {"gremio": "FONTANERIA", "tipo": "KIT", "descripcion": "Sustitución de bote sifónico en baño", "cantidad_default": 1.0, "precio_unitario": 110.0},
    {"gremio": "FONTANERIA", "tipo": "MATERIAL", "descripcion": "Latiguillos inoxidables flexibles 3/8-3/8 30cm (pareja)", "cantidad_default": 1.0, "precio_unitario": 14.5},
    {"gremio": "FONTANERIA", "tipo": "MATERIAL", "descripcion": "Llave de escuadra antical con filtro lavadora/lavavajillas", "cantidad_default": 1.0, "precio_unitario": 18.0},
    {"gremio": "FONTANERIA", "tipo": "TRABAJO", "descripcion": "Localización acústica de fugas no visibles en circuito de agua", "cantidad_default": 1.0, "precio_unitario": 150.0},
    {"gremio": "FONTANERIA", "tipo": "MATERIAL", "descripcion": "Tratamiento antical magnético para acometida general", "cantidad_default": 1.0, "precio_unitario": 85.0},
    {"gremio": "ELECTRICIDAD", "tipo": "KIT", "descripcion": "Revisión cuadro eléctrico + sustitución diferencial 2P 40A 30mA", "cantidad_default": 1.0, "precio_unitario": 85.0},
    {"gremio": "ELECTRICIDAD", "tipo": "MATERIAL", "descripcion": "Magnetotérmico curva C 16A/20A homologado", "cantidad_default": 1.0, "precio_unitario": 24.0},
    {"gremio": "ELECTRICIDAD", "tipo": "TRABAJO", "descripcion": "Emisión de Boletín Eléctrico (CIE) y certificación oficial", "cantidad_default": 1.0, "precio_unitario": 140.0},
    {"gremio": "ELECTRICIDAD", "tipo": "KIT", "descripcion": "Instalación punto de luz / enchufe empotrado con cableado libre halógenos", "cantidad_default": 1.0, "precio_unitario": 55.0},
    {"gremio": "ELECTRICIDAD", "tipo": "MATERIAL", "descripcion": "Protector contra sobretensiones permanentes y transitorias V-Check", "cantidad_default": 1.0, "precio_unitario": 95.0},
    {"gremio": "ELECTRICIDAD", "tipo": "TRABAJO", "descripcion": "Sustitución de acometida monofásica a cuadro general", "cantidad_default": 1.0, "precio_unitario": 180.0},
    {"gremio": "ELECTRICIDAD", "tipo": "MATERIAL", "descripcion": "Diferencial superinmunizado clase A 40A 30mA", "cantidad_default": 1.0, "precio_unitario": 95.0},
    {"gremio": "ELECTRICIDAD", "tipo": "KIT", "descripcion": "Instalación de iluminación LED empotrable downlight (pareja)", "cantidad_default": 1.0, "precio_unitario": 45.0},
    {"gremio": "ELECTRICIDAD", "tipo": "TRABAJO", "descripcion": "Localización y reparación de cortocircuito o derivación a tierra", "cantidad_default": 1.0, "precio_unitario": 75.0},
    {"gremio": "ELECTRICIDAD", "tipo": "MATERIAL", "descripcion": "Conmutador doble estanco IP55 para exterior o garaje", "cantidad_default": 1.0, "precio_unitario": 22.0},
    {"gremio": "ELECTRICIDAD", "tipo": "KIT", "descripcion": "Instalación de toma de recarga coche eléctrico Schuko reforzado", "cantidad_default": 1.0, "precio_unitario": 210.0},
    {"gremio": "ELECTRICIDAD", "tipo": "MATERIAL", "descripcion": "Sustitución de automático general IGA 32A/40A", "cantidad_default": 1.0, "precio_unitario": 38.0},
    {"gremio": "ELECTRICIDAD", "tipo": "MATERIAL", "descripcion": "Canaleta perimétrica autoadhesiva 40x20mm (tramo 2m)", "cantidad_default": 1.0, "precio_unitario": 12.0},
    {"gremio": "ELECTRICIDAD", "tipo": "KIT", "descripcion": "Instalación de detector de movimiento 360º para zonas comunes", "cantidad_default": 1.0, "precio_unitario": 48.0},
    {"gremio": "ELECTRICIDAD", "tipo": "MATERIAL", "descripcion": "Cuadro eléctrico de distribución 18 módulos superficie", "cantidad_default": 1.0, "precio_unitario": 52.0},
    {"gremio": "ELECTRICIDAD", "tipo": "KIT", "descripcion": "Revisión y puesta a tierra con pica de cobre 2m y borne", "cantidad_default": 1.0, "precio_unitario": 95.0},
    {"gremio": "CLIMATIZACION", "tipo": "KIT", "descripcion": "Mantenimiento preventivo anual caldera de gas + análisis combustión", "cantidad_default": 1.0, "precio_unitario": 90.0},
    {"gremio": "CLIMATIZACION", "tipo": "KIT", "descripcion": "Carga de gas refrigerante R32/R410A y detección de fugas en split", "cantidad_default": 1.0, "precio_unitario": 115.0},
    {"gremio": "CLIMATIZACION", "tipo": "MATERIAL", "descripcion": "Termostato digital programable WiFi modulante", "cantidad_default": 1.0, "precio_unitario": 95.0},
    {"gremio": "CLIMATIZACION", "tipo": "TRABAJO", "descripcion": "Limpieza e higienización antibacteriana de filtros y batería interior A/A", "cantidad_default": 1.0, "precio_unitario": 60.0},
    {"gremio": "CLIMATIZACION", "tipo": "KIT", "descripcion": "Sustitución de bomba de condensados para split de aire acondicionado", "cantidad_default": 1.0, "precio_unitario": 85.0},
    {"gremio": "CLIMATIZACION", "tipo": "TRABAJO", "descripcion": "Reparación de placa electrónica o sonda NTC de caldera", "cantidad_default": 1.0, "precio_unitario": 125.0},
    {"gremio": "CLIMATIZACION", "tipo": "TRABAJO", "descripcion": "Instalación completa split 1x1 3000 frigorías Inverter A+++", "cantidad_default": 1.0, "precio_unitario": 250.0},
    {"gremio": "CLIMATIZACION", "tipo": "TRABAJO", "descripcion": "Desmontaje y retirada ecológica de equipo de climatización antiguo", "cantidad_default": 1.0, "precio_unitario": 70.0},
    {"gremio": "CLIMATIZACION", "tipo": "MATERIAL", "descripcion": "Válvula termostática para radiador bitubo", "cantidad_default": 1.0, "precio_unitario": 28.0},
    {"gremio": "CLIMATIZACION", "tipo": "TRABAJO", "descripcion": "Purga y equilibrado hidráulico de circuito de radiadores", "cantidad_default": 1.0, "precio_unitario": 65.0},
    {"gremio": "CLIMATIZACION", "tipo": "MATERIAL", "descripcion": "Vaso de expansión para calefacción 8 litros", "cantidad_default": 1.0, "precio_unitario": 55.0},
    {"gremio": "CLIMATIZACION", "tipo": "KIT", "descripcion": "Limpieza química anticalcárea de intercambiador de placas", "cantidad_default": 1.0, "precio_unitario": 110.0},
    {"gremio": "CLIMATIZACION", "tipo": "MATERIAL", "descripcion": "Soportes antivibratorios y amortiguadores para unidad exterior", "cantidad_default": 1.0, "precio_unitario": 35.0},
    {"gremio": "CLIMATIZACION", "tipo": "MATERIAL", "descripcion": "Conducto flexible aislado fibra de vidrio 200mm (10m)", "cantidad_default": 1.0, "precio_unitario": 65.0},
    {"gremio": "CLIMATIZACION", "tipo": "KIT", "descripcion": "Sustitución de quemador o electrodo de encendido caldera gasoil", "cantidad_default": 1.0, "precio_unitario": 95.0},
    {"gremio": "CLIMATIZACION", "tipo": "MATERIAL", "descripcion": "Rejilla motorizada de difusión con pasarela de control", "cantidad_default": 1.0, "precio_unitario": 85.0},
    {"gremio": "REFORMAS", "tipo": "TRABAJO", "descripcion": "Saneado de paramentos, enfoscado maestreado y alisado", "cantidad_default": 1.0, "precio_unitario": 68.0},
    {"gremio": "REFORMAS", "tipo": "MATERIAL", "descripcion": "Saco mortero cola porcelánico flexible C2TE S1 (25 kg)", "cantidad_default": 1.0, "precio_unitario": 18.5},
    {"gremio": "REFORMAS", "tipo": "KIT", "descripcion": "Alicatado y solado de baño completo (mano de obra y cola)", "cantidad_default": 1.0, "precio_unitario": 340.0},
    {"gremio": "REFORMAS", "tipo": "TRABAJO", "descripcion": "Desescombro y retirada a punto limpio autorizado con saco big-bag", "cantidad_default": 1.0, "precio_unitario": 85.0},
    {"gremio": "REFORMAS", "tipo": "TRABAJO", "descripcion": "Demolición de tabique de ladrillo hueco sencillo (m2)", "cantidad_default": 1.0, "precio_unitario": 28.0},
    {"gremio": "REFORMAS", "tipo": "TRABAJO", "descripcion": "Ayudas de albañilería a fontanería y electricidad (jornada)", "cantidad_default": 1.0, "precio_unitario": 180.0},
    {"gremio": "REFORMAS", "tipo": "KIT", "descripcion": "Formación de plato de ducha de obra con impermeabilización líquida", "cantidad_default": 1.0, "precio_unitario": 290.0},
    {"gremio": "REFORMAS", "tipo": "TRABAJO", "descripcion": "Colocación de precésped artificial o gres extrusionado exterior (m2)", "cantidad_default": 1.0, "precio_unitario": 35.0},
    {"gremio": "REFORMAS", "tipo": "MATERIAL", "descripcion": "Plaste de renovación y cubregotelé en pasta lista al uso (15 kg)", "cantidad_default": 1.0, "precio_unitario": 32.0},
    {"gremio": "REFORMAS", "tipo": "MATERIAL", "descripcion": "Vierteaguas cerámico extrusionado esmaltado para ventana", "cantidad_default": 1.0, "precio_unitario": 22.0},
    {"gremio": "REFORMAS", "tipo": "TRABAJO", "descripcion": "Nivelación de solera con mortero autonivelante bombeado (m2)", "cantidad_default": 1.0, "precio_unitario": 18.0},
    {"gremio": "REFORMAS", "tipo": "KIT", "descripcion": "Recrecido de dintel con vigueta pretensada autorresistente", "cantidad_default": 1.0, "precio_unitario": 95.0},
    {"gremio": "REFORMAS", "tipo": "TRABAJO", "descripcion": "Rejuntado epoxi antimoho de juntas de alicatado (m2)", "cantidad_default": 1.0, "precio_unitario": 14.0},
    {"gremio": "REFORMAS", "tipo": "TRABAJO", "descripcion": "Instalación de falso techo registrable o continuo (m2)", "cantidad_default": 1.0, "precio_unitario": 32.0},
    {"gremio": "REFORMAS", "tipo": "MATERIAL", "descripcion": "Sellado perimetral con masilla de poliuretano elástica (cartucho)", "cantidad_default": 1.0, "precio_unitario": 8.5},
    {"gremio": "REFORMAS", "tipo": "KIT", "descripcion": "Reparación puntual de arqueta o registro enterrado", "cantidad_default": 1.0, "precio_unitario": 130.0},
    {"gremio": "CERRAJERIA", "tipo": "TRABAJO", "descripcion": "Apertura técnica de cerradura sin daños en puerta", "cantidad_default": 1.0, "precio_unitario": 75.0},
    {"gremio": "CERRAJERIA", "tipo": "MATERIAL", "descripcion": "Cilindro de seguridad europerfil antibumping y antirotura", "cantidad_default": 1.0, "precio_unitario": 98.0},
    {"gremio": "CERRAJERIA", "tipo": "KIT", "descripcion": "Instalación de cerrojo suplementario FAC de alta seguridad", "cantidad_default": 1.0, "precio_unitario": 120.0},
    {"gremio": "CERRAJERIA", "tipo": "TRABAJO", "descripcion": "Apertura nocturna o festiva de puerta acorazada/blindada", "cantidad_default": 1.0, "precio_unitario": 110.0},
    {"gremio": "CERRAJERIA", "tipo": "MATERIAL", "descripcion": "Escudo de seguridad acorazado macizo con lenteja de protección", "cantidad_default": 1.0, "precio_unitario": 75.0},
    {"gremio": "CERRAJERIA", "tipo": "KIT", "descripcion": "Sustitución de cerradura embutida para puerta metálica o madera", "cantidad_default": 1.0, "precio_unitario": 85.0},
    {"gremio": "CERRAJERIA", "tipo": "KIT", "descripcion": "Reparación de persiana doméstica (cambio cinta, recogedor y polea)", "cantidad_default": 1.0, "precio_unitario": 62.0},
    {"gremio": "CERRAJERIA", "tipo": "KIT", "descripcion": "Motorización tubular de persiana doméstica con mando a distancia", "cantidad_default": 1.0, "precio_unitario": 160.0},
    {"gremio": "CERRAJERIA", "tipo": "KIT", "descripcion": "Instalación de muelle cierrapuertas hidráulico regulable", "cantidad_default": 1.0, "precio_unitario": 80.0},
    {"gremio": "CERRAJERIA", "tipo": "TRABAJO", "descripcion": "Amaestramiento de cilindros para comunidad o empresa (cilindro)", "cantidad_default": 1.0, "precio_unitario": 35.0},
    {"gremio": "CERRAJERIA", "tipo": "MATERIAL", "descripcion": "Duplicado controlado de llave de alta seguridad con tarjeta propiedad", "cantidad_default": 1.0, "precio_unitario": 25.0},
    {"gremio": "CERRAJERIA", "tipo": "TRABAJO", "descripcion": "Ajuste y calibración de bisagras y holguras en puerta blindada", "cantidad_default": 1.0, "precio_unitario": 50.0},
    {"gremio": "CERRAJERIA", "tipo": "KIT", "descripcion": "Instalación de cerradura invisible electrónica con mando bluetooth", "cantidad_default": 1.0, "precio_unitario": 175.0},
    {"gremio": "CERRAJERIA", "tipo": "KIT", "descripcion": "Sustitución de borjas por bombín europerfil en puerta acorazada", "cantidad_default": 1.0, "precio_unitario": 280.0},
    {"gremio": "CERRAJERIA", "tipo": "MATERIAL", "descripcion": "Barra antipánico para salida de emergencia homologada", "cantidad_default": 1.0, "precio_unitario": 135.0},
    {"gremio": "CERRAJERIA", "tipo": "KIT", "descripcion": "Reparación de cerradura de portal comunitaria y abrepuertas eléctrico", "cantidad_default": 1.0, "precio_unitario": 95.0},
    {"gremio": "PINTURA", "tipo": "TRABAJO", "descripcion": "Plastecido de grietas, lijado fino y aplicación 2 manos pintura plástica", "cantidad_default": 1.0, "precio_unitario": 48.0},
    {"gremio": "PINTURA", "tipo": "MATERIAL", "descripcion": "Bote pintura plástica blanca mate lavable alta cobertura (15L)", "cantidad_default": 1.0, "precio_unitario": 52.0},
    {"gremio": "PINTURA", "tipo": "KIT", "descripcion": "Tratamiento antihumedad y pintura fungicida en techos cocina/baño", "cantidad_default": 1.0, "precio_unitario": 85.0},
    {"gremio": "PINTURA", "tipo": "KIT", "descripcion": "Pintado integral de vivienda estándar (hasta 70m2 útiles)", "cantidad_default": 1.0, "precio_unitario": 650.0},
    {"gremio": "PINTURA", "tipo": "TRABAJO", "descripcion": "Esmaltado de carpintería metálica o rejas con esmalte sintético", "cantidad_default": 1.0, "precio_unitario": 55.0},
    {"gremio": "PINTURA", "tipo": "TRABAJO", "descripcion": "Alisado de paredes con eliminación mecánica de gotelé (m2)", "cantidad_default": 1.0, "precio_unitario": 16.0},
    {"gremio": "PINTURA", "tipo": "MATERIAL", "descripcion": "Imprimación fijadora penetrante al agua (bote 5L)", "cantidad_default": 1.0, "precio_unitario": 28.0},
    {"gremio": "PINTURA", "tipo": "TRABAJO", "descripcion": "Barnizado o lasurado protector de pérgola o valla de madera", "cantidad_default": 1.0, "precio_unitario": 65.0},
    {"gremio": "PINTURA", "tipo": "TRABAJO", "descripcion": "Aplicación de pintura epoxi bicomponente para suelos de garaje (m2)", "cantidad_default": 1.0, "precio_unitario": 24.0},
    {"gremio": "PINTURA", "tipo": "MATERIAL", "descripcion": "Cinta de carrocero krepp profesional de pintor (pack 3 rollos)", "cantidad_default": 1.0, "precio_unitario": 9.5},
    {"gremio": "PINTURA", "tipo": "MATERIAL", "descripcion": "Pintura impermeabilizante de fachadas elastomérica acrílica (15L)", "cantidad_default": 1.0, "precio_unitario": 78.0},
    {"gremio": "PINTURA", "tipo": "KIT", "descripcion": "Tratamiento de manchas de condensación, moho y nicotina", "cantidad_default": 1.0, "precio_unitario": 75.0},
    {"gremio": "PINTURA", "tipo": "TRABAJO", "descripcion": "Lacado de puertas de paso en blanco mate con pistola (unidad)", "cantidad_default": 1.0, "precio_unitario": 90.0},
    {"gremio": "PINTURA", "tipo": "MATERIAL", "descripcion": "Papel con cinta incorporada para protección de rodapiés", "cantidad_default": 1.0, "precio_unitario": 11.0},
    {"gremio": "PINTURA", "tipo": "TRABAJO", "descripcion": "Revestimiento decorativo microcemento o estuco veneciano (m2)", "cantidad_default": 1.0, "precio_unitario": 55.0},
    {"gremio": "PINTURA", "tipo": "MATERIAL", "descripcion": "Sellador acrílico pintable para juntas y grietas en pared", "cantidad_default": 1.0, "precio_unitario": 6.0},
    {"gremio": "CARPINTERIA", "tipo": "TRABAJO", "descripcion": "Cepillado, reajuste de holguras y lubricación de puerta de paso", "cantidad_default": 1.0, "precio_unitario": 42.0},
    {"gremio": "CARPINTERIA", "tipo": "MATERIAL", "descripcion": "Juego de manivelas roseta inox con picaporte magnético", "cantidad_default": 1.0, "precio_unitario": 36.0},
    {"gremio": "CARPINTERIA", "tipo": "KIT", "descripcion": "Instalación de rodapié lacado blanco con sellado perimetral", "cantidad_default": 1.0, "precio_unitario": 65.0},
    {"gremio": "CARPINTERIA", "tipo": "TRABAJO", "descripcion": "Montaje e instalación de puerta de paso block estándar", "cantidad_default": 1.0, "precio_unitario": 75.0},
    {"gremio": "CARPINTERIA", "tipo": "MATERIAL", "descripcion": "Sustitución de guías de cajón telescópicas cierre amortiguado (par)", "cantidad_default": 1.0, "precio_unitario": 22.0},
    {"gremio": "CARPINTERIA", "tipo": "TRABAJO", "descripcion": "Reparación y encintado de cantos de PVC en muebles de cocina", "cantidad_default": 1.0, "precio_unitario": 45.0},
    {"gremio": "CARPINTERIA", "tipo": "TRABAJO", "descripcion": "Instalación de suelo laminado flotante AC5 (m2 sin material)", "cantidad_default": 1.0, "precio_unitario": 14.0},
    {"gremio": "CARPINTERIA", "tipo": "KIT", "descripcion": "Colocación de copete de cocina de aluminio anodizado", "cantidad_default": 1.0, "precio_unitario": 35.0},
    {"gremio": "CARPINTERIA", "tipo": "KIT", "descripcion": "Fabricación y montaje de baldas a medida en armario empotrado", "cantidad_default": 1.0, "precio_unitario": 85.0},
    {"gremio": "CARPINTERIA", "tipo": "MATERIAL", "descripcion": "Bisagras cazoleta 35mm con freno amortiguador (pack 4 unidades)", "cantidad_default": 1.0, "precio_unitario": 16.0},
    {"gremio": "CARPINTERIA", "tipo": "TRABAJO", "descripcion": "Cepillado y ajuste de puerta de entrada blindada rozando en suelo", "cantidad_default": 1.0, "precio_unitario": 60.0},
    {"gremio": "CARPINTERIA", "tipo": "TRABAJO", "descripcion": "Forrado de armario empotrado con tablero melamina lino textil (m2)", "cantidad_default": 1.0, "precio_unitario": 45.0},
    {"gremio": "CARPINTERIA", "tipo": "MATERIAL", "descripcion": "Colocación de burlete aislante perimetral bajo puerta de entrada", "cantidad_default": 1.0, "precio_unitario": 18.0},
    {"gremio": "CARPINTERIA", "tipo": "TRABAJO", "descripcion": "Reparación de tiradores y bisagras descolgadas en muebles de baño", "cantidad_default": 1.0, "precio_unitario": 40.0},
    {"gremio": "CARPINTERIA", "tipo": "MATERIAL", "descripcion": "Tablero contrachapado fenólico marino cortado a medida", "cantidad_default": 1.0, "precio_unitario": 58.0},
    {"gremio": "CARPINTERIA", "tipo": "MATERIAL", "descripcion": "Masilla para madera y cera de retoque color roble/nogal/blanco", "cantidad_default": 1.0, "precio_unitario": 12.0},
    {"gremio": "ENERGIA_SOLAR", "tipo": "TRABAJO", "descripcion": "Revisión técnica anual, reapriete conectores MC4 y diagnosis inversor", "cantidad_default": 1.0, "precio_unitario": 110.0},
    {"gremio": "ENERGIA_SOLAR", "tipo": "MATERIAL", "descripcion": "Protector sobretensiones transitorias y permanentes DC 1000V", "cantidad_default": 1.0, "precio_unitario": 78.0},
    {"gremio": "ENERGIA_SOLAR", "tipo": "KIT", "descripcion": "Limpieza desionizada y tratamiento hidrofóbico en módulos fotovoltaicos", "cantidad_default": 1.0, "precio_unitario": 85.0},
    {"gremio": "ENERGIA_SOLAR", "tipo": "MATERIAL", "descripcion": "Monitor de energía y vatímetro monofásico de balance neto", "cantidad_default": 1.0, "precio_unitario": 120.0},
    {"gremio": "ENERGIA_SOLAR", "tipo": "MATERIAL", "descripcion": "Sustitución de fusible cerámico gPV 10x38 15A 1000V DC", "cantidad_default": 1.0, "precio_unitario": 14.0},
    {"gremio": "ENERGIA_SOLAR", "tipo": "TRABAJO", "descripcion": "Comprobación y reapriete de estructura coplanar de cubierta", "cantidad_default": 1.0, "precio_unitario": 70.0},
    {"gremio": "ENERGIA_SOLAR", "tipo": "MATERIAL", "descripcion": "Conector solar MC4 macho/hembra crimpado profesional (pack 4)", "cantidad_default": 1.0, "precio_unitario": 16.0},
    {"gremio": "ENERGIA_SOLAR", "tipo": "TRABAJO", "descripcion": "Instalación y parametrización de batería de litio residencial", "cantidad_default": 1.0, "precio_unitario": 220.0},
    {"gremio": "ENERGIA_SOLAR", "tipo": "TRABAJO", "descripcion": "Revisión de aislamiento de string fotovoltaico con megóhmetro", "cantidad_default": 1.0, "precio_unitario": 95.0},
    {"gremio": "ENERGIA_SOLAR", "tipo": "MATERIAL", "descripcion": "Caja estanca seccionadora DC IP65 con doble seccionador rotativo", "cantidad_default": 1.0, "precio_unitario": 85.0},
    {"gremio": "ENERGIA_SOLAR", "tipo": "MATERIAL", "descripcion": "Cable solar libre de halógenos H1Z2Z2-K 6mm2 (rollo 25m)", "cantidad_default": 1.0, "precio_unitario": 48.0},
    {"gremio": "ENERGIA_SOLAR", "tipo": "TRABAJO", "descripcion": "Diagnosis y actualización de firmware de inversor híbrido", "cantidad_default": 1.0, "precio_unitario": 65.0},
    {"gremio": "ENERGIA_SOLAR", "tipo": "KIT", "descripcion": "Puesta a tierra equipotencial de marcos de placas solares", "cantidad_default": 1.0, "precio_unitario": 90.0},
    {"gremio": "ENERGIA_SOLAR", "tipo": "KIT", "descripcion": "Sistema antipalomas y de protección perimetral de módulos solares", "cantidad_default": 1.0, "precio_unitario": 140.0},
    {"gremio": "ENERGIA_SOLAR", "tipo": "KIT", "descripcion": "Instalación de inversor microinversor por panel de 400W", "cantidad_default": 1.0, "precio_unitario": 175.0},
    {"gremio": "ENERGIA_SOLAR", "tipo": "TRABAJO", "descripcion": "Emisión de memoria técnica de legalización de autoconsumo", "cantidad_default": 1.0, "precio_unitario": 160.0},
    {"gremio": "TELECOMUNICACIONES", "tipo": "TRABAJO", "descripcion": "Orientación antena TDT/Satélite y medición de señal con analizador", "cantidad_default": 1.0, "precio_unitario": 60.0},
    {"gremio": "TELECOMUNICACIONES", "tipo": "KIT", "descripcion": "Instalación y certificación de toma de red UTP Cat6 con conectorización", "cantidad_default": 1.0, "precio_unitario": 48.0},
    {"gremio": "TELECOMUNICACIONES", "tipo": "KIT", "descripcion": "Amplificador de mástil TDT con filtro LTE/5G y fuente alimentación", "cantidad_default": 1.0, "precio_unitario": 75.0},
    {"gremio": "TELECOMUNICACIONES", "tipo": "MATERIAL", "descripcion": "Centralita amplificadora programable de cabecera comunitaria", "cantidad_default": 1.0, "precio_unitario": 290.0},
    {"gremio": "TELECOMUNICACIONES", "tipo": "KIT", "descripcion": "Sustitución de telefonillo analógico por interfono universal", "cantidad_default": 1.0, "precio_unitario": 65.0},
    {"gremio": "TELECOMUNICACIONES", "tipo": "KIT", "descripcion": "Instalación de kit videoportero 2 hilos con monitor color", "cantidad_default": 1.0, "precio_unitario": 240.0},
    {"gremio": "TELECOMUNICACIONES", "tipo": "MATERIAL", "descripcion": "Repartidor / derivador de señal de TV de 4 salidas con paso de DC", "cantidad_default": 1.0, "precio_unitario": 18.0},
    {"gremio": "TELECOMUNICACIONES", "tipo": "MATERIAL", "descripcion": "Cable coaxial RG6 de cobre apantallado especial ICT-2 (rollo 50m)", "cantidad_default": 1.0, "precio_unitario": 38.0},
    {"gremio": "TELECOMUNICACIONES", "tipo": "KIT", "descripcion": "Configuración y despliegue de punto de acceso WiFi Mesh PoE", "cantidad_default": 1.0, "precio_unitario": 95.0},
    {"gremio": "TELECOMUNICACIONES", "tipo": "TRABAJO", "descripcion": "Peinado y conexionado de panel de parcheo RJ45 24 puertos", "cantidad_default": 1.0, "precio_unitario": 85.0},
    {"gremio": "TELECOMUNICACIONES", "tipo": "MATERIAL", "descripcion": "Instalación de rack mural 19 pulgadas 6U con bandeja y regleta", "cantidad_default": 1.0, "precio_unitario": 110.0},
    {"gremio": "TELECOMUNICACIONES", "tipo": "MATERIAL", "descripcion": "Sustitución de abrepuertas eléctrico en placa de calle", "cantidad_default": 1.0, "precio_unitario": 42.0},
    {"gremio": "TELECOMUNICACIONES", "tipo": "TRABAJO", "descripcion": "Comprobación y reajuste de cámara de videovigilancia CCTV IP", "cantidad_default": 1.0, "precio_unitario": 55.0},
    {"gremio": "TELECOMUNICACIONES", "tipo": "MATERIAL", "descripcion": "Conmutador Switch Gigabit 8 puertos no gestionable", "cantidad_default": 1.0, "precio_unitario": 34.0},
    {"gremio": "TELECOMUNICACIONES", "tipo": "MATERIAL", "descripcion": "Toma de antena TV-FM-SAT separadora paso o final", "cantidad_default": 1.0, "precio_unitario": 12.5},
    {"gremio": "TELECOMUNICACIONES", "tipo": "TRABAJO", "descripcion": "Certificación y emisión de boletín de telecomunicaciones ICT", "cantidad_default": 1.0, "precio_unitario": 130.0},
    {"gremio": "JARDINERIA", "tipo": "TRABAJO", "descripcion": "Puesta a punto de clorador salino, bomba y filtro de arena de piscina", "cantidad_default": 1.0, "precio_unitario": 75.0},
    {"gremio": "JARDINERIA", "tipo": "KIT", "descripcion": "Mantenimiento y programación de electroválvulas de riego por goteo", "cantidad_default": 1.0, "precio_unitario": 55.0},
    {"gremio": "JARDINERIA", "tipo": "KIT", "descripcion": "Sustitución de arena de sílice por vidrio filtrante en filtro de piscina", "cantidad_default": 1.0, "precio_unitario": 130.0},
    {"gremio": "JARDINERIA", "tipo": "MATERIAL", "descripcion": "Programador de riego digital a pilas 4 estaciones para exterior", "cantidad_default": 1.0, "precio_unitario": 88.0},
    {"gremio": "JARDINERIA", "tipo": "TRABAJO", "descripcion": "Poda y perfilado de setos perimetrales y arizónicas (jornada)", "cantidad_default": 1.0, "precio_unitario": 160.0},
    {"gremio": "JARDINERIA", "tipo": "MATERIAL", "descripcion": "Saco de sal marina especial piscinas para cloración salina (25 kg)", "cantidad_default": 1.0, "precio_unitario": 14.0},
    {"gremio": "JARDINERIA", "tipo": "MATERIAL", "descripcion": "Electroválvula de riego 1 pulgada 24V con control de caudal", "cantidad_default": 1.0, "precio_unitario": 26.0},
    {"gremio": "JARDINERIA", "tipo": "TRABAJO", "descripcion": "Escarificado, abonado y resiembra de césped natural (m2)", "cantidad_default": 1.0, "precio_unitario": 6.5},
    {"gremio": "JARDINERIA", "tipo": "MATERIAL", "descripcion": "Sustitución de célula autolimpiable de clorador salino 20g/h", "cantidad_default": 1.0, "precio_unitario": 220.0},
    {"gremio": "JARDINERIA", "tipo": "MATERIAL", "descripcion": "Tubo de polietileno con goteros integrados autocompensantes 16mm (50m)", "cantidad_default": 1.0, "precio_unitario": 32.0},
    {"gremio": "JARDINERIA", "tipo": "TRABAJO", "descripcion": "Limpieza y descalcificación de skimmers y boquillas de impulsión", "cantidad_default": 1.0, "precio_unitario": 45.0},
    {"gremio": "JARDINERIA", "tipo": "TRABAJO", "descripcion": "Tratamiento fitosanitario contra picudo rojo o procesionaria", "cantidad_default": 1.0, "precio_unitario": 95.0},
    {"gremio": "JARDINERIA", "tipo": "MATERIAL", "descripcion": "Sustitución de válvula selectora de 6 vías para filtro de piscina", "cantidad_default": 1.0, "precio_unitario": 75.0},
    {"gremio": "JARDINERIA", "tipo": "KIT", "descripcion": "Instalación de césped artificial decorativo 35mm (m2 con colocación)", "cantidad_default": 1.0, "precio_unitario": 32.0},
    {"gremio": "JARDINERIA", "tipo": "MATERIAL", "descripcion": "Bomba sumergible achique de aguas residuales y pluviales con boya", "cantidad_default": 1.0, "precio_unitario": 115.0},
    {"gremio": "JARDINERIA", "tipo": "KIT", "descripcion": "Iluminación sumergible foco LED blanco/RGB para piscina", "cantidad_default": 1.0, "precio_unitario": 95.0},
    {"gremio": "AISLAMIENTOS", "tipo": "TRABAJO", "descripcion": "Montaje de tabiquería seca pladur con aislamiento de lana de roca", "cantidad_default": 1.0, "precio_unitario": 55.0},
    {"gremio": "AISLAMIENTOS", "tipo": "MATERIAL", "descripcion": "Placa de yeso laminado hidrófuga antihumedad (2.50 x 1.20 m)", "cantidad_default": 1.0, "precio_unitario": 19.5},
    {"gremio": "AISLAMIENTOS", "tipo": "MATERIAL", "descripcion": "Panel de lana de roca semirrígido acústico y térmico 50mm (paquete)", "cantidad_default": 1.0, "precio_unitario": 42.0},
    {"gremio": "AISLAMIENTOS", "tipo": "TRABAJO", "descripcion": "Aislamiento insuflado de celulosa o lana mineral en cámara de aire (m2)", "cantidad_default": 1.0, "precio_unitario": 28.0},
    {"gremio": "AISLAMIENTOS", "tipo": "MATERIAL", "descripcion": "Cinta de papel microperforada para juntas de placa de yeso (150m)", "cantidad_default": 1.0, "precio_unitario": 14.0},
    {"gremio": "AISLAMIENTOS", "tipo": "MATERIAL", "descripcion": "Pasta de secado rápido 2 horas para tratamiento de juntas pladur (25 kg)", "cantidad_default": 1.0, "precio_unitario": 24.0},
    {"gremio": "AISLAMIENTOS", "tipo": "MATERIAL", "descripcion": "Perfilería montante de acero galvanizado 46mm (unidad 3m)", "cantidad_default": 1.0, "precio_unitario": 6.5},
    {"gremio": "AISLAMIENTOS", "tipo": "MATERIAL", "descripcion": "Perfilería canal de acero galvanizado 48mm para suelo/techo (unidad 3m)", "cantidad_default": 1.0, "precio_unitario": 5.8},
    {"gremio": "AISLAMIENTOS", "tipo": "KIT", "descripcion": "Instalación de trampilla de inspección estanca para techos de pladur", "cantidad_default": 1.0, "precio_unitario": 65.0},
    {"gremio": "AISLAMIENTOS", "tipo": "KIT", "descripcion": "Aislamiento acústico de bajante comunitaria con membrana elastomérica", "cantidad_default": 1.0, "precio_unitario": 95.0},
    {"gremio": "AISLAMIENTOS", "tipo": "MATERIAL", "descripcion": "Placa de yeso con alta resistencia al fuego RF", "cantidad_default": 1.0, "precio_unitario": 22.0},
    {"gremio": "AISLAMIENTOS", "tipo": "MATERIAL", "descripcion": "Banda acústica autoadhesiva desolidarizadora para perfiles (rollo 30m)", "cantidad_default": 1.0, "precio_unitario": 18.0},
    {"gremio": "AISLAMIENTOS", "tipo": "TRABAJO", "descripcion": "Trasdosado autoportante de placa pladur con estructura omega (m2)", "cantidad_default": 1.0, "precio_unitario": 36.0},
    {"gremio": "AISLAMIENTOS", "tipo": "MATERIAL", "descripcion": "Tornillos fosfatados autorroscantes placa-metal 3.5x25mm (caja 1000)", "cantidad_default": 1.0, "precio_unitario": 15.0},
    {"gremio": "AISLAMIENTOS", "tipo": "TRABAJO", "descripcion": "Lijado con aspiración de juntas y preparación de soporte para pintar", "cantidad_default": 1.0, "precio_unitario": 40.0},
    {"gremio": "AISLAMIENTOS", "tipo": "MATERIAL", "descripcion": "Membrana lámina de polietileno expandido anti-impacto bajo tarima (m2)", "cantidad_default": 1.0, "precio_unitario": 3.5},
    {"gremio": "LIMPIEZA", "tipo": "TRABAJO", "descripcion": "Limpieza técnica integral fin de obra con maquinaria rotativa", "cantidad_default": 1.0, "precio_unitario": 95.0},
    {"gremio": "LIMPIEZA", "tipo": "KIT", "descripcion": "Tratamiento desincrustante y decapado de pavimentos cerámicos", "cantidad_default": 1.0, "precio_unitario": 60.0},
    {"gremio": "LIMPIEZA", "tipo": "TRABAJO", "descripcion": "Abrillantado y cristalizado de suelos de mármol o terrazo (m2)", "cantidad_default": 1.0, "precio_unitario": 9.0},
    {"gremio": "LIMPIEZA", "tipo": "KIT", "descripcion": "Limpieza y desinfección de conductos de aire y campanas de extracción", "cantidad_default": 1.0, "precio_unitario": 180.0},
    {"gremio": "LIMPIEZA", "tipo": "TRABAJO", "descripcion": "Desinfección y nebulización bactericida/fungicida certificada", "cantidad_default": 1.0, "precio_unitario": 85.0},
    {"gremio": "LIMPIEZA", "tipo": "TRABAJO", "descripcion": "Limpieza a presión con hidrolavadora de fachadas y aceras", "cantidad_default": 1.0, "precio_unitario": 65.0},
    {"gremio": "LIMPIEZA", "tipo": "TRABAJO", "descripcion": "Limpieza profunda de cristales en altura con pértiga y osmosis", "cantidad_default": 1.0, "precio_unitario": 75.0},
    {"gremio": "LIMPIEZA", "tipo": "MATERIAL", "descripcion": "Detergente ácido desincrustante para restos de obra y cemento (5L)", "cantidad_default": 1.0, "precio_unitario": 18.0},
    {"gremio": "LIMPIEZA", "tipo": "MATERIAL", "descripcion": "Cera abrillantadora metalizada de alta resistencia al tráfico (5L)", "cantidad_default": 1.0, "precio_unitario": 28.0},
    {"gremio": "LIMPIEZA", "tipo": "TRABAJO", "descripcion": "Limpieza y desodorización por ozonización de locales y viviendas", "cantidad_default": 1.0, "precio_unitario": 70.0},
    {"gremio": "LIMPIEZA", "tipo": "KIT", "descripcion": "Limpieza integral y desengrasado de cocinas industriales", "cantidad_default": 1.0, "precio_unitario": 210.0},
    {"gremio": "LIMPIEZA", "tipo": "TRABAJO", "descripcion": "Retirada y gestión de restos de escombros de limpieza en bolsas", "cantidad_default": 1.0, "precio_unitario": 45.0},
    {"gremio": "LIMPIEZA", "tipo": "TRABAJO", "descripcion": "Desinfección virucida de zonas comunes de comunidades (mensual)", "cantidad_default": 1.0, "precio_unitario": 120.0},
    {"gremio": "LIMPIEZA", "tipo": "KIT", "descripcion": "Tratamiento oleófugo antimanchas para suelos de barro cocido o gres", "cantidad_default": 1.0, "precio_unitario": 90.0},
    {"gremio": "LIMPIEZA", "tipo": "TRABAJO", "descripcion": "Limpieza de grafitis en fachadas con decapante ecológico y agua caliente", "cantidad_default": 1.0, "precio_unitario": 85.0},
    {"gremio": "LIMPIEZA", "tipo": "KIT", "descripcion": "Limpieza de aljibes y depósitos de agua potable con analítica", "cantidad_default": 1.0, "precio_unitario": 250.0},
]



def hash_password(password: str) -> str:
    """Genera hash seguro PBKDF2-HMAC-SHA256 con salt criptográfico de 16 bytes."""
    salt = secrets.token_hex(16)
    pw_hash = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), 100000).hex()
    return f"{salt}${pw_hash}"

def verify_password(password: str, stored_hash: str) -> bool:
    """Verifica una contraseña contra el hash almacenado en tiempo constante."""
    try:
        salt, pw_hash = stored_hash.split('$', 1)
        check_hash = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), 100000).hex()
        return secrets.compare_digest(pw_hash, check_hash)
    except Exception:
        return False

@contextmanager
def get_connection():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=5.0)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA journal_mode = WAL;")
        conn.execute("PRAGMA synchronous = NORMAL;")
        conn.execute("PRAGMA busy_timeout = 5000;")
        conn.execute("PRAGMA foreign_keys = ON;")
    except Exception:
        pass
    try:
        yield conn
    finally:
        conn.close()


def _get_table_columns(cursor, table_name: str) -> set:
    cursor.execute(f"PRAGMA table_info({table_name});")
    return {row[1] for row in cursor.fetchall()}


def init_db(seed_catalog: bool = False):
    with get_connection() as conn:
        cursor = conn.cursor()

        # Tabla de configuración de la empresa/autónomo
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS config (
            key TEXT PRIMARY KEY,
            value TEXT
        );
        """)

        # Tabla de Clientes
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            telefono TEXT,
            email TEXT,
            direccion TEXT,
            poblacion TEXT,
            notas TEXT,
            fecha_alta TEXT,
            nif_cif TEXT DEFAULT ''
        );
        """)

        # Migración no destructiva: clientes
        clientes_cols = _get_table_columns(cursor, "clientes")
        if "nif_cif" not in clientes_cols:
            cursor.execute("ALTER TABLE clientes ADD COLUMN nif_cif TEXT DEFAULT '';")

        # Tabla de Presupuestos / Trabajos
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS presupuestos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            numero TEXT UNIQUE NOT NULL,
            cliente_id INTEGER NOT NULL,
            fecha TEXT NOT NULL,
            estado TEXT NOT NULL DEFAULT 'BORRADOR',
            concepto_averia TEXT NOT NULL,
            es_urgencia INTEGER DEFAULT 0,
            recargo_urgencia REAL DEFAULT 0.0,
            horas_mano_obra REAL DEFAULT 1.0,
            precio_hora REAL DEFAULT 35.0,
            subtotal_materiales REAL DEFAULT 0.0,
            subtotal_general REAL NOT NULL,
            iva_porcentaje REAL DEFAULT 0.21,
            total_iva REAL NOT NULL,
            total_factura REAL NOT NULL,
            pdf_path TEXT,
            numero_factura TEXT,
            fecha_factura TEXT,
            descuento_porcentaje REAL DEFAULT 0.0,
            total_descuento REAL DEFAULT 0.0,
            base_imponible REAL DEFAULT 0.0,
            irpf_porcentaje REAL DEFAULT 0.0,
            total_irpf REAL DEFAULT 0.0,
            garantia_meses INTEGER DEFAULT 6,
            notas_tecnicas TEXT DEFAULT '',
            firma_base64 TEXT DEFAULT '',
            foto_base64 TEXT DEFAULT '',
            FOREIGN KEY (cliente_id) REFERENCES clientes(id)
        );
        """)

        # Migración no destructiva: presupuestos
        presupuestos_cols = _get_table_columns(cursor, "presupuestos")
        new_presupuestos_cols = [
            ("numero_factura", "TEXT"),
            ("fecha_factura", "TEXT"),
            ("descuento_porcentaje", "REAL DEFAULT 0.0"),
            ("total_descuento", "REAL DEFAULT 0.0"),
            ("base_imponible", "REAL DEFAULT 0.0"),
            ("irpf_porcentaje", "REAL DEFAULT 0.0"),
            ("total_irpf", "REAL DEFAULT 0.0"),
            ("garantia_meses", "INTEGER DEFAULT 6"),
            ("notas_tecnicas", "TEXT DEFAULT ''"),
            ("firma_base64", "TEXT DEFAULT ''"),
            ("foto_base64", "TEXT DEFAULT ''"),
            ("anticipo_importe", "REAL DEFAULT 0.0"),
            ("anticipo_fecha", "TEXT DEFAULT ''"),
            ("es_rectificativa", "INTEGER DEFAULT 0"),
            ("factura_origen_id", "INTEGER"),
            ("numero_factura_origen", "TEXT DEFAULT ''"),
            ("motivo_rectificacion", "TEXT DEFAULT ''"),
            ("huella_verifactu", "TEXT DEFAULT ''"),
            ("huella_anterior", "TEXT DEFAULT ''"),
        ]
        for col_name, col_def in new_presupuestos_cols:
            if col_name not in presupuestos_cols:
                cursor.execute(f"ALTER TABLE presupuestos ADD COLUMN {col_name} {col_def};")

        # Sincronizar base_imponible en presupuestos v1.0 migrados
        cursor.execute("""
        UPDATE presupuestos
        SET base_imponible = ROUND(subtotal_general - COALESCE(total_descuento, 0.0), 2)
        WHERE (base_imponible IS NULL OR base_imponible = 0.0) AND subtotal_general > 0;
        """)

        # Tabla de Partidas / Materiales
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS partidas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            presupuesto_id INTEGER NOT NULL,
            tipo TEXT DEFAULT 'MATERIAL',
            descripcion TEXT NOT NULL,
            cantidad REAL NOT NULL,
            precio_unitario REAL NOT NULL,
            subtotal REAL NOT NULL,
            FOREIGN KEY (presupuesto_id) REFERENCES presupuestos(id)
        );
        """)

        # Tabla de Catálogo de Partidas Rápidas por Gremio
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS catalogo_partidas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            gremio TEXT NOT NULL,
            tipo TEXT DEFAULT 'MATERIAL',
            descripcion TEXT NOT NULL,
            cantidad_default REAL DEFAULT 1.0,
            precio_unitario REAL NOT NULL
        );
        """)

        # Migracion no destructiva: catalogo_partidas (campos de stock y compras)
        cat_cols = _get_table_columns(cursor, "catalogo_partidas")
        new_cat_cols = [
            ("stock_actual", "REAL DEFAULT 0.0"),
            ("stock_minimo_alerta", "REAL DEFAULT 5.0"),
            ("precio_coste", "REAL DEFAULT 0.0"),
            ("proveedor_id", "INTEGER"),
            ("controla_stock", "INTEGER DEFAULT 1")
        ]
        for col_name, col_def in new_cat_cols:
            if col_name not in cat_cols:
                cursor.execute(f"ALTER TABLE catalogo_partidas ADD COLUMN {col_name} {col_def};")

        # Migracion no destructiva: partidas
        partidas_cols = _get_table_columns(cursor, "partidas")
        if "catalogo_id" not in partidas_cols:
            cursor.execute("ALTER TABLE partidas ADD COLUMN catalogo_id INTEGER;")

        # Tabla de Proveedores de Material
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS proveedores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            cif_nif TEXT DEFAULT '',
            telefono TEXT DEFAULT '',
            email TEXT DEFAULT '',
            contacto TEXT DEFAULT '',
            direccion TEXT DEFAULT '',
            poblacion TEXT DEFAULT '',
            notas TEXT DEFAULT '',
            fecha_alta TEXT
        );
        """)

        # Tabla de Compras y Gastos de Material
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS compras_gastos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            numero_factura TEXT NOT NULL,
            proveedor_id INTEGER,
            fecha TEXT NOT NULL,
            concepto TEXT NOT NULL,
            base_imponible REAL NOT NULL,
            iva_porcentaje REAL DEFAULT 0.21,
            total_iva REAL NOT NULL,
            total_factura REAL NOT NULL,
            forma_pago TEXT DEFAULT 'TRANSFERENCIA',
            estado TEXT DEFAULT 'PAGADO',
            notas TEXT DEFAULT '',
            FOREIGN KEY (proveedor_id) REFERENCES proveedores(id)
        );
        """)

        # Tabla de Lineas de Compras
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS compras_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            compra_id INTEGER NOT NULL,
            catalogo_id INTEGER,
            descripcion TEXT NOT NULL,
            cantidad REAL NOT NULL,
            precio_coste REAL NOT NULL,
            subtotal REAL NOT NULL,
            FOREIGN KEY (compra_id) REFERENCES compras_gastos(id),
            FOREIGN KEY (catalogo_id) REFERENCES catalogo_partidas(id)
        );
        """)

        # Tabla de Movimientos y Trazabilidad de Stock
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS stock_movimientos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            catalogo_id INTEGER NOT NULL,
            tipo_movimiento TEXT NOT NULL,
            cantidad REAL NOT NULL,
            stock_resultante REAL NOT NULL,
            referencia_id INTEGER,
            motivo TEXT,
            fecha TEXT NOT NULL,
            FOREIGN KEY (catalogo_id) REFERENCES catalogo_partidas(id)
        );
        """)

        # Tabla de Registro Inmutable de Auditoría de Seguridad y RGPD (Art. 32 RGPD)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS auditoria_seguridad (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fecha TEXT NOT NULL,
            usuario TEXT NOT NULL,
            rol TEXT NOT NULL,
            accion TEXT NOT NULL,
            detalle TEXT DEFAULT '',
            ip TEXT DEFAULT ''
        );
        """)

        # Configuración por defecto si está vacía
        cursor.execute("SELECT COUNT(*) FROM config;")
        if cursor.fetchone()[0] == 0:
            default_config = {
                "empresa_nombre": "Mi Empresa / Servicio Técnico",
                "empresa_cif": "B-00000000",
                "empresa_telefono": "",
                "empresa_email": "",
                "empresa_direccion": "",
                "empresa_poblacion": "",
                "empresa_iban": "",
                "primera_configuracion_pendiente": "1",
                "precio_hora_default": "38.0",
                "recargo_urgencia_default": "45.0",
                "stock_alerta_default": "5.0"
            }
            for k, v in default_config.items():
                cursor.execute("INSERT OR REPLACE INTO config (key, value) VALUES (?, ?);", (k, v))

        # Base de datos virgen para entrega comercial: clientes arrancan vacíos
        # Asegurar clave primera_configuracion_pendiente en bases de datos existentes
        cursor.execute("SELECT value FROM config WHERE key = 'primera_configuracion_pendiente';")
        _pending_row = cursor.fetchone()
        if not _pending_row:
            cursor.execute("SELECT value FROM config WHERE key = 'empresa_nombre';")
            _emp_row = cursor.fetchone()
            _emp_val = _emp_row[0] if _emp_row else ""
            _is_unconfigured = not _emp_val or _emp_val == "Mi Empresa / Servicio Técnico"
            cursor.execute("INSERT OR REPLACE INTO config (key, value) VALUES ('primera_configuracion_pendiente', ?);", ("1" if _is_unconfigured else "0",))

        cursor.execute("SELECT COUNT(*) FROM clientes;")
        # No se inyectan clientes demo para garantizar una instalación Kilómetro Cero limpia
        # Instalación Kilómetro Cero limpia para despliegue (0 partidas, 0 stock, 0 proveedores)
        if seed_catalog:
            seed_default_catalog_with_cursor(cursor)

        
        # Tabla de Usuarios y Control de Roles (Admin vs Tecnico) con vinculación a empresa
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            nombre TEXT NOT NULL,
            rol TEXT NOT NULL CHECK(rol IN ('ADMIN', 'TECNICO')),
            activo INTEGER DEFAULT 1,
            created_at TEXT NOT NULL,
            empresa_cif TEXT DEFAULT '',
            empresa_nombre TEXT DEFAULT ''
        );
        """)

        # Migración no destructiva: usuarios (vinculación con empresa_cif y empresa_nombre)
        usuarios_cols = _get_table_columns(cursor, "usuarios")
        if "empresa_cif" not in usuarios_cols:
            cursor.execute("ALTER TABLE usuarios ADD COLUMN empresa_cif TEXT DEFAULT '';")
        if "empresa_nombre" not in usuarios_cols:
            cursor.execute("ALTER TABLE usuarios ADD COLUMN empresa_nombre TEXT DEFAULT '';")

        # Registro Global de Identidades Únicas entre Empresas (evita colisión de usernames)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS registro_identidades_globales (
            username TEXT PRIMARY KEY COLLATE NOCASE,
            empresa_cif TEXT DEFAULT '',
            empresa_nombre TEXT DEFAULT '',
            created_at TEXT NOT NULL
        );
        """)

        # Si no hay usuarios, se inicializa el administrador base (reemplazable en el Wizard de Kilómetro Cero)
        cursor.execute("SELECT COUNT(*) FROM usuarios;")
        if cursor.fetchone()[0] == 0:
            admin_hash = hash_password("admin123")
            now_iso = datetime.now().isoformat()
            cursor.execute(
                "INSERT INTO usuarios (username, password_hash, nombre, rol, activo, created_at, empresa_cif, empresa_nombre) VALUES (?, ?, ?, ?, 1, ?, '', '');",
                ("admin", admin_hash, "Administrador Principal", "ADMIN", now_iso)
            )

        # Tabla de Memoria Operativa del Asistente Técnico (RGPD Local)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS asistente_memoria (
            clave TEXT PRIMARY KEY,
            valor TEXT NOT NULL,
            categoria TEXT DEFAULT 'general',
            fecha_actualizacion TEXT NOT NULL
        );
        """)

        # Índices de alto rendimiento e integridad relacional
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_partidas_presupuesto ON partidas(presupuesto_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_presupuestos_cliente ON presupuestos(cliente_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_presupuestos_num_fac ON presupuestos(numero_factura);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_compras_items_compra ON compras_items(compra_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_catalogo_gremio ON catalogo_partidas(gremio);")
        cursor.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_presupuestos_numero_factura_unique ON presupuestos(numero_factura) WHERE numero_factura IS NOT NULL;")
        cursor.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_usuarios_username_nocase ON usuarios(username COLLATE NOCASE);")

        conn.commit()

def seed_default_catalog_with_cursor(cursor):
    cursor.execute("SELECT descripcion FROM catalogo_partidas;")
    existing_items = {r[0] for r in cursor.fetchall()}
    for item in DEFAULT_CATALOG_ITEMS:
        if item["descripcion"] not in existing_items:
            is_mat = item["tipo"] == "MATERIAL"
            coste = round(item["precio_unitario"] * 0.52, 2) if is_mat else 0.0
            cursor.execute("""
            INSERT INTO catalogo_partidas (
                gremio, tipo, descripcion, cantidad_default, precio_unitario,
                stock_actual, stock_minimo_alerta, precio_coste, controla_stock
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
            """, (
                item["gremio"],
                item["tipo"],
                item["descripcion"],
                item["cantidad_default"],
                item["precio_unitario"],
                0.0,
                5.0,
                coste,
                1 if is_mat else 0
            ))


def seed_default_catalog():
    """Siembra bajo demanda las 192 partidas técnicas de catálogo con existencias físicas en 0."""
    with get_connection() as conn:
        cursor = conn.cursor()
        seed_default_catalog_with_cursor(cursor)
        conn.commit()



def get_config():
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT key, value FROM config;")
        rows = cursor.fetchall()
        return {r["key"]: r["value"] for r in rows}


ALLOWED_CONFIG_KEYS = {
    "empresa_nombre",
    "empresa_cif",
    "empresa_telefono",
    "empresa_email",
    "empresa_direccion",
    "empresa_poblacion",
    "empresa_iban",
    "primera_configuracion_pendiente",
    "precio_hora_default",
    "recargo_urgencia_default",
    "stock_alerta_default",
    "iva_default",
    "irpf_default",
    "sector",
    "sector_custom_nombre",
    "color_theme",
    "metodo_cobro",
    "smtp_host",
    "smtp_port",
    "smtp_user",
    "smtp_password",
    "smtp_pass",
    "garantia_default_meses",
    "test_key",
    "subscription_status"
}


def update_config(data: dict):
    if not isinstance(data, dict):
        return get_config()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE IF NOT EXISTS config (key TEXT PRIMARY KEY, value TEXT);")
        for k, v in data.items():
            key_str = str(k).strip()
            if key_str not in ALLOWED_CONFIG_KEYS:
                continue
            val_str = "" if v is None else str(v)
            if len(val_str) > 500:
                val_str = val_str[:500]
            # Si la contraseña SMTP viene enmascarada ("********") desde el frontend, conservar la existente
            if key_str in ("smtp_password", "smtp_pass") and val_str == "********":
                continue
            cursor.execute("INSERT OR REPLACE INTO config (key, value) VALUES (?, ?);", (key_str, val_str))
            if key_str == "smtp_password":
                cursor.execute("INSERT OR REPLACE INTO config (key, value) VALUES ('smtp_pass', ?);", (val_str,))
            elif key_str == "smtp_pass":
                cursor.execute("INSERT OR REPLACE INTO config (key, value) VALUES ('smtp_password', ?);", (val_str,))
        # Si cambian empresa_cif o empresa_nombre en config, sincronizar en usuarios asociados al negocio
        new_cif = data.get("empresa_cif")
        new_emp = data.get("empresa_nombre")
        if new_cif is not None:
            cursor.execute("UPDATE usuarios SET empresa_cif = ? WHERE empresa_cif = '' OR empresa_cif = 'B-00000000';", (str(new_cif).strip()[:64],))
            cursor.execute("UPDATE registro_identidades_globales SET empresa_cif = ? WHERE empresa_cif = '' OR empresa_cif = 'B-00000000';", (str(new_cif).strip()[:64],))
        if new_emp is not None:
            cursor.execute("UPDATE usuarios SET empresa_nombre = ? WHERE empresa_nombre = '' OR empresa_nombre = 'Mi Empresa / Servicio Técnico';", (str(new_emp).strip()[:120],))
            cursor.execute("UPDATE registro_identidades_globales SET empresa_nombre = ? WHERE empresa_nombre = '' OR empresa_nombre = 'Mi Empresa / Servicio Técnico';", (str(new_emp).strip()[:120],))
        conn.commit()
    return get_config()


def create_client(nombre, telefono="", email="", direccion="", poblacion="", notas="", nif_cif=""):
    with get_connection() as conn:
        cursor = conn.cursor()
        fecha_alta = datetime.now().strftime("%Y-%m-%d %H:%M")
        cursor.execute("""
        INSERT INTO clientes (nombre, telefono, email, direccion, poblacion, notas, fecha_alta, nif_cif)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?);
        """, (nombre, telefono, email, direccion, poblacion, notas, fecha_alta, nif_cif or ""))
        conn.commit()
        return cursor.lastrowid


def update_client(client_id: int, data: dict):
    existing = get_client(client_id)
    if not existing:
        return None

    nombre = data.get("nombre", existing.get("nombre", ""))
    telefono = data.get("telefono", existing.get("telefono", ""))
    email = data.get("email", existing.get("email", ""))
    direccion = data.get("direccion", existing.get("direccion", ""))
    poblacion = data.get("poblacion", existing.get("poblacion", ""))
    notas = data.get("notas", existing.get("notas", ""))
    nif_cif = data.get("nif_cif", existing.get("nif_cif", ""))

    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
        UPDATE clientes
        SET nombre = ?, telefono = ?, email = ?, direccion = ?, poblacion = ?, notas = ?, nif_cif = ?
        WHERE id = ?;
        """, (nombre, telefono, email, direccion, poblacion, notas, nif_cif, client_id))
        conn.commit()
    return get_client(client_id)


def list_clients(search: str = None):
    with get_connection() as conn:
        cursor = conn.cursor()
        if search and str(search).strip():
            q = f"%{str(search).strip()}%"
            cursor.execute("""
            SELECT * FROM clientes
            WHERE nombre LIKE ?
               OR telefono LIKE ?
               OR nif_cif LIKE ?
               OR direccion LIKE ?
               OR poblacion LIKE ?
            ORDER BY id DESC;
            """, (q, q, q, q, q))
        else:
            cursor.execute("SELECT * FROM clientes ORDER BY id DESC;")
        return [dict(r) for r in cursor.fetchall()]


def get_client(client_id: int):
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM clientes WHERE id = ?;", (client_id,))
        row = cursor.fetchone()
        return dict(row) if row else None


def delete_client(client_id: int) -> bool:
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM presupuestos WHERE cliente_id = ?;", (client_id,))
        count = cursor.fetchone()[0]
        if count > 0:
            raise ValueError(f"No se puede eliminar el cliente {client_id}: tiene {count} presupuesto(s) asociado(s).")
        cursor.execute("DELETE FROM clientes WHERE id = ?;", (client_id,))
        conn.commit()
        return cursor.rowcount > 0


def list_catalog(gremio: str = None):
    with get_connection() as conn:
        cursor = conn.cursor()
        if gremio and str(gremio).strip() and str(gremio).strip().upper() != "TODOS":
            g_upper = str(gremio).strip().upper()
            if g_upper == "CERRAJERIA_REFORMAS":
                cursor.execute(
                    "SELECT * FROM catalogo_partidas WHERE UPPER(gremio) IN ('CERRAJERIA_REFORMAS', 'CERRAJERIA', 'REFORMAS') ORDER BY id ASC;"
                )
            else:
                cursor.execute(
                    "SELECT * FROM catalogo_partidas WHERE UPPER(gremio) = ? ORDER BY id ASC;",
                    (g_upper,)
                )
        else:
            cursor.execute("SELECT * FROM catalogo_partidas ORDER BY gremio ASC, id ASC;")
        return [dict(r) for r in cursor.fetchall()]



def get_catalog_item(item_id: int):
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM catalogo_partidas WHERE id = ?;", (item_id,))
        row = cursor.fetchone()
        return dict(row) if row else None

def create_catalog_item(data: dict):
    gremio = str(data.get("gremio", "FONTANERIA")).strip().upper()
    tipo = str(data.get("tipo", "MATERIAL")).strip().upper()
    descripcion = str(data.get("descripcion", "")).strip()
    cantidad_default = float(data.get("cantidad_default", 1.0))
    precio_unitario = float(data.get("precio_unitario", 0.0))
    stock_actual = float(data.get("stock_actual", 0.0))
    stock_minimo_alerta = float(data.get("stock_minimo_alerta", 5.0))
    precio_coste = float(data.get("precio_coste", 0.0))
    proveedor_id = data.get("proveedor_id")
    controla_stock = int(data.get("controla_stock", 1))

    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
        INSERT INTO catalogo_partidas (
            gremio, tipo, descripcion, cantidad_default, precio_unitario,
            stock_actual, stock_minimo_alerta, precio_coste, proveedor_id, controla_stock
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """, (gremio, tipo, descripcion, cantidad_default, precio_unitario,
                stock_actual, stock_minimo_alerta, precio_coste, proveedor_id, controla_stock))
        item_id = cursor.lastrowid
        conn.commit()
        cursor.execute("SELECT * FROM catalogo_partidas WHERE id = ?;", (item_id,))
        row = cursor.fetchone()
        return dict(row) if row else None


def delete_catalog_item(item_id: int) -> bool:
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM catalogo_partidas WHERE id = ?;", (item_id,))
        conn.commit()
        return True


def _generate_next_quote_number(cursor) -> str:
    year = datetime.now().year
    prefix = f"PRE-{year}-"
    cursor.execute("SELECT numero FROM presupuestos WHERE numero LIKE ?;", (f"{prefix}%",))
    max_seq = 0
    for row in cursor.fetchall():
        num_str = row["numero"] if isinstance(row, sqlite3.Row) else row[0]
        try:
            seq_part = int(str(num_str).split("-")[-1])
            if seq_part > max_seq:
                max_seq = seq_part
        except (ValueError, IndexError):
            pass

    next_seq = max_seq + 1
    while True:
        candidate = f"{prefix}{next_seq:04d}"
        cursor.execute("SELECT 1 FROM presupuestos WHERE numero = ?;", (candidate,))
        if not cursor.fetchone():
            return candidate
        next_seq += 1


def _generate_next_invoice_number(cursor) -> str:
    year = datetime.now().year
    prefix = f"FAC-{year}-"
    cursor.execute("SELECT numero_factura FROM presupuestos WHERE numero_factura LIKE ?;", (f"{prefix}%",))
    max_seq = 0
    for row in cursor.fetchall():
        num_str = row["numero_factura"] if isinstance(row, sqlite3.Row) else row[0]
        if not num_str:
            continue
        try:
            seq_part = int(str(num_str).split("-")[-1])
            if seq_part > max_seq:
                max_seq = seq_part
        except (ValueError, IndexError):
            pass

    next_seq = max_seq + 1
    while True:
        candidate = f"{prefix}{next_seq:04d}"
        cursor.execute("SELECT 1 FROM presupuestos WHERE numero_factura = ?;", (candidate,))
        if not cursor.fetchone():
            return candidate
        next_seq += 1


def _generate_next_rectifying_number(cursor) -> str:
    year = datetime.now().year
    prefix = f"REC-{year}-"
    cursor.execute("SELECT numero_factura FROM presupuestos WHERE numero_factura LIKE ?;", (f"{prefix}%",))
    max_seq = 0
    for row in cursor.fetchall():
        num_str = row["numero_factura"] if isinstance(row, sqlite3.Row) else row[0]
        if not num_str:
            continue
        try:
            seq_part = int(str(num_str).split("-")[-1])
            if seq_part > max_seq:
                max_seq = seq_part
        except (ValueError, IndexError):
            pass

    next_seq = max_seq + 1
    while True:
        candidate = f"{prefix}{next_seq:04d}"
        cursor.execute(
            "SELECT 1 FROM presupuestos WHERE numero_factura = ? OR numero = ?;",
            (candidate, candidate)
        )
        if not cursor.fetchone():
            return candidate
        next_seq += 1


def _compute_verifactu_hash(
    cursor,
    cif_emisor: str,
    numero_factura: str,
    fecha_factura: str,
    total_factura: float,
    exclude_quote_id: int = None
) -> tuple[str, str]:
    """
    Calcula la huella criptográfica SHA-256 encadenada (estándar Veri*Factu AEAT)
    tomando como eslabón previo la huella de la última factura emitida.
    Devuelve (huella_actual, huella_anterior).
    """
    if exclude_quote_id is not None:
        cursor.execute("""
            SELECT huella_verifactu FROM presupuestos
            WHERE numero_factura IS NOT NULL AND numero_factura != ''
              AND huella_verifactu IS NOT NULL AND huella_verifactu != ''
              AND id != ?
            ORDER BY id DESC LIMIT 1;
        """, (exclude_quote_id,))
    else:
        cursor.execute("""
            SELECT huella_verifactu FROM presupuestos
            WHERE numero_factura IS NOT NULL AND numero_factura != ''
              AND huella_verifactu IS NOT NULL AND huella_verifactu != ''
            ORDER BY id DESC LIMIT 1;
        """)
    row = cursor.fetchone()
    huella_anterior = (row["huella_verifactu"] if isinstance(row, sqlite3.Row) else row[0]) if row else "GENESIS"
    if not huella_anterior:
        huella_anterior = "GENESIS"

    clean_cif = (cif_emisor or "B00000000").strip().upper()
    clean_num = (numero_factura or "").strip().upper()
    clean_fec = (fecha_factura or "").strip()
    raw_chain = f"ID_EMISOR:{clean_cif}|NUM_SERIE:{clean_num}|FECHA:{clean_fec}|IMPORTE:{float(total_factura):.2f}|HUELLA_ANT:{huella_anterior}"
    huella_actual = hashlib.sha256(raw_chain.encode("utf-8")).hexdigest().upper()
    return huella_actual, huella_anterior


def _calculate_quote_financials(data: dict):
    es_urgencia = 1 if data.get("es_urgencia") else 0
    recargo_urgencia = float(data.get("recargo_urgencia", 0.0) or 0.0) if es_urgencia else 0.0
    horas_mo = float(data.get("horas_mano_obra") if data.get("horas_mano_obra") is not None else 1.0)
    precio_hora = float(data.get("precio_hora") if data.get("precio_hora") is not None else 38.0)
    subtotal_mo = round(horas_mo * precio_hora, 2)

    items = data.get("partidas") or data.get("items") or []
    subtotal_mat = 0.0
    calculated_items = []
    for it in items:
        if not isinstance(it, dict):
            continue
        raw_desc = str(it.get("descripcion") or "").strip()
        desc = raw_desc if raw_desc else "Material / Partida"
        cant_val = it.get("cantidad")
        pu_val = it.get("precio_unitario")
        try:
            cant = float(cant_val) if cant_val is not None and cant_val != "" else 1.0
        except (ValueError, TypeError):
            cant = 1.0
        try:
            pu = float(pu_val) if pu_val is not None and pu_val != "" else 0.0
        except (ValueError, TypeError):
            pu = 0.0
        tot_it = round(cant * pu, 2)
        subtotal_mat += tot_it
        calculated_items.append({
            "tipo": it.get("tipo", "MATERIAL") or "MATERIAL",
            "descripcion": desc,
            "cantidad": cant,
            "precio_unitario": pu,
            "subtotal": tot_it,
            "catalogo_id": it.get("catalogo_id")
        })

    subtotal_mat = round(subtotal_mat, 2)
    subtotal_general = round(subtotal_mo + subtotal_mat + recargo_urgencia, 2)

    # Normalizar descuento_porcentaje
    desc_raw = float(data.get("descuento_porcentaje") or 0.0)
    if 0 < desc_raw < 1:
        desc_pct = round(desc_raw * 100.0, 2)
        desc_factor = desc_raw
    elif desc_raw >= 1:
        desc_pct = round(desc_raw, 2)
        desc_factor = desc_raw / 100.0
    else:
        desc_pct = 0.0
        desc_factor = 0.0

    total_descuento = round(subtotal_general * desc_factor, 2)
    base_imponible = round(subtotal_general - total_descuento, 2)

    # Normalizar IVA e IRPF
    iva_raw = float(data["iva_porcentaje"]) if data.get("iva_porcentaje") is not None else 0.21
    iva_rate = iva_raw / 100.0 if iva_raw > 1 else iva_raw

    irpf_raw = float(data["irpf_porcentaje"]) if data.get("irpf_porcentaje") is not None else 0.0
    irpf_rate = irpf_raw / 100.0 if irpf_raw > 1 else irpf_raw

    total_iva = round(base_imponible * iva_rate, 2)
    total_irpf = round(base_imponible * irpf_rate, 2)
    total_factura = round(base_imponible + total_iva - total_irpf, 2)

    try:
        anticipo_importe = round(max(0.0, float(data.get("anticipo_importe") or 0.0)), 2)
    except (ValueError, TypeError):
        anticipo_importe = 0.0
    anticipo_fecha = str(data.get("anticipo_fecha") or "").strip()
    if anticipo_importe > 0 and not anticipo_fecha:
        anticipo_fecha = datetime.now().strftime("%Y-%m-%d %H:%M")

    garantia_meses = int(data["garantia_meses"]) if data.get("garantia_meses") is not None else 6
    notas_tecnicas = data.get("notas_tecnicas") or ""
    firma_base64 = data.get("firma_base64") or ""
    foto_base64 = data.get("foto_base64") or ""

    return {
        "es_urgencia": es_urgencia,
        "recargo_urgencia": recargo_urgencia,
        "horas_mo": horas_mo,
        "precio_hora": precio_hora,
        "subtotal_mat": subtotal_mat,
        "subtotal_general": subtotal_general,
        "descuento_porcentaje": desc_pct,
        "total_descuento": total_descuento,
        "base_imponible": base_imponible,
        "iva_porcentaje": iva_rate,
        "total_iva": total_iva,
        "irpf_porcentaje": irpf_rate,
        "total_irpf": total_irpf,
        "total_factura": total_factura,
        "anticipo_importe": anticipo_importe,
        "anticipo_fecha": anticipo_fecha,
        "pendiente_cobro": round(total_factura - anticipo_importe, 2),
        "garantia_meses": garantia_meses,
        "notas_tecnicas": notas_tecnicas,
        "firma_base64": firma_base64,
        "foto_base64": foto_base64,
        "calculated_items": calculated_items,
    }


def create_quote(data: dict):
    """
    Crea un nuevo presupuesto/trabajo calculando automáticamente subtotales, descuentos, base imponible, IVA, IRPF, anticipo y totales.
    """
    with get_connection() as conn:
        cursor = conn.cursor()

        numero = _generate_next_quote_number(cursor)
        cliente_id = int(data.get("cliente_id"))
        concepto = data.get("concepto_averia", "Reparación y mantenimiento")
        fecha = datetime.now().strftime("%Y-%m-%d %H:%M")

        calc = _calculate_quote_financials(data)

        cursor.execute("""
        INSERT INTO presupuestos (
            numero, cliente_id, fecha, estado, concepto_averia, es_urgencia, recargo_urgencia,
            horas_mano_obra, precio_hora, subtotal_materiales, subtotal_general,
            descuento_porcentaje, total_descuento, base_imponible,
            iva_porcentaje, total_iva, irpf_porcentaje, total_irpf, total_factura,
            anticipo_importe, anticipo_fecha,
            garantia_meses, notas_tecnicas, firma_base64, foto_base64
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """, (
            numero, cliente_id, fecha, 'BORRADOR', concepto, calc["es_urgencia"], calc["recargo_urgencia"],
            calc["horas_mo"], calc["precio_hora"], calc["subtotal_mat"], calc["subtotal_general"],
            calc["descuento_porcentaje"], calc["total_descuento"], calc["base_imponible"],
            calc["iva_porcentaje"], calc["total_iva"], calc["irpf_porcentaje"], calc["total_irpf"], calc["total_factura"],
            calc["anticipo_importe"], calc["anticipo_fecha"],
            calc["garantia_meses"], calc["notas_tecnicas"], calc["firma_base64"], calc["foto_base64"]
        ))
        presupuesto_id = cursor.lastrowid

        for ci in calc["calculated_items"]:
            cursor.execute("""
            INSERT INTO partidas (presupuesto_id, tipo, descripcion, cantidad, precio_unitario, subtotal, catalogo_id)
            VALUES (?, ?, ?, ?, ?, ?, ?);
            """, (presupuesto_id, ci["tipo"], ci["descripcion"], ci["cantidad"], ci["precio_unitario"], ci["subtotal"], ci.get("catalogo_id")))

        conn.commit()
        return get_quote(presupuesto_id)


def update_quote(quote_id: int, data: dict):
    """
    Recalcula totales, actualiza la cabecera del presupuesto y reemplaza sus partidas si `items` viene en `data`.
    """
    existing = get_quote(quote_id)
    if not existing:
        return None

    merged = {
        "cliente_id": data.get("cliente_id", existing["cliente_id"]),
        "concepto_averia": data.get("concepto_averia", existing["concepto_averia"]),
        "es_urgencia": data.get("es_urgencia") if "es_urgencia" in data else bool(existing.get("es_urgencia")),
        "recargo_urgencia": data.get("recargo_urgencia") if "recargo_urgencia" in data else existing.get("recargo_urgencia", 0.0),
        "horas_mano_obra": data.get("horas_mano_obra") if "horas_mano_obra" in data else existing.get("horas_mano_obra", 1.0),
        "precio_hora": data.get("precio_hora") if "precio_hora" in data else existing.get("precio_hora", 38.0),
        "descuento_porcentaje": data.get("descuento_porcentaje") if "descuento_porcentaje" in data else existing.get("descuento_porcentaje", 0.0),
        "iva_porcentaje": data.get("iva_porcentaje") if "iva_porcentaje" in data else existing.get("iva_porcentaje", 0.21),
        "irpf_porcentaje": data.get("irpf_porcentaje") if "irpf_porcentaje" in data else existing.get("irpf_porcentaje", 0.0),
        "anticipo_importe": data.get("anticipo_importe") if "anticipo_importe" in data else existing.get("anticipo_importe", 0.0),
        "anticipo_fecha": data.get("anticipo_fecha") if "anticipo_fecha" in data else existing.get("anticipo_fecha", ""),
        "garantia_meses": data.get("garantia_meses") if "garantia_meses" in data else existing.get("garantia_meses", 6),
        "notas_tecnicas": data.get("notas_tecnicas") if "notas_tecnicas" in data else existing.get("notas_tecnicas", ""),
        "firma_base64": data.get("firma_base64") if "firma_base64" in data else existing.get("firma_base64", ""),
        "foto_base64": data.get("foto_base64") if "foto_base64" in data else existing.get("foto_base64", ""),
        "items": data["items"] if "items" in data and data["items"] is not None else existing.get("partidas", [])
    }

    calc = _calculate_quote_financials(merged)

    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
        UPDATE presupuestos
        SET cliente_id = ?,
            concepto_averia = ?,
            es_urgencia = ?,
            recargo_urgencia = ?,
            horas_mano_obra = ?,
            precio_hora = ?,
            subtotal_materiales = ?,
            subtotal_general = ?,
            descuento_porcentaje = ?,
            total_descuento = ?,
            base_imponible = ?,
            iva_porcentaje = ?,
            total_iva = ?,
            irpf_porcentaje = ?,
            total_irpf = ?,
            total_factura = ?,
            anticipo_importe = ?,
            anticipo_fecha = ?,
            garantia_meses = ?,
            notas_tecnicas = ?,
            firma_base64 = ?,
            foto_base64 = ?
        WHERE id = ?;
        """, (
            int(merged["cliente_id"]),
            merged["concepto_averia"],
            calc["es_urgencia"],
            calc["recargo_urgencia"],
            calc["horas_mo"],
            calc["precio_hora"],
            calc["subtotal_mat"],
            calc["subtotal_general"],
            calc["descuento_porcentaje"],
            calc["total_descuento"],
            calc["base_imponible"],
            calc["iva_porcentaje"],
            calc["total_iva"],
            calc["irpf_porcentaje"],
            calc["total_irpf"],
            calc["total_factura"],
            calc["anticipo_importe"],
            calc["anticipo_fecha"],
            calc["garantia_meses"],
            calc["notas_tecnicas"],
            calc["firma_base64"],
            calc["foto_base64"],
            quote_id
        ))

        if "items" in data and data["items"] is not None:
            cursor.execute("DELETE FROM partidas WHERE presupuesto_id = ?;", (quote_id,))
            for ci in calc["calculated_items"]:
                cursor.execute("""
                INSERT INTO partidas (presupuesto_id, catalogo_id, tipo, descripcion, cantidad, precio_unitario, subtotal)
                VALUES (?, ?, ?, ?, ?, ?, ?);
                """, (quote_id, ci.get("catalogo_id"), ci["tipo"], ci["descripcion"], ci["cantidad"], ci["precio_unitario"], ci["subtotal"]))

        conn.commit()

    return get_quote(quote_id)


def record_quote_advance(quote_id: int, anticipo_importe: float):
    """Registra o actualiza un anticipo / entrega a cuenta sobre un presupuesto o factura."""
    existing = get_quote(quote_id)
    if not existing:
        return None
    amt = round(max(0.0, float(anticipo_importe or 0.0)), 2)
    fec = datetime.now().strftime("%Y-%m-%d %H:%M") if amt > 0 else ""
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE presupuestos SET anticipo_importe = ?, anticipo_fecha = ? WHERE id = ?;",
            (amt, fec, quote_id)
        )
        conn.commit()
    return get_quote(quote_id)


def delete_quote(quote_id: int) -> bool:
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT estado, numero_factura FROM presupuestos WHERE id = ?;", (quote_id,))
        row = cursor.fetchone()
        if not row:
            return False
        estado = (row["estado"] or "").upper()
        num_fac = row["numero_factura"]
        if estado == "COBRADO" or (num_fac and str(num_fac).strip()):
            raise ValueError(f"No se puede eliminar una factura oficial emitida o cobrada ({num_fac or estado}) por normativa fiscal.")
        cursor.execute("DELETE FROM partidas WHERE presupuesto_id = ?;", (quote_id,))
        cursor.execute("DELETE FROM presupuestos WHERE id = ?;", (quote_id,))
        conn.commit()
        return True


def duplicate_quote(quote_id: int):
    existing = get_quote(quote_id)
    if not existing:
        return None

    clone_payload = {
        "cliente_id": existing["cliente_id"],
        "concepto_averia": existing["concepto_averia"],
        "es_urgencia": bool(existing.get("es_urgencia")),
        "recargo_urgencia": existing.get("recargo_urgencia", 0.0),
        "horas_mano_obra": existing.get("horas_mano_obra", 1.0),
        "precio_hora": existing.get("precio_hora", 38.0),
        "descuento_porcentaje": existing.get("descuento_porcentaje", 0.0),
        "iva_porcentaje": existing.get("iva_porcentaje", 0.21),
        "irpf_porcentaje": existing.get("irpf_porcentaje", 0.0),
        "garantia_meses": existing.get("garantia_meses", 6),
        "notas_tecnicas": existing.get("notas_tecnicas", ""),
        "firma_base64": "",
        "foto_base64": existing.get("foto_base64", ""),
        "items": [
            {
                "tipo": p.get("tipo", "MATERIAL"),
                "descripcion": p.get("descripcion", "Material"),
                "cantidad": p.get("cantidad", 1.0),
                "precio_unitario": p.get("precio_unitario", 0.0)
            }
            for p in existing.get("partidas", [])
        ]
    }
    return create_quote(clone_payload)


def save_quote_signature(quote_id: int, firma_base64: str, aprobar: bool = True):
    existing = get_quote(quote_id)
    if not existing:
        return None

    new_status = existing["estado"]
    if aprobar and existing["estado"] in ("BORRADOR", "ENVIADO"):
        new_status = "APROBADO"

    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE presupuestos SET firma_base64 = ?, estado = ? WHERE id = ?;",
            (firma_base64 or "", new_status, quote_id)
        )
        conn.commit()
    return get_quote(quote_id)


def list_quotes():
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
        SELECT p.*, c.nombre as cliente_nombre, c.telefono as cliente_telefono, c.email as cliente_email,
               c.nif_cif as cliente_nif_cif, c.direccion as cliente_direccion, c.poblacion as cliente_poblacion
        FROM presupuestos p
        JOIN clientes c ON p.cliente_id = c.id
        ORDER BY p.id DESC;
        """)
        quotes = [dict(r) for r in cursor.fetchall()]
        if not quotes:
            return []

        cursor.execute("SELECT * FROM partidas ORDER BY id ASC;")
        all_partidas = {}
        for r in cursor.fetchall():
            d = dict(r)
            all_partidas.setdefault(d["presupuesto_id"], []).append(d)

        for q in quotes:
            q["partidas"] = all_partidas.get(q["id"], [])
            tot_f = float(q.get("total_factura") or 0.0)
            ant_f = float(q.get("anticipo_importe") or 0.0)
            q["anticipo_importe"] = round(ant_f, 2)
            q["pendiente_cobro"] = 0.0 if (q.get("estado") or "").upper() == "COBRADO" else round(max(0.0, tot_f - ant_f), 2)
        return quotes


def get_quote(quote_id: int):
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
        SELECT p.*, c.nombre as cliente_nombre, c.telefono as cliente_telefono, c.email as cliente_email,
               c.nif_cif as cliente_nif_cif, c.direccion as cliente_direccion, c.poblacion as cliente_poblacion
        FROM presupuestos p
        JOIN clientes c ON p.cliente_id = c.id
        WHERE p.id = ?;
        """, (quote_id,))
        quote_row = cursor.fetchone()
        if not quote_row:
            return None

        quote_dict = dict(quote_row)
        cursor.execute("SELECT * FROM partidas WHERE presupuesto_id = ? ORDER BY id ASC;", (quote_id,))
        quote_dict["partidas"] = [dict(r) for r in cursor.fetchall()]
        quote_dict["items"] = quote_dict["partidas"]
        tot_f = float(quote_dict.get("total_factura") or 0.0)
        ant_f = float(quote_dict.get("anticipo_importe") or 0.0)
        quote_dict["anticipo_importe"] = round(ant_f, 2)
        quote_dict["pendiente_cobro"] = 0.0 if (quote_dict.get("estado") or "").upper() == "COBRADO" else round(max(0.0, tot_f - ant_f), 2)
        return quote_dict


def update_quote_status(quote_id: int, new_status: str):
    valid_statuses = ['BORRADOR', 'ENVIADO', 'APROBADO', 'COBRADO', 'CANCELADO']
    status_upper = new_status.upper()
    if status_upper not in valid_statuses:
        raise ValueError(f"Estado no válido: {new_status}")

    cfg = get_config()
    cif_emisor = cfg.get("empresa_cif", "B00000000")
    created_invoice = False

    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT numero_factura, fecha_factura, total_factura, huella_verifactu FROM presupuestos WHERE id = ?;",
            (quote_id,)
        )
        row = cursor.fetchone()
        if not row:
            return None

        num_fac = row["numero_factura"]
        fec_fac = row["fecha_factura"]
        tot_fac = float(row["total_factura"] or 0.0)
        existing_hash = row["huella_verifactu"]

        if status_upper == "COBRADO" and not num_fac:
            num_fac = _generate_next_invoice_number(cursor)
            fec_fac = datetime.now().strftime("%Y-%m-%d %H:%M")
            huella_act, huella_ant = _compute_verifactu_hash(
                cursor, cif_emisor, num_fac, fec_fac, tot_fac, exclude_quote_id=quote_id
            )
            cursor.execute(
                """UPDATE presupuestos
                   SET estado = ?, numero_factura = ?, fecha_factura = ?,
                       huella_verifactu = ?, huella_anterior = ?
                   WHERE id = ?;""",
                (status_upper, num_fac, fec_fac, huella_act, huella_ant, quote_id)
            )
            created_invoice = True
        elif status_upper == "COBRADO" and num_fac and not existing_hash:
            huella_act, huella_ant = _compute_verifactu_hash(
                cursor, cif_emisor, num_fac, fec_fac or datetime.now().strftime("%Y-%m-%d %H:%M"), tot_fac, exclude_quote_id=quote_id
            )
            cursor.execute(
                "UPDATE presupuestos SET estado = ?, huella_verifactu = ?, huella_anterior = ? WHERE id = ?;",
                (status_upper, huella_act, huella_ant, quote_id)
            )
        else:
            cursor.execute("UPDATE presupuestos SET estado = ? WHERE id = ?;", (status_upper, quote_id))
        conn.commit()

    if created_invoice:
        try:
            ensure_auto_backup(reason="invoice")
        except Exception:
            pass

    return get_quote(quote_id)


def create_rectifying_invoice(quote_id: int, motivo: str = "Rectificación / Abono de factura emitida"):
    """
    Emite una Factura Rectificativa oficial (serie REC-YYYY-NNNN) con importes negativos
    vinculada a una factura cobrada, con huella Veri*Factu encadenada y copia de seguridad automática.
    """
    orig = get_quote(quote_id)
    if not orig:
        raise ValueError("El presupuesto o factura original no existe.")
    if orig.get("es_rectificativa"):
        raise ValueError("No se puede emitir una factura rectificativa sobre otra factura rectificativa.")
    orig_num_fac = (orig.get("numero_factura") or "").strip()
    if (orig.get("estado") or "").upper() != "COBRADO" and not orig_num_fac:
        raise ValueError("Solo se pueden emitir facturas rectificativas sobre facturas ya emitidas o cobradas.")

    # Verificar que no haya sido ya rectificada íntegramente
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT numero_factura FROM presupuestos WHERE factura_origen_id = ? AND es_rectificativa = 1;",
            (quote_id,)
        )
        already = cursor.fetchone()
        if already:
            existing_rec_num = already["numero_factura"] if isinstance(already, sqlite3.Row) else already[0]
            raise ValueError(f"Esta factura ya cuenta con una factura rectificativa emitida ({existing_rec_num}).")

        cfg = get_config()
        cif_emisor = cfg.get("empresa_cif", "B00000000")
        rec_num = _generate_next_rectifying_number(cursor)
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M")
        clean_motivo = (motivo or "Rectificación contable / Abono de factura").strip()

        horas_mo = -abs(float(orig.get("horas_mano_obra") or 0.0))
        precio_hora = abs(float(orig.get("precio_hora") or 0.0))
        recargo_urg = -abs(float(orig.get("recargo_urgencia") or 0.0))
        subtotal_mat = -abs(float(orig.get("subtotal_materiales") or 0.0))
        subtotal_gen = -abs(float(orig.get("subtotal_general") or 0.0))
        desc_pct = float(orig.get("descuento_porcentaje") or 0.0)
        total_desc = -abs(float(orig.get("total_descuento") or 0.0))
        base_imp = -abs(float(orig.get("base_imponible") or 0.0))
        iva_pct = float(orig.get("iva_porcentaje") if orig.get("iva_porcentaje") is not None else 0.21)
        total_iva = -abs(float(orig.get("total_iva") or 0.0))
        irpf_pct = float(orig.get("irpf_porcentaje") or 0.0)
        total_irpf = -abs(float(orig.get("total_irpf") or 0.0))
        total_fac = -abs(float(orig.get("total_factura") or 0.0))

        ref_label = orig_num_fac or orig.get("numero", f"ID-{quote_id}")
        concepto_rec = f"[FACTURA RECTIFICATIVA DE {ref_label}] {clean_motivo} — {orig.get('concepto_averia', '')}"

        huella_act, huella_ant = _compute_verifactu_hash(
            cursor, cif_emisor, rec_num, now_str, total_fac
        )

        cursor.execute("""
        INSERT INTO presupuestos (
            numero, cliente_id, fecha, estado, concepto_averia, es_urgencia, recargo_urgencia,
            horas_mano_obra, precio_hora, subtotal_materiales, subtotal_general,
            descuento_porcentaje, total_descuento, base_imponible,
            iva_porcentaje, total_iva, irpf_porcentaje, total_irpf, total_factura,
            numero_factura, fecha_factura,
            es_rectificativa, factura_origen_id, numero_factura_origen, motivo_rectificacion,
            huella_verifactu, huella_anterior,
            garantia_meses, notas_tecnicas
        ) VALUES (?, ?, ?, 'COBRADO', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?);
        """, (
            rec_num, orig["cliente_id"], now_str, concepto_rec, int(orig.get("es_urgencia") or 0), recargo_urg,
            horas_mo, precio_hora, subtotal_mat, subtotal_gen,
            desc_pct, total_desc, base_imp,
            iva_pct, total_iva, irpf_pct, total_irpf, total_fac,
            rec_num, now_str,
            quote_id, ref_label, clean_motivo,
            huella_act, huella_ant,
            int(orig.get("garantia_meses") or 6),
            f"Rectificación oficial de factura {ref_label}. Motivo: {clean_motivo}"
        ))
        rec_id = cursor.lastrowid

        for p in orig.get("partidas", []):
            cant_neg = -abs(float(p.get("cantidad") or 1.0))
            pu_pos = abs(float(p.get("precio_unitario") or 0.0))
            sub_neg = round(cant_neg * pu_pos, 2)
            cursor.execute("""
            INSERT INTO partidas (presupuesto_id, catalogo_id, tipo, descripcion, cantidad, precio_unitario, subtotal)
            VALUES (?, ?, ?, ?, ?, ?, ?);
            """, (
                rec_id, p.get("catalogo_id"), p.get("tipo", "MATERIAL"),
                f"[ABONO] {p.get('descripcion', 'Partida')}", cant_neg, pu_pos, sub_neg
            ))

        conn.commit()

    try:
        ensure_auto_backup(reason="rectification")
    except Exception:
        pass

    return get_quote(rec_id)


def get_analytics_summary() -> dict:
    quotes = list_quotes()
    conteo_por_estado = {
        "BORRADOR": 0,
        "ENVIADO": 0,
        "APROBADO": 0,
        "COBRADO": 0,
        "CANCELADO": 0
    }

    total_facturado_cobrado = 0.0
    total_aprobado_pendiente = 0.0
    total_en_borrador_enviado = 0.0

    facturas_emitidas = 0
    base_imponible_total = 0.0
    iva_21_base = 0.0
    iva_21_cuota = 0.0
    iva_10_base = 0.0
    iva_10_cuota = 0.0
    iva_total_repercutido = 0.0
    irpf_total_retenido = 0.0
    total_neto_caja = 0.0

    active_totals = []

    for q in quotes:
        st = (q.get("estado") or "BORRADOR").upper()
        if st in conteo_por_estado:
            conteo_por_estado[st] += 1

        tot = float(q.get("total_factura") or 0.0)
        base = float(q.get("base_imponible") or q.get("subtotal_general") or 0.0)
        iva_pct = float(q.get("iva_porcentaje") if q.get("iva_porcentaje") is not None else 0.21)
        tot_iva = float(q.get("total_iva") or 0.0)
        tot_irpf = float(q.get("total_irpf") or 0.0)

        # En el cómputo fiscal oficial solo tributan facturas emitidas o cobradas (matching _populate_sales_sheet)
        es_factura_oficial = (st in ("COBRADO", "FACTURADO")) or (bool(q.get("numero_factura")) and st not in ("BORRADOR", "CANCELADO", "ENVIADO"))

        if st == "COBRADO":
            total_facturado_cobrado += tot
            total_neto_caja += tot
        elif st == "APROBADO":
            total_aprobado_pendiente += tot
        elif st in ("BORRADOR", "ENVIADO"):
            total_en_borrador_enviado += tot

        if st != "CANCELADO":
            active_totals.append(tot)

        if es_factura_oficial:
            facturas_emitidas += 1
            base_imponible_total += base
            iva_total_repercutido += tot_iva
            irpf_total_retenido += tot_irpf
            if abs(iva_pct - 0.10) < 0.02:
                iva_10_base += base
                iva_10_cuota += tot_iva
            elif abs(iva_pct - 0.21) < 0.02:
                iva_21_base += base
                iva_21_cuota += tot_iva

    total_presupuestos = len(quotes)
    total_presupuestado = round(sum(active_totals), 2)
    convertidos = conteo_por_estado["APROBADO"] + conteo_por_estado["COBRADO"]
    tasa_conversion_pct = round((convertidos / total_presupuestos) * 100.0, 1) if total_presupuestos > 0 else 0.0
    ticket_medio = round(sum(active_totals) / len(active_totals), 2) if active_totals else 0.0

    now = datetime.now()
    quarter = (now.month - 1) // 3 + 1
    trimestre_actual = f"{now.year}-T{quarter}"

    # =========================================================================
    # RECONCILIACION FISCAL CON COMPRAS Y GASTOS A PROVEEDORES
    # =========================================================================
    expenses = list_expenses()
    compras_facturas = 0
    gastos_base_total = 0.0
    total_gastos_facturas = 0.0
    iva_soportado_21_base = 0.0
    iva_soportado_21_cuota = 0.0
    iva_soportado_10_base = 0.0
    iva_soportado_10_cuota = 0.0
    iva_total_soportado = 0.0

    for exp in expenses:
        st_exp = (exp.get("estado") or "PAGADO").upper()
        if st_exp != "CANCELADO":
            compras_facturas += 1
            b_exp = float(exp.get("base_imponible") or 0.0)
            iva_cuota_exp = float(exp.get("total_iva") or 0.0)
            tot_exp = float(exp.get("total_factura") or 0.0)
            iva_pct_exp = float(exp.get("iva_porcentaje") if exp.get("iva_porcentaje") is not None else 0.21)

            gastos_base_total += b_exp
            iva_total_soportado += iva_cuota_exp
            total_gastos_facturas += tot_exp

            if abs(iva_pct_exp - 0.10) < 0.02:
                iva_soportado_10_base += b_exp
                iva_soportado_10_cuota += iva_cuota_exp
            else:
                iva_soportado_21_base += b_exp
                iva_soportado_21_cuota += iva_cuota_exp

    # Liquidacion Modelo 303: IVA Repercutido - IVA Soportado
    modelo_303_resultado = round(iva_total_repercutido - iva_total_soportado, 2)
    modelo_303_tipo = "A_INGRESAR" if modelo_303_resultado >= 0 else "A_COMPENSAR"

    # Rendimiento de la actividad y Modelo 130 IRPF
    rendimiento_neto = round(base_imponible_total - gastos_base_total, 2)
    modelo_130_estimado = round(max(0.0, (rendimiento_neto * 0.20) - irpf_total_retenido), 2)

    return {
        "kpis": {
            "total_presupuestos": total_presupuestos,
            "total_presupuestado": total_presupuestado,
            "total_facturado_cobrado": round(total_facturado_cobrado, 2),
            "total_aprobado_pendiente": round(total_aprobado_pendiente, 2),
            "total_en_borrador_enviado": round(total_en_borrador_enviado, 2),
            "total_gastos_compras": round(total_gastos_facturas, 2),
            "ticket_medio": ticket_medio,
            "tasa_conversion_pct": tasa_conversion_pct,
            "conteo_por_estado": conteo_por_estado
        },
        "fiscal_trimestral": {
            "trimestre_actual": trimestre_actual,
            "facturas_emitidas": facturas_emitidas,
            "base_imponible_total": round(base_imponible_total, 2),
            "iva_21_base": round(iva_21_base, 2),
            "iva_21_cuota": round(iva_21_cuota, 2),
            "iva_10_base": round(iva_10_base, 2),
            "iva_10_cuota": round(iva_10_cuota, 2),
            "iva_total_repercutido": round(iva_total_repercutido, 2),
            "irpf_total_retenido": round(irpf_total_retenido, 2),
            "total_neto_caja": round(total_neto_caja, 2),
            # Compras y Liquidacion Trimestral Oficial
            "compras_facturas": compras_facturas,
            "gastos_base_total": round(gastos_base_total, 2),
            "total_gastos_facturas": round(total_gastos_facturas, 2),
            "iva_soportado_21_base": round(iva_soportado_21_base, 2),
            "iva_soportado_21_cuota": round(iva_soportado_21_cuota, 2),
            "iva_soportado_10_base": round(iva_soportado_10_base, 2),
            "iva_soportado_10_cuota": round(iva_soportado_10_cuota, 2),
            "iva_total_soportado": round(iva_total_soportado, 2),
            "modelo_303_resultado": modelo_303_resultado,
            "modelo_303_tipo": modelo_303_tipo,
            "rendimiento_neto": rendimiento_neto,
            "modelo_130_estimado": modelo_130_estimado
        }
    }


# =========================================================================
# GESTION DE PROVEEDORES (SUPPLIERS)
# =========================================================================
def create_supplier(nombre, cif_nif="", telefono="", email="", contacto="", direccion="", poblacion="", notas=""):
    with get_connection() as conn:
        cursor = conn.cursor()
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cursor.execute("""
        INSERT INTO proveedores (nombre, cif_nif, telefono, email, contacto, direccion, poblacion, notas, fecha_alta)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
        """, (str(nombre).strip(), str(cif_nif).strip(), str(telefono).strip(), str(email).strip(),
              str(contacto).strip(), str(direccion).strip(), str(poblacion).strip(), str(notas).strip(), now))
        conn.commit()
        return cursor.lastrowid


def update_supplier(supplier_id: int, data: dict):
    existing = get_supplier(supplier_id)
    if not existing:
        return None
    nombre = str(data.get("nombre", existing["nombre"])).strip()
    raw_cif = data.get("cif_nif") if "cif_nif" in data else data.get("cif")
    cif_nif = str(raw_cif if raw_cif is not None else existing.get("cif_nif", "")).strip()
    telefono = str(data.get("telefono", existing.get("telefono", ""))).strip()
    email = str(data.get("email", existing.get("email", ""))).strip()
    contacto = str(data.get("contacto", existing.get("contacto", ""))).strip()
    direccion = str(data.get("direccion", existing.get("direccion", ""))).strip()
    poblacion = str(data.get("poblacion", existing.get("poblacion", ""))).strip()
    notas = str(data.get("notas", existing.get("notas", ""))).strip()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
        UPDATE proveedores
        SET nombre = ?, cif_nif = ?, telefono = ?, email = ?, contacto = ?, direccion = ?, poblacion = ?, notas = ?
        WHERE id = ?;
        """, (nombre, cif_nif, telefono, email, contacto, direccion, poblacion, notas, supplier_id))
        conn.commit()
    return get_supplier(supplier_id)


def delete_supplier(supplier_id: int) -> bool:
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM compras_gastos WHERE proveedor_id = ?;", (supplier_id,))
        count = cursor.fetchone()[0]
        if count > 0:
            raise ValueError(f"No se puede eliminar el proveedor {supplier_id}: tiene {count} factura(s) de compra asociada(s).")
        cursor.execute("DELETE FROM proveedores WHERE id = ?;", (supplier_id,))
        conn.commit()
        return cursor.rowcount > 0


def get_supplier(supplier_id: int):
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM proveedores WHERE id = ?;", (supplier_id,))
        row = cursor.fetchone()
        if not row:
            return None
        d = dict(row)
        d["cif"] = d.get("cif_nif", "")
        return d


def list_suppliers(search: str = None):
    with get_connection() as conn:
        cursor = conn.cursor()
        if search and str(search).strip():
            q = f"%{str(search).strip()}%"
            cursor.execute("""
            SELECT * FROM proveedores
            WHERE nombre LIKE ? OR cif_nif LIKE ? OR contacto LIKE ? OR telefono LIKE ? OR poblacion LIKE ?
            ORDER BY nombre ASC;
            """, (q, q, q, q, q))
        else:
            cursor.execute("SELECT * FROM proveedores ORDER BY nombre ASC;")
        results = []
        for r in cursor.fetchall():
            d = dict(r)
            d["cif"] = d.get("cif_nif", "")
            results.append(d)
        return results


# =========================================================================
# GESTION DE COMPRAS Y GASTOS DE MATERIAL
# =========================================================================
def create_expense(data: dict, items: list = None):
    with get_connection() as conn:
        cursor = conn.cursor()
        numero_factura = str(data.get("numero_factura", "")).strip()
        proveedor_id = data.get("proveedor_id")
        fecha = str(data.get("fecha", datetime.now().strftime("%Y-%m-%d")))
        concepto = str(data.get("concepto", "Compra de material")).strip()
        base_imponible = float(data.get("base_imponible", 0.0))
        iva_porcentaje = float(data.get("iva_porcentaje", 0.21))
        total_iva = round(base_imponible * iva_porcentaje, 2)
        total_factura = round(base_imponible + total_iva, 2)
        forma_pago = str(data.get("forma_pago", "TRANSFERENCIA")).upper()
        estado = str(data.get("estado", "PAGADO")).upper()
        notas = str(data.get("notas", "")).strip()

        cursor.execute("""
        INSERT INTO compras_gastos (numero_factura, proveedor_id, fecha, concepto, base_imponible, iva_porcentaje, total_iva, total_factura, forma_pago, estado, notas)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """, (numero_factura, proveedor_id, fecha, concepto, base_imponible, iva_porcentaje, total_iva, total_factura, forma_pago, estado, notas))
        compra_id = cursor.lastrowid

        # Insertar partidas y sumar al stock automatico
        if items:
            for it in items:
                cat_id = it.get("catalogo_id")
                desc = str(it.get("descripcion", concepto)).strip()
                cant = float(it.get("cantidad", 1.0))
                coste = float(it.get("precio_coste", 0.0))
                subtot = round(cant * coste, 2)
                cursor.execute("""
                INSERT INTO compras_items (compra_id, catalogo_id, descripcion, cantidad, precio_coste, subtotal)
                VALUES (?, ?, ?, ?, ?, ?);
                """, (compra_id, cat_id, desc, cant, coste, subtot))

                if cat_id and cant > 0:
                    cursor.execute("SELECT stock_actual, precio_coste FROM catalogo_partidas WHERE id = ?;", (cat_id,))
                    cat_row = cursor.fetchone()
                    if cat_row:
                        current_stock = float(cat_row[0] or 0.0)
                        new_stock = current_stock + cant
                        cursor.execute("""
                        UPDATE catalogo_partidas
                        SET stock_actual = ?, precio_coste = CASE WHEN ? > 0 THEN ? ELSE precio_coste END
                        WHERE id = ?;
                        """, (new_stock, coste, coste, cat_id))

                        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        cursor.execute("""
                        INSERT INTO stock_movimientos (catalogo_id, tipo_movimiento, cantidad, stock_resultante, referencia_id, motivo, fecha)
                        VALUES (?, 'COMPRA', ?, ?, ?, ?, ?);
                        """, (cat_id, cant, new_stock, compra_id, f"Compra Factura {numero_factura}", now))

        conn.commit()
        return get_expense(compra_id)


def get_expense(compra_id: int):
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
        SELECT cg.*, p.nombre as proveedor_nombre, p.cif_nif as proveedor_cif
        FROM compras_gastos cg
        LEFT JOIN proveedores p ON cg.proveedor_id = p.id
        WHERE cg.id = ?;
        """, (compra_id,))
        row = cursor.fetchone()
        if not row:
            return None
        res = dict(row)
        res["total"] = res.get("total_factura", 0.0)
        res["iva_importe"] = res.get("total_iva", 0.0)
        cursor.execute("SELECT * FROM compras_items WHERE compra_id = ?;", (compra_id,))
        res["items"] = [dict(r) for r in cursor.fetchall()]
        return res


def list_expenses(gremio: str = None):
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
        SELECT cg.*, p.nombre as proveedor_nombre, p.cif_nif as proveedor_cif
        FROM compras_gastos cg
        LEFT JOIN proveedores p ON cg.proveedor_id = p.id
        ORDER BY cg.fecha DESC, cg.id DESC;
        """)
        out = []
        for r in cursor.fetchall():
            d = dict(r)
            d["total"] = d.get("total_factura", 0.0)
            d["iva_importe"] = d.get("total_iva", 0.0)
            
            # Cargar items detallados para ver pieza, coste y uds adquiridas
            cursor.execute("""
            SELECT ci.*, cp.gremio
            FROM compras_items ci
            LEFT JOIN catalogo_partidas cp ON ci.catalogo_id = cp.id
            WHERE ci.compra_id = ?;
            """, (d["id"],))
            items = [dict(it) for it in cursor.fetchall()]
            d["items"] = items

            if gremio and gremio != "ALL":
                has_gremio = any(it.get("gremio") == gremio for it in items)
                if not has_gremio:
                    continue
            out.append(d)
        return out


def delete_expense(compra_id: int) -> bool:
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT catalogo_id, cantidad FROM compras_items WHERE compra_id = ? AND catalogo_id IS NOT NULL;", (compra_id,))
        for cat_id, cant in cursor.fetchall():
            cursor.execute("SELECT stock_actual FROM catalogo_partidas WHERE id = ?;", (cat_id,))
            c_row = cursor.fetchone()
            if c_row:
                curr = float(c_row[0] or 0.0)
                reverted = max(0.0, curr - float(cant))
                cursor.execute("UPDATE catalogo_partidas SET stock_actual = ? WHERE id = ?;", (reverted, cat_id))
        cursor.execute("DELETE FROM compras_items WHERE compra_id = ?;", (compra_id,))
        cursor.execute("DELETE FROM compras_gastos WHERE id = ?;", (compra_id,))
        conn.commit()
        return cursor.rowcount > 0


# =========================================================================
# CONTROL DE STOCK, ALERTAS Y DESCUENTO AUTOMATICO
# =========================================================================
def adjust_stock(catalogo_id: int, cantidad_cambio: float, motivo: str = "Ajuste manual", tipo_movimiento: str = "AJUSTE_MANUAL", referencia_id: int = None):
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT stock_actual, descripcion FROM catalogo_partidas WHERE id = ?;", (catalogo_id,))
        row = cursor.fetchone()
        if not row:
            raise ValueError(f"Articulo de catalogo {catalogo_id} no encontrado")
        current_stock = float(row[0] or 0.0)
        new_stock = max(0.0, current_stock + float(cantidad_cambio))
        cursor.execute("UPDATE catalogo_partidas SET stock_actual = ? WHERE id = ?;", (new_stock, catalogo_id))
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cursor.execute("""
        INSERT INTO stock_movimientos (catalogo_id, tipo_movimiento, cantidad, stock_resultante, referencia_id, motivo, fecha)
        VALUES (?, ?, ?, ?, ?, ?, ?);
        """, (catalogo_id, tipo_movimiento, float(cantidad_cambio), new_stock, referencia_id, motivo, now))
        conn.commit()
        return {"id": catalogo_id, "stock_anterior": current_stock, "stock_actual": new_stock, "nuevo_stock": new_stock, "diferencia": cantidad_cambio}


def list_stock_alerts():
    cfg = get_config()
    default_min = float(cfg.get("stock_alerta_default", 5.0))
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
        SELECT *, COALESCE(stock_minimo_alerta, ?) as alerta_umbral
        FROM catalogo_partidas
        WHERE controla_stock = 1 AND stock_actual <= COALESCE(stock_minimo_alerta, ?)
        ORDER BY stock_actual ASC, gremio ASC;
        """, (default_min, default_min))
        return [dict(r) for r in cursor.fetchall()]


def get_stock_summary():
    cfg = get_config()
    default_min = float(cfg.get("stock_alerta_default", 5.0))
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
        SELECT 
            COUNT(*) as total_items,
            COALESCE(SUM(stock_actual), 0.0) as total_unidades,
            COALESCE(SUM(stock_actual * precio_coste), 0.0) as valor_almacen_coste,
            COALESCE(SUM(stock_actual * precio_unitario), 0.0) as valor_almacen_pvp,
            COALESCE(SUM(CASE WHEN stock_actual <= COALESCE(stock_minimo_alerta, ?) THEN 1 ELSE 0 END), 0) as alertas_bajo_stock,
            COALESCE(SUM(CASE WHEN stock_actual <= 0 THEN 1 ELSE 0 END), 0) as sin_stock
        FROM catalogo_partidas
        WHERE controla_stock = 1;
        """, (default_min,))
        row = cursor.fetchone()
        if not row:
            return {}
        d = dict(row)
        d["total_articulos"] = d.get("total_items", 0)
        d["unidades_totales"] = d.get("total_unidades", 0.0)
        d["valor_total_almacen_coste"] = d.get("valor_almacen_coste", 0.0)
        d["articulos_sin_existencias"] = d.get("sin_stock", 0)
        return d


def deduct_quote_stock(quote_id: int):
    """Descuenta del stock los materiales utilizados al aprobar o cobrar un presupuesto."""
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT numero FROM presupuestos WHERE id = ?;", (quote_id,))
        p_row = cursor.fetchone()
        num_doc = p_row[0] if p_row else f"ID {quote_id}"

        cursor.execute("SELECT COUNT(*) FROM stock_movimientos WHERE referencia_id = ? AND tipo_movimiento = 'CONSUMO_PRESUPUESTO';", (quote_id,))
        if cursor.fetchone()[0] > 0:
            return

        cursor.execute("SELECT catalogo_id, descripcion, cantidad FROM partidas WHERE presupuesto_id = ?;", (quote_id,))
        partidas_rows = cursor.fetchall()

        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        for cat_id, desc, cant in partidas_rows:
            target_cat_id = cat_id
            if not target_cat_id:
                cursor.execute("SELECT id FROM catalogo_partidas WHERE descripcion = ? LIMIT 1;", (desc.strip(),))
                match = cursor.fetchone()
                if match:
                    target_cat_id = match[0]

            if target_cat_id:
                cursor.execute("SELECT stock_actual, controla_stock FROM catalogo_partidas WHERE id = ?;", (target_cat_id,))
                c_row = cursor.fetchone()
                if c_row and (c_row[1] is None or c_row[1] == 1):
                    current = float(c_row[0] or 0.0)
                    new_s = max(0.0, current - float(cant))
                    cursor.execute("UPDATE catalogo_partidas SET stock_actual = ? WHERE id = ?;", (new_s, target_cat_id))
                    cursor.execute("""
                    INSERT INTO stock_movimientos (catalogo_id, tipo_movimiento, cantidad, stock_resultante, referencia_id, motivo, fecha)
                    VALUES (?, 'CONSUMO_PRESUPUESTO', ?, ?, ?, ?, ?);
                    """, (target_cat_id, -float(cant), new_s, quote_id, f"Presupuesto {num_doc}", now))
        conn.commit()


# =========================================================================
# EXPORTACION PROFESIONAL A EXCEL PARA GESTORIA (OPENPYXL MULTI-HOJA)
# =========================================================================
def _get_excel_styles():
    header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    header_fill = PatternFill(fill_type="solid", start_color="1E293B", end_color="1E293B")
    exp_header_fill = PatternFill(fill_type="solid", start_color="334155", end_color="334155")
    center_align = Alignment(horizontal="center", vertical="center", wrap_text=True)
    right_align = Alignment(horizontal="right", vertical="center")
    left_align = Alignment(horizontal="left", vertical="center")
    thin_border = Border(
        left=Side(style="thin", color="E2E8F0"),
        right=Side(style="thin", color="E2E8F0"),
        top=Side(style="thin", color="E2E8F0"),
        bottom=Side(style="thin", color="E2E8F0")
    )
    double_bottom = Border(
        top=Side(style="thin", color="94A3B8"),
        bottom=Side(style="double", color="1E293B")
    )
    total_fill = PatternFill(fill_type="solid", start_color="F1F5F9", end_color="F1F5F9")
    return {
        "header_font": header_font,
        "header_fill": header_fill,
        "exp_header_fill": exp_header_fill,
        "center_align": center_align,
        "right_align": right_align,
        "left_align": left_align,
        "thin_border": thin_border,
        "double_bottom": double_bottom,
        "total_fill": total_fill
    }

def _sanitize_excel_value(val):
    """
    Prevención de CSV / Excel Formula Injection (CWE-1236):
    Si una cadena de texto empieza por '=', '+', '-', '@', tabulador o retorno de carro,
    antepone un apóstrofe seguro para que Excel/LibreOffice nunca lo evalúe como fórmula ejecutable.
    """
    if not isinstance(val, str):
        return val
    stripped = val.lstrip(" ")
    if stripped and stripped[0] in ("=", "+", "-", "@", "\t", "\r", "\n"):
        return "'" + val
    return val


def _populate_sales_sheet(ws1, quotes):
    styles = _get_excel_styles()
    cols_deseadas = [
        "numero", "numero_factura", "fecha", "fecha_factura",
        "cliente_nombre", "cliente_nif_cif", "cliente_telefono", "estado",
        "concepto_averia", "subtotal_general", "descuento_porcentaje", "total_descuento",
        "base_imponible", "iva_porcentaje", "total_iva", "irpf_porcentaje", "total_irpf",
        "total_factura"
    ]
    ws1.append(cols_deseadas)
    ws1.row_dimensions[1].height = 26
    for col_idx in range(1, len(cols_deseadas) + 1):
        cell = ws1.cell(row=1, column=col_idx)
        cell.font = styles["header_font"]
        cell.fill = styles["header_fill"]
        cell.alignment = styles["center_align"]

    tot_base_ventas = 0.0
    tot_iva_ventas = 0.0
    tot_irpf_ventas = 0.0
    tot_facturas_ventas = 0.0

    for q in quotes:
        estado_q = str(q.get("estado") or "").strip().upper()
        # En el libro contable de facturas emitidas solo se exportan facturas cobradas / oficiales
        if estado_q not in ("COBRADO", "FACTURADO") and not (bool(q.get("numero_factura")) and estado_q not in ("BORRADOR", "CANCELADO", "ENVIADO", "APROBADO")):
            continue

        row_vals = [
            _sanitize_excel_value(q.get("numero", "")),
            _sanitize_excel_value(q.get("numero_factura", "")),
            _sanitize_excel_value(q.get("fecha", "")),
            _sanitize_excel_value(q.get("fecha_factura", "")),
            _sanitize_excel_value(q.get("cliente_nombre", "")),
            _sanitize_excel_value(q.get("cliente_nif_cif", "")),
            _sanitize_excel_value(q.get("cliente_telefono", "")),
            _sanitize_excel_value(q.get("estado", "")),
            _sanitize_excel_value(q.get("concepto_averia", "")),
            float(q.get("subtotal_general") or 0.0),
            float(q.get("descuento_porcentaje") or 0.0),
            float(q.get("total_descuento") or 0.0),
            float(q.get("base_imponible") or 0.0),
            float(q.get("iva_porcentaje") or 0.0),
            float(q.get("total_iva") or 0.0),
            float(q.get("irpf_porcentaje") or 0.0),
            float(q.get("total_irpf") or 0.0),
            float(q.get("total_factura") or 0.0)
        ]
        ws1.append(row_vals)
        r_idx = ws1.max_row
        ws1.row_dimensions[r_idx].height = 20

        tot_base_ventas += float(q.get("base_imponible") or 0.0)
        tot_iva_ventas += float(q.get("total_iva") or 0.0)
        tot_irpf_ventas += float(q.get("total_irpf") or 0.0)
        tot_facturas_ventas += float(q.get("total_factura") or 0.0)

        for c_idx in (10, 12, 13, 15, 17, 18):
            cell = ws1.cell(row=r_idx, column=c_idx)
            cell.number_format = '#,##0.00 €'
            cell.alignment = styles["right_align"]
            cell.border = styles["thin_border"]

        for c_idx in (11, 14, 16):
            cell = ws1.cell(row=r_idx, column=c_idx)
            cell.number_format = '0.00%' if cell.value < 1.0 else '0.0%'
            cell.alignment = styles["right_align"]
            cell.border = styles["thin_border"]

        for c_idx in (1, 2, 3, 4, 6, 8):
            ws1.cell(row=r_idx, column=c_idx).alignment = styles["center_align"]
            ws1.cell(row=r_idx, column=c_idx).border = styles["thin_border"]
        for c_idx in (5, 7, 9):
            ws1.cell(row=r_idx, column=c_idx).alignment = styles["left_align"]
            ws1.cell(row=r_idx, column=c_idx).border = styles["thin_border"]

    tot_row_idx = ws1.max_row + 1
    ws1.cell(row=tot_row_idx, column=1, value="TOTALES").font = Font(name="Calibri", size=11, bold=True, color="1E293B")
    ws1.cell(row=tot_row_idx, column=13, value=round(tot_base_ventas, 2)).number_format = '#,##0.00 €'
    ws1.cell(row=tot_row_idx, column=15, value=round(tot_iva_ventas, 2)).number_format = '#,##0.00 €'
    ws1.cell(row=tot_row_idx, column=17, value=round(tot_irpf_ventas, 2)).number_format = '#,##0.00 €'
    ws1.cell(row=tot_row_idx, column=18, value=round(tot_facturas_ventas, 2)).number_format = '#,##0.00 €'

    ws1.row_dimensions[tot_row_idx].height = 24
    for c_idx in range(1, len(cols_deseadas) + 1):
        cell = ws1.cell(row=tot_row_idx, column=c_idx)
        cell.font = Font(name="Calibri", size=11, bold=True, color="1E293B")
        cell.fill = styles["total_fill"]
        cell.border = styles["double_bottom"]

    return tot_base_ventas, tot_iva_ventas, tot_irpf_ventas, tot_facturas_ventas

def _populate_expenses_sheet(ws2, expenses):
    styles = _get_excel_styles()
    exp_headers = [
        "ID", "Nº Factura Proveedor", "Fecha", "Proveedor", "NIF/CIF",
        "Concepto", "Base Imponible", "IVA %", "Cuota IVA", "Total Factura",
        "Forma de Pago", "Estado"
    ]
    ws2.append(exp_headers)
    ws2.row_dimensions[1].height = 26
    for col_idx in range(1, len(exp_headers) + 1):
        cell = ws2.cell(row=1, column=col_idx)
        cell.font = styles["header_font"]
        cell.fill = styles["exp_header_fill"]
        cell.alignment = styles["center_align"]

    tot_base_compras = 0.0
    tot_iva_compras = 0.0
    tot_facturas_compras = 0.0

    for exp in expenses:
        estado_exp = str(exp.get("estado") or "PAGADO").strip().upper()
        # En el libro contable de compras y gastos solo se exportan facturas pagadas
        if estado_exp != "PAGADO":
            continue

        b_imp = float(exp.get("base_imponible") or 0.0)
        t_iva = float(exp.get("total_iva") or 0.0)
        t_tot = float(exp.get("total_factura") or 0.0)
        tot_base_compras += b_imp
        tot_iva_compras += t_iva
        tot_facturas_compras += t_tot

        ws2.append([
            exp.get("id"),
            _sanitize_excel_value(exp.get("numero_factura", "")),
            _sanitize_excel_value(exp.get("fecha", "")),
            _sanitize_excel_value(exp.get("proveedor_nombre", "Sin asignar")),
            _sanitize_excel_value(exp.get("proveedor_cif", "-")),
            _sanitize_excel_value(exp.get("concepto", "")),
            b_imp,
            float(exp.get("iva_porcentaje") or 0.21),
            t_iva,
            t_tot,
            _sanitize_excel_value(exp.get("forma_pago", "TRANSFERENCIA")),
            _sanitize_excel_value(exp.get("estado", "PAGADO"))
        ])
        r = ws2.max_row
        ws2.row_dimensions[r].height = 20
        ws2.cell(row=r, column=7).number_format = '#,##0.00 €'
        ws2.cell(row=r, column=8).number_format = '0.0%'
        ws2.cell(row=r, column=9).number_format = '#,##0.00 €'
        ws2.cell(row=r, column=10).number_format = '#,##0.00 €'

    tot_exp_row = ws2.max_row + 1
    ws2.cell(row=tot_exp_row, column=1, value="TOTAL GASTOS").font = Font(bold=True)
    ws2.cell(row=tot_exp_row, column=7, value=round(tot_base_compras, 2)).number_format = '#,##0.00 €'
    ws2.cell(row=tot_exp_row, column=9, value=round(tot_iva_compras, 2)).number_format = '#,##0.00 €'
    ws2.cell(row=tot_exp_row, column=10, value=round(tot_facturas_compras, 2)).number_format = '#,##0.00 €'
    for c_idx in range(1, len(exp_headers) + 1):
        cell = ws2.cell(row=tot_exp_row, column=c_idx)
        cell.font = Font(bold=True)
        cell.fill = styles["total_fill"]
        cell.border = styles["double_bottom"]

    return tot_base_compras, tot_iva_compras, tot_facturas_compras

def _auto_fit_columns(sheet):
    for col in sheet.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            val_str = str(cell.value or "")
            max_len = max(max_len, len(val_str))
        sheet.column_dimensions[col_letter].width = max(max_len + 3, 12)

def export_sales_to_excel(output_filename="data/export_facturas_clientes.xlsx"):
    quotes = list_quotes()
    out_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), output_filename)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Facturas_Emitidas_Clientes"
    _populate_sales_sheet(ws, quotes)
    _auto_fit_columns(ws)
    wb.save(out_path)
    return out_path

def export_expenses_to_excel(output_filename="data/export_facturas_proveedores.xlsx"):
    expenses = list_expenses()
    out_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), output_filename)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Facturas_Compras_Proveedores"
    _populate_expenses_sheet(ws, expenses)
    _auto_fit_columns(ws)
    wb.save(out_path)
    return out_path

def export_to_excel(output_filename="data/export_facturacion.xlsx"):
    quotes = list_quotes()
    expenses = list_expenses()
    cfg = get_config()
    styles = _get_excel_styles()

    out_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), output_filename)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    wb = openpyxl.Workbook()

    # HOJA 1: FACTURAS Y PRESUPUESTOS EMITIDOS (VENTAS)
    ws1 = wb.active
    ws1.title = "Facturas_Emitidas"
    tot_base_ventas, tot_iva_ventas, tot_irpf_ventas, tot_facturas_ventas = _populate_sales_sheet(ws1, quotes)

    # HOJA 2: COMPRAS Y GASTOS DE MATERIAL (PROVEEDORES)
    ws2 = wb.create_sheet(title="Compras_Gastos_Proveedores")
    tot_base_compras, tot_iva_compras, tot_facturas_compras = _populate_expenses_sheet(ws2, expenses)

    # HOJA 3: RESUMEN FISCAL MODELO 303 Y 130
    ws3 = wb.create_sheet(title="Resumen_Fiscal_Trimestral")
    ws3.column_dimensions["A"].width = 38
    ws3.column_dimensions["B"].width = 22

    ws3["A1"] = "OFIGREMIO PRO — LIQUIDACIÓN FISCAL ESTIMADA"
    ws3["A1"].font = Font(name="Calibri", size=14, bold=True, color="1E293B")
    ws3["A2"] = f"Empresa: {cfg.get('empresa_nombre', 'Autónomo')} | NIF/CIF: {cfg.get('empresa_cif', 'B-00000000')}"
    ws3["A2"].font = Font(name="Calibri", size=10, italic=True, color="64748B")
    ws3["A3"] = f"Fecha de emisión: {datetime.now().strftime('%d/%m/%Y %H:%M')}"
    ws3["A3"].font = Font(name="Calibri", size=9, color="94A3B8")

    ws3.append([])
    ws3.append(["1. LIQUIDACIÓN IVA (MODELO 303)", "IMPORTE (€)"])
    ws3.row_dimensions[5].height = 22
    ws3["A5"].font = Font(bold=True, color="FFFFFF")
    ws3["A5"].fill = styles["header_fill"]
    ws3["B5"].font = Font(bold=True, color="FFFFFF")
    ws3["B5"].fill = styles["header_fill"]

    ws3.append(["(+) Base Imponible Ventas / Servicios Emitidos", round(tot_base_ventas, 2)])
    ws3.append(["(+) Cuota IVA Repercutido (a liquidar)", round(tot_iva_ventas, 2)])
    ws3.append(["(-) Base Imponible Compras / Gastos Material", round(tot_base_compras, 2)])
    ws3.append(["(-) Cuota IVA Soportado (deducible)", round(tot_iva_compras, 2)])
    
    diff_iva = round(tot_iva_ventas - tot_iva_compras, 2)
    ws3.append(["(=) RESULTADO ESTIMADO MODELO 303", diff_iva])
    res_303_row = ws3.max_row
    ws3[f"A{res_303_row}"].font = Font(bold=True, color="1E293B")
    ws3[f"B{res_303_row}"].font = Font(bold=True, color="1E293B")
    res_303_fill = PatternFill(fill_type="solid", start_color="FEF08A" if diff_iva > 0 else "BBF7D0", end_color="FEF08A" if diff_iva > 0 else "BBF7D0")
    ws3[f"A{res_303_row}"].fill = res_303_fill
    ws3[f"B{res_303_row}"].fill = res_303_fill

    ws3.append([])
    ws3.append(["2. RENDIMIENTO IRPF (MODELO 130)", "IMPORTE (€)"])
    irpf_hdr = ws3.max_row
    irpf_fill = PatternFill(fill_type="solid", start_color="0F766E", end_color="0F766E")
    ws3[f"A{irpf_hdr}"].font = Font(bold=True, color="FFFFFF")
    ws3[f"A{irpf_hdr}"].fill = irpf_fill
    ws3[f"B{irpf_hdr}"].font = Font(bold=True, color="FFFFFF")
    ws3[f"B{irpf_hdr}"].fill = irpf_fill

    rend_neto = round(tot_base_ventas - tot_base_compras, 2)
    ws3.append(["(+) Total Ingresos Computables (Base Ventas)", round(tot_base_ventas, 2)])
    ws3.append(["(-) Total Gastos Deducibles (Base Compras)", round(tot_base_compras, 2)])
    ws3.append(["(=) RENDIMIENTO NETO PREVIO", rend_neto])
    ws3.append(["(-) Retenciones IRPF Soportadas por Clientes", round(tot_irpf_ventas, 2)])

    for row_i in range(6, ws3.max_row + 1):
        if ws3[f"B{row_i}"].value is not None:
            ws3[f"B{row_i}"].number_format = '#,##0.00 €'
            ws3[f"B{row_i}"].alignment = styles["right_align"]

    _auto_fit_columns(ws1)
    _auto_fit_columns(ws2)

    wb.save(out_path)
    return out_path


def _rotate_backup_files(output_dir: str, max_keep: int = 3):
    """
    Política de retención: conserva únicamente los max_keep respaldos más recientes.
    """
    try:
        backups = []
        for fname in os.listdir(output_dir):
            if fname.startswith("ofigremio_backup_") and fname.endswith(".db"):
                fpath = os.path.join(output_dir, fname)
                if os.path.isfile(fpath):
                    backups.append((os.path.getmtime(fpath), fpath))
        backups.sort(key=lambda x: x[0], reverse=True)
        for _, old_path in backups[max_keep:]:
            try:
                os.remove(old_path)
            except Exception:
                pass
    except Exception:
        pass


def get_backups_dir() -> str:
    base_dir = os.path.dirname(os.path.abspath(DB_PATH))
    backups_dir = os.path.join(base_dir, "backups")
    os.makedirs(backups_dir, exist_ok=True)
    return backups_dir


def create_backup_copy(output_dir: str = None, max_keep: int = 3) -> str:
    """
    Realiza una copia de seguridad íntegra y consistente de la base de datos SQLite
    usando la API nativa de respaldo online de SQLite.
    Aplica rotación automática conservando las max_keep copias más recientes.
    """
    if output_dir is None:
        output_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:18]
    backup_filename = f"ofigremio_backup_{timestamp}.db"
    backup_path = os.path.join(output_dir, backup_filename)

    src_conn = sqlite3.connect(DB_PATH)
    try:
        dst_conn = sqlite3.connect(backup_path)
        try:
            src_conn.backup(dst_conn)
        finally:
            dst_conn.close()
    finally:
        src_conn.close()

    # Rotación automática de respaldos
    _rotate_backup_files(output_dir, max_keep=max_keep)

    return backup_path


def ensure_auto_backup(reason: str = "auto", max_keep: int = 30) -> str:
    """
    Crea una copia de seguridad atómica automática en la carpeta dedicada `backups/`
    junto a la base de datos activa, conservando hasta 30 puntos de restauración.
    """
    backups_dir = get_backups_dir()
    clean_reason = "".join(ch for ch in (reason or "auto").lower() if ch.isalnum() or ch == "_")[:20] or "auto"
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:18]
    backup_filename = f"ofigremio_backup_{timestamp}_{clean_reason}.db"
    backup_path = os.path.join(backups_dir, backup_filename)

    if not os.path.exists(DB_PATH):
        init_db()

    src_conn = sqlite3.connect(DB_PATH)
    try:
        dst_conn = sqlite3.connect(backup_path)
        try:
            src_conn.backup(dst_conn)
        finally:
            dst_conn.close()
    finally:
        src_conn.close()

    _rotate_backup_files(backups_dir, max_keep=max_keep)
    return backup_path


def list_backups() -> dict:
    """
    Devuelve el estado de integridad de la base de datos activa, su ubicación física
    y el listado de puntos de restauración disponibles ordenados del más reciente al más antiguo.
    """
    backups_dir = get_backups_dir()
    data_dir = os.path.dirname(os.path.abspath(DB_PATH))
    items = []
    seen_names = set()

    for folder in (backups_dir, data_dir):
        if not os.path.isdir(folder):
            continue
        for fname in os.listdir(folder):
            if fname.startswith("ofigremio_backup_") and fname.endswith(".db") and fname not in seen_names:
                fpath = os.path.join(folder, fname)
                if os.path.isfile(fpath):
                    seen_names.add(fname)
                    mtime = os.path.getmtime(fpath)
                    size_kb = round(os.path.getsize(fpath) / 1024.0, 1)
                    dt_str = datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M:%S")
                    items.append({
                        "filename": fname,
                        "created_at": dt_str,
                        "size_kb": size_kb,
                        "mtime": mtime
                    })

    items.sort(key=lambda x: x["mtime"], reverse=True)
    for it in items:
        it.pop("mtime", None)

    integrity_ok = True
    journal_mode = "wal"
    try:
        with get_connection() as conn:
            cur = conn.cursor()
            cur.execute("PRAGMA quick_check;")
            chk = cur.fetchone()
            integrity_ok = bool(chk and str(chk[0]).lower() == "ok")
            cur.execute("PRAGMA journal_mode;")
            jm = cur.fetchone()
            if jm:
                journal_mode = str(jm[0]).lower()
    except Exception:
        integrity_ok = False

    db_size_kb = round(os.path.getsize(DB_PATH) / 1024.0, 1) if os.path.exists(DB_PATH) else 0.0
    return {
        "db_path": os.path.abspath(DB_PATH),
        "db_size_kb": db_size_kb,
        "integrity_ok": integrity_ok,
        "journal_mode": journal_mode.upper(),
        "backups_count": len(items),
        "last_backup_at": items[0]["created_at"] if items else None,
        "backups": items
    }


def restore_backup_from_file(filename: str) -> dict:
    """
    Verifica la integridad de una copia de seguridad (`PRAGMA integrity_check`),
    crea antes una copia de resguardo del estado actual y restaura la base de datos de forma atómica.
    """
    safe_name = os.path.basename(str(filename or "").strip())
    if not safe_name.startswith("ofigremio_backup_") or not safe_name.endswith(".db"):
        raise ValueError("Nombre de archivo de copia de seguridad no válido.")

    backups_dir = get_backups_dir()
    data_dir = os.path.dirname(os.path.abspath(DB_PATH))
    candidate_paths = [
        os.path.join(backups_dir, safe_name),
        os.path.join(data_dir, safe_name)
    ]
    target_path = next((p for p in candidate_paths if os.path.isfile(p)), None)
    if not target_path:
        raise ValueError("No se encontró el archivo de copia de seguridad solicitado.")

    # 1. Verificar integridad del archivo de backup antes de tocar la BD activa
    chk_conn = sqlite3.connect(target_path)
    try:
        cur = chk_conn.cursor()
        cur.execute("PRAGMA integrity_check;")
        res = cur.fetchone()
        if not res or str(res[0]).lower() != "ok":
            raise ValueError("El archivo de copia seleccionado no superó la prueba de integridad SQLite.")
    finally:
        chk_conn.close()

    # 2. Crear punto de seguridad previo antes de restaurar
    safety_backup = ensure_auto_backup(reason="pre_restore")

    # 3. Restauración atómica mediante la API de backup de SQLite
    src_conn = sqlite3.connect(target_path)
    try:
        dst_conn = sqlite3.connect(DB_PATH)
        try:
            src_conn.backup(dst_conn)
        finally:
            dst_conn.close()
    finally:
        src_conn.close()

    # 4. Asegurar migraciones no destructivas sobre la base restaurada
    init_db()

    return {
        "status": "restored",
        "restored_from": safe_name,
        "safety_backup": os.path.basename(safety_backup)
    }


# =========================================================================
# GESTION DE MEMORIA PERSISTENTE DEL ASISTENTE TECNICO (LOCAL RGPD)
# =========================================================================
def get_assistant_memory(key: str = None):
    with get_connection() as conn:
        cursor = conn.cursor()
        if key:
            cursor.execute("SELECT * FROM asistente_memoria WHERE clave = ?;", (str(key).strip(),))
            row = cursor.fetchone()
            return dict(row) if row else None
        else:
            cursor.execute("SELECT * FROM asistente_memoria ORDER BY categoria ASC, clave ASC;")
            return [dict(r) for r in cursor.fetchall()]


def set_assistant_memory(key: str, value: str, category: str = "general"):
    with get_connection() as conn:
        cursor = conn.cursor()
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cursor.execute("""
        INSERT INTO asistente_memoria (clave, valor, categoria, fecha_actualizacion)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor, categoria=excluded.categoria, fecha_actualizacion=excluded.fecha_actualizacion;
        """, (str(key).strip(), str(value).strip(), str(category).strip(), now))
        conn.commit()
        return {"clave": key, "valor": value, "categoria": category, "fecha_actualizacion": now}


def delete_assistant_memory(key: str) -> bool:
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM asistente_memoria WHERE clave = ?;", (str(key).strip(),))
        conn.commit()
        return cursor.rowcount > 0


# =========================================================================
# GESTION DE USUARIOS, UNICIDAD GLOBAL Y VINCULACION EMPRESA (ADMIN / TECNICO)
# =========================================================================
def _normalize_username(username: str) -> str:
    return (username or "").strip().lower()


def is_username_available(username: str, allow_replace_bootstrap: bool = False, current_user: str | dict = None, current_username: str = None) -> bool:
    norm = _normalize_username(username)
    if not norm or len(norm) < 3 or len(norm) > 64:
        return False
    curr = current_username
    if not curr and current_user:
        curr = current_user.get("username") if isinstance(current_user, dict) else str(current_user)
    if curr and _normalize_username(curr) == norm:
        return True
    with get_connection() as conn:
        cursor = conn.cursor()
        if allow_replace_bootstrap:
            cursor.execute("SELECT value FROM config WHERE key = 'primera_configuracion_pendiente';")
            row_cfg = cursor.fetchone()
            is_pending = (row_cfg[0] == "1") if row_cfg else False
            if is_pending:
                cursor.execute("SELECT COUNT(*) FROM usuarios WHERE LOWER(username) = LOWER(?) AND LOWER(username) != 'admin';", (norm,))
                if cursor.fetchone()[0] > 0:
                    return False
                cursor.execute("SELECT COUNT(*) FROM registro_identidades_globales WHERE LOWER(username) = LOWER(?) AND LOWER(username) != 'admin';", (norm,))
                return cursor.fetchone()[0] == 0
        cursor.execute("SELECT COUNT(*) FROM usuarios WHERE LOWER(username) = LOWER(?);", (norm,))
        if cursor.fetchone()[0] > 0:
            return False
        cursor.execute("SELECT COUNT(*) FROM registro_identidades_globales WHERE LOWER(username) = LOWER(?);", (norm,))
        return cursor.fetchone()[0] == 0


def create_user(username: str, password: str, nombre: str, rol: str = "TECNICO", empresa_cif: str = None, empresa_nombre: str = None) -> dict:
    norm_user = _normalize_username(username)
    if not norm_user:
        raise ValueError("El nombre de usuario no puede estar vacío")
    if len(norm_user) < 3 or len(norm_user) > 64:
        raise ValueError("El nombre de usuario debe tener entre 3 y 64 caracteres")
    if not password or len(password) < 4 or len(password) > 128:
        raise ValueError("La contraseña debe tener entre 4 y 128 caracteres")
    if rol not in ("ADMIN", "TECNICO"):
        raise ValueError("El rol debe ser ADMIN o TECNICO")

    cfg = get_config()
    cif_val = (empresa_cif if empresa_cif is not None else cfg.get("empresa_cif", "")).strip()
    emp_val = (empresa_nombre if empresa_nombre is not None else cfg.get("empresa_nombre", "")).strip()

    pw_hash = hash_password(password)
    now_iso = datetime.now().isoformat()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, empresa_cif FROM usuarios WHERE LOWER(username) = LOWER(?);", (norm_user,))
        existing = cursor.fetchone()
        if existing:
            raise ValueError(f"El nombre de usuario '{norm_user}' ya está ocupado por otra cuenta o empresa. Elige uno distinto.")
        cursor.execute("SELECT username, empresa_cif FROM registro_identidades_globales WHERE LOWER(username) = LOWER(?);", (norm_user,))
        existing_glob = cursor.fetchone()
        if existing_glob:
            raise ValueError(f"El nombre de usuario '{norm_user}' ya está registrado por otra empresa. Elige uno distinto.")

        cursor.execute(
            "INSERT INTO usuarios (username, password_hash, nombre, rol, activo, created_at, empresa_cif, empresa_nombre) VALUES (?, ?, ?, ?, 1, ?, ?, ?);",
            (norm_user, pw_hash, (nombre or norm_user).strip(), rol, now_iso, cif_val, emp_val)
        )
        uid = cursor.lastrowid
        cursor.execute(
            "INSERT OR REPLACE INTO registro_identidades_globales (username, empresa_cif, empresa_nombre, created_at) VALUES (?, ?, ?, ?);",
            (norm_user, cif_val, emp_val, now_iso)
        )
        conn.commit()
        cursor.execute("SELECT id, username, nombre, rol, activo, created_at, empresa_cif, empresa_nombre FROM usuarios WHERE id = ?;", (uid,))
        return dict(cursor.fetchone())


def setup_initial_admin_user(username: str, password: str, nombre: str, empresa_cif: str = "", empresa_nombre: str = "") -> dict:
    """
    Crea o configura el primer usuario Administrador Principal dentro del Wizard de Puesta en Marcha.
    Vincula el usuario de forma única a su empresa (empresa_cif y empresa_nombre) y reemplaza
    limpiamente el usuario de inicialización 'admin' si aún no se había configurado el negocio.
    """
    norm_user = _normalize_username(username)
    if not norm_user or len(norm_user) < 3 or len(norm_user) > 64:
        raise ValueError("El usuario administrador debe tener entre 3 y 64 caracteres sin espacios")
    if not password or len(password.strip()) < 6 or len(password) > 128:
        raise ValueError("La contraseña del administrador debe tener al menos 6 caracteres")

    clean_nombre = (nombre or "Administrador Principal").strip()
    clean_cif = (empresa_cif or "").strip()
    clean_emp = (empresa_nombre or "").strip()
    pw_hash = hash_password(password)
    now_iso = datetime.now().isoformat()

    with get_connection() as conn:
        cursor = conn.cursor()
        # Verificar que no exista otro usuario distinto con ese mismo username
        cursor.execute("SELECT id, username, empresa_cif FROM usuarios WHERE LOWER(username) = LOWER(?);", (norm_user,))
        existing_row = cursor.fetchone()

        cursor.execute("SELECT id, username FROM usuarios WHERE LOWER(username) = 'admin' AND rol = 'ADMIN' ORDER BY id ASC LIMIT 1;")
        default_admin_row = cursor.fetchone()

        if existing_row:
            # Si el usuario ya existe, actualizar sus credenciales, nombre y vincular a la empresa sin error
            uid = existing_row["id"]
            cursor.execute(
                "UPDATE usuarios SET username = ?, password_hash = ?, nombre = ?, rol = 'ADMIN', activo = 1, empresa_cif = ?, empresa_nombre = ? WHERE id = ?;",
                (norm_user, pw_hash, clean_nombre, clean_cif, clean_emp, uid)
            )
        elif default_admin_row:
            # Reemplazar el placeholder 'admin' por el nuevo usuario Administrador elegido en el Wizard
            uid = default_admin_row["id"]
            cursor.execute("DELETE FROM registro_identidades_globales WHERE LOWER(username) = 'admin';")
            cursor.execute(
                "UPDATE usuarios SET username = ?, password_hash = ?, nombre = ?, rol = 'ADMIN', activo = 1, empresa_cif = ?, empresa_nombre = ? WHERE id = ?;",
                (norm_user, pw_hash, clean_nombre, clean_cif, clean_emp, uid)
            )
        else:
            cursor.execute(
                "INSERT INTO usuarios (username, password_hash, nombre, rol, activo, created_at, empresa_cif, empresa_nombre) VALUES (?, ?, ?, 'ADMIN', 1, ?, ?, ?);",
                (norm_user, pw_hash, clean_nombre, now_iso, clean_cif, clean_emp)
            )
            uid = cursor.lastrowid

        cursor.execute(
            "INSERT OR REPLACE INTO registro_identidades_globales (username, empresa_cif, empresa_nombre, created_at) VALUES (?, ?, ?, ?);",
            (norm_user, clean_cif, clean_emp, now_iso)
        )

        if clean_cif:
            cursor.execute("INSERT OR REPLACE INTO config (key, value) VALUES ('empresa_cif', ?);", (clean_cif,))
        if clean_emp:
            cursor.execute("INSERT OR REPLACE INTO config (key, value) VALUES ('empresa_nombre', ?);", (clean_emp,))

        conn.commit()
        cursor.execute("SELECT id, username, nombre, rol, activo, created_at, empresa_cif, empresa_nombre FROM usuarios WHERE id = ?;", (uid,))
        return dict(cursor.fetchone())


def delete_user(user_id: int, acting_user_id: int = None) -> bool:
    if acting_user_id is not None and int(user_id) == int(acting_user_id):
        raise ValueError("No puedes eliminar tu propio usuario con la sesión activa")
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, username, rol FROM usuarios WHERE id = ?;", (user_id,))
        target = cursor.fetchone()
        if not target:
            return False
        if target["rol"] == "ADMIN":
            cursor.execute("SELECT COUNT(*) FROM usuarios WHERE rol = 'ADMIN' AND activo = 1;")
            if cursor.fetchone()[0] <= 1:
                raise ValueError("No se puede eliminar el único Administrador activo del negocio")
        cursor.execute("DELETE FROM registro_identidades_globales WHERE LOWER(username) = LOWER(?);", (target["username"],))
        cursor.execute("DELETE FROM usuarios WHERE id = ?;", (user_id,))
        conn.commit()
        return cursor.rowcount > 0


def _enrich_user_company(user_dict: dict) -> dict:
    if not user_dict:
        return None
    if not user_dict.get("empresa_cif") or not user_dict.get("empresa_nombre"):
        cfg = get_config()
        if not user_dict.get("empresa_cif"):
            user_dict["empresa_cif"] = cfg.get("empresa_cif", "")
        if not user_dict.get("empresa_nombre"):
            user_dict["empresa_nombre"] = cfg.get("empresa_nombre", "")
    return user_dict


def get_user_by_username(username: str) -> dict:
    if not username:
        return None
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM usuarios WHERE LOWER(username) = LOWER(?);", (username.strip().lower(),))
        row = cursor.fetchone()
        return _enrich_user_company(dict(row)) if row else None


def get_user_by_id(user_id: int) -> dict:
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, username, nombre, rol, activo, created_at, empresa_cif, empresa_nombre FROM usuarios WHERE id = ?;", (user_id,))
        row = cursor.fetchone()
        return _enrich_user_company(dict(row)) if row else None


def list_users(empresa_cif: str = None) -> list:
    cfg = get_config()
    default_cif = cfg.get("empresa_cif", "")
    default_emp = cfg.get("empresa_nombre", "")
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, username, nombre, rol, activo, created_at, empresa_cif, empresa_nombre FROM usuarios ORDER BY id ASC;")
        users = []
        for r in cursor.fetchall():
            d = dict(r)
            if not d.get("empresa_cif"):
                d["empresa_cif"] = default_cif
            if not d.get("empresa_nombre"):
                d["empresa_nombre"] = default_emp
            if empresa_cif and d.get("empresa_cif") and d["empresa_cif"] != empresa_cif:
                continue
            users.append(d)
        return users


DUMMY_PASSWORD_HASH = hash_password("ofigremio-constant-time-dummy-shield-2026")


def verify_user_credentials(username: str, password: str) -> dict:
    if not password or len(password) > 128:
        return None
    user = get_user_by_username(username)
    if not user or not user.get("activo", 1):
        # Verificación señuelo en tiempo constante para evitar enumeración de usuarios por timing attack
        verify_password(password, DUMMY_PASSWORD_HASH)
        return None
    if verify_password(password, user["password_hash"]):
        return {
            "id": user["id"],
            "username": user["username"],
            "nombre": user["nombre"],
            "rol": user["rol"],
            "empresa_cif": user.get("empresa_cif", ""),
            "empresa_nombre": user.get("empresa_nombre", "")
        }
    return None


def change_user_password(user_id: int, current_password: str, new_password: str) -> bool:
    if not new_password or len(new_password.strip()) < 6 or len(new_password) > 128:
        raise ValueError("La nueva contraseña debe tener entre 6 y 128 caracteres")
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT password_hash FROM usuarios WHERE id = ? AND activo = 1;", (user_id,))
        row = cursor.fetchone()
        if not row:
            raise ValueError("Usuario no encontrado")
        if not verify_password(current_password or "", row["password_hash"]):
            raise ValueError("La contraseña actual no es correcta")
        new_hash = hash_password(new_password)
        cursor.execute("UPDATE usuarios SET password_hash = ? WHERE id = ?;", (new_hash, user_id))
        conn.commit()
        return True


AUTH_SECRET_KEY = os.environ.get("OFIGREMIO_SECRET_KEY", "ofigremio-secret-jwt-key-2026-v370")
MAX_ACTIVE_AUTH_SESSIONS = 5000
ACTIVE_AUTH_SESSIONS: dict[str, dict] = {}
REVOKED_AUTH_TOKENS: dict[str, int] = {}


def revoke_auth_token(token: str) -> bool:
    """Revoca inmediatamente un token de sesión activo (Logout seguro en servidor)."""
    if not token or not isinstance(token, str):
        return False
    token = token.strip()
    ACTIVE_AUTH_SESSIONS.pop(token, None)
    now_ts = int(datetime.now(timezone.utc).timestamp())
    if len(REVOKED_AUTH_TOKENS) > MAX_ACTIVE_AUTH_SESSIONS:
        # Purgar los más antiguos
        cutoff = now_ts - 86400 * 7
        expired = [k for k, ts in REVOKED_AUTH_TOKENS.items() if ts < cutoff]
        for k in expired:
            REVOKED_AUTH_TOKENS.pop(k, None)
    REVOKED_AUTH_TOKENS[token] = now_ts
    return True


def cleanup_expired_auth_sessions() -> int:
    """
    Purga sesiones expiradas de ACTIVE_AUTH_SESSIONS y asegura límite máximo (FIFO/LRU)
    para evitar fugas de memoria en entornos de producción prolongados.
    """
    now_ts = int(datetime.now(timezone.utc).timestamp())
    expired_keys = [t for t, sess in ACTIVE_AUTH_SESSIONS.items() if now_ts >= sess.get("expires_at", 0)]
    for t in expired_keys:
        ACTIVE_AUTH_SESSIONS.pop(t, None)

    if len(ACTIVE_AUTH_SESSIONS) > MAX_ACTIVE_AUTH_SESSIONS:
        sorted_sessions = sorted(
            ACTIVE_AUTH_SESSIONS.items(),
            key=lambda item: item[1].get("expires_at", 0),
            reverse=True
        )
        ACTIVE_AUTH_SESSIONS.clear()
        ACTIVE_AUTH_SESSIONS.update(dict(sorted_sessions[:MAX_ACTIVE_AUTH_SESSIONS]))

    return len(expired_keys)


def create_auth_token(user: dict, expires_in_seconds: int = 86400 * 7) -> str:
    """
    Genera un token de autenticación criptográficamente seguro (HMAC-SHA256 firmado con expiración)
    vinculado a la identidad única del usuario y a su empresa asociada (empresa_cif).
    """
    # Limpieza acotada periódica cuando la tabla supera un umbral prudente
    if len(ACTIVE_AUTH_SESSIONS) >= 100:
        cleanup_expired_auth_sessions()

    now_ts = int(datetime.now(timezone.utc).timestamp())
    exp_ts = now_ts + expires_in_seconds
    emp_cif = user.get("empresa_cif", "")
    emp_nom = user.get("empresa_nombre", "")
    raw_payload = {
        "uid": user["id"],
        "username": user["username"],
        "rol": user["rol"],
        "empresa_cif": emp_cif,
        "iat": now_ts,
        "exp": exp_ts,
        "nonce": secrets.token_hex(16)
    }
    encoded_payload = base64.urlsafe_b64encode(json.dumps(raw_payload, sort_keys=True).encode()).decode()
    signature = hmac.new(AUTH_SECRET_KEY.encode(), encoded_payload.encode(), hashlib.sha256).hexdigest()
    token = f"{encoded_payload}.{signature}"
    ACTIVE_AUTH_SESSIONS[token] = {
        "user_id": user["id"],
        "username": user["username"],
        "rol": user["rol"],
        "empresa_cif": emp_cif,
        "empresa_nombre": emp_nom,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "expires_at": exp_ts
    }
    return token


def verify_auth_token(token: str) -> dict | None:
    """
    Verifica la firma criptográfica y la vigencia del token de autenticación.
    Devuelve el perfil del usuario activo de la base de datos con su empresa asociada o None si es inválido.
    """
    if not token or not isinstance(token, str) or "." not in token:
        return None
    token = token.strip()
    if token in REVOKED_AUTH_TOKENS:
        return None
    try:
        encoded_payload, sig = token.split(".", 1)
        expected_sig = hmac.new(AUTH_SECRET_KEY.encode(), encoded_payload.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, expected_sig):
            return None
        payload_bytes = base64.urlsafe_b64decode(encoded_payload.encode())
        payload = json.loads(payload_bytes.decode())

        now_ts = int(datetime.now(timezone.utc).timestamp())
        if payload.get("exp") and now_ts > payload["exp"]:
            ACTIVE_AUTH_SESSIONS.pop(token, None)
            return None

        uid = payload.get("uid")
        if not uid:
            return None

        user = get_user_by_id(uid)
        if not user or not user.get("activo", 1):
            return None

        return {
            "id": user["id"],
            "username": user["username"],
            "nombre": user["nombre"],
            "rol": user["rol"],
            "empresa_cif": user.get("empresa_cif", ""),
            "empresa_nombre": user.get("empresa_nombre", "")
        }
    except Exception:
        return None


# =========================================================================
# AUDITORÍA DE SEGURIDAD Y DERECHOS DE PRIVACIDAD RGPD / LOPDGDD
# =========================================================================

def log_security_event(usuario: str, rol: str, accion: str, detalle: str = "", ip: str = ""):
    """Registra un evento en la tabla inmutable de auditoría de seguridad (Art. 32 RGPD)."""
    try:
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO auditoria_seguridad (fecha, usuario, rol, accion, detalle, ip)
                VALUES (?, ?, ?, ?, ?, ?);
            """, (
                now_str,
                str(usuario or "sistema")[:64],
                str(rol or "SYSTEM")[:32],
                str(accion or "EVENTO")[:64],
                str(detalle or "")[:500],
                str(ip or "")[:64]
            ))
            conn.commit()
    except Exception:
        pass


def list_security_audit_logs(limit: int = 80) -> List[Dict[str, Any]]:
    """Devuelve los eventos más recientes del registro de auditoría de seguridad."""
    safe_limit = max(1, min(int(limit or 80), 500))
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, fecha, usuario, rol, accion, detalle, ip
            FROM auditoria_seguridad
            ORDER BY id DESC
            LIMIT ?;
        """, (safe_limit,))
        return [dict(r) for r in cursor.fetchall()]


def export_client_gdpr_data(client_id: int) -> Dict[str, Any]:
    """
    Derecho de Acceso y Portabilidad (Art. 15 y 20 RGPD):
    Exporta en formato estructurado todos los datos personales, presupuestos y facturas de un cliente.
    """
    cli = get_client(client_id)
    if not cli:
        raise ValueError("Cliente no encontrado")
    cfg = get_config()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, numero, numero_factura, fecha, fecha_factura, concepto_averia,
                   base_imponible, total_iva, total_irpf, total_factura, anticipo_importe,
                   estado, es_rectificativa, huella_verifactu
            FROM presupuestos
            WHERE cliente_id = ?
            ORDER BY id DESC;
        """, (client_id,))
        docs = [dict(r) for r in cursor.fetchall()]

    return {
        "normativa": "RGPD (UE) 2016/679 Art. 15 y 20 / LOPDGDD 3/2018",
        "fecha_exportacion": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "responsable_tratamiento": {
            "empresa_nombre": cfg.get("empresa_nombre", ""),
            "empresa_cif": cfg.get("empresa_cif", ""),
            "empresa_email": cfg.get("empresa_email", ""),
            "empresa_direccion": cfg.get("empresa_direccion", "")
        },
        "datos_personales_cliente": cli,
        "documentos_vinculados": docs
    }


def anonymize_client_gdpr(client_id: int) -> Dict[str, Any]:
    """
    Derecho de Supresión / Olvido compatible con la Ley General Tributaria (Art. 17.3.b RGPD + Art. 66 LGT):
    - Si el cliente tiene facturas cobradas/emitidas, conserva exclusivamente el Nombre/Razón Social, NIF/CIF e importes
      exigidos por Hacienda durante el plazo de prescripción fiscal, pero purga de inmediato teléfono, email,
      notas comerciales, fotografías y firmas de presupuestos no facturados.
    - Si el cliente no tiene facturas cobradas, anonimiza también su nombre y limpia todos los datos de contacto y firmas.
    """
    cli = get_client(client_id)
    if not cli:
        raise ValueError("Cliente no encontrado")

    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT COUNT(*) FROM presupuestos
            WHERE cliente_id = ? AND (estado = 'COBRADO' OR (numero_factura IS NOT NULL AND numero_factura != ''));
        """, (client_id,))
        has_official_invoices = cursor.fetchone()[0] > 0

        if has_official_invoices:
            nota_rgpd = "[BLOQUEADO RGPD - DATOS DE CONTACTO ELIMINADOS / CONSERVACIÓN FISCAL OBLIGATORIA LGT]"
            cursor.execute("""
                UPDATE clientes
                SET telefono = '000000000',
                    email = '',
                    notas = ?
                WHERE id = ?;
            """, (nota_rgpd, client_id))
            cursor.execute("""
                UPDATE presupuestos
                SET firma_base64 = '', foto_base64 = '', notas_tecnicas = ''
                WHERE cliente_id = ? AND estado != 'COBRADO';
            """, (client_id,))
            mode = "fiscal_retention_anonymized"
        else:
            nota_rgpd = "[ANONIMIZADO RGPD - DERECHO DE SUPRESIÓN]"
            cursor.execute("""
                UPDATE clientes
                SET nombre = ?,
                    telefono = '000000000',
                    email = '',
                    direccion = '',
                    poblacion = '',
                    notas = ?
                WHERE id = ?;
            """, (f"Cliente Anonimizado #{client_id}", nota_rgpd, client_id))
            cursor.execute("""
                UPDATE presupuestos
                SET firma_base64 = '', foto_base64 = '', notas_tecnicas = ''
                WHERE cliente_id = ?;
            """, (client_id,))
            mode = "full_anonymized"

        conn.commit()

    return {
        "client_id": client_id,
        "mode": mode,
        "has_official_invoices": has_official_invoices,
        "client": get_client(client_id)
    }
