#!/usr/bin/env bash
# =========================================================================
# OfiGremio PRO v4.2.1 — Instalador Automatizado para Linux (Solo 1a Vez)
# Configura Python 3, entorno virtual aislado, dependencias y acceso directo.
# =========================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "========================================================================="
echo "   OfiGremio PRO — Instalador para Linux (Solo la Primera Vez)"
echo "   Software Local-First para Instaladores, Gremios y Reformas"
echo "========================================================================="
echo ""

# 1. Comprobar Python 3
echo "[1/4] Comprobando entorno de ejecución Python 3..."
if ! command -v python3 &>/dev/null; then
    echo "[ERROR] Python 3 no está instalado en el sistema."
    echo "Instálelo en su terminal mediante:"
    echo "  sudo apt install python3 python3-venv python3-pip   (Ubuntu / Debian / Mint)"
    echo "  sudo dnf install python3 python3-pip               (Fedora / RHEL)"
    echo "  sudo pacman -S python python-pip                   (Arch Linux / Manjaro)"
    exit 1
fi
echo "[OK] Python 3 detectado: $(python3 --version)"

# 2. Comprobar / Crear entorno virtual .venv
echo ""
echo "[2/4] Configurando Entorno Virtual Aislado (.venv)..."
if [ ! -d ".venv" ]; then
    python3 -m venv .venv || {
        echo "[ERROR] No se pudo crear el entorno virtual aislado."
        echo "Asegúrese de tener instalado el soporte venv (ej: sudo apt install python3-venv)."
        exit 1
    }
    echo "[OK] Entorno virtual privado creado con éxito."
else
    echo "[OK] Entorno virtual existente detectado."
fi

# 3. Instalar dependencias oficiales en el entorno virtual
echo ""
echo "[3/4] Instalando dependencias oficiales (FastAPI, ReportLab, etc.)..."
.venv/bin/python -m pip install --upgrade pip --quiet
.venv/bin/python -m pip install -r requirements.txt --quiet
echo "[OK] Todas las dependencias han quedado instaladas y verificadas."

# 4. Crear acceso directo en el Escritorio (Desktop Entry)
echo ""
echo "[4/4] Creando lanzador de escritorio..."
DESKTOP_DIR="$HOME/Desktop"
[ ! -d "$DESKTOP_DIR" ] && DESKTOP_DIR="$HOME/Escritorio"

DESKTOP_FILE="OfiGremio.desktop"
cat <<EOF > "$DESKTOP_FILE"
[Desktop Entry]
Version=1.0
Type=Application
Name=OfiGremio PRO
Comment=Gestión Integral para Gremios, Presupuestos y Facturación
Exec=bash "$SCRIPT_DIR/2_abrir_ofigremio.sh"
Icon=$SCRIPT_DIR/static/icon-192.png
Terminal=false
Categories=Office;Finance;
StartupNotify=true
EOF

chmod +x "$DESKTOP_FILE"
chmod +x "2_abrir_ofigremio.sh"

if [ -d "$DESKTOP_DIR" ]; then
    cp "$DESKTOP_FILE" "$DESKTOP_DIR/"
    chmod +x "$DESKTOP_DIR/$DESKTOP_FILE"
    echo "[OK] Acceso directo 'OfiGremio PRO' creado con éxito en: $DESKTOP_DIR"
fi

echo ""
echo "========================================================================="
echo "   [INSTALACIÓN COMPLETADA CON ÉXITO]"
echo "   OfiGremio PRO está 100% configurado y listo para usar en este equipo."
echo "========================================================================="
echo ""
read -p "Presione Enter para iniciar OfiGremio PRO ahora mismo..." dummy
bash "$SCRIPT_DIR/2_abrir_ofigremio.sh"

