"""

Servidor Backend FastAPI Local-First para OfiGremio Pro v2.0.

Consumo ultra-bajo de memoria (<40 MB RAM), respuesta instantánea (<15 ms).

"""



import os

import sys



# Forzar codificacion UTF-8 en stdout/stderr para Windows

if hasattr(sys.stdout, 'reconfigure'):

    try:

        sys.stdout.reconfigure(encoding='utf-8', errors='replace')

    except Exception:

        pass

if hasattr(sys.stderr, 'reconfigure'):

    try:

        sys.stderr.reconfigure(encoding='utf-8', errors='replace')

    except Exception:

        pass

import re
import json

from datetime import datetime

import urllib.parse

import shutil

from fastapi import FastAPI, HTTPException, Request, Response, Depends

from fastapi.staticfiles import StaticFiles

from fastapi.responses import FileResponse, JSONResponse

from pydantic import BaseModel, Field

from typing import List, Optional

import ipaddress



import database as db

from local_assistant import OfiGremioLocalAssistant



local_ai_assistant = OfiGremioLocalAssistant()

import wizard_backend_bridge

import pdf_engine

import license_manager



# Inicializar Base de Datos SQLite al arrancar y crear punto de respaldo automático

db.init_db()

try:

    db.ensure_auto_backup(reason="startup")

except Exception:

    pass



app = FastAPI(title="OfiGremio Express API", version="3.7.0")



# -------------------------------------------------------------

# Middleware Defensivo: Cabeceras de Seguridad y Control Anti-CSRF

# -------------------------------------------------------------

def is_allowed_origin(hostname: str | None, host_header: str | None) -> bool:

    if not hostname:

        return False

    hostname_lower = hostname.lower()

    if hostname_lower in ("127.0.0.1", "localhost", "testserver"):

        return True

    if host_header:

        expected_host = host_header.split(":")[0].lower()

        if hostname_lower == expected_host:

            return True

    try:

        ip = ipaddress.ip_address(hostname_lower)

        if ip.is_private or ip.is_loopback:

            return True

    except ValueError:

        pass

    return False





@app.middleware("http")

async def security_defense_middleware(request: Request, call_next):

    # 1. Mitigación Anti-CSRF para métodos de mutación

    if request.method in ("POST", "PUT", "DELETE", "PATCH"):

        origin = request.headers.get("origin")

        referer = request.headers.get("referer")

        host_header = request.headers.get("host")

        for h_val in (origin, referer):

            if h_val:

                parsed = urllib.parse.urlparse(h_val)

                if not is_allowed_origin(parsed.hostname, host_header):

                    return JSONResponse(

                        status_code=403,

                        content={"detail": "Origen no autorizado (Protección Anti-CSRF activa)"}

                    )



    response = await call_next(request)



    # 2. Inyección de Cabeceras Defensivas HTTP (OWASP Top 10)

    response.headers["Content-Security-Policy"] = (

        "default-src 'self'; "

        "script-src 'self' 'unsafe-inline'; "

        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "

        "font-src 'self' https://fonts.gstatic.com data:; "

        "img-src 'self' data:; "

        "connect-src 'self';"

    )

    if request.url.path in ("/", "/sw.js") or request.url.path.endswith((".html", ".js", ".css")):

        response.headers["Cache-Control"] = "no-cache, must-revalidate"

    response.headers["X-Content-Type-Options"] = "nosniff"

    response.headers["X-Frame-Options"] = "SAMEORIGIN"

    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"

    response.headers["Permissions-Policy"] = "geolocation=(), microphone=self, camera=self"

    if "server" in response.headers:

        del response.headers["server"]



    return response





# -------------------------------------------------------------

# Autenticación y Control de Acceso Basado en Roles (RBAC)

# -------------------------------------------------------------

def get_current_user(request: Request) -> dict:

    auth_header = request.headers.get("authorization")



    # 1. Cabecera Authorization: Bearer <token>

    if auth_header is not None:

        auth_str = auth_header.strip()

        if not auth_str:

            raise HTTPException(status_code=401, detail="No autenticado")

        if auth_str.lower().startswith("bearer "):

            token = auth_str[7:].strip()

        else:

            token = auth_str

        user = db.verify_auth_token(token)

        if not user:

            raise HTTPException(status_code=401, detail="Token de autorización inválido o expirado")

        return user



    # 2. Cookie de sesión HttpOnly

    cookie_token = request.cookies.get("session_token")

    if cookie_token:

        user = db.verify_auth_token(cookie_token)

        if user:

            return user



    # 3. Cabecera personalizada de sesión

    x_token = request.headers.get("x-auth-token") or request.headers.get("x-session-token")

    if x_token:

        user = db.verify_auth_token(x_token)

        if user:

            return user

        raise HTTPException(status_code=401, detail="Token de autorización inválido o expirado")



    # 4. Solicitud sin credenciales válidas

    raise HTTPException(status_code=401, detail="No autenticado")





def require_admin(user: dict = Depends(get_current_user)) -> dict:

    if user.get("rol") != "ADMIN":

        raise HTTPException(

            status_code=403,

            detail="Acceso denegado: se requieren permisos de Administrador"

        )

    return user





def require_user(user: dict = Depends(get_current_user)) -> dict:

    return user





@app.post("/api/wizard/complete")

def complete_wizard_route(data: wizard_backend_bridge.WizardCompleteModel, request: Request, response: Response):

    cfg = db.get_config()

    is_pending = str(cfg.get("primera_configuracion_pendiente", "0")) == "1"

    if not (is_pending and data.admin_username and data.admin_password):

        user = get_current_user(request)

        if user.get("rol") != "ADMIN":

            raise HTTPException(status_code=403, detail="Acceso denegado: se requieren permisos de Administrador")

    res = wizard_backend_bridge.complete_wizard(data)

    if res.get("token"):

        response.set_cookie(

            key="session_token",

            value=res["token"],

            httponly=True,

            samesite="lax",

            path="/"

        )

    return res



app.include_router(wizard_backend_bridge.router)



BASE_DIR = os.path.dirname(os.path.abspath(__file__))

STATIC_DIR = os.path.join(BASE_DIR, "static")

DATA_DIR = os.path.join(BASE_DIR, "data")





# Modelos Pydantic



class BootstrapAdminRequest(BaseModel):

    username: str = Field(..., min_length=3, max_length=64)

    password: str = Field(..., min_length=6, max_length=128)

    nombre: Optional[str] = "Administrador Principal"

    empresa_nombre: Optional[str] = ""

    empresa_cif: Optional[str] = ""





class LoginRequest(BaseModel):

    username: str = Field(..., min_length=1, max_length=64)

    password: str = Field(..., min_length=1, max_length=128)





class PasswordChangeRequest(BaseModel):

    current_password: str = Field(..., min_length=1, max_length=128)

    new_password: str = Field(..., min_length=6, max_length=128)





class UserCreateRequest(BaseModel):

    username: str = Field(..., min_length=1, max_length=64)

    password: str = Field(..., min_length=4, max_length=128)

    nombre: str = Field(..., min_length=1, max_length=120)

    rol: Optional[str] = "TECNICO"



class ClientModel(BaseModel):

    nombre: str

    telefono: Optional[str] = ""

    email: Optional[str] = ""

    direccion: Optional[str] = ""

    poblacion: Optional[str] = ""

    notas: Optional[str] = ""

    nif_cif: Optional[str] = ""





class ClientUpdateModel(BaseModel):

    nombre: Optional[str] = None

    telefono: Optional[str] = None

    email: Optional[str] = None

    direccion: Optional[str] = None

    poblacion: Optional[str] = None

    notas: Optional[str] = None

    nif_cif: Optional[str] = None







class AssistantChatModel(BaseModel):

    message: str = Field(..., min_length=1, max_length=1000)

    context: Optional[dict] = None





class AssistantMemoryModel(BaseModel):

    key: str

    value: str

    category: Optional[str] = "general"



class ItemModel(BaseModel):

    tipo: Optional[str] = "MATERIAL"

    descripcion: Optional[str] = "Material"

    cantidad: Optional[float] = 1.0

    precio_unitario: Optional[float] = 0.0

    catalogo_id: Optional[int] = None





class QuoteCreateModel(BaseModel):

    cliente_id: int

    concepto_averia: str

    es_urgencia: Optional[bool] = False

    recargo_urgencia: Optional[float] = 0.0

    horas_mano_obra: Optional[float] = 1.0

    precio_hora: Optional[float] = 38.0

    descuento_porcentaje: Optional[float] = 0.0

    iva_porcentaje: Optional[float] = 0.21

    irpf_porcentaje: Optional[float] = 0.0

    anticipo_importe: Optional[float] = 0.0

    garantia_meses: Optional[int] = 6

    notas_tecnicas: Optional[str] = ""

    firma_base64: Optional[str] = ""

    foto_base64: Optional[str] = ""

    items: Optional[List[ItemModel]] = []

    partidas: Optional[List[ItemModel]] = []





class QuoteUpdateModel(BaseModel):

    cliente_id: Optional[int] = None

    concepto_averia: Optional[str] = None

    es_urgencia: Optional[bool] = None

    recargo_urgencia: Optional[float] = None

    horas_mano_obra: Optional[float] = None

    precio_hora: Optional[float] = None

    descuento_porcentaje: Optional[float] = None

    iva_porcentaje: Optional[float] = None

    irpf_porcentaje: Optional[float] = None

    anticipo_importe: Optional[float] = None

    garantia_meses: Optional[int] = None

    notas_tecnicas: Optional[str] = None

    firma_base64: Optional[str] = None

    foto_base64: Optional[str] = None

    items: Optional[List[ItemModel]] = None





class StatusUpdateModel(BaseModel):

    estado: str





class QuoteAdvanceModel(BaseModel):

    anticipo_importe: float = Field(..., ge=0.0)





class QuoteRectifyModel(BaseModel):

    motivo: Optional[str] = "Rectificación contable / Abono de factura"





class SendEmailModel(BaseModel):

    to_email: Optional[str] = None

    email_destino: Optional[str] = None





class RestoreBackupModel(BaseModel):

    filename: str





class SignatureModel(BaseModel):

    firma_base64: str

    aprobar: Optional[bool] = True





class LicenseActivationRequest(BaseModel):

    key: str



class CatalogItemModel(BaseModel):

    gremio: str

    tipo: Optional[str] = "MATERIAL"

    descripcion: str

    cantidad_default: Optional[float] = 1.0

    precio_unitario: float

    stock_actual: Optional[float] = 0.0

    stock_minimo_alerta: Optional[float] = 5.0

    precio_coste: Optional[float] = 0.0

    proveedor_id: Optional[int] = None

    controla_stock: Optional[int] = 1





class SupplierModel(BaseModel):

    nombre: str

    cif: Optional[str] = None

    cif_nif: Optional[str] = None

    telefono: Optional[str] = ""

    email: Optional[str] = ""

    contacto: Optional[str] = ""

    direccion: Optional[str] = ""

    poblacion: Optional[str] = ""

    notas: Optional[str] = ""





class SupplierUpdateModel(BaseModel):

    nombre: Optional[str] = None

    cif: Optional[str] = None

    cif_nif: Optional[str] = None

    telefono: Optional[str] = None

    email: Optional[str] = None

    contacto: Optional[str] = None

    direccion: Optional[str] = None

    poblacion: Optional[str] = None

    notas: Optional[str] = None





class ExpenseItemModel(BaseModel):

    catalogo_id: Optional[int] = None

    descripcion: Optional[str] = ""

    cantidad: float = 1.0

    precio_coste: Optional[float] = 0.0

    precio_coste_unitario: Optional[float] = None





class ExpenseCreateModel(BaseModel):

    numero_factura: str

    proveedor_id: Optional[int] = None

    fecha: Optional[str] = None

    concepto: str

    base_imponible: float

    iva_porcentaje: Optional[float] = 0.21

    forma_pago: Optional[str] = "TRANSFERENCIA"

    estado: Optional[str] = "PAGADO"

    notas: Optional[str] = ""

    items: Optional[List[ExpenseItemModel]] = []





class StockAdjustModel(BaseModel):

    catalogo_id: int

    cantidad_cambio: float

    motivo: Optional[str] = "Ajuste manual"





def _get_client_ip(request: Request) -> str:

    if not request or not request.client:

        return "127.0.0.1"

    return str(request.client.host or "127.0.0.1")





def _validate_base64_image(data_uri: Optional[str], field_name: str = "imagen"):

    """

    Prevención de inyección de URIs arbitrarios y denegación de servicio por tamaño (CWE-400 / CWE-434):

    Valida que el payload Base64 sea una imagen raster válida (png, jpeg, jpg, webp) y <= 3.5M chars (~2.5 MB).

    """

    if not data_uri:

        return

    val = str(data_uri).strip()

    if not val:

        return

    if len(val) > 3_500_000:

        raise HTTPException(status_code=400, detail=f"El campo {field_name} supera el tamaño máximo permitido (2.5 MB)")

    if not re.match(r"^data:image/(png|jpeg|jpg|webp);base64,[A-Za-z0-9+/=\s]+$", val, re.IGNORECASE):

        raise HTTPException(status_code=400, detail=f"Formato de {field_name} no válido. Debe ser una imagen PNG, JPEG o WEBP en Base64.")





def _mask_config_secrets(cfg: dict, user: dict) -> dict:

    """Enmascara secretos sensibles (como contraseñas SMTP) antes de enviarlos al cliente."""

    safe_cfg = dict(cfg or {})

    has_smtp_pw = bool((safe_cfg.get("smtp_password") or safe_cfg.get("smtp_pass") or "").strip())

    safe_cfg["smtp_password_configured"] = "1" if has_smtp_pw else "0"

    if user and user.get("rol") == "TECNICO":

        for secret_k in ("smtp_password", "smtp_pass", "smtp_user", "smtp_host", "smtp_port"):

            safe_cfg.pop(secret_k, None)

    else:

        masked_val = "********" if has_smtp_pw else ""

        safe_cfg["smtp_password"] = masked_val

        safe_cfg["smtp_pass"] = masked_val

    return safe_cfg





# Endpoints API

@app.get("/api/health")

def health():

    return {"status": "ok", "app": "OfiGremio Express", "version": "4.1.0"}





@app.get("/api/config")

def get_config(user: dict = Depends(require_user)):

    return _mask_config_secrets(db.get_config(), user)





@app.put("/api/config")

@app.post("/api/config")

def update_config(config_data: dict, request: Request, user: dict = Depends(require_admin)):

    updated = db.update_config(config_data)

    db.log_security_event(

        usuario=user.get("username", "admin"),

        rol=user.get("rol", "ADMIN"),

        accion="CONFIG_UPDATE",

        detalle="Actualización de configuración fiscal/SMTP",

        ip=_get_client_ip(request)

    )

    return _mask_config_secrets(updated, user)





@app.get("/api/clients")

def list_clients(q: Optional[str] = None, user: dict = Depends(require_user)):

    return db.list_clients(search=q)





@app.post("/api/clients")

def create_client(client: ClientModel, user: dict = Depends(require_user)):

    cid = db.create_client(

        nombre=client.nombre,

        telefono=client.telefono,

        email=client.email,

        direccion=client.direccion,

        poblacion=client.poblacion,

        notas=client.notas,

        nif_cif=client.nif_cif

    )

    return db.get_client(cid)





@app.put("/api/clients/{client_id}")

def update_client(client_id: int, client: ClientUpdateModel, user: dict = Depends(require_user)):

    payload = {k: v for k, v in client.model_dump().items() if v is not None}

    updated = db.update_client(client_id, payload)

    if not updated:

        raise HTTPException(status_code=404, detail="Cliente no encontrado")

    return updated





@app.delete("/api/clients/{client_id}")

def delete_client(client_id: int, user: dict = Depends(require_admin)):

    client = db.get_client(client_id)

    if not client:

        raise HTTPException(status_code=404, detail="Cliente no encontrado")

    try:

        deleted = db.delete_client(client_id)

        if not deleted:

            raise HTTPException(status_code=404, detail="Cliente no encontrado")

        return {"status": "deleted", "id": client_id}

    except ValueError as e:

        raise HTTPException(status_code=400, detail=str(e))





@app.get("/api/clients/{client_id}/gdpr-export")

def export_client_gdpr(client_id: int, request: Request, user: dict = Depends(require_admin)):

    try:

        data = db.export_client_gdpr_data(client_id)

        db.log_security_event(

            usuario=user.get("username", "admin"),

            rol=user.get("rol", "ADMIN"),

            accion="GDPR_EXPORT",

            detalle=f"Exportación de portabilidad RGPD para cliente ID {client_id}",

            ip=_get_client_ip(request)

        )

        return data

    except ValueError as e:

        raise HTTPException(status_code=404, detail=str(e))





@app.post("/api/clients/{client_id}/gdpr-anonymize")

def anonymize_client_gdpr(client_id: int, request: Request, user: dict = Depends(require_admin)):

    try:

        res = db.anonymize_client_gdpr(client_id)

        db.log_security_event(

            usuario=user.get("username", "admin"),

            rol=user.get("rol", "ADMIN"),

            accion="GDPR_ANONYMIZE",

            detalle=f"Anonimización RGPD cliente ID {client_id} (modo: {res.get('mode')})",

            ip=_get_client_ip(request)

        )

        return res

    except ValueError as e:

        raise HTTPException(status_code=404, detail=str(e))





@app.get("/api/security/audit-log")

def get_security_audit_log(limit: int = 80, user: dict = Depends(require_admin)):

    return {"logs": db.list_security_audit_logs(limit=limit)}





@app.get("/api/catalog")

def list_catalog(gremio: Optional[str] = None, user: dict = Depends(require_user)):

    return db.list_catalog(gremio=gremio)





@app.post("/api/catalog")

def create_catalog_item(item: CatalogItemModel, user: dict = Depends(require_user)):

    return db.create_catalog_item(item.model_dump())





@app.delete("/api/catalog/{item_id}")

def delete_catalog_item(item_id: int, user: dict = Depends(require_admin)):

    db.delete_catalog_item(item_id)

    return {"status": "deleted", "id": item_id}





@app.get("/api/analytics")

def get_analytics(user: dict = Depends(require_admin)):

    return db.get_analytics_summary()





@app.get("/api/quotes")

def list_quotes(user: dict = Depends(require_user)):

    return db.list_quotes()





@app.post("/api/quotes")

def create_quote(quote: QuoteCreateModel, user: dict = Depends(require_user)):

    _validate_base64_image(quote.firma_base64, "firma_base64")

    _validate_base64_image(quote.foto_base64, "foto_base64")

    data = quote.model_dump()

    created = db.create_quote(data)



    # Generar automáticamente el PDF del presupuesto

    cfg = db.get_config()

    pdf_path = pdf_engine.generate_quote_pdf(created, cfg)



    # Actualizar ruta de PDF en BD

    with db.get_connection() as conn:

        conn.cursor().execute("UPDATE presupuestos SET pdf_path = ? WHERE id = ?;", (pdf_path, created["id"]))

        conn.commit()



    return db.get_quote(created["id"])





@app.get("/api/quotes/{quote_id}")

def get_quote(quote_id: int, user: dict = Depends(require_user)):

    q = db.get_quote(quote_id)

    if not q:

        raise HTTPException(status_code=404, detail="Presupuesto no encontrado")

    return q





@app.put("/api/quotes/{quote_id}")

def update_quote(quote_id: int, quote: QuoteUpdateModel, user: dict = Depends(require_user)):

    _validate_base64_image(quote.firma_base64, "firma_base64")

    _validate_base64_image(quote.foto_base64, "foto_base64")

    payload = {k: v for k, v in quote.model_dump().items() if v is not None}

    updated = db.update_quote(quote_id, payload)

    if not updated:

        raise HTTPException(status_code=404, detail="Presupuesto no encontrado")



    cfg = db.get_config()

    pdf_path = pdf_engine.generate_quote_pdf(updated, cfg)

    with db.get_connection() as conn:

        conn.cursor().execute("UPDATE presupuestos SET pdf_path = ? WHERE id = ?;", (pdf_path, quote_id))

        conn.commit()



    return db.get_quote(quote_id)





@app.delete("/api/quotes/{quote_id}")

def delete_quote(quote_id: int, user: dict = Depends(require_admin)):

    try:

        deleted = db.delete_quote(quote_id)

        if not deleted:

            raise HTTPException(status_code=404, detail="Presupuesto no encontrado")

        return {"status": "deleted", "id": quote_id}

    except ValueError as e:

        raise HTTPException(status_code=400, detail=str(e))





@app.post("/api/quotes/{quote_id}/duplicate")

def duplicate_quote(quote_id: int, user: dict = Depends(require_user)):

    duplicated = db.duplicate_quote(quote_id)

    if not duplicated:

        raise HTTPException(status_code=404, detail="Presupuesto no encontrado")



    cfg = db.get_config()

    pdf_path = pdf_engine.generate_quote_pdf(duplicated, cfg)

    with db.get_connection() as conn:

        conn.cursor().execute("UPDATE presupuestos SET pdf_path = ? WHERE id = ?;", (pdf_path, duplicated["id"]))

        conn.commit()



    return db.get_quote(duplicated["id"])





@app.post("/api/quotes/{quote_id}/signature")

def save_signature(quote_id: int, sig: SignatureModel, user: dict = Depends(require_user)):

    _validate_base64_image(sig.firma_base64, "firma_base64")

    updated = db.save_quote_signature(quote_id, sig.firma_base64, aprobar=bool(sig.aprobar))

    if not updated:

        raise HTTPException(status_code=404, detail="Presupuesto no encontrado")



    cfg = db.get_config()

    pdf_path = pdf_engine.generate_quote_pdf(updated, cfg)

    with db.get_connection() as conn:

        conn.cursor().execute("UPDATE presupuestos SET pdf_path = ? WHERE id = ?;", (pdf_path, quote_id))

        conn.commit()



    return db.get_quote(quote_id)





@app.patch("/api/quotes/{quote_id}/status")

@app.put("/api/quotes/{quote_id}/status")

def update_status(quote_id: int, status_update: StatusUpdateModel, user: dict = Depends(require_user)):

    try:

        updated = db.update_quote_status(quote_id, status_update.estado)

        if not updated:

            raise HTTPException(status_code=404, detail="Presupuesto no encontrado")

        # Descuento de stock automatico si pasa a APROBADO o COBRADO

        if status_update.estado.upper() in ("APROBADO", "EN_PROCESO", "COBRADO"):

            try:

                db.deduct_quote_stock(quote_id)

            except Exception as ex:

                print(f"[Stock] Warning deduciendo stock: {ex}")



        # Regenerar PDF (si pasa a COBRADO se emite como FACTURA OFICIAL con FAC-YYYY-XXXX)

        cfg = db.get_config()

        pdf_engine.generate_quote_pdf(updated, cfg)

        return updated

    except ValueError as e:

        raise HTTPException(status_code=400, detail=str(e))





@app.post("/api/quotes/{quote_id}/advance")

def update_quote_advance(quote_id: int, payload: QuoteAdvanceModel, user: dict = Depends(require_user)):

    updated = db.record_quote_advance(quote_id, payload.anticipo_importe)

    if not updated:

        raise HTTPException(status_code=404, detail="Presupuesto no encontrado")

    cfg = db.get_config()

    pdf_path = pdf_engine.generate_quote_pdf(updated, cfg)

    with db.get_connection() as conn:

        conn.cursor().execute("UPDATE presupuestos SET pdf_path = ? WHERE id = ?;", (pdf_path, quote_id))

        conn.commit()

    return db.get_quote(quote_id)





@app.post("/api/quotes/{quote_id}/rectify")

def rectify_paid_invoice(quote_id: int, payload: QuoteRectifyModel, request: Request, user: dict = Depends(require_admin)):

    try:

        rectified = db.create_rectifying_invoice(quote_id, motivo=payload.motivo or "Rectificación contable / Abono de factura")

        cfg = db.get_config()

        pdf_path = pdf_engine.generate_quote_pdf(rectified, cfg)

        with db.get_connection() as conn:

            conn.cursor().execute("UPDATE presupuestos SET pdf_path = ? WHERE id = ?;", (pdf_path, rectified["id"]))

            conn.commit()

        db.log_security_event(

            usuario=user.get("username", "admin"),

            rol=user.get("rol", "ADMIN"),

            accion="INVOICE_RECTIFIED",

            detalle=f"Emitida factura rectificativa {rectified.get('numero_factura')} sobre ID {quote_id}",

            ip=_get_client_ip(request)

        )

        return db.get_quote(rectified["id"])

    except ValueError as e:

        raise HTTPException(status_code=400, detail=str(e))





@app.get("/api/quotes/{quote_id}/pdf")

def download_pdf(quote_id: int, user: dict = Depends(require_user)):

    q = db.get_quote(quote_id)

    if not q:

        raise HTTPException(status_code=404, detail="Presupuesto no encontrado")



    cfg = db.get_config()

    pdf_path = pdf_engine.generate_quote_pdf(q, cfg)



    safe_path = os.path.abspath(pdf_path)

    if not safe_path.startswith(os.path.abspath(pdf_engine.PDF_DIR)):

        raise HTTPException(status_code=403, detail="Ruta de PDF no autorizada")



    raw_doc_num = q.get("numero_factura") if q.get("estado") == "COBRADO" and q.get("numero_factura") else q.get("numero", "presupuesto")

    safe_filename = f"{re.sub(r'[^A-Za-z0-9_\-]', '_', str(raw_doc_num))}.pdf"

    return FileResponse(safe_path, media_type="application/pdf", filename=safe_filename)





@app.get("/api/quotes/{quote_id}/whatsapp")

def get_whatsapp_url(quote_id: int, user: dict = Depends(require_user)):

    """

    Genera el enlace directo para enviar el presupuesto o factura oficial por WhatsApp en un clic.

    """

    q = db.get_quote(quote_id)

    if not q:

        raise HTTPException(status_code=404, detail="Presupuesto no encontrado")



    cfg = db.get_config()

    cliente = q.get("cliente_nombre", "Estimado cliente")

    numero = q.get("numero", "PRE-0000")

    numero_factura = q.get("numero_factura")

    estado = (q.get("estado") or "BORRADOR").upper()

    total = float(q.get("total_factura") or 0.0)

    anticipo = float(q.get("anticipo_importe") or 0.0)

    pendiente = float(q.get("pendiente_cobro") if q.get("pendiente_cobro") is not None else max(0.0, total - anticipo))

    total_desc = float(q.get("total_descuento") or 0.0)

    total_irpf = float(q.get("total_irpf") or 0.0)

    concepto = q.get("concepto_averia", "Reparación")

    empresa = cfg.get("empresa_nombre", "Servicio Técnico")

    raw_tel = re.sub(r'\D', '', str(q.get("cliente_telefono") or ""))

    if len(raw_tel) == 9 and raw_tel[0] in ('6', '7', '8', '9'):

        telefono = f"34{raw_tel}"

    else:

        telefono = raw_tel



    desglose_extra = ""

    if total_desc > 0:

        desglose_extra += f"🏷️ *Descuento aplicado:* -{total_desc:.2f} €\n"

    if total_irpf > 0:

        desglose_extra += f"📑 *Retención IRPF:* -{total_irpf:.2f} €\n"

    if anticipo > 0 and estado != "COBRADO":

        desglose_extra += f"💶 *Anticipo entregado:* -{anticipo:.2f} €\n"

        desglose_extra += f"⏳ *Pendiente de abonar:* {pendiente:.2f} €\n"



    if estado == "COBRADO" and numero_factura:

        doc_label = "FACTURA RECTIFICATIVA" if q.get("es_rectificativa") else "FACTURA OFICIAL"

        mensaje = (

            f"Hola {cliente}, le saluda {empresa}.\n\n"

            f"Le adjuntamos su *{doc_label} {numero_factura}* (Ref. {numero}) correspondiente a:\n"

            f"🔧 _{concepto}_\n\n"

            f"{desglose_extra}"

            f"✅ *Importe total:* {total:.2f} €\n"

            f"Muchas gracias por su confianza."

        )

    else:

        mensaje = (

            f"Hola {cliente}, le saluda {empresa}.\n\n"

            f"Le enviamos el presupuesto *{numero}* correspondiente a la intervención de:\n"

            f"🔧 _{concepto}_\n\n"

            f"{desglose_extra}"

            f"💵 *Total presupuesto (impuestos incluidos):* {total:.2f} €\n"

            f"Puede solicitar su documento en PDF o confirmar la intervención respondiendo a este mensaje.\n\n"

            f"Muchas gracias por su confianza."

        )



    encoded_msg = urllib.parse.quote(mensaje)

    whatsapp_url = f"https://wa.me/{telefono}?text={encoded_msg}" if telefono else f"https://wa.me/?text={encoded_msg}"



    return {

        "status": "success",

        "whatsapp_url": whatsapp_url,

        "preformatted_message": mensaje

    }





@app.get("/api/backup/download")

def download_backup_database(user: dict = Depends(require_admin)):

    """Descarga una copia de seguridad directa, atómica y segura de SQLite."""

    try:

        backup_path = db.create_backup_copy()

        safe_path = os.path.abspath(backup_path)

        # Validación defensiva path traversal

        if not safe_path.startswith(os.path.abspath(DATA_DIR)):

            raise HTTPException(status_code=403, detail="Acceso denegado a ruta no autorizada")

        filename = os.path.basename(safe_path)

        return FileResponse(

            safe_path,

            media_type="application/x-sqlite3",

            filename=filename,

            headers={"Cache-Control": "no-store, no-cache"}

        )

    except HTTPException:

        raise

    except Exception as e:

        raise HTTPException(status_code=500, detail=f"Error al generar copia de seguridad: {str(e)}")





@app.get("/api/backup/list")

def list_database_backups(user: dict = Depends(require_admin)):

    """Lista las copias de seguridad automáticas y el estado de integridad de SQLite."""

    return db.list_backups()





@app.post("/api/backup/create")

def create_manual_backup_point(user: dict = Depends(require_admin)):

    """Crea un nuevo punto de restauración atómico en el servidor."""

    try:

        path = db.ensure_auto_backup(reason="manual")

        return {

            "status": "success",

            "filename": os.path.basename(path),

            "summary": db.list_backups()

        }

    except Exception as e:

        raise HTTPException(status_code=500, detail=f"Error al crear copia de seguridad: {str(e)}")





@app.post("/api/backup/restore")

def restore_database_backup(payload: RestoreBackupModel, user: dict = Depends(require_admin)):

    """Restaura una copia de seguridad verificando antes su integridad y creando resguardo previo."""

    try:

        res = db.restore_backup_from_file(payload.filename)

        return res

    except ValueError as e:

        raise HTTPException(status_code=400, detail=str(e))

    except Exception as e:

        raise HTTPException(status_code=500, detail=f"Error al restaurar copia de seguridad: {str(e)}")







@app.get("/api/export/sales-excel")

def export_sales_excel(user: dict = Depends(require_admin)):

    excel_path = db.export_sales_to_excel("data/export_facturas_clientes.xlsx")

    return FileResponse(

        excel_path,

        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",

        filename="facturas_emitidas_clientes.xlsx"

    )





@app.get("/api/export/expenses-excel")

def export_expenses_excel(user: dict = Depends(require_admin)):

    excel_path = db.export_expenses_to_excel("data/export_facturas_proveedores.xlsx")

    return FileResponse(

        excel_path,

        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",

        filename="facturas_compras_proveedores.xlsx"

    )





# -------------------------------------------------------------

# Escudo Anti-Fuerza Bruta (Rate Limiting & Account Lockout)

# -------------------------------------------------------------

LOGIN_MAX_ATTEMPTS = 5

LOGIN_WINDOW_SECONDS = 300

LOGIN_LOCKOUT_SECONDS = 60

LOGIN_FAILED_ATTEMPTS: dict[str, dict] = {}





def clear_login_attempts(key: str = None):

    if key is None:

        LOGIN_FAILED_ATTEMPTS.clear()

    else:

        LOGIN_FAILED_ATTEMPTS.pop(key, None)





def _check_and_record_login_attempt(client_ip: str, username: str) -> int:

    """

    Devuelve 0 si se permite el intento, o los segundos restantes de bloqueo (>0) si está bloqueado.

    """

    now_ts = int(datetime.now().timestamp())

    norm_user = (username or "").strip().lower()[:64]

    key = f"{client_ip}:{norm_user}"



    if len(LOGIN_FAILED_ATTEMPTS) > 2000:

        stale = [k for k, v in LOGIN_FAILED_ATTEMPTS.items() if now_ts - v.get("first_ts", 0) > LOGIN_WINDOW_SECONDS]

        for k in stale:

            LOGIN_FAILED_ATTEMPTS.pop(k, None)



    entry = LOGIN_FAILED_ATTEMPTS.get(key)

    if not entry:

        return 0



    locked_until = entry.get("locked_until", 0)

    if locked_until > now_ts:

        return locked_until - now_ts



    if now_ts - entry.get("first_ts", 0) > LOGIN_WINDOW_SECONDS:

        LOGIN_FAILED_ATTEMPTS.pop(key, None)

        return 0



    return 0





def _register_failed_login(client_ip: str, username: str) -> tuple[int, int]:

    """

    Registra un fallo de login. Devuelve (intentos_actuales, segundos_bloqueado).

    """

    now_ts = int(datetime.now().timestamp())

    norm_user = (username or "").strip().lower()[:64]

    key = f"{client_ip}:{norm_user}"

    entry = LOGIN_FAILED_ATTEMPTS.get(key)



    if not entry or (now_ts - entry.get("first_ts", 0) > LOGIN_WINDOW_SECONDS):

        entry = {"count": 1, "first_ts": now_ts, "locked_until": 0}

    else:

        entry["count"] = entry.get("count", 0) + 1



    if entry["count"] >= LOGIN_MAX_ATTEMPTS:

        entry["locked_until"] = now_ts + LOGIN_LOCKOUT_SECONDS



    LOGIN_FAILED_ATTEMPTS[key] = entry

    rem_lock = max(0, entry["locked_until"] - now_ts)

    return entry["count"], rem_lock





@app.post("/api/auth/login")

def login(req: LoginRequest, request: Request, response: Response):

    client_ip = request.client.host if request.client else "127.0.0.1"

    norm_user = (req.username or "").strip().lower()

    rate_key = f"{client_ip}:{norm_user}"



    wait_seconds = _check_and_record_login_attempt(client_ip, norm_user)

    if wait_seconds > 0:

        return JSONResponse(

            status_code=429,

            headers={"Retry-After": str(wait_seconds)},

            content={

                "detail": f"Demasiados intentos fallidos. Acceso bloqueado temporalmente por seguridad durante {wait_seconds} segundos.",

                "retry_after_seconds": wait_seconds

            }

        )



    user = db.verify_user_credentials(req.username, req.password)

    if not user:

        attempts, lock_secs = _register_failed_login(client_ip, norm_user)

        db.log_security_event(

            usuario=norm_user,

            rol="UNKNOWN",

            accion="LOGIN_FAILED",

            detalle=f"Intento fallido ({attempts}/{LOGIN_MAX_ATTEMPTS})",

            ip=client_ip

        )

        if lock_secs > 0:

            return JSONResponse(

                status_code=429,

                headers={"Retry-After": str(lock_secs)},

                content={

                    "detail": f"Has superado los {LOGIN_MAX_ATTEMPTS} intentos permitidos. Cuenta protegida durante {lock_secs} segundos.",

                    "retry_after_seconds": lock_secs

                }

            )

        remaining = max(0, LOGIN_MAX_ATTEMPTS - attempts)

        raise HTTPException(

            status_code=401,

            detail=f"Usuario o contraseña incorrectos ({remaining} intentos restantes antes del bloqueo temporal)"

        )



    clear_login_attempts(rate_key)

    token = db.create_auth_token(user)

    db.log_security_event(

        usuario=user.get("username", norm_user),

        rol=user.get("rol", "ADMIN"),

        accion="LOGIN_SUCCESS",

        detalle="Inicio de sesión autenticado",

        ip=client_ip

    )

    response.set_cookie(

        key="session_token",

        value=token,

        httponly=True,

        samesite="lax",

        path="/"

    )

    return {

        "success": True,

        "token": token,

        "user": user

    }





@app.get("/api/auth/bootstrap-status")

def get_bootstrap_status():

    cfg = db.get_config()

    is_pending = str(cfg.get("primera_configuracion_pendiente", "0")) == "1"

    return {

        "needs_initial_setup": is_pending,

        "primera_configuracion_pendiente": cfg.get("primera_configuracion_pendiente", "0"),

        "empresa_nombre": cfg.get("empresa_nombre", "")

    }





@app.post("/api/auth/bootstrap-admin")

def bootstrap_initial_admin(req: BootstrapAdminRequest, request: Request, response: Response):

    cfg = db.get_config()

    is_pending = str(cfg.get("primera_configuracion_pendiente", "0")) == "1"

    if not is_pending:

        # Si ya se completó la puesta en marcha inicial, exigir sesión ADMIN activa

        try:

            curr = get_current_user(request)

            if curr.get("rol") != "ADMIN":

                raise HTTPException(status_code=403, detail="Se requieren permisos de Administrador")

        except HTTPException:

            raise HTTPException(

                status_code=403,

                detail="La puesta en marcha inicial ya fue completada. Inicia sesión con tu usuario Administrador."

            )

    try:

        admin_user = db.setup_initial_admin_user(

            username=req.username,

            password=req.password,

            nombre=req.nombre or "Administrador Principal",

            empresa_cif=req.empresa_cif or "",

            empresa_nombre=req.empresa_nombre or ""

        )

        token = db.create_auth_token(admin_user)

        response.set_cookie(

            key="session_token",

            value=token,

            httponly=True,

            samesite="lax",

            path="/"

        )

        return {

            "success": True,

            "token": token,

            "user": admin_user

        }

    except ValueError as e:

        raise HTTPException(status_code=400, detail=str(e))





@app.get("/api/auth/me")

def get_current_user_profile(user: dict = Depends(get_current_user)):

    return user





@app.post("/api/auth/logout")

def logout(request: Request, response: Response):

    auth_header = request.headers.get("authorization")

    if auth_header:

        a_str = auth_header.strip()

        tok = a_str[7:].strip() if a_str.lower().startswith("bearer ") else a_str

        db.revoke_auth_token(tok)

    cookie_token = request.cookies.get("session_token")

    if cookie_token:

        db.revoke_auth_token(cookie_token)

    x_token = request.headers.get("x-auth-token") or request.headers.get("x-session-token")

    if x_token:

        db.revoke_auth_token(x_token)

    response.delete_cookie(key="session_token", path="/")

    return {"success": True, "message": "Sesión cerrada y revocada correctamente"}





@app.post("/api/auth/change-password")

def change_password(req: PasswordChangeRequest, user: dict = Depends(require_user)):

    try:

        db.change_user_password(user["id"], req.current_password, req.new_password)

        return {"success": True, "message": "Contraseña actualizada con éxito"}

    except ValueError as e:

        raise HTTPException(status_code=400, detail=str(e))





@app.get("/api/users")

def get_users(user: dict = Depends(require_admin)):

    return db.list_users(empresa_cif=user.get("empresa_cif") or None)





@app.post("/api/users")

def create_new_user(req: UserCreateRequest, user: dict = Depends(require_admin)):

    try:

        new_u = db.create_user(

            username=req.username,

            password=req.password,

            nombre=req.nombre,

            rol=req.rol or "TECNICO",

            empresa_cif=user.get("empresa_cif"),

            empresa_nombre=user.get("empresa_nombre")

        )

        return {"success": True, "user": new_u}

    except ValueError as e:

        raise HTTPException(status_code=400, detail=str(e))

    except Exception as e:

        raise HTTPException(status_code=500, detail=f"Error al crear usuario: {str(e)}")





@app.delete("/api/users/{user_id}")

def delete_existing_user(user_id: int, user: dict = Depends(require_admin)):

    try:

        deleted = db.delete_user(user_id, acting_user_id=user["id"])

        if not deleted:

            raise HTTPException(status_code=404, detail="Usuario no encontrado")

        return {"success": True, "deleted_id": user_id}

    except ValueError as e:

        raise HTTPException(status_code=400, detail=str(e))





@app.get("/api/export/excel")

def export_excel(user: dict = Depends(require_admin)):

    excel_path = db.export_to_excel("data/export_facturacion.xlsx")

    return FileResponse(

        excel_path,

        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",

        filename="export_facturacion.xlsx"

    )





# Servir Frontend Estático

if os.path.exists(STATIC_DIR):

    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")



# =========================================================================

# CONTROL DE LICENCIA HWID Y PROTECCIÓN ANTI-PIRATERÍA

# =========================================================================

@app.middleware("http")

async def license_enforcement_middleware(request: Request, call_next):

    path = request.url.path

    if (

        path.startswith("/static")

        or path.startswith("/api/license")

        or path.startswith("/api/health")

        or path.startswith("/api/system")

        or path.startswith("/api/auth")

        or path in ["/activacion", "/favicon.ico", "/apple-touch-icon.png", "/sw.js", "/"]

    ):

        return await call_next(request)



    lic = license_manager.verify_license()

    if not lic.get("valid"):

        return JSONResponse(

            status_code=403,

            content={

                "detail": "LICENSE_REQUIRED",

                "status": lic.get("status"),

                "message": lic.get("message"),

                "hwid": lic.get("hwid")

            }

        )

    return await call_next(request)





@app.get("/api/license/status")
def get_license_status():
    """Devuelve el estado de licencia y el HWID del equipo actual."""
    lic = license_manager.verify_license()
    if not lic.get("valid"):
        try:
            sync_res = license_manager.sync_online_subscription(timeout=2.0)
            if sync_res.get("success"):
                lic = license_manager.verify_license()
        except Exception:
            pass
    return lic





@app.post("/api/license/activate")

def activate_app_license(body: LicenseActivationRequest):

    """Activa la licencia del equipo mediante clave criptográfica firmada."""

    res = license_manager.activate_license(body.key)

    if not res.get("success"):

        raise HTTPException(status_code=400, detail=res.get("message", "Clave no válida"))

    return res


@app.get("/api/license/stripe-config")
def get_stripe_subscription_config():
    """Devuelve la configuración de suscripción mensual con Stripe y la URL con el HWID pre-vinculado."""
    current_hwid = license_manager.get_machine_hwid()
    config_file = os.path.join(DATA_DIR, "stripe_config.json")
    cfg = {
        "enabled": True,
        "payment_link_monthly": "https://buy.stripe.com/test_ofigremio_15eur_monthly",
        "customer_portal_link": "https://billing.stripe.com/p/login/test_ofigremio",
        "monthly_price_eur": 15.00,
        "currency": "EUR"
    }
    if os.path.exists(config_file):
        try:
            with open(config_file, "r", encoding="utf-8") as f:
                loaded = json.load(f)
                if isinstance(loaded, dict):
                    cfg.update(loaded)
        except Exception:
            pass

    base_link = cfg.get("payment_link_monthly", "").strip()
    sep = "&" if "?" in base_link else "?"
    checkout_url = f"{base_link}{sep}client_reference_id={current_hwid}" if base_link else ""

    return {
        "enabled": bool(cfg.get("enabled", True)),
        "hwid": current_hwid,
        "monthly_price_eur": float(cfg.get("monthly_price_eur", 15.0)),
        "currency": cfg.get("currency", "EUR"),
        "checkout_url": checkout_url,
        "customer_portal_url": cfg.get("customer_portal_link", "")
    }


@app.post("/api/license/sync-now")
def trigger_license_online_sync():
    """Sincroniza manualmente la suscripción con el relay online de Stripe."""
    sync_res = license_manager.sync_online_subscription()
    current_status = license_manager.verify_license()
    return {
        "sync_result": sync_res,
        "current_license": current_status
    }





@app.get("/activacion", response_class=FileResponse)

def get_activation_page():

    act_file = os.path.join(STATIC_DIR, "activacion.html")

    if os.path.exists(act_file):

        return FileResponse(act_file)

    raise HTTPException(status_code=404, detail="Página de activación no encontrada")





@app.get("/api/system/check-updates")

def check_system_updates():

    """Comprueba versión actual y elegibilidad de actualizaciones según licencia."""

    lic = license_manager.verify_license()

    updates_until = lic.get("payload", {}).get("updates_until", "2027-10-29") if lic.get("payload") else "2027-10-29"

    return {

        "current_version": "4.2.1",

        "latest_version": "4.2.1",

        "update_available": False,

        "updates_until": updates_until,

        "eligible_for_updates": True

    }







@app.get("/")

def serve_index():

    lic = license_manager.verify_license()

    if not lic.get("valid"):

        act_file = os.path.join(STATIC_DIR, "activacion.html")

        if os.path.exists(act_file):

            return FileResponse(act_file)

    index_file = os.path.join(STATIC_DIR, "index.html")

    if os.path.exists(index_file):

        return FileResponse(index_file)

    return {"message": "OfiGremio Express API activa. Frontend en /static/index.html"}





@app.get("/sw.js")

def serve_service_worker():

    sw_file = os.path.join(STATIC_DIR, "sw.js")

    if os.path.exists(sw_file):

        return FileResponse(

            sw_file,

            media_type="application/javascript",

            headers={"Service-Worker-Allowed": "/"}

        )

    raise HTTPException(status_code=404, detail="sw.js no encontrado")





@app.get("/api/quotes/{quote_id}/client-view")

def get_quote_client_view(quote_id: int):

    q = db.get_quote(quote_id)

    if not q:

        raise HTTPException(status_code=404, detail="Presupuesto no encontrado")

    cfg = db.get_config()

    return {

        "quote": q,

        "company": {

            "nombre": cfg.get("empresa_nombre", ""),

            "cif": cfg.get("empresa_cif", ""),

            "telefono": cfg.get("empresa_telefono", ""),

            "direccion": cfg.get("empresa_direccion", ""),

            "poblacion": cfg.get("empresa_poblacion", ""),

            "iban": cfg.get("empresa_iban", "")

        }

    }





def _build_quote_email_payload(q: dict, cfg: dict, override_to: str = None) -> dict:

    empresa = cfg.get("empresa_nombre", "Servicio Técnico")

    empresa_email = (cfg.get("empresa_email") or "").strip()

    empresa_tel = (cfg.get("empresa_telefono") or "").strip()

    cliente = q.get("cliente_nombre", "Estimado/a cliente")

    to_email = (override_to if override_to is not None else (q.get("cliente_email") or "")).strip()

    numero = q.get("numero", "PRE-0000")

    numero_factura = (q.get("numero_factura") or "").strip()

    estado = (q.get("estado") or "BORRADOR").upper()

    es_rect = bool(q.get("es_rectificativa")) or numero_factura.startswith("REC-")

    total = float(q.get("total_factura") or 0.0)

    base_imp = float(q.get("base_imponible") or 0.0)

    total_iva = float(q.get("total_iva") or 0.0)

    anticipo = float(q.get("anticipo_importe") or 0.0)

    pendiente = float(q.get("pendiente_cobro") if q.get("pendiente_cobro") is not None else max(0.0, total - anticipo))

    concepto = q.get("concepto_averia", "Intervención técnica")

    huella = (q.get("huella_verifactu") or "").strip()



    if es_rect:

        doc_title = f"Factura Rectificativa {numero_factura or numero}"

        intro = f"Le remitimos la Factura Rectificativa oficial {numero_factura or numero} (Rectifica a: {q.get('numero_factura_origen') or 'Factura original'})."

    elif estado == "COBRADO" and numero_factura:

        doc_title = f"Factura Oficial {numero_factura}"

        intro = f"Le remitimos su Factura Oficial {numero_factura} (Ref. Presupuesto {numero})."

    else:

        doc_title = f"Presupuesto {numero}"

        intro = f"Le remitimos el presupuesto oficial {numero} correspondiente a los trabajos solicitados."



    subject = f"{doc_title} — {empresa}"

    desglose_lines = [

        f"• Intervención: {concepto}",

        f"• Base Imponible: {base_imp:.2f} €",

        f"• IVA aplicable: {total_iva:.2f} €",

        f"• Total Oficial: {total:.2f} €"

    ]

    if anticipo > 0 and not es_rect and estado != "COBRADO":

        desglose_lines.append(f"• Anticipo a cuenta: -{anticipo:.2f} €")

        desglose_lines.append(f"• Importe pendiente de abonar: {pendiente:.2f} €")

    if huella:

        desglose_lines.append(f"• Huella Veri*Factu SHA-256: {huella[:16]}...{huella[-8:]}")



    desglose_str = "\n".join(desglose_lines)

    contacto_footer = f"Tel: {empresa_tel}" + (f" | Correo: {empresa_email}" if empresa_email else "")

    body = (

        f"Hola {cliente},\n\n"

        f"{intro}\n\n"

        f"{desglose_str}\n\n"

        f"Para cualquier consulta o confirmación puede responder directamente a este correo electrónico.\n\n"

        f"Atentamente,\n{empresa}\n{contacto_footer}"

    )

    cc_param = f"&cc={urllib.parse.quote(empresa_email)}" if empresa_email else ""

    mailto_url = f"mailto:{to_email}?subject={urllib.parse.quote(subject)}&body={urllib.parse.quote(body)}{cc_param}"

    return {

        "subject": subject,

        "body": body,

        "to_email": to_email,

        "from_email": empresa_email,

        "empresa_email": empresa_email,

        "mailto_url": mailto_url

    }





@app.get("/api/quotes/{quote_id}/email-template")

def get_email_template(quote_id: int, user: dict = Depends(require_user)):

    q = db.get_quote(quote_id)

    if not q:

        raise HTTPException(status_code=404, detail="Presupuesto no encontrado")

    cfg = db.get_config()

    return _build_quote_email_payload(q, cfg)





@app.post("/api/quotes/{quote_id}/send-email")

def send_quote_email(quote_id: int, payload: SendEmailModel, user: dict = Depends(require_user)):

    q = db.get_quote(quote_id)

    if not q:

        raise HTTPException(status_code=404, detail="Presupuesto no encontrado")



    cfg = db.get_config()

    raw_target = payload.to_email or payload.email_destino or q.get("cliente_email") or ""

    if "\r" in raw_target or "\n" in raw_target:

        raise HTTPException(status_code=400, detail="Dirección de correo electrónico no válida (caracteres de control detectados)")

    target_email = raw_target.strip()

    if target_email and not re.match(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$", target_email):

        raise HTTPException(status_code=400, detail="El formato del correo electrónico del destinatario no es válido")



    # Si el usuario indicó el correo del cliente y no estaba guardado en la ficha, enlazarlo automáticamente

    if target_email and target_email != (q.get("cliente_email") or "").strip():

        try:

            db.update_client(int(q["cliente_id"]), {"email": target_email})

            q = db.get_quote(quote_id)

        except Exception:

            pass



    email_data = _build_quote_email_payload(q, cfg, override_to=target_email)

    smtp_host = (cfg.get("smtp_host") or "").strip()

    smtp_port = int(cfg.get("smtp_port") or 587)

    smtp_user = (cfg.get("smtp_user") or cfg.get("empresa_email") or "").strip()

    smtp_pass = (cfg.get("smtp_pass") or cfg.get("smtp_password") or "").strip()



    # Prevención SSRF en smtp_host: bloquear IPs de metadatos cloud y rangos internos reservados

    if smtp_host and (

        smtp_host.startswith("169.254.")

        or smtp_host in ("0.0.0.0", "127.0.0.1", "localhost", "::1")

        or "\r" in smtp_host

        or "\n" in smtp_host

    ):

        smtp_host = ""



    if smtp_host and smtp_user and smtp_pass and target_email:

        import smtplib

        from email.message import EmailMessage



        pdf_path = pdf_engine.generate_quote_pdf(q, cfg)

        msg = EmailMessage()

        msg["Subject"] = email_data["subject"]

        msg["From"] = f"{cfg.get('empresa_nombre', 'OfiGremio')} <{smtp_user}>"

        msg["To"] = target_email

        if email_data["from_email"]:

            msg["Reply-To"] = email_data["from_email"]

        msg.set_content(email_data["body"])



        if os.path.isfile(pdf_path):

            with open(pdf_path, "rb") as f:

                pdf_bytes = f.read()

            doc_num = q.get("numero_factura") if q.get("estado") == "COBRADO" and q.get("numero_factura") else q.get("numero", "documento")

            safe_fname = f"{re.sub(r'[^A-Za-z0-9_\-]', '_', str(doc_num))}.pdf"

            msg.add_attachment(pdf_bytes, maintype="application", subtype="pdf", filename=safe_fname)



        try:

            if smtp_port == 465:

                with smtplib.SMTP_SSL(smtp_host, smtp_port, timeout=10) as server:

                    server.login(smtp_user, smtp_pass)

                    server.send_message(msg)

            else:

                with smtplib.SMTP(smtp_host, smtp_port, timeout=10) as server:

                    server.starttls()

                    server.login(smtp_user, smtp_pass)

                    server.send_message(msg)

            return {

                "status": "sent_smtp",

                "sent_via_smtp": True,

                "message": f"Correo enviado automáticamente con PDF adjunto a {target_email}",

                **email_data

            }

        except Exception as smtp_err:

            return {

                "status": "mailto_fallback",

                "sent_via_smtp": False,

                "smtp_warning": str(smtp_err),

                **email_data

            }



    return {

        "status": "mailto_fallback",

        "sent_via_smtp": False,

        **email_data

    }







# -------------------------------------------------------------

# Endpoints: Proveedores (Suppliers)

# -------------------------------------------------------------

@app.get("/api/suppliers")

def list_suppliers(q: Optional[str] = None, user: dict = Depends(require_user)):

    return db.list_suppliers(search=q)





@app.post("/api/suppliers")

def create_supplier(supplier: SupplierModel, user: dict = Depends(require_user)):

    cif_val = supplier.cif_nif or supplier.cif or ""

    sid = db.create_supplier(

        nombre=supplier.nombre,

        cif_nif=cif_val,

        telefono=supplier.telefono,

        email=supplier.email,

        contacto=supplier.contacto,

        direccion=supplier.direccion,

        poblacion=supplier.poblacion,

        notas=supplier.notas

    )

    return db.get_supplier(sid)





@app.get("/api/suppliers/{supplier_id}")

def get_supplier(supplier_id: int, user: dict = Depends(require_user)):

    sup = db.get_supplier(supplier_id)

    if not sup:

        raise HTTPException(status_code=404, detail="Proveedor no encontrado")

    return sup





@app.put("/api/suppliers/{supplier_id}")

def update_supplier(supplier_id: int, supplier: SupplierUpdateModel, user: dict = Depends(require_user)):

    dumped = supplier.model_dump()

    if dumped.get("cif") and not dumped.get("cif_nif"):

        dumped["cif_nif"] = dumped["cif"]

    payload = {k: v for k, v in dumped.items() if v is not None and k != "cif"}

    updated = db.update_supplier(supplier_id, payload)

    if not updated:

        raise HTTPException(status_code=404, detail="Proveedor no encontrado")

    return updated





@app.delete("/api/suppliers/{supplier_id}")

def delete_supplier(supplier_id: int, user: dict = Depends(require_admin)):

    sup = db.get_supplier(supplier_id)

    if not sup:

        raise HTTPException(status_code=404, detail="Proveedor no encontrado")

    try:

        deleted = db.delete_supplier(supplier_id)

        if not deleted:

            raise HTTPException(status_code=404, detail="Proveedor no encontrado")

        return {"status": "deleted", "id": supplier_id}

    except ValueError as e:

        raise HTTPException(status_code=400, detail=str(e))





# -------------------------------------------------------------

# Endpoints: Compras y Gastos de Material

# -------------------------------------------------------------

@app.get("/api/expenses")

def list_expenses(gremio: Optional[str] = None, user: dict = Depends(require_user)):

    return db.list_expenses(gremio=gremio)





@app.post("/api/expenses")

def create_expense(expense: ExpenseCreateModel, user: dict = Depends(require_user)):

    try:

        exp_data = {

            "numero_factura": expense.numero_factura,

            "proveedor_id": expense.proveedor_id,

            "fecha": expense.fecha or datetime.now().strftime("%Y-%m-%d"),

            "concepto": expense.concepto,

            "base_imponible": expense.base_imponible,

            "iva_porcentaje": expense.iva_porcentaje or 0.21,

            "forma_pago": expense.forma_pago or "TRANSFERENCIA",

            "estado": expense.estado or "PAGADO",

            "notas": expense.notas or ""

        }

        items = [it.model_dump() for it in expense.items] if expense.items else []

        created = db.create_expense(exp_data, items=items)

        return created

    except Exception as e:

        raise HTTPException(status_code=400, detail=str(e))





@app.get("/api/expenses/{expense_id}")

def get_expense(expense_id: int, user: dict = Depends(require_user)):

    exp = db.get_expense(expense_id)

    if not exp:

        raise HTTPException(status_code=404, detail="Gasto no encontrado")

    return exp





@app.delete("/api/expenses/{expense_id}")

def delete_expense(expense_id: int, user: dict = Depends(require_admin)):

    exp = db.get_expense(expense_id)

    if not exp:

        raise HTTPException(status_code=404, detail="Gasto no encontrado")

    db.delete_expense(expense_id)

    return {"status": "deleted", "id": expense_id}





# -------------------------------------------------------------

# Endpoints: Stock, Almacén y Alertas

# -------------------------------------------------------------

@app.get("/api/stock")

def get_stock(gremio: Optional[str] = None, user: dict = Depends(require_user)):

    return db.list_catalog(gremio=gremio)





@app.get("/api/stock/alerts")

def get_stock_alerts(user: dict = Depends(require_user)):

    return db.list_stock_alerts()





@app.get("/api/stock/summary")

def get_stock_summary(user: dict = Depends(require_user)):

    return db.get_stock_summary()





@app.post("/api/stock/adjust")

def adjust_stock(adj: StockAdjustModel, user: dict = Depends(require_user)):

    try:

        res = db.adjust_stock(adj.catalogo_id, adj.cantidad_cambio, motivo=adj.motivo or "Ajuste manual")

        return res

    except ValueError as e:

        raise HTTPException(status_code=404, detail=str(e))







# -------------------------------------------------------------

# Endpoints: Asistente Tecnico Chatbot Local y Memoria de Negocio

# -------------------------------------------------------------

@app.post("/api/assistant/chat")

def assistant_chat(payload: AssistantChatModel, user: dict = Depends(require_user)):

    try:

        return local_ai_assistant.chat(payload.message, payload.context, user=user)

    except Exception as e:

        raise HTTPException(status_code=500, detail=f"Error en motor asistente: {str(e)}")





@app.get("/api/assistant/llm-status")

def get_assistant_llm_status(user: dict = Depends(require_user)):

    return local_ai_assistant.get_llm_status()





@app.post("/api/assistant/setup-llm")

def setup_assistant_local_llm(user: dict = Depends(require_user)):

    return local_ai_assistant.start_llm_setup_background()





@app.post("/api/assistant/reset-session")

def reset_assistant_session(user: dict = Depends(require_user)):

    local_ai_assistant.reset_session(user=user)

    return {"status": "ok"}





@app.get("/api/assistant/memory")

def get_assistant_memory(key: Optional[str] = None, user: dict = Depends(require_user)):

    return db.get_assistant_memory(key=key)





@app.post("/api/assistant/memory")

def set_assistant_memory(item: AssistantMemoryModel, user: dict = Depends(require_user)):

    try:

        return db.set_assistant_memory(item.key, item.value, item.category)

    except Exception as e:

        raise HTTPException(status_code=400, detail=str(e))





@app.delete("/api/assistant/memory/{key}")

def delete_assistant_memory(key: str, user: dict = Depends(require_user)):

    ok = db.delete_assistant_memory(key)

    if not ok:

        raise HTTPException(status_code=404, detail="Clave no encontrada")

    return {"status": "deleted", "key": key}







# -------------------------------------------------------------

# Endpoints: Iconos Oficiales y Conexión Móvil en Red Local

# -------------------------------------------------------------

@app.get("/favicon.ico", include_in_schema=False)

def get_favicon():

    fav = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "favicon.ico")

    if os.path.exists(fav):

        return FileResponse(fav, media_type="image/x-icon")

    return Response(status_code=404)





@app.get("/apple-touch-icon.png", include_in_schema=False)

def get_apple_touch_icon():

    ico = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "apple-touch-icon.png")

    if os.path.exists(ico):

        return FileResponse(ico, media_type="image/png")

    return Response(status_code=404)





def _get_local_ip() -> str:

    import socket

    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    try:

        s.connect(("10.255.255.255", 1))

        ip = s.getsockname()[0]

    except Exception:

        ip = "127.0.0.1"

    finally:

        s.close()

    return ip





@app.get("/api/system/network-info")

def get_system_network_info():

    """Devuelve la IP de red local, puerto activo y estado del túnel remoto 4G para conectar móviles por código QR."""

    local_ip = _get_local_ip()

    port = int(os.environ.get("OFIGREMIO_ACTIVE_PORT") or os.environ.get("OFIGREMIO_PORT") or 8080)

    local_url = f"http://{local_ip}:{port}"



    local_qr_b64 = ""

    try:

        import io

        import base64

        import qrcode

        qr = qrcode.QRCode(box_size=6, border=2)

        qr.add_data(local_url)

        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white")

        buf = io.BytesIO()

        img.save(buf, format="PNG")

        local_qr_b64 = f"data:image/png;base64,{base64.b64encode(buf.getvalue()).decode('ascii')}"

    except Exception:

        pass



    tunnel_data = {}

    tunnel_file = os.path.join(DATA_DIR, "remote_tunnel.json")

    if os.path.exists(tunnel_file):

        try:

            with open(tunnel_file, "r", encoding="utf-8") as f:

                tunnel_data = json.load(f)

        except Exception:

            pass



    return {

        "local_ip": local_ip,

        "port": port,

        "local_url": local_url,

        "local_qr_b64": local_qr_b64,

        "loopback_url": f"http://127.0.0.1:{port}",

        "remote_tunnel_active": bool(tunnel_data.get("tunnel_url")),

        "remote_tunnel_url": tunnel_data.get("tunnel_url", ""),

        "remote_qr_b64": tunnel_data.get("qr_data_uri", ""),

        "remote_created_at": tunnel_data.get("created_at", "")

    }





def find_available_port(preferred_port: int = 8080, max_attempts: int = 50) -> int:

    """Busca el primer puerto libre a partir del preferido para evitar bloqueos por colisión."""

    import socket

    for p in range(preferred_port, preferred_port + max_attempts):

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:

            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

            try:

                s.bind(("0.0.0.0", p))

                return p

            except OSError:

                continue

    return preferred_port





if __name__ == "__main__":

    import uvicorn

    import json



    preferred_port = int(os.environ.get("OFIGREMIO_PORT", 8080))

    host = os.environ.get("OFIGREMIO_HOST", "0.0.0.0")

    port = find_available_port(preferred_port=preferred_port)



    os.environ["OFIGREMIO_ACTIVE_PORT"] = str(port)



    # Guardar estado activo en data/server_info.json

    try:

        data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

        os.makedirs(data_dir, exist_ok=True)

        info_file = os.path.join(data_dir, "server_info.json")

        with open(info_file, "w", encoding="utf-8") as f:

            json.dump({

                "host": host,

                "port": port,

                "local_ip": _get_local_ip(),

                "url": f"http://localhost:{port}",

                "network_url": f"http://{_get_local_ip()}:{port}",

                "started_at": datetime.now().isoformat()

            }, f, indent=2)

    except Exception:

        pass



    if port != preferred_port:

        print(f"[AVISO] DE SEGURIDAD] Puerto {preferred_port} ocupado por otro programa. Asignado puerto dinámico libre: {port}")

    else:

        print(f"[OK] OfiGremio PRO enlazado correctamente en puerto: {port}")



    uvicorn.run(app, host=host, port=port)

