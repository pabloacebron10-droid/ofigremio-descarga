// OfiGremio Pro v2.5 — Wizard Paso 2: Cobro y Fiscalidad
window.WizardStep2 = {
    _esc: function(v) {
        return String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    },

    onEnter: function() {
        const pane = document.getElementById('wizard-step-2');
        if (!pane) return;

        const currentIban = this._esc(window.WizardController.data.payment.empresa_iban || window.WizardController.data.business.empresa_telefono || '');
        const currentIva = Number(window.WizardController.data.payment.iva_default ?? 0.21);
        const currentIrpf = Number(window.WizardController.data.payment.irpf_default ?? 0.0);

        pane.innerHTML = `
            <div style="margin-bottom:16px;">
                <h3 style="font-size:1.15rem; font-weight:700; margin-bottom:4px;">💶 Métodos de Cobro y Parámetros Fiscales</h3>
                <p style="font-size:0.85rem; color:#64748b;">Configura cómo deseas cobrar en tus facturas para activar pagos instantáneos con QR.</p>
            </div>

            <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:14px; margin-bottom:14px;">
                <label style="font-size:0.8rem; font-weight:600; display:block; margin-bottom:4px;">Teléfono Bizum o IBAN Bancario *</label>
                <input type="text" id="wiz-iban" value="${currentIban}" placeholder="Ej. ES91 2100 0418 ... o 612 345 678 (Bizum)" style="width:100%; padding:10px; border-radius:8px; border:1px solid #cbd5e1;" oninput="WizardStep2.updateQrPreview()">
                <small style="color:#64748b; font-size:0.75rem; display:block; margin-top:4px;">Aparecerá en el pie de tus presupuestos y facturas en PDF con un código QR escaneable.</small>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:14px;">
                <div>
                    <label style="font-size:0.8rem; font-weight:600; display:block; margin-bottom:4px;">Tipo de IVA Habitual</label>
                    <select id="wiz-iva" style="width:100%; padding:10px; border-radius:8px; border:1px solid #cbd5e1;">
                        <option value="0.21" ${Math.abs(currentIva - 0.21) < 0.01 ? 'selected' : ''}>21% (General / Obras Comerciales)</option>
                        <option value="0.10" ${Math.abs(currentIva - 0.10) < 0.01 ? 'selected' : ''}>10% (Reducido / Reformas Vivienda)</option>
                    </select>
                </div>
                <div>
                    <label style="font-size:0.8rem; font-weight:600; display:block; margin-bottom:4px;">Retención IRPF (si aplica)</label>
                    <select id="wiz-irpf" style="width:100%; padding:10px; border-radius:8px; border:1px solid #cbd5e1;">
                        <option value="0.0" ${currentIrpf === 0 ? 'selected' : ''}>0% (Sociedades o Particular)</option>
                        <option value="0.15" ${Math.abs(currentIrpf - 0.15) < 0.01 ? 'selected' : ''}>15% (Autónomo Profesional General)</option>
                        <option value="0.07" ${Math.abs(currentIrpf - 0.07) < 0.01 ? 'selected' : ''}>7% (Nuevos Autónomos / Reducido)</option>
                    </select>
                </div>
            </div>

            <div style="border:1px dashed #cbd5e1; border-radius:10px; padding:12px; display:flex; align-items:center; gap:16px; background:#fafafa;">
                <div style="width:64px; height:64px; background:#0f172a; border-radius:8px; display:flex; align-items:center; justify-content:center; color:#ffffff; font-size:1.8rem;">
                    📱
                </div>
                <div style="flex:1;">
                    <div style="font-size:0.85rem; font-weight:700;">Vista Previa de Cobro en Factura:</div>
                    <div id="wiz-qr-preview-text" style="font-size:0.8rem; color:#475569; margin-top:2px;">
                        QR activo para cobro directo a: <strong>${currentIban || 'No configurado'}</strong>
                    </div>
                </div>
            </div>
        `;
    },

    updateQrPreview: function() {
        const val = this._esc(document.getElementById('wiz-iban')?.value.trim() || 'No configurado');
        const el = document.getElementById('wiz-qr-preview-text');
        if (el) el.innerHTML = `QR activo para cobro directo a: <strong>${val}</strong>`;
    },

    validate: function() {
        const iban = document.getElementById('wiz-iban')?.value.trim();
        const iva = parseFloat(document.getElementById('wiz-iva')?.value) || 0.21;
        const irpf = parseFloat(document.getElementById('wiz-irpf')?.value) || 0.0;

        window.WizardController.data.payment.empresa_iban = iban || '';
        window.WizardController.data.payment.iva_default = iva;
        window.WizardController.data.payment.irpf_default = irpf;
        return true;
    }
};
