// OfiGremio Pro v3.1 — Wizard Paso 1: Negocio y Catálogo
window.WizardStep1 = {
    sectors: [
        { id: 'FONTANERIA', name: 'Fontanería', icon: '🚰', color: '#2563eb', rate: 38, urg: 45 },
        { id: 'ELECTRICIDAD', name: 'Electricidad', icon: '⚡', color: '#d97706', rate: 42, urg: 50 },
        { id: 'CLIMATIZACION', name: 'Climatización', icon: '❄️', color: '#0284c7', rate: 45, urg: 55 },
        { id: 'REFORMAS', name: 'Reformas', icon: '🔨', color: '#059669', rate: 40, urg: 60 },
        { id: 'CERRAJERIA', name: 'Cerrajería 24h', icon: '🔐', color: '#dc2626', rate: 45, urg: 60 },
        { id: 'PINTURA', name: 'Pintura y Deco', icon: '🎨', color: '#7c3aed', rate: 32, urg: 40 },
        { id: 'CARPINTERIA', name: 'Carpintería', icon: '🪚', color: '#b45309', rate: 38, urg: 50 },
        { id: 'ENERGIA_SOLAR', name: 'Energía Solar', icon: '☀️', color: '#ca8a04', rate: 44, urg: 55 },
        { id: 'TELECOMUNICACIONES', name: 'Telecom y Redes', icon: '📡', color: '#4f46e5', rate: 40, urg: 50 },
        { id: 'JARDINERIA', name: 'Jardinería', icon: '🌿', color: '#16a34a', rate: 30, urg: 40 },
        { id: 'AISLAMIENTOS', name: 'Pladur y Techos', icon: '🧱', color: '#475569', rate: 35, urg: 45 },
        { id: 'LIMPIEZA', name: 'Limpieza Técnica', icon: '🧹', color: '#0d9488', rate: 28, urg: 35 },
        { id: 'OTRO', name: '✨ Otro Sector...', icon: '✨', color: '#6366f1', rate: 35, urg: 45 }
    ],

    onEnter: function() {
        this.init();
        const b = window.WizardController?.data?.business || {};
        this.selectSector(b.sector || 'FONTANERIA');
    },

    init: function() {
        const pane = document.getElementById('wizard-step-1');
        if (!pane) return;

        const b = window.WizardController?.data?.business || {};
        const adm = window.WizardController?.data?.admin || {};
        const currUser = window.state?.currentUser;
        const esc = (v) => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
        const defaultAdminUser = esc(adm.username || (currUser && currUser.username !== 'admin' ? currUser.username : ''));
        const defaultAdminNombre = esc(adm.nombre || (currUser ? currUser.nombre : 'Administrador Principal'));

        pane.innerHTML = `
            <div style="background:linear-gradient(135deg, #eff6ff 0%, #f8fafc 100%); border:1px solid #bfdbfe; border-radius:10px; padding:12px 14px; margin-bottom:14px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px; flex-wrap:wrap; gap:6px;">
                    <h4 style="margin:0; font-size:0.95rem; font-weight:800; color:#1e3a8a;">🔐 1. Cuenta de Administrador Principal de tu Empresa</h4>
                    <span style="font-size:0.72rem; background:#dbeafe; color:#1d4ed8; padding:2px 8px; border-radius:999px; font-weight:700;">Rol: ADMIN (Control Total)</span>
                </div>
                <p style="font-size:0.78rem; color:#475569; margin:0 0 10px 0;">
                    Crea tu usuario único de Administrador. Quedará vinculado automáticamente a tu empresa y con él podrás crear cuentas para tus operarios técnicos desde dentro.
                </p>
                <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:8px;">
                    <div>
                        <label style="font-size:0.76rem; font-weight:700; display:block; margin-bottom:3px; color:#1e293b;">Usuario Único (Login) *</label>
                        <input type="text" id="wiz-admin-username" value="${defaultAdminUser}" placeholder="Ej. admin_ramos" oninput="WizardStep1.checkUsernameLive(this.value)" style="width:100%; padding:8px; border-radius:6px; border:1px solid #93c5fd; font-size:0.85rem; background:#fff;">
                        <div id="wiz-username-status" style="font-size:0.72rem; margin-top:3px; color:#64748b;">Mín. 3 caracteres sin espacios</div>
                    </div>
                    <div>
                        <label style="font-size:0.76rem; font-weight:700; display:block; margin-bottom:3px; color:#1e293b;">Contraseña Admin *</label>
                        <div style="position:relative; display:flex; align-items:center;">
                            <input type="password" id="wiz-admin-password" value="${adm.password || ''}" placeholder="Mínimo 6 caracteres" style="width:100%; padding:8px 32px 8px 8px; border-radius:6px; border:1px solid #93c5fd; font-size:0.85rem; background:#fff;">
                            <button type="button" onclick="WizardStep1.toggleAdminPw()" title="Mostrar / Ocultar" style="position:absolute; right:6px; background:none; border:none; cursor:pointer; font-size:0.85rem;">👁️</button>
                        </div>
                    </div>
                    <div>
                        <label style="font-size:0.76rem; font-weight:700; display:block; margin-bottom:3px; color:#1e293b;">Tu Nombre / Cargo *</label>
                        <input type="text" id="wiz-admin-nombre" value="${defaultAdminNombre}" placeholder="Ej. Pablo (Gerente)" style="width:100%; padding:8px; border-radius:6px; border:1px solid #93c5fd; font-size:0.85rem; background:#fff;">
                    </div>
                </div>
            </div>

            <div style="margin-bottom:10px;">
                <h3 style="font-size:1.05rem; font-weight:700; margin-bottom:2px;">🏢 2. Datos Fiscales de la Empresa y Sector</h3>
                <p style="font-size:0.8rem; color:#64748b; margin:0;">Selecciona tu gremio profesional y define los datos oficiales para tus facturas y presupuestos.</p>
            </div>

            <div style="margin-bottom:12px;">
                <label style="font-size:0.8rem; font-weight:600; display:block; margin-bottom:6px;">Sector Principal *</label>
                <div class="sector-grid" id="wiz-sector-grid" style="display:grid; grid-template-columns:repeat(auto-fill, minmax(125px, 1fr)); gap:6px; max-height:155px; overflow-y:auto; padding:4px;">
                    ${this.sectors.map(s => `
                        <div class="sector-card ${s.id === (b.sector || 'FONTANERIA') ? 'selected' : ''}" id="card-sec-${s.id}" onclick="WizardStep1.selectSector('${s.id}')" style="cursor:pointer; border:1px solid #cbd5e1; border-radius:8px; padding:8px 6px; text-align:center; transition:all 0.2s;">
                            <div class="sector-icon" style="font-size:1.25rem;">${s.icon}</div>
                            <div style="font-size:0.76rem; font-weight:700; margin-top:3px;">${s.name}</div>
                            <div style="font-size:0.7rem; color:#2563eb; font-weight:600; margin-top:2px;">${s.rate} €/h</div>
                        </div>
                    `).join('')}
                </div>
            </div>

            <div id="wiz-custom-sector-box" style="display:${b.sector === 'OTRO' ? 'block' : 'none'}; background:#f1f5f9; border:1px dashed #94a3b8; border-radius:8px; padding:10px; margin-bottom:12px;">
                <div style="font-size:0.8rem; font-weight:700; margin-bottom:6px; color:#1e293b;">🛠️ Personaliza tu Sector / Actividad:</div>
                <div style="display:grid; grid-template-columns:1fr 130px 100px; gap:8px;">
                    <input type="text" id="wiz-custom-sec-name" value="${b.sector_custom_nombre || ''}" placeholder="Ej. Forja y Cerrajería" style="padding:8px; border-radius:6px; border:1px solid #cbd5e1; font-size:0.85rem;">
                    <div style="display:flex; align-items:center; background:#ffffff; border:1px solid #cbd5e1; border-radius:6px; padding-right:8px;">
                        <input type="number" id="wiz-custom-sec-rate" value="${b.precio_hora_default || 38}" placeholder="38" style="padding:8px; border:none; border-radius:6px; font-size:0.85rem; width:100%; text-align:right;">
                        <span style="font-size:0.8rem; font-weight:700; color:#64748b; margin-left:4px;">€/h</span>
                    </div>
                    <select id="wiz-custom-sec-color" onchange="WizardStep1.changeCustomColor(this.value)" style="padding:8px; border-radius:6px; border:1px solid #cbd5e1; font-size:0.85rem;">
                        <option value="#2563eb" ${b.color_theme === '#2563eb' ? 'selected' : ''}>Azul</option>
                        <option value="#059669" ${b.color_theme === '#059669' ? 'selected' : ''}>Verde</option>
                        <option value="#d97706" ${b.color_theme === '#d97706' ? 'selected' : ''}>Ámbar</option>
                        <option value="#dc2626" ${b.color_theme === '#dc2626' ? 'selected' : ''}>Rojo</option>
                        <option value="#7c3aed" ${b.color_theme === '#7c3aed' ? 'selected' : ''}>Violeta</option>
                        <option value="#6366f1" ${b.color_theme === '#6366f1' ? 'selected' : ''}>Indigo</option>
                    </select>
                </div>
            </div>

            <div style="display:flex; flex-direction:column; gap:8px;">
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                    <div>
                        <label style="font-size:0.8rem; font-weight:600; display:block; margin-bottom:3px;">Nombre Comercial / Empresa o Autónomo *</label>
                        <input type="text" id="wiz-empresa" value="${esc(b.empresa_nombre || 'Mi Empresa de Servicios Técnicos')}" placeholder="Ej. Instalaciones Ramos S.L." style="width:100%; padding:8px; border-radius:8px; border:1px solid #cbd5e1; font-size:0.88rem;">
                    </div>
                    <div>
                        <label style="font-size:0.8rem; font-weight:600; display:block; margin-bottom:3px;">Correo Electrónico de la Empresa *</label>
                        <input type="email" id="wiz-email" value="${esc(b.empresa_email || 'contacto@miempresa.es')}" placeholder="Ej. administracion@tuempresa.es" style="width:100%; padding:8px; border-radius:8px; border:1px solid #cbd5e1; font-size:0.88rem;">
                    </div>
                </div>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                    <div>
                        <label style="font-size:0.8rem; font-weight:600; display:block; margin-bottom:3px;">NIF / CIF de la Empresa *</label>
                        <input type="text" id="wiz-cif" value="${esc(b.empresa_cif || 'B-12345678')}" placeholder="Ej. B-88776655" style="width:100%; padding:8px; border-radius:8px; border:1px solid #cbd5e1; font-size:0.88rem;">
                    </div>
                    <div>
                        <label style="font-size:0.8rem; font-weight:600; display:block; margin-bottom:3px;">Teléfono WhatsApp *</label>
                        <input type="tel" id="wiz-telefono" value="${esc(b.empresa_telefono || '600123456')}" placeholder="Ej. 612 345 678" style="width:100%; padding:8px; border-radius:8px; border:1px solid #cbd5e1; font-size:0.88rem;">
                    </div>
                </div>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                    <div>
                        <label style="font-size:0.8rem; font-weight:600; display:block; margin-bottom:3px;">Ciudad / Población</label>
                        <input type="text" id="wiz-poblacion" value="${esc(b.empresa_poblacion || 'Madrid')}" placeholder="Ej. Madrid" style="width:100%; padding:8px; border-radius:8px; border:1px solid #cbd5e1; font-size:0.88rem;">
                    </div>
                    <div>
                        <label style="font-size:0.8rem; font-weight:600; display:block; margin-bottom:3px;">Dirección Fiscal</label>
                        <input type="text" id="wiz-direccion" value="${esc(b.empresa_direccion || '')}" placeholder="Ej. C/ Mayor 12" style="width:100%; padding:8px; border-radius:8px; border:1px solid #cbd5e1; font-size:0.88rem;">
                    </div>
                </div>
            </div>
        `;
    },

    toggleAdminPw: function() {
        const inp = document.getElementById('wiz-admin-password');
        if (!inp) return;
        inp.type = inp.type === 'password' ? 'text' : 'password';
    },

    checkUsernameLive: async function(val) {
        const statusEl = document.getElementById('wiz-username-status');
        if (!statusEl) return;
        const norm = (val || '').trim().toLowerCase();
        if (norm.length < 3) {
            statusEl.style.color = '#64748b';
            statusEl.textContent = 'Mín. 3 caracteres sin espacios';
            return;
        }
        const curr = window.state?.currentUser?.username || '';
        if (curr && curr.trim().toLowerCase() === norm) {
            statusEl.style.color = '#10b981';
            statusEl.textContent = `✓ Tu usuario actual ('${norm}')`;
            return;
        }
        try {
            const res = await fetch(`/api/wizard/check-username?username=${encodeURIComponent(norm)}`);
            if (res.ok) {
                const data = await res.json();
                if (data.available) {
                    statusEl.style.color = '#10b981';
                    statusEl.textContent = `✓ '${data.username}' disponible y único`;
                } else {
                    statusEl.style.color = '#ef4444';
                    statusEl.textContent = `⚠️ ${data.reason || 'Usuario no disponible'}`;
                }
            }
        } catch (_) {}
    },

    selectSector: function(secId) {
        this.sectors.forEach(s => {
            const el = document.getElementById(`card-sec-${s.id}`);
            if (el) {
                el.style.borderColor = '#cbd5e1';
                el.style.backgroundColor = '#ffffff';
            }
        });
        const selected = document.getElementById(`card-sec-${secId}`);
        const secObj = this.sectors.find(s => s.id === secId);

        if (selected && secObj) {
            selected.style.borderColor = secObj.color;
            selected.style.backgroundColor = secObj.color + '15';
        }

        const customBox = document.getElementById('wiz-custom-sector-box');
        if (customBox) {
            customBox.style.display = secId === 'OTRO' ? 'block' : 'none';
        }

        if (secObj && window.WizardController) {
            window.WizardController.data.business.sector = secId;
            window.WizardController.data.business.precio_hora_default = secObj.rate;
            window.WizardController.data.business.recargo_urgencia_default = secObj.urg;
            window.WizardController.data.business.color_theme = secObj.color;
            document.documentElement.style.setProperty('--primary-color', secObj.color);
        }
    },

    changeCustomColor: function(color) {
        if (window.WizardController) {
            window.WizardController.data.business.color_theme = color;
            document.documentElement.style.setProperty('--primary-color', color);
        }
    },

    validate: async function() {
        const emp = document.getElementById('wiz-empresa')?.value.trim() || 'Mi Empresa de Servicios';
        const cif = document.getElementById('wiz-cif')?.value.trim() || 'B-12345678';
        const tel = document.getElementById('wiz-telefono')?.value.trim() || '600123456';
        const email = document.getElementById('wiz-email')?.value.trim() || '';
        const dir = document.getElementById('wiz-direccion')?.value.trim() || '';
        const pob = document.getElementById('wiz-poblacion')?.value.trim() || 'Madrid';

        const adminUser = (document.getElementById('wiz-admin-username')?.value || '').trim().toLowerCase();
        const adminPass = document.getElementById('wiz-admin-password')?.value || '';
        const adminNom = (document.getElementById('wiz-admin-nombre')?.value || '').trim() || 'Administrador Principal';

        const isInitial = Boolean(window.WizardController?.isInitialSetup) && !window.state?.currentUser;

        // Solo exigir contraseña de administrador en la configuración inicial no autenticada o si el usuario ingresó una contraseña explícita
        if (isInitial || (adminPass && adminPass.length > 0)) {
            if (!adminUser || adminUser.length < 3 || /\s/.test(adminUser)) {
                if (typeof showToast === 'function') showToast('⚠️ Introduce un Usuario Administrador válido (mín. 3 caracteres, sin espacios)', 'error');
                document.getElementById('wiz-admin-username')?.focus();
                return false;
            }
            if (!adminPass || adminPass.length < 6) {
                if (typeof showToast === 'function') showToast('⚠️ La contraseña del Administrador debe tener al menos 6 caracteres', 'error');
                document.getElementById('wiz-admin-password')?.focus();
                return false;
            }
            try {
                const res = await fetch('/api/auth/bootstrap-admin', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        username: adminUser,
                        password: adminPass,
                        nombre: adminNom,
                        empresa_nombre: emp,
                        empresa_cif: cif
                    })
                });
                const data = await res.json().catch(() => ({}));
                if (!res.ok) {
                    if (typeof showToast === 'function') showToast(`❌ ${data.detail || 'Error al registrar Administrador'}`, 'error');
                    return false;
                }
                if (data.token) {
                    localStorage.setItem('ofigremio_token', data.token);
                    localStorage.setItem('ofigremio_auth_token', data.token);
                }
                if (data.user) {
                    if (window.state) window.state.currentUser = data.user;
                    document.body.classList.remove('auth-locked');
                    if (typeof applyRoleUI === 'function') applyRoleUI(data.user);
                }
                if (window.WizardController?.data) {
                    window.WizardController.data.admin = {
                        username: adminUser,
                        password: adminPass,
                        nombre: adminNom
                    };
                }
            } catch (e) {
                if (typeof showToast === 'function') showToast('❌ Error de red al crear el usuario Administrador', 'error');
                return false;
            }
        }

        const secId = window.WizardController.data.business.sector || 'FONTANERIA';
        let customName = '';
        if (secId === 'OTRO') {
            customName = document.getElementById('wiz-custom-sec-name')?.value.trim() || 'Servicios Técnicos';
            const customRate = parseFloat(document.getElementById('wiz-custom-sec-rate')?.value) || 38.0;
            const customColor = document.getElementById('wiz-custom-sec-color')?.value || '#6366f1';
            window.WizardController.data.business.sector_custom_nombre = customName;
            window.WizardController.data.business.precio_hora_default = customRate;
            window.WizardController.data.business.color_theme = customColor;
        } else {
            const currentSec = this.sectors.find(s => s.id === secId);
            if (currentSec) {
                window.WizardController.data.business.precio_hora_default = currentSec.rate;
                window.WizardController.data.business.recargo_urgencia_default = currentSec.urg;
                window.WizardController.data.business.color_theme = currentSec.color;
            }
        }

        window.WizardController.data.business.empresa_nombre = emp;
        window.WizardController.data.business.empresa_cif = cif;
        window.WizardController.data.business.empresa_telefono = tel;
        window.WizardController.data.business.empresa_email = email;
        window.WizardController.data.business.empresa_poblacion = pob;
        window.WizardController.data.business.empresa_direccion = dir;

        // Persistir inmediatamente los campos de negocio en SQLite vía POST /api/config
        try {
            const configPayload = {
                empresa_nombre: emp,
                empresa_cif: cif,
                empresa_telefono: tel,
                empresa_email: email,
                empresa_direccion: dir,
                empresa_poblacion: pob,
                sector: secId,
                color_theme: window.WizardController.data.business.color_theme || '#2563eb',
                precio_hora_default: window.WizardController.data.business.precio_hora_default ?? 38.0,
                recargo_urgencia_default: window.WizardController.data.business.recargo_urgencia_default ?? 45.0
            };
            if (secId === 'OTRO' && customName) {
                configPayload.sector_custom_nombre = customName;
            }
            await fetch('/api/config', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(configPayload)
            });
            if (window.state?.config) {
                Object.assign(window.state.config, configPayload);
            }
        } catch (e) {
            console.warn('[WizardStep1] Aviso al persistir configuración de negocio:', e);
        }

        return true;
    }
};

document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => { if (window.WizardStep1) window.WizardStep1.init(); }, 250);
});
