// =============================================================

// SANITIZACIÓN DEFENSIVA GLOBAL CONTRA XSS (OWASP A03)

// =============================================================

function escapeHtml(str) {

    if (str === null || str === undefined) return '';

    return String(str)

        .replace(/&/g, '&amp;')

        .replace(/</g, '&lt;')

        .replace(/>/g, '&gt;')

        .replace(/"/g, '&quot;')

        .replace(/'/g, '&#39;');

}



// =============================================================

// GESTIÓN DE TOKEN DE AUTENTICACIÓN Y ENVOLTORIO FETCH (RBAC)

// =============================================================

const originalFetch = window.fetch;



window.fetch = async function(resource, init = {}) {

    init = init || {};

    if (!init.credentials) {

        init.credentials = 'same-origin';

    }

    const token = localStorage.getItem('ofigremio_token') || localStorage.getItem('ofigremio_auth_token');

    if (token) {

        let headers = init.headers;

        if (!headers) {

            headers = {};

        }

        if (headers instanceof Headers) {

            if (!headers.has('Authorization')) {

                headers.set('Authorization', `Bearer ${token}`);

            }

        } else if (Array.isArray(headers)) {

            const hasAuth = headers.some(([k]) => k.toLowerCase() === 'authorization');

            if (!hasAuth) {

                headers.push(['Authorization', `Bearer ${token}`]);

            }

        } else if (typeof headers === 'object') {

            if (!headers['Authorization'] && !headers['authorization']) {

                headers['Authorization'] = `Bearer ${token}`;

            }

        }

        init.headers = headers;

    }

    const response = await originalFetch(resource, init);

    const urlStr = typeof resource === 'string' ? resource : (resource?.url || '');

    const isBootstrapFlow = Boolean(window.WizardController?.isInitialSetup) ||

        urlStr.includes('/api/auth/') ||

        urlStr.includes('/api/wizard/');

    if (response.status === 401 && !isBootstrapFlow) {

        openLoginModal('Tu sesión ha expirado o requiere iniciar sesión para guardar cambios.');

    }

    return response;

};



async function authFetch(resource, init = {}) {

    return window.fetch(resource, init);

}



let loginLockoutTimer = null;



function showSplashScreen(statusText = 'Verificando sesión segura...', progressPct = 45) {

    const splash = document.getElementById('app-splash-screen');

    const statusEl = document.getElementById('splash-status-text');

    const barEl = document.getElementById('splash-progress-bar');

    if (statusEl && statusText) statusEl.innerText = statusText;

    if (barEl && progressPct !== undefined) barEl.style.width = `${progressPct}%`;

    if (splash) splash.classList.remove('splash-hidden');

}



function hideSplashScreen() {

    const barEl = document.getElementById('splash-progress-bar');

    if (barEl) barEl.style.width = '100%';

    setTimeout(() => {

        const splash = document.getElementById('app-splash-screen');

        if (splash) splash.classList.add('splash-hidden');

    }, 180);

}



function toggleLoginPasswordVisibility() {

    const pwInput = document.getElementById('login-password');

    const btn = document.getElementById('btn-toggle-pw');

    if (!pwInput) return;

    if (pwInput.type === 'password') {

        pwInput.type = 'text';

        if (btn) btn.innerText = '🙈';

    } else {

        pwInput.type = 'password';

        if (btn) btn.innerText = '👁️';

    }

}



function startLockoutCountdown(seconds) {

    const btn = document.getElementById('btn-login-submit');

    const errBox = document.getElementById('login-error-box');

    if (loginLockoutTimer) clearInterval(loginLockoutTimer);

    let rem = Math.max(1, parseInt(seconds) || 60);



    const updateUI = () => {

        if (btn) {

            btn.disabled = true;

            btn.innerText = `⏳ Bloqueado por seguridad (${rem}s)`;

        }

        if (errBox) {

            errBox.innerText = `🛡️ Escudo Anti-Fuerza Bruta activo: Demasiados intentos fallidos. Espera ${rem} segundos para volver a intentarlo.`;

            errBox.style.display = 'block';

        }

    };

    updateUI();



    loginLockoutTimer = setInterval(() => {

        rem -= 1;

        if (rem <= 0) {

            clearInterval(loginLockoutTimer);

            loginLockoutTimer = null;

            if (btn) {

                btn.disabled = false;

                btn.innerText = '🚀 Iniciar Sesión';

            }

            if (errBox) {

                errBox.style.display = 'none';

            }

        } else {

            updateUI();

        }

    }, 1000);

}



function openLoginModal(errorMsg = '') {

    document.body.classList.add('auth-locked');

    const modal = document.getElementById('modal-login');

    if (!modal) return;

    const errBox = document.getElementById('login-error-box');

    if (errBox) {

        if (errorMsg) {

            errBox.innerText = errorMsg;

            errBox.style.display = 'block';

        } else {

            errBox.style.display = 'none';

        }

    }

    modal.classList.add('active');

    setTimeout(() => {

        const userInp = document.getElementById('login-username');

        if (userInp) userInp.focus();

    }, 80);

}



async function submitLogin(username, password) {

    const res = await originalFetch('/api/auth/login', {

        method: 'POST',

        credentials: 'same-origin',

        headers: { 'Content-Type': 'application/json' },

        body: JSON.stringify({ username, password })

    });

    if (!res.ok) {

        const errData = await res.json().catch(() => ({}));

        const errorObj = new Error(errData.detail || 'Usuario o contraseña incorrectos');

        errorObj.status = res.status;

        errorObj.retryAfter = errData.retry_after_seconds || parseInt(res.headers.get('Retry-After') || '0', 10);

        throw errorObj;

    }

    const data = await res.json();

    if (data.token) {

        localStorage.setItem('ofigremio_token', data.token);

        localStorage.setItem('ofigremio_auth_token', data.token);

    }

    const modal = document.getElementById('modal-login');

    if (modal) modal.classList.remove('active');

    const pwInp = document.getElementById('login-password');

    if (pwInp) {

        pwInp.value = '';

        pwInp.type = 'password';

    }

    showSplashScreen('Cargando datos de tu negocio...', 75);

    await initUserRole();

    await loadAllData();

    document.body.classList.remove('auth-locked');

    hideSplashScreen();

    return data;

}



async function handleLoginFormSubmit(e) {

    if (e) e.preventDefault();

    if (loginLockoutTimer) return;

    const username = (document.getElementById('login-username')?.value || '').trim();

    const password = document.getElementById('login-password')?.value || '';

    const btn = document.getElementById('btn-login-submit');

    const errBox = document.getElementById('login-error-box');

    if (errBox) errBox.style.display = 'none';

    if (btn) {

        btn.disabled = true;

        btn.innerText = 'Verificando credenciales...';

    }

    try {

        const data = await submitLogin(username, password);

        showToast(`🔓 Sesión iniciada como ${data.user?.nombre || username} (${data.user?.rol || 'ADMIN'})`, 'success');

    } catch (err) {

        if (err.status === 429) {

            startLockoutCountdown(err.retryAfter || 60);

            return;

        }

        if (errBox) {

            errBox.innerText = `⚠️ ${err.message || 'Usuario o contraseña incorrectos'}`;

            errBox.style.display = 'block';

        } else {

            showToast(err.message || 'Error de autenticación', 'error');

        }

    } finally {

        if (btn && !loginLockoutTimer) {

            btn.disabled = false;

            btn.innerText = '🚀 Iniciar Sesión';

        }

    }

}



async function submitLogout() {

    try {

        const token = localStorage.getItem('ofigremio_token') || localStorage.getItem('ofigremio_auth_token');

        const headers = token ? { 'Authorization': `Bearer ${token}` } : {};

        await originalFetch('/api/auth/logout', {

            method: 'POST',

            credentials: 'same-origin',

            headers

        });

    } catch (_) {}

    localStorage.removeItem('ofigremio_token');

    localStorage.removeItem('ofigremio_auth_token');

    state.currentUser = null;

    state.quotes = [];

    state.clients = [];

    state.catalog = [];

    state.suppliers = [];

    state.expenses = [];

    state.analytics = null;



    if (window.WizardController && typeof window.WizardController.close === 'function') {

        window.WizardController.close();

    }

    document.querySelectorAll('.modal-backdrop.active').forEach(m => m.classList.remove('active'));

    document.body.classList.add('auth-locked');



    const uInp = document.getElementById('login-username');

    const pInp = document.getElementById('login-password');

    if (uInp) uInp.value = '';

    if (pInp) {

        pInp.value = '';

        pInp.type = 'password';

    }

    openLoginModal();

    showToast('🔒 Sesión cerrada de forma segura', 'info');

}



async function submitChangePasswordForm(e) {

    e.preventDefault();

    const current_password = document.getElementById('cp-current-password')?.value || '';

    const new_password = document.getElementById('cp-new-password')?.value || '';

    if (!current_password || !new_password) return;

    try {

        const res = await fetch('/api/auth/change-password', {

            method: 'POST',

            headers: { 'Content-Type': 'application/json' },

            body: JSON.stringify({ current_password, new_password })

        });

        if (res.ok) {

            document.getElementById('change-password-form')?.reset();

            showToast('🔑 Contraseña actualizada correctamente', 'success');

        } else {

            const err = await res.json().catch(() => ({}));

            showToast(err.detail || 'No se pudo actualizar la contraseña', 'error');

        }

    } catch (err) {

        showToast('Error de red al cambiar la contraseña', 'error');

    }

}



async function openAuthOrUsersModal() {

    if (!state.currentUser) {

        openLoginModal();

        return;

    }

    const lbl = document.getElementById('current-session-user-label');

    if (lbl) {

        lbl.innerText = `${state.currentUser.rol} · ${state.currentUser.username}`;

    }

    const compLbl = document.getElementById('current-session-company-label');

    if (compLbl) {

        const empNom = state.currentUser.empresa_nombre || state.config?.empresa_nombre || 'Mi Empresa';

        const empCif = state.currentUser.empresa_cif || state.config?.empresa_cif || '';

        compLbl.innerText = `🏢 Vinculado a: ${empNom}${empCif ? ' (' + empCif + ')' : ''}`;

    }

    const adminSection = document.getElementById('admin-users-management-section');

    if (adminSection) {

        adminSection.style.display = state.currentUser.rol === 'ADMIN' ? 'block' : 'none';

    }

    document.getElementById('modal-users')?.classList.add('active');

    if (state.currentUser.rol === 'ADMIN') {

        await loadUsersList();

    }

}



function renderUserRowsHtml(users) {

    const currId = state.currentUser?.id;

    return users.map(u => {

        const isSelf = currId && Number(u.id) === Number(currId);

        const empInfo = u.empresa_cif ? ` · <span style="color:var(--text-muted);">${escapeHtml(u.empresa_cif)}</span>` : '';

        return `

            <div style="display:flex; justify-content:space-between; align-items:center; padding:9px 10px; border-bottom:1px solid var(--border); gap:8px; flex-wrap:wrap;">

                <div>

                    <b>${escapeHtml(u.nombre || u.username)}</b>

                    <small style="color:var(--text-muted);">(@${escapeHtml(u.username)}${empInfo})</small>

                </div>

                <div style="display:flex; align-items:center; gap:8px;">

                    <span class="badge-status ${u.rol === 'ADMIN' ? 'status-APROBADO' : 'status-ENVIADO'}" style="font-size:0.75rem;">

                        ${u.rol === 'ADMIN' ? '👤 ADMIN' : '🔧 TÉCNICO'}

                    </span>

                    ${!isSelf ? `<button type="button" class="btn btn-danger-subtle btn-sm" style="padding:3px 8px; font-size:0.75rem;" onclick="deleteBusinessUser(${Number(u.id)}, '${escapeHtml(u.username)}')" title="Dar de baja este usuario">🗑️ Baja</button>` : '<small style="font-size:0.72rem; color:var(--text-muted);">(Tú)</small>'}

                </div>

            </div>

        `;

    }).join('');

}



async function loadUsersList() {

    const modalContainer = document.getElementById('users-list-container');

    const cfgContainer = document.getElementById('config-users-list-container');

    try {

        const res = await fetch('/api/users');

        if (!res.ok) {

            const msg = '<div style="padding:8px; color:var(--text-muted);">Solo administradores pueden gestionar usuarios del negocio.</div>';

            if (modalContainer) modalContainer.innerHTML = msg;

            if (cfgContainer) cfgContainer.innerHTML = msg;

            return;

        }

        const users = await res.json();

        if (!Array.isArray(users) || users.length === 0) {

            const emptyMsg = '<div style="padding:8px; color:var(--text-muted);">Sin usuarios registrados.</div>';

            if (modalContainer) modalContainer.innerHTML = emptyMsg;

            if (cfgContainer) cfgContainer.innerHTML = emptyMsg;

            return;

        }

        const rowsHtml = renderUserRowsHtml(users);

        if (modalContainer) modalContainer.innerHTML = rowsHtml;

        if (cfgContainer) cfgContainer.innerHTML = rowsHtml;

    } catch (e) {

        const errMsg = '<div style="padding:8px; color:var(--danger);">Error cargando lista de usuarios.</div>';

        if (modalContainer) modalContainer.innerHTML = errMsg;

        if (cfgContainer) cfgContainer.innerHTML = errMsg;

    }

}



async function createBusinessUserCommon(username, password, nombre, rol, formToResetId) {

    if (!username || !password || !nombre) return;

    try {

        const res = await fetch('/api/users', {

            method: 'POST',

            headers: { 'Content-Type': 'application/json' },

            body: JSON.stringify({ username, password, nombre, rol })

        });

        if (res.ok) {

            if (formToResetId) document.getElementById(formToResetId)?.reset();

            showToast(`✅ Usuario único @${username.toLowerCase()} (${rol}) creado y vinculado a tu empresa`, 'success');

            await loadUsersList();

        } else {

            const err = await res.json().catch(() => ({}));

            showToast(err.detail || 'Error al crear usuario', 'error');

        }

    } catch (err) {

        showToast('Error de conexión al crear usuario', 'error');

    }

}



async function submitCreateUserForm(e) {

    e.preventDefault();

    const username = document.getElementById('new-user-username')?.value.trim();

    const password = document.getElementById('new-user-password')?.value || '';

    const nombre = document.getElementById('new-user-nombre')?.value.trim();

    const rol = document.getElementById('new-user-rol')?.value || 'TECNICO';

    await createBusinessUserCommon(username, password, nombre, rol, 'create-user-form');

}



async function submitConfigCreateUserForm(e) {

    e.preventDefault();

    const username = document.getElementById('cfg-new-user-username')?.value.trim();

    const password = document.getElementById('cfg-new-user-password')?.value || '';

    const nombre = document.getElementById('cfg-new-user-nombre')?.value.trim();

    const rol = document.getElementById('cfg-new-user-rol')?.value || 'TECNICO';

    await createBusinessUserCommon(username, password, nombre, rol, 'config-create-user-form');

}



async function deleteBusinessUser(userId, username) {

    if (!confirm(`¿Seguro que deseas dar de baja al usuario @${username}?`)) return;

    try {

        const res = await fetch(`/api/users/${userId}`, { method: 'DELETE' });

        if (res.ok) {

            showToast(`🗑️ Usuario @${username} dado de baja`, 'warning');

            await loadUsersList();

        } else {

            const err = await res.json().catch(() => ({}));

            showToast(err.detail || 'No se pudo eliminar el usuario', 'error');

        }

    } catch (e) {

        showToast('Error de red al eliminar usuario', 'error');

    }

}





// =============================================================

// NAVEGACIÓN OCULTA (OFF-CANVAS DRAWER) v3.4.0

// =============================================================

function toggleNavDrawer(forceState) {

    const drawer = document.getElementById('nav-drawer');

    const backdrop = document.getElementById('nav-drawer-backdrop');

    if (!drawer || !backdrop) return;

    const isOpening = forceState !== undefined ? forceState : !drawer.classList.contains('active');

    if (isOpening) {

        drawer.classList.add('active');

        backdrop.classList.add('active');

        drawer.setAttribute('aria-hidden', 'false');

    } else {

        drawer.classList.remove('active');

        backdrop.classList.remove('active');

        drawer.setAttribute('aria-hidden', 'true');

    }

}



function navTo(tabId) {

    switchTab(tabId);

    toggleNavDrawer(false);

    const tabNames = {

        'tab-quotes': 'Presupuestos y Obras',

        'tab-stock': 'Stock y Proveedores',

        'tab-fiscal': 'Fiscalidad Modelo 303',

        'tab-clients': 'Clientes',

        'tab-config': 'Ajustes de Negocio'

    };

    const subtitle = document.getElementById('header-active-section');

    if (subtitle) subtitle.innerText = tabNames[tabId] || 'OfiGremio PRO';

    document.querySelectorAll('.drawer-item').forEach(b => {

        if (b.getAttribute('data-tab') === tabId) b.classList.add('active');

        else b.classList.remove('active');

    });

}



// =============================================================

// CALCULADOR DE MARGEN DE BENEFICIO COMERCIAL INTEGRADO

// =============================================================

function calculateProfitMargin(costeVal, pvpVal) {

    const coste = parseFloat(costeVal) || 0;

    const pvp = parseFloat(pvpVal) || 0;

    if (pvp <= 0) return null;

    const beneficio = pvp - coste;

    const margenComercialPct = (beneficio / pvp) * 100;

    const markupPct = coste > 0 ? (beneficio / coste) * 100 : 100;

    return {

        beneficio: beneficio,

        margenPct: margenComercialPct,

        markupPct: markupPct

    };

}



function updateMarginCalculator(costInputId = 'cat-precio-coste', pvpInputId = 'cat-precio', boxId = 'cat-margin-box') {

    const coste = parseFloat(document.getElementById(costInputId)?.value) || 0;

    const pvp = parseFloat(document.getElementById(pvpInputId)?.value) || 0;

    const box = document.getElementById(boxId);

    if (!box) return;



    if (coste <= 0 && pvp <= 0) {

        box.style.display = 'none';

        return;

    }

    box.style.display = 'block';



    const res = calculateProfitMargin(coste, pvp);

    const badge = document.getElementById('cat-margin-badge');

    const profitEl = document.getElementById('cat-margin-profit');

    const markupEl = document.getElementById('cat-margin-markup');



    if (!res) {

        if (badge) {

            badge.innerText = 'Introduce PVP';

            badge.className = 'margin-badge';

        }

        return;

    }



    if (profitEl) profitEl.innerText = `${res.beneficio >= 0 ? '+' : ''}${res.beneficio.toFixed(2)} € / ud`;

    if (markupEl) markupEl.innerText = `${res.markupPct.toFixed(1)}%`;



    if (badge) {

        badge.innerText = `${res.margenPct.toFixed(1)}% Margen`;

        badge.className = 'margin-badge ' + (

            res.margenPct >= 35 ? 'margin-badge-high' :

            res.margenPct >= 15 ? 'margin-badge-mid' :

            res.margenPct >= 0 ? 'margin-badge-low' : 'margin-badge-neg'

        );

    }

}



function applyMarginPreset(marginPct, costInputId = 'cat-precio-coste', pvpInputId = 'cat-precio') {

    const costInput = document.getElementById(costInputId);

    const pvpInput = document.getElementById(pvpInputId);

    const coste = parseFloat(costInput?.value) || 0;

    if (coste <= 0) {

        showToast('Introduce primero el precio de coste', 'warning');

        costInput?.focus();

        return;

    }

    const targetMargin = marginPct / 100;

    let targetPvp;

    if (targetMargin >= 1) {

        targetPvp = coste * 2;

    } else {

        targetPvp = Math.round((coste / (1 - targetMargin)) * 100) / 100;

    }

    if (pvpInput) {

        pvpInput.value = targetPvp.toFixed(2);

        updateMarginCalculator(costInputId, pvpInputId);

        showToast(`PVP ajustado con ${marginPct}% de margen comercial`, 'success');

    }

}



// Menú desplegable flotante para acciones de fila

function toggleRowDropdown(e, quoteId) {

    e.stopPropagation();

    document.querySelectorAll('.dropdown-menu').forEach(m => {

        if (m.id !== `dropdown-menu-${quoteId}`) m.classList.remove('active');

    });

    const targetMenu = document.getElementById(`dropdown-menu-${quoteId}`);

    if (targetMenu) targetMenu.classList.toggle('active');

}



document.addEventListener('click', () => {

    document.querySelectorAll('.dropdown-menu').forEach(m => m.classList.remove('active'));

});



function parseDec(val, defaultVal = 0) {

    if (val === null || val === undefined) return defaultVal;

    const str = String(val).replace(',', '.').trim();

    const num = parseFloat(str);

    return isNaN(num) ? defaultVal : num;

}



// OfiGremio Express PRO v2.0 — Lógica Frontend Interactiva, Firma Digital y Analítica Fiscal



let state = {

    suppliers: [],

    expenses: [],

    stockAlerts: [],

    stockSummary: {},

    quotes: [],

    clients: [],

    catalog: [],

    analytics: null,

    config: {},

    currentTab: 'tab-quotes',

    quoteFilter: 'ALL',

    quotesViewMode: 'table', // 'table' | 'cards'

    catalogFilter: 'ALL',

    catalogTypeFilter: 'ALL',

    catalogCategoryFilter: 'ALL',

    catalogAlertsOnly: false,

    signatureHasDrawing: false,

    currentPhotoBase64: '',

    previewQuoteId: null,

    previewSigHasDrawing: false

};

window.state = state;



const GUILD_QUICK_KITS = {
    FONTANERIA: [],
    ELECTRICIDAD: []
};



document.addEventListener('DOMContentLoaded', async () => {

    initTheme();

    initSignaturePad('signature-canvas', () => { state.signatureHasDrawing = true; });

    initKeyboardShortcuts();

    initServiceWorker();

    await bootApplicationWithSplash();

});



async function bootApplicationWithSplash() {

    showSplashScreen('Verificando estado de puesta en marcha...', 35);

    try {

        const bootRes = await originalFetch('/api/auth/bootstrap-status', { credentials: 'same-origin' });

        if (bootRes.ok) {

            const bootData = await bootRes.json();

            if (bootData && bootData.needs_initial_setup) {
                showSplashScreen('Iniciando Asistente de Puesta en Marcha...', 85);
                const existingToken = localStorage.getItem('ofigremio_token') || localStorage.getItem('ofigremio_auth_token');
                let hasValidSession = false;
                if (existingToken) {
                    try {
                        const meRes = await originalFetch('/api/auth/me', {
                            headers: { 'Authorization': `Bearer ${existingToken}` },
                            credentials: 'same-origin'
                        });
                        if (meRes.ok) {
                            hasValidSession = true;
                            const meData = await meRes.json();
                            state.currentUser = meData.user || meData;
                        }
                    } catch (e) {
                        hasValidSession = false;
                    }
                }
                if (!hasValidSession) {
                    localStorage.removeItem('ofigremio_token');
                    localStorage.removeItem('ofigremio_auth_token');
                }
                sessionStorage.removeItem('ofigremio_wizard_skipped');
                localStorage.removeItem('ofigremio_wizard_dismissed');

                document.getElementById('modal-login')?.classList.remove('active');

                document.body.classList.remove('auth-locked');

                if (window.WizardController) {

                    window.WizardController.isInitialSetup = true;

                    await window.WizardController.open();

                }

                hideSplashScreen();

                return;

            }

        }

    } catch (e) {

        console.warn('[Bootstrap] Aviso verificando bootstrap-status:', e);

    }



    showSplashScreen('Verificando sesión segura...', 55);

    const authenticated = await initUserRole();

    if (authenticated) {

        showSplashScreen('Cargando datos de tu negocio...', 80);

        await loadAllData();

        document.body.classList.remove('auth-locked');

        hideSplashScreen();

    } else {

        document.body.classList.add('auth-locked');

        hideSplashScreen();

    }

}



// -------------------------------------------------------------

// Tema Oscuro / Modo Sótano y Atajos de Teclado

// -------------------------------------------------------------



function applyRoleUI(user) {

    if (!user) return;

    state.currentUser = user;

    const badge = document.getElementById('user-role-badge');

    if (badge) {

        if (user.rol === 'TECNICO') {

            badge.innerHTML = `🔧 TÉCNICO · ${escapeHtml(user.username)}`;

            badge.className = 'badge-status status-ENVIADO';

        } else {

            badge.innerHTML = `👤 ADMIN · ${escapeHtml(user.username)}`;

            badge.className = 'badge-status status-APROBADO';

        }

    }



    const compBadge = document.getElementById('config-company-binding-badge');

    if (compBadge) {

        const empNom = user.empresa_nombre || state.config?.empresa_nombre || 'Mi Empresa';

        const empCif = user.empresa_cif || state.config?.empresa_cif || '';

        compBadge.innerText = `🏢 ${empNom}${empCif ? ' (' + empCif + ')' : ''}`;

    }



    if (user.rol === 'TECNICO') {

        document.querySelectorAll('[data-tab="tab-fiscal"], [onclick*="tab-fiscal"], #tab-btn-fiscal').forEach(el => el.style.display = 'none');

        document.querySelectorAll('[data-tab="tab-config"], [onclick*="tab-config"], #tab-btn-config').forEach(el => el.style.display = 'none');

        document.querySelectorAll('[onclick*="exportExcel"], [onclick*="exportSalesExcel"], [onclick*="exportExpensesExcel"], [onclick*="downloadBackup"]').forEach(el => el.style.display = 'none');

        document.querySelectorAll('#pill-subview-expenses, #subview-expenses, [onclick*="switchStockSubView(\'expenses\'"]').forEach(el => el.style.display = 'none');

        if (state.currentTab === 'tab-fiscal' || state.currentTab === 'tab-config') {

            navTo('tab-quotes');

        }

    } else {

        document.querySelectorAll('[data-tab="tab-fiscal"], [onclick*="tab-fiscal"], #tab-btn-fiscal').forEach(el => el.style.display = '');

        document.querySelectorAll('[data-tab="tab-config"], [onclick*="tab-config"], #tab-btn-config').forEach(el => el.style.display = '');

        document.querySelectorAll('[onclick*="exportExcel"], [onclick*="exportSalesExcel"], [onclick*="exportExpensesExcel"], [onclick*="downloadBackup"]').forEach(el => el.style.display = '');

        document.querySelectorAll('#pill-subview-expenses').forEach(el => el.style.display = '');

        loadUsersList();

        if (typeof loadBackupsList === 'function') loadBackupsList();

    }

}



async function initUserRole() {

    try {

        const res = await fetch('/api/auth/me');

        if (res.ok) {

            const user = await res.json();

            applyRoleUI(user);

            return true;

        } else {

            state.currentUser = null;

            openLoginModal();

            return false;

        }

    } catch (e) {

        console.warn('Auth role check note:', e);

        openLoginModal();

        return false;

    }

}



function initServiceWorker() {

    if ('serviceWorker' in navigator) {

        navigator.serviceWorker.register('/sw.js', { scope: '/' })

            .catch(() => navigator.serviceWorker.register('/static/sw.js', { scope: '/' }))

            .catch((err) => {

                console.log('SW registration note:', err);

            });

    }

}



function initTheme() {

    const saved = localStorage.getItem('ofigremio_theme') || 'light';

    applyTheme(saved);

}



function toggleTheme() {

    const current = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';

    const next = current === 'dark' ? 'light' : 'dark';

    applyTheme(next);

    localStorage.setItem('ofigremio_theme', next);

    showToast(next === 'dark' ? '🌙 Modo Sótano (Alto Contraste) activado' : '☀️ Modo Día activado', 'success');

}



function applyTheme(theme) {

    const btn = document.getElementById('btn-theme-toggle');

    if (theme === 'dark') {

        document.documentElement.setAttribute('data-theme', 'dark');

        if (btn) btn.innerHTML = '☀️ Modo Día';

    } else {

        document.documentElement.removeAttribute('data-theme');

        if (btn) btn.innerHTML = '🌙 Modo Sótano';

    }

}



function initKeyboardShortcuts() {

    document.addEventListener('keydown', (e) => {

        if (document.body.classList.contains('auth-locked') || !state.currentUser) {

            return;

        }

        if (e.altKey && (e.key === 'n' || e.key === 'N')) {

            e.preventDefault();

            openNewQuoteModal();

        } else if (e.key === 'Escape') {

            document.querySelectorAll('.modal-backdrop.active').forEach(m => {

                if (m.id !== 'modal-login') {

                    m.classList.remove('active');

                }

            });

        }

    });

}



// -------------------------------------------------------------

// Sistema de Notificaciones Toast (Cero alert() bloqueantes)

// -------------------------------------------------------------

function showToast(message, type = 'success') {

    const container = document.getElementById('toast-container');

    if (!container) return;



    const toast = document.createElement('div');

    toast.className = `toast toast-${type}`;

    toast.innerHTML = `

        <span>${message}</span>

        <button class="btn-close" style="color:inherit; font-size:1.1rem;" onclick="this.parentElement.remove()">&times;</button>

    `;

    container.appendChild(toast);



    setTimeout(() => {

        if (toast.parentElement) toast.remove();

    }, 3800);

}



// -------------------------------------------------------------

// Navegación por Pestañas (sin depender de window.event)

// -------------------------------------------------------------

function switchTab(tabId, btnEl) {

    state.currentTab = tabId;

    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));

    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));



    if (btnEl) {

        btnEl.classList.add('active');

    } else {

        const matchBtn = document.querySelector(`.tab-btn[data-tab="${tabId}"]`);

        if (matchBtn) matchBtn.classList.add('active');

    }



    const panel = document.getElementById(tabId);

    if (panel) panel.classList.add('active');

}



// -------------------------------------------------------------

// API: Carga de Datos

// -------------------------------------------------------------

async function loadAllData() {
    checkLicenseStatus(); // Comprobar estado de licencia y suscripción en segundo plano

    const isAdmin = !state.currentUser || state.currentUser.rol === 'ADMIN';

    const tasks = [

        loadConfig(),

        loadClients(),

        loadCatalog(),

        loadQuotes(),

        loadSuppliers(),

        loadExpenses(),

        loadStockSummary()

    ];

    if (isAdmin) {

        tasks.push(loadAnalytics());

    }

    await Promise.all(tasks);

    updateDashboardStats();

}



async function loadConfig() {

    try {

        const res = await fetch('/api/config');

        if (!res.ok) return;

        const data = await res.json();

        if (!data || typeof data !== 'object') return;

        state.config = data;

        window.state.config = state.config;



        document.getElementById('cfg-nombre').value = state.config.empresa_nombre || '';

        document.getElementById('cfg-cif').value = state.config.empresa_cif || '';

        document.getElementById('cfg-telefono').value = state.config.empresa_telefono || '';

        document.getElementById('cfg-email').value = state.config.empresa_email || '';

        document.getElementById('cfg-direccion').value = state.config.empresa_direccion || '';

        document.getElementById('cfg-poblacion').value = state.config.empresa_poblacion || '';

        document.getElementById('cfg-iban').value = state.config.empresa_iban || '';

        document.getElementById('cfg-precio-hora').value = state.config.precio_hora_default || '38.0';

        document.getElementById('cfg-recargo-urgencia').value = state.config.recargo_urgencia_default || '45.0';

        if (document.getElementById('cfg-stock-alerta')) {

            document.getElementById('cfg-stock-alerta').value = state.config.stock_alerta_default || '5';

        }

        if (document.getElementById('cfg-smtp-host')) {

            document.getElementById('cfg-smtp-host').value = state.config.smtp_host || '';

        }

        if (document.getElementById('cfg-smtp-port')) {

            document.getElementById('cfg-smtp-port').value = state.config.smtp_port || '587';

        }

        if (document.getElementById('cfg-smtp-user')) {

            document.getElementById('cfg-smtp-user').value = state.config.smtp_user || '';

        }

        if (document.getElementById('cfg-smtp-pass')) {

            document.getElementById('cfg-smtp-pass').value = state.config.smtp_password || '';

        }

        if (document.getElementById('cfg-verifactu-entorno')) {
            document.getElementById('cfg-verifactu-entorno').value = state.config.verifactu_entorno || 'test';
        }
        if (document.getElementById('cfg-gemini-key')) {
            document.getElementById('cfg-gemini-key').value = state.config.gemini_api_key || '';
        }
        if (typeof loadVerifactuStatus === 'function') {
            loadVerifactuStatus();
        }

        if (!state.currentUser || state.currentUser.rol === 'ADMIN') {

            if (typeof loadBackupsList === 'function') loadBackupsList();

        }



        // Disparar comprobación del asistente de bienvenida con la configuración lista (solo Admin)

        if ((!state.currentUser || state.currentUser.rol === 'ADMIN') && window.WizardController && typeof window.WizardController.checkAutoStart === 'function') {

            window.WizardController.checkAutoStart(state.config);

        }

    } catch (err) {

        console.error('Error cargando configuración:', err);

    }

}



async function loadClients() {

    try {

        const res = await fetch('/api/clients');

        if (!res.ok) return;

        const data = await res.json();

        if (Array.isArray(data)) {

            state.clients = data;

            window.state.clients = state.clients;

            renderClientsTable();

            populateClientSelect();

            updateDashboardStats();

        }

    } catch (err) {

        console.error('Error cargando clientes:', err);

    }

}



async function loadCatalog() {

    try {

        const res = await fetch('/api/catalog');

        if (res.ok) {

            const data = await res.json();

            if (Array.isArray(data)) {

                state.catalog = data;

                window.state.catalog = state.catalog;

                renderCatalogTable();

                renderUserCategories();

                populateCatalogPicker();

                updateDashboardStats();

            }

        }

    } catch (err) {

        console.error('Error cargando catálogo:', err);

    }

}



async function loadQuotes() {

    try {

        const res = await fetch('/api/quotes');

        if (!res.ok) return;

        const data = await res.json();

        if (Array.isArray(data)) {

            state.quotes = data;

            window.state.quotes = state.quotes;

            updateQuotePillCounts();

            renderQuotesView();

            updateDashboardStats();

        }

    } catch (err) {

        console.error('Error cargando presupuestos:', err);

    }

}



async function loadAnalytics() {

    try {

        if (state.currentUser && state.currentUser.rol !== 'ADMIN') return;

        const res = await fetch('/api/analytics');

        if (res.ok) {

            state.analytics = await res.json();

            window.state.analytics = state.analytics;

            renderFiscalDashboard();

            updateDashboardStats();

        }

    } catch (err) {

        console.error('Error cargando analítica fiscal:', err);

    }

}



// -------------------------------------------------------------

// KPIs Superiores y Cuadro Fiscal Modelo 303

// -------------------------------------------------------------

function updateDashboardStats() {

    const kpis = state.analytics?.kpis || {};

    const totalCobrado = kpis.total_facturado_cobrado !== undefined ? kpis.total_facturado_cobrado : state.quotes

        .filter(q => q.estado === 'COBRADO')

        .reduce((sum, q) => sum + (q.total_factura || 0), 0);



    const totalPresupuestado = kpis.total_presupuestado !== undefined ? kpis.total_presupuestado : state.quotes

        .filter(q => q.estado !== 'CANCELADO')

        .reduce((sum, q) => sum + (q.total_factura || 0), 0);



    const numFacturas = (kpis.conteo_por_estado && kpis.conteo_por_estado.COBRADO) || state.quotes.filter(q => q.estado === 'COBRADO').length;

    const numEnCalle = ((kpis.conteo_por_estado?.BORRADOR || 0) + (kpis.conteo_por_estado?.ENVIADO || 0) + (kpis.conteo_por_estado?.APROBADO || 0));



    const elCobrado = document.getElementById('stat-total-facturado');

    if (elCobrado) elCobrado.innerText = `${Number(totalCobrado).toFixed(2)} €`;



    const elPresupuestado = document.getElementById('stat-total-presupuestado');

    if (elPresupuestado) elPresupuestado.innerText = `${Number(totalPresupuestado).toFixed(2)} €`;



    const elFactCount = document.getElementById('stat-facturas-count');

    if (elFactCount) elFactCount.innerText = `${numFacturas} facturas cobradas en caja`;



    const elPendientes = document.getElementById('stat-pendientes');

    if (elPendientes) elPendientes.innerText = `${numEnCalle} presupuestos activos en cartera`;



    // Safe updates for legacy hidden elements

    const elPendienteCobro = document.getElementById('stat-pendiente-cobro');

    if (elPendienteCobro) elPendienteCobro.innerText = `${((kpis.total_aprobado_pendiente || 0) + (kpis.total_en_borrador_enviado || 0)).toFixed(2)} €`;



    const elTicket = document.getElementById('stat-ticket-medio');

    if (elTicket) elTicket.innerText = `${(kpis.ticket_medio || 0).toFixed(2)} €`;



    const elTotalP = document.getElementById('stat-total-presupuestos');

    if (elTotalP) elTotalP.innerText = kpis.total_presupuestos || state.quotes.length;



    const elConv = document.getElementById('stat-conversion-badge');

    if (elConv) elConv.innerText = `${(kpis.tasa_conversion_pct || 0).toFixed(0)}% éxito`;



    const elTotalCli = document.getElementById('stat-total-clientes');

    if (elTotalCli) elTotalCli.innerText = state.clients?.length || 0;



    const elTotalCat = document.getElementById('stat-total-catalogo');

    if (elTotalCat) elTotalCat.innerText = state.catalog?.length || 0;



    // Actualización de alertas de stock en el menú

    const countAlerts = (state.stockAlerts || []).length;

    const badgeNav = document.getElementById('badge-stock-alerts-nav');

    if (badgeNav) {

        badgeNav.innerText = countAlerts;

        badgeNav.style.display = countAlerts > 0 ? 'inline-block' : 'none';

    }

}



function renderFiscalDashboard() {

    if (!state.analytics) return;

    const f = state.analytics.fiscal_trimestral || {};

    const k = state.analytics.kpis || {};



    const setText = (id, val) => {

        const el = document.getElementById(id);

        if (el) el.innerText = val;

    };



    // 1. IVA Repercutido (Ventas)

    setText('fisc-facturas-count', `${f.facturas_emitidas || 0} Facturas`);

    setText('fisc-iva21-base', `${Number(f.iva_21_base || 0).toFixed(2)} €`);

    setText('fisc-iva21-cuota', `+${Number(f.iva_21_cuota || 0).toFixed(2)} €`);

    setText('fisc-iva10-base', `${Number(f.iva_10_base || 0).toFixed(2)} €`);

    setText('fisc-iva10-cuota', `+${Number(f.iva_10_cuota || 0).toFixed(2)} €`);

    setText('fisc-iva-total', `${Number(f.iva_total_repercutido || 0).toFixed(2)} €`);



    // 2. IVA Soportado (Compras a Proveedores)

    const comprasCount = f.compras_facturas ?? f.compras_count ?? 0;

    setText('fisc-compras-count', `${comprasCount} Compras`);

    setText('fisc-iva-sop21-base', `${Number(f.iva_soportado_21_base ?? f.iva_sop21_base ?? 0).toFixed(2)} €`);

    setText('fisc-iva-sop21-cuota', `+${Number(f.iva_soportado_21_cuota ?? f.iva_sop21_cuota ?? 0).toFixed(2)} €`);

    setText('fisc-iva-sop10-base', `${Number(f.iva_soportado_10_base ?? f.iva_sop10_base ?? 0).toFixed(2)} €`);

    setText('fisc-iva-sop10-cuota', `+${Number(f.iva_soportado_10_cuota ?? f.iva_sop10_cuota ?? 0).toFixed(2)} €`);

    setText('fisc-iva-sop-total', `${Number(f.iva_total_soportado ?? f.iva_sop_total ?? 0).toFixed(2)} €`);



    // 3. Liquidación Modelo 303 (IVA)

    const ivaRep = Number(f.iva_total_repercutido || 0);

    const ivaSop = Number(f.iva_total_soportado ?? f.iva_sop_total ?? 0);

    const mod303Res = Number(f.modelo_303_resultado ?? f.mod303_resultado ?? (ivaRep - ivaSop));



    setText('fisc-mod303-rep', `+${ivaRep.toFixed(2)} €`);

    setText('fisc-mod303-sop', `-${ivaSop.toFixed(2)} €`);

    setText('fisc-mod303-resultado', `${mod303Res.toFixed(2)} €`);



    const badge303 = document.getElementById('fisc-mod303-badge');

    if (badge303) {

        if (mod303Res >= 0) {

            badge303.innerText = 'A INGRESAR';

            badge303.className = 'badge-status status-COBRADO';

        } else {

            badge303.innerText = 'A COMPENSAR';

            badge303.className = 'badge-status status-CANCELADO';

        }

    }



    const legend303 = document.getElementById('fisc-mod303-legend');

    if (legend303) {

        if (mod303Res >= 0) {

            legend303.innerText = 'Importe neto estimado a liquidar e ingresar en la declaración trimestral.';

        } else {

            legend303.innerText = 'Saldo a tu favor deducible y compensable en las siguientes liquidaciones.';

        }

    }



    // 4. Rendimiento y Modelo 130 (IRPF)

    const baseTotal = Number(f.base_imponible_total || 0);

    const gastosTotal = Number(f.gastos_base_total ?? f.gastos_total ?? 0);

    const rendimientoNeto = Number(f.rendimiento_neto ?? (baseTotal - gastosTotal));

    const irpfRetenido = Number(f.irpf_total_retenido || 0);

    const mod130Est = Number(f.modelo_130_estimado ?? f.mod130_estimado ?? Math.max(0, (rendimientoNeto * 0.20) - irpfRetenido));



    setText('fisc-base-total', `${baseTotal.toFixed(2)} €`);

    setText('fisc-gastos-total', `${gastosTotal.toFixed(2)} €`);

    setText('fisc-rendimiento-neto', `${rendimientoNeto.toFixed(2)} €`);

    setText('fisc-irpf-total', `-${irpfRetenido.toFixed(2)} €`);

    setText('fisc-mod130-estimado', `${mod130Est.toFixed(2)} €`);

}



// -------------------------------------------------------------

// Pestaña 1: Presupuestos (Filtros, Vista Tabla y Vista Tarjetas)

// -------------------------------------------------------------

function updateQuotePillCounts() {

    const counts = {

        ALL: state.quotes.length,

        BORRADOR: 0,

        ENVIADO: 0,

        APROBADO: 0,

        COBRADO: 0,

        URGENTE: 0

    };

    state.quotes.forEach(q => {

        if (counts[q.estado] !== undefined) counts[q.estado]++;

        if (q.es_urgencia) counts.URGENTE++;

    });



    Object.keys(counts).forEach(k => {

        const el = document.getElementById(`count-${k}`);

        if (el) el.innerText = counts[k];

    });

}



function setQuoteFilter(filterKey, btnEl) {

    state.quoteFilter = filterKey;

    document.querySelectorAll('#quotes-status-pills .pill').forEach(p => p.classList.remove('active'));

    if (btnEl) btnEl.classList.add('active');

    renderQuotesView();

}



function setQuotesViewMode(mode) {

    state.quotesViewMode = mode;

    document.getElementById('btn-view-table').classList.toggle('active', mode === 'table');

    document.getElementById('btn-view-cards').classList.toggle('active', mode === 'cards');

    document.getElementById('quotes-table-wrapper').style.display = mode === 'table' ? 'block' : 'none';

    document.getElementById('quotes-cards-wrapper').style.display = mode === 'cards' ? 'grid' : 'none';

    renderQuotesView();

}



function getFilteredQuotes() {

    const qText = (document.getElementById('quotes-search')?.value || '').toLowerCase().trim();

    return state.quotes.filter(q => {

        if (state.quoteFilter === 'URGENTE') {

            if (!q.es_urgencia) return false;

        } else if (state.quoteFilter !== 'ALL' && q.estado !== state.quoteFilter) {

            return false;

        }



        if (!qText) return true;

        const haystack = [

            q.numero,

            q.numero_factura || '',

            q.cliente_nombre || '',

            q.cliente_nif_cif || '',

            q.cliente_telefono || '',

            q.concepto_averia || ''

        ].join(' ').toLowerCase();

        return haystack.includes(qText);

    });

}



function renderQuotesView() {

    const list = getFilteredQuotes();

    renderQuotesTable(list);

    renderQuotesCards(list);

}



function renderQuotesTable(quotesList) {

    const tbody = document.getElementById('quotes-table-body');

    if (!quotesList || quotesList.length === 0) {

        tbody.innerHTML = `<tr><td colspan="7" class="text-center" style="padding:28px; color:var(--text-muted);">No se encontraron presupuestos con los filtros actuales.</td></tr>`;

        return;

    }



    tbody.innerHTML = quotesList.map(q => {

        const hasSig = q.firma_base64 && q.firma_base64.trim().length > 20;

        const hasPhoto = q.foto_base64 && q.foto_base64.trim().length > 20;

        const hasDiscount = (q.descuento_porcentaje || 0) > 0;

        const hasIrpf = (q.irpf_porcentaje || 0) > 0;

        const anticipo = Number(q.anticipo_importe || 0);

        const pendiente = Number(q.pendiente_cobro ?? ((q.total_factura || 0) - anticipo));

        const isRect = Boolean(q.es_rectificativa);

        const isAdmin = !state.currentUser || state.currentUser.rol === 'ADMIN';



        return `

            <tr>

                <td class="td-nowrap">

                    <b>${escapeHtml(q.numero)}</b>

                    ${q.numero_factura ? `<br><span class="badge-invoice">${isRect ? '🧾 Rectificativa ' : '🧾 '}${escapeHtml(q.numero_factura)}</span>` : ''}

                    ${q.huella_verifactu ? `<br><small style="color:var(--text-muted); font-size:0.7rem;" title="Huella Veri*Factu SHA-256: ${escapeHtml(q.huella_verifactu)}">🔐 Veri*Factu: ${escapeHtml(q.huella_verifactu.slice(0, 10))}…</small>` : ''}
                    ${q.verifactu_estado ? `<span class="badge" style="background:${q.verifactu_estado === 'ACEPTADO' ? '#059669' : '#d97706'}; color:#fff; font-size:0.68rem; padding:1px 5px; border-radius:3px; font-weight:700; margin-left:3px;">${escapeHtml(q.verifactu_estado)}</span>` : ''}
                    ${q.verifactu_csv ? `<br><small style="color:#059669; font-size:0.68rem; font-family:monospace;"><b>CSV:</b> ${escapeHtml(q.verifactu_csv)}</small>` : ''}

                </td>

                <td class="td-nowrap"><small>${escapeHtml((q.fecha || '').split(' ')[0])}</small></td>

                <td class="td-client">

                    <b>${escapeHtml(q.cliente_nombre)}</b>

                    ${q.cliente_nif_cif ? `<small style="color:var(--text-muted);"> (${escapeHtml(q.cliente_nif_cif)})</small>` : ''}<br/>

                    <small style="color:var(--text-muted);">📞 ${escapeHtml(q.cliente_telefono || '-')}${q.cliente_email ? ' · ✉️ ' + escapeHtml(q.cliente_email) : ''}</small>

                </td>

                <td class="td-concept" title="${escapeHtml(q.concepto_averia || '')}">

                    <span class="td-truncate-2">${isRect ? '<b style="color:var(--danger);">[ABONO / RECTIFICATIVA]</b> ' : ''}${q.es_urgencia ? '🚨 <b style="color:var(--danger);">[URGENTE]</b> ' : ''}${escapeHtml(q.concepto_averia)}</span>

                    ${hasSig ? '<span class="badge-signed" title="Firmado digitalmente por el cliente">✍️ Firmado</span>' : ''}

                    ${hasPhoto ? '<span class="badge-signed" title="Incluye evidencia fotográfica">📷 Foto</span>' : ''}

                </td>

                <td class="td-amount">

                    <b style="font-size:1.05rem; ${isRect ? 'color:var(--danger);' : ''}">${(q.total_factura || 0).toFixed(2)} €</b><br/>

                    <small style="color:var(--text-muted);">

                        Base: ${(q.base_imponible || 0).toFixed(2)}€ · IVA ${Math.round((q.iva_porcentaje || 0.21)*100)}%

                        ${hasDiscount ? ` · Dto -${q.descuento_porcentaje}%` : ''}

                        ${hasIrpf ? ` · IRPF -${Math.round(q.irpf_porcentaje*100)}%` : ''}

                    </small>

                    ${anticipo > 0 && !isRect ? `<br><small style="color:#047857; font-weight:600;">Anticipo: -${anticipo.toFixed(2)}€ · Pte: ${pendiente.toFixed(2)}€</small>` : ''}

                </td>

                <td class="td-nowrap">

                    <select onchange="changeStatus(${q.id}, this.value)" class="badge-status status-${escapeHtml(q.estado)}" style="border:none; cursor:pointer;">

                        <option value="BORRADOR" ${q.estado === 'BORRADOR' ? 'selected' : ''}>Borrador</option>

                        <option value="ENVIADO" ${q.estado === 'ENVIADO' ? 'selected' : ''}>Enviado</option>

                        <option value="APROBADO" ${q.estado === 'APROBADO' ? 'selected' : ''}>Aprobado</option>

                        <option value="COBRADO" ${q.estado === 'COBRADO' ? 'selected' : ''}>Cobrado (Factura)</option>

                        <option value="CANCELADO" ${q.estado === 'CANCELADO' ? 'selected' : ''}>Cancelado</option>

                    </select>

                </td>

                <td class="td-actions">

                    <div style="display:flex; gap:6px; align-items:center; justify-content:flex-end;">

                        <a href="/api/quotes/${q.id}/pdf" target="_blank" class="btn btn-secondary-dark btn-sm" title="Descargar PDF Oficial">📄 PDF</a>

                        <button type="button" onclick="openEditQuoteModal(${q.id})" class="btn btn-secondary-dark btn-sm" title="Editar presupuesto">✏️ Editar</button>

                        <div class="dropdown-actions">

                            <button type="button" class="btn-dropdown-trigger" onclick="toggleRowDropdown(event, ${q.id})">Más ▾</button>

                            <div class="dropdown-menu" id="dropdown-menu-${q.id}">

                                <button type="button" class="dropdown-item" onclick="openPreviewModal(${q.id})">Vista y Firma</button>

                                <button type="button" class="dropdown-item" onclick="sendQuoteByEmail(${q.id})">Enviar por Correo</button>

                                <button type="button" class="dropdown-item" onclick="shareWhatsApp(${q.id})">Enviar por WhatsApp</button>

                                <button type="button" class="dropdown-item" onclick="duplicateQuote(${q.id})">Duplicar Presupuesto</button>

                                ${isAdmin && q.estado === 'COBRADO' && !isRect ? `<button type="button" class="dropdown-item" onclick="issueRectifyingInvoice(${q.id})">Emitir Factura Rectificativa</button>` : ''}
                                ${q.numero_factura ? `<button type="button" class="dropdown-item" onclick="downloadVerifactuXml(${q.id})">Descargar XML AEAT</button>` : ''}
                                ${q.numero_factura && q.verifactu_estado !== 'ACEPTADO' ? `<button type="button" class="dropdown-item" onclick="retryVerifactuInvoice(${q.id})">Reintentar Envío AEAT</button>` : ''}

                                <button type="button" class="dropdown-item danger" onclick="deleteQuote(${q.id}, '${escapeHtml(q.numero || '').replace(/'/g, "\\'")}')">Eliminar</button>

                            </div>

                        </div>

                    </div>

                </td>

            </tr>

        `;

    }).join('');

}



function renderQuotesCards(quotesList) {

    const container = document.getElementById('quotes-cards-wrapper');

    if (!container) return;

    if (!quotesList || quotesList.length === 0) {

        container.innerHTML = `<div class="quote-card"><p class="text-center">Sin presupuestos para mostrar.</p></div>`;

        return;

    }



    container.innerHTML = quotesList.map(q => {

        const hasSig = q.firma_base64 && q.firma_base64.trim().length > 20;

        return `

            <div class="quote-card">

                <div class="quote-card-top">

                    <div>

                        <b>${escapeHtml(q.numero)}</b>

                        ${q.numero_factura ? `<span class="badge-invoice">🧾 ${escapeHtml(q.numero_factura)}</span>` : ''}

                        <div style="font-size:0.78rem; color:var(--text-muted);">${escapeHtml((q.fecha || '').split(' ')[0])} · Garantía ${Number(q.garantia_meses || 6)}m</div>

                    </div>

                    <span class="badge-status status-${escapeHtml(q.estado)}">${escapeHtml(q.estado)}</span>

                </div>

                <div>

                    <div style="font-weight:700;">👤 ${escapeHtml(q.cliente_nombre)}</div>

                    <div style="font-size:0.84rem; color:var(--text-muted); margin-top:4px;">

                        ${q.es_urgencia ? '🚨 <b style="color:var(--danger);">[URGENTE]</b> ' : ''}${escapeHtml(q.concepto_averia)}

                    </div>

                </div>

                <div style="display:flex; justify-content:space-between; align-items:center;">

                    <span style="font-size:1.25rem; font-weight:800;">${(q.total_factura || 0).toFixed(2)} €</span>

                    ${hasSig ? '<span class="badge-signed">✍️ Firmado</span>' : '<span style="font-size:0.75rem; color:var(--text-muted);">Pendiente firma</span>'}

                </div>

                <div class="quote-card-actions">

                    <button onclick="openPreviewModal(${q.id})" class="btn-icon">Vista y Firma</button>

                    <button onclick="openEditQuoteModal(${q.id})" class="btn-icon">Editar</button>

                    <button onclick="sendQuoteByEmail(${q.id})" class="btn-icon">Enviar por Correo</button>

                    <a href="/api/quotes/${q.id}/pdf" target="_blank" class="btn-icon">PDF</a>

                    <button onclick="shareWhatsApp(${q.id})" class="btn-action-wa">WhatsApp</button>

                </div>

            </div>

        `;

    }).join('');

}



// -------------------------------------------------------------

// Pestaña 2: Catálogo y Kits por Gremio

// -------------------------------------------------------------

// =============================================================

// CONCEPTOS HABITUALES DINÁMICOS Y PERSONALIZADOS DEL AUTÓNOMO

// =============================================================

function getUserFrequentConcepts() {

    let concepts = [];

    try {

        const saved = JSON.parse(localStorage.getItem('ofigremio_user_concepts') || '[]');

        if (Array.isArray(saved)) concepts = saved;

    } catch (_) {}



    if (state.quotes && Array.isArray(state.quotes)) {

        state.quotes.forEach(q => {

            const c = (q.concepto_averia || '').trim();

            if (c && !concepts.includes(c)) {

                concepts.push(c);

            }

        });

    }

    return concepts.filter(Boolean);

}



function saveUserConcept(concept) {

    if (!concept || !concept.trim()) return;

    concept = concept.trim();

    let concepts = getUserFrequentConcepts();

    if (!concepts.includes(concept)) {

        concepts.unshift(concept);

        if (concepts.length > 40) concepts = concepts.slice(0, 40);

        localStorage.setItem('ofigremio_user_concepts', JSON.stringify(concepts));

    }

    renderUserFrequentConcepts();

}



function applyUserConcept(text) {

    const input = document.getElementById('q-concepto');

    if (input) {

        input.value = text;

        input.focus();

    }

}



function renderUserFrequentConcepts() {

    const concepts = getUserFrequentConcepts();

    const dl = document.getElementById('q-conceptos-datalist');

    if (dl) {

        dl.innerHTML = concepts.map(c => `<option value="${escapeHtml(c)}"></option>`).join('');

    }



    const container = document.getElementById('user-frequent-concepts-bar');

    if (container) {

        if (concepts.length > 0) {

            container.style.display = 'flex';

            container.innerHTML = '<span style="font-size:0.75rem; color:var(--text-muted); font-weight:600; align-self:center; margin-right:4px;">Tus trabajos habituales:</span>' +

                concepts.slice(0, 5).map(c => `<span class="chip" style="cursor:pointer;" onclick="applyUserConcept('${escapeHtml(c)}')">${escapeHtml(c)}</span>`).join('');

        } else {

            container.style.display = 'none';

        }

    }

}



// =============================================================

// CATEGORÍAS LIBRES Y DINÁMICAS DE INVENTARIO

// =============================================================

function getUserCategories() {

    let cats = [];

    try {

        const saved = JSON.parse(localStorage.getItem('ofigremio_user_categories') || '[]');

        if (Array.isArray(saved)) cats = saved;

    } catch (_) {}



    if (state.catalog && Array.isArray(state.catalog)) {

        state.catalog.forEach(item => {

            const g = (item.gremio || '').trim();

            if (g && !cats.includes(g)) {

                cats.push(g);

            }

        });

    }

    return cats.filter(Boolean);

}



function saveUserCategory(cat) {

    if (!cat || !cat.trim()) return;

    cat = cat.trim();

    let cats = getUserCategories();

    if (!cats.includes(cat)) {

        cats.push(cat);

        localStorage.setItem('ofigremio_user_categories', JSON.stringify(cats));

    }

    renderUserCategories();

}



function selectCatPill(cat) {

    const input = document.getElementById('cat-gremio');

    if (input) {

        input.value = cat;

        input.focus();

    }

}



function filterCatalog(gremio, btnEl) {

    state.catalogCategoryFilter = gremio;

    renderCatalogTable();

}



function filterCatalogType(tipo, btnEl) {

    state.catalogTypeFilter = tipo;

    state.catalogAlertsOnly = false;

    const alertPill = document.getElementById('pill-stock-alerts');

    if (alertPill) alertPill.classList.remove('active');

    if (btnEl && btnEl.parentElement) {

        btnEl.parentElement.querySelectorAll('.pill').forEach(p => p.classList.remove('active'));

        btnEl.classList.add('active');

    }

    renderCatalogTable();

}



function filterCatalogAlerts(btnEl) {

    state.catalogAlertsOnly = !state.catalogAlertsOnly;

    if (state.catalogAlertsOnly) {

        btnEl.classList.add('active');

    } else {

        btnEl.classList.remove('active');

    }

    renderCatalogTable();

}



function filterCatalogCategory(cat, btnEl) {

    state.catalogCategoryFilter = cat;

    const container = document.getElementById('catalog-user-category-pills');

    if (container) {

        container.querySelectorAll('.pill').forEach(p => p.classList.remove('active'));

    }

    if (btnEl) btnEl.classList.add('active');

    renderCatalogTable();

}



function renderUserCategories() {

    const cats = getUserCategories();

    

    // 1. Datalist del input de alta de pieza

    const dl = document.getElementById('cat-categories-list');

    if (dl) {

        dl.innerHTML = cats.map(c => `<option value="${escapeHtml(c)}"></option>`).join('');

    }



    // 2. Chips sugeridos bajo el input de alta

    const formPills = document.getElementById('cat-suggested-pills');

    if (formPills) {

        if (cats.length > 0) {

            formPills.innerHTML = '<span style="font-size:0.75rem; color:var(--text-muted); align-self:center;">Sugerencias:</span>' +

                cats.slice(0, 8).map(c => `<button type="button" class="chip" style="font-size:0.75rem; padding:2px 8px;" onclick="selectCatPill('${escapeHtml(c)}')">${escapeHtml(c)}</button>`).join('');

            formPills.style.display = 'flex';

        } else {

            formPills.style.display = 'none';

        }

    }



    // 3. Píldoras de filtro en la barra de stock

    const catContainer = document.getElementById('catalog-category-filter-container');

    const catPills = document.getElementById('catalog-user-category-pills');

    if (catContainer && catPills) {

        if (cats.length > 0) {

            catContainer.style.display = 'block';

            let html = `<button type="button" class="pill ${state.catalogCategoryFilter === 'ALL' ? 'active' : ''}" onclick="filterCatalogCategory('ALL', this)">Todas las Categorías</button>`;

            cats.forEach(c => {

                const count = (state.catalog || []).filter(item => (item.gremio || '').trim().toLowerCase() === c.toLowerCase()).length;

                html += `<button type="button" class="pill ${state.catalogCategoryFilter === c ? 'active' : ''}" onclick="filterCatalogCategory('${escapeHtml(c)}', this)">${escapeHtml(c)} <span style="font-size:0.75rem; opacity:0.8;">(${count})</span></button>`;

            });

            catPills.innerHTML = html;

        } else {

            catContainer.style.display = 'none';

        }

    }

}



function renderCatalogTable() {

    const tbody = document.getElementById('catalog-table-body');

    if (!tbody) return;



    const searchTerm = (document.getElementById('catalog-search')?.value || '').toLowerCase().trim();

    const defaultAlertThreshold = parseFloat(state.config?.stock_alerta_default || 5);



    let list = state.catalog || [];



    // Filtro por Alertas de Stock

    if (state.catalogAlertsOnly) {

        list = list.filter(item => {

            const stock = parseFloat(item.stock_actual ?? 0);

            const minAlert = parseFloat(item.stock_minimo_alerta ?? defaultAlertThreshold);

            return stock <= minAlert;

        });

    }



    // Filtro por Tipo de Partida

    if (state.catalogTypeFilter && state.catalogTypeFilter !== 'ALL') {

        list = list.filter(item => (item.tipo || '').toUpperCase() === state.catalogTypeFilter.toUpperCase());

    }



    // Filtro por Categoría / Familia

    if (state.catalogCategoryFilter && state.catalogCategoryFilter !== 'ALL') {

        list = list.filter(item => (item.gremio || '').trim().toLowerCase() === state.catalogCategoryFilter.toLowerCase());

    }



    // Búsqueda en tiempo real

    if (searchTerm) {

        list = list.filter(item => 

            (item.descripcion || '').toLowerCase().includes(searchTerm) ||

            (item.gremio || '').toLowerCase().includes(searchTerm) ||

            (item.tipo || '').toLowerCase().includes(searchTerm)

        );

    }



    if (list.length === 0) {

        tbody.innerHTML = `<tr><td colspan="7" class="text-center" style="padding:24px; color:var(--text-muted);">No se encontraron partidas ni existencias con este filtro.</td></tr>`;

        return;

    }



    tbody.innerHTML = list.map(item => {

        const stock = parseFloat(item.stock_actual ?? 0);

        const minAlert = parseFloat(item.stock_minimo_alerta ?? defaultAlertThreshold);

        let stockBadge = '';

        if (stock <= 0) {

            stockBadge = `<span class="badge-stock-empty">❌ 0 uds (Agotado)</span>`;

        } else if (stock <= minAlert) {

            stockBadge = `<span class="badge-stock-low">⚠️ ${stock} uds (Bajo)</span>`;

        } else {

            stockBadge = `<span class="badge-stock-ok">✅ ${stock} uds</span>`;

        }



        const catName = escapeHtml(item.gremio || 'General');



        return `

            <tr>

                <td class="td-nowrap"><span class="badge-status status-PAGADO" style="background:var(--bg-input); color:var(--text-main); border:1px solid var(--border); font-size:0.8rem;">🏷️ ${catName}</span></td>

                <td class="td-nowrap"><span class="badge-status status-BORRADOR">${escapeHtml(item.tipo || '')}</span></td>

                <td class="td-desc" title="${escapeHtml(item.descripcion || '')}"><span class="td-truncate-2"><b>${escapeHtml(item.descripcion || '')}</b></span></td>

                <td class="td-nowrap">${stockBadge}</td>

                <td class="td-amount">${Number(item.precio_coste || 0).toFixed(2)} €</td>

                <td class="td-amount"><b style="color:var(--text-main);">${Number(item.precio_unitario || 0).toFixed(2)} €</b></td>

                <td class="td-actions">

                    <div style="display:flex; gap:6px; align-items:center; justify-content:flex-end;">

                        <button class="btn btn-secondary-dark btn-sm" onclick="openStockAdjustModal(${item.id})" title="Ajustar existencias físicas">📦 Ajustar</button>

                        <button class="btn btn-danger-subtle btn-sm" onclick="deleteCatalogItem(${item.id})" title="Eliminar del catálogo">🗑️ Borrar</button>

                    </div>

                </td>

            </tr>

        `;

    }).join('');

}



function populateCatalogPicker() {

    const picker = document.getElementById('q-catalog-picker');

    if (!picker) return;

    const defaultThreshold = parseFloat(state.config?.stock_alerta_default || 5);

    picker.innerHTML = '<option value="">📦 + Elegir pieza del catálogo (con stock en almacén)...</option>' +

        (state.catalog || []).map(c => {

            const stock = parseFloat(c.stock_actual || 0);

            const minAlert = parseFloat(c.stock_minimo_alerta || defaultThreshold);

            let badge = `(Stock: ${stock} uds)`;

            if (stock <= 0) badge = `[⚠️ SIN STOCK]`;

            else if (stock <= minAlert) badge = `[⚠️ Bajo Stock: ${stock} uds]`;

            return `<option value="${c.id}">[${escapeHtml(c.gremio || '')}] ${escapeHtml(c.descripcion || '')} — ${Number(c.precio_unitario || 0).toFixed(2)} € ${badge}</option>`;

        }).join('');

}



async function submitNewCatalogItem(e) {

    e.preventDefault();

    const stockIni = parseFloat(document.getElementById('cat-stock-ini')?.value) || 0;

    const stockMin = parseFloat(document.getElementById('cat-stock-min')?.value) || 5;

    const precioCoste = parseFloat(document.getElementById('cat-precio-coste')?.value) || 0;



    const payload = {

        gremio: (document.getElementById('cat-gremio')?.value || 'General').trim(),

        tipo: document.getElementById('cat-tipo').value,

        descripcion: document.getElementById('cat-descripcion').value.trim(),

        cantidad_default: 1,

        precio_unitario: parseFloat(document.getElementById('cat-precio').value) || 0,

        stock_actual: stockIni,

        stock_minimo_alerta: stockMin,

        precio_coste: precioCoste,

        controla_stock: 1

    };



    try {

        const res = await fetch('/api/catalog', {

            method: 'POST',

            headers: { 'Content-Type': 'application/json' },

            body: JSON.stringify(payload)

        });

        if (res.ok) {

            document.getElementById('cat-descripcion').value = '';

            document.getElementById('cat-precio').value = '';

            if (document.getElementById('cat-precio-coste')) document.getElementById('cat-precio-coste').value = '';

            showToast('🧰 Partida añadida al catálogo y existencias registradas', 'success');

            await Promise.all([loadCatalog(), loadStockSummary()]);

            saveUserCategory(payload.gremio);

            renderUserCategories();

        } else {

            const err = await res.json().catch(() => ({}));

            showToast(err.detail || 'Error al guardar partida en catálogo', 'error');

        }

    } catch (err) {

        showToast('Error al guardar en catálogo', 'error');

    }

}



async function deleteCatalogItem(itemId) {

    try {

        const res = await fetch(`/api/catalog/${itemId}`, { method: 'DELETE' });

        if (res.ok) {

            showToast('Partida eliminada del catálogo', 'warning');

            await Promise.all([loadCatalog(), loadStockSummary()]);

            saveUserCategory(payload.gremio);

            renderUserCategories();

        }

    } catch (err) {

        showToast('Error eliminando partida', 'error');

    }

}



// -------------------------------------------------------------

// Pestaña 4: Clientes (Búsqueda, Creación, Edición e In-Situ)

// -------------------------------------------------------------

function renderClientsTable() {

    const tbody = document.getElementById('clients-table-body');

    if (!tbody) return;



    const search = (document.getElementById('clients-search')?.value || '').toLowerCase().trim();

    const filtered = state.clients.filter(c => {

        if (!search) return true;

        return [c.nombre, c.nif_cif, c.telefono, c.direccion, c.poblacion, c.notas]

            .join(' ')

            .toLowerCase()

            .includes(search);

    });



    if (filtered.length === 0) {

        tbody.innerHTML = `<tr><td colspan="6" class="text-center" style="padding:20px;">No se encontraron clientes.</td></tr>`;

        return;

    }



    const isAdmin = !state.currentUser || state.currentUser.rol === 'ADMIN';

    tbody.innerHTML = filtered.map(c => `

        <tr>

            <td><b>${escapeHtml(c.nombre)}</b><br><small style="color:var(--text-muted);">${escapeHtml(c.email || '')}</small></td>

            <td><code>${escapeHtml(c.nif_cif || '-')}</code></td>

            <td><a href="tel:${escapeHtml(c.telefono)}" style="color:var(--accent); text-decoration:none; font-weight:700;">📞 ${escapeHtml(c.telefono || '-')}</a></td>

            <td>${escapeHtml(c.direccion || '-')} <small>(${escapeHtml(c.poblacion || '')})</small></td>

            <td><small style="color:var(--text-muted);">${escapeHtml(c.notas || '-')}</small></td>

            <td>

                <div style="display:flex; gap:6px; flex-wrap:wrap;">

                    <button class="btn btn-secondary-dark btn-sm" onclick="openEditClientModal(${c.id})" title="Editar cliente">Editar</button>

                    ${isAdmin ? `<button class="btn btn-secondary btn-sm" onclick="exportClientGdpr(${c.id})" title="Exportar portabilidad RGPD (Art. 20)">Exportar Datos RGPD</button>` : ''}
                    ${isAdmin ? `<button class="btn btn-secondary btn-sm" onclick="anonymizeClientGdpr(${c.id})" title="Derecho al olvido / Anonimización compatible con Hacienda (Art. 17 RGPD)">Anonimizar Datos RGPD</button>` : ''}
                    <button class="btn btn-danger-subtle btn-sm" onclick="deleteClient(${c.id})" title="Eliminar cliente">Eliminar</button>
                    <button type="button" class="btn btn-secondary-dark btn-sm" onclick="openWhatsAppModalForClient(${c.id})" style="color:#25d366; font-weight:700;">WhatsApp</button>

                </div>

            </td>

        </tr>

    `).join('');

}



function populateClientSelect(selectedId = null) {

    const select = document.getElementById('q-cliente-id');

    if (!select) return;

    select.innerHTML = '<option value="">-- Selecciona un cliente --</option>' +

        state.clients.map(c => `<option value="${c.id}" ${Number(selectedId) === Number(c.id) ? 'selected' : ''}>${c.nombre} ${c.nif_cif ? '[' + c.nif_cif + ']' : ''} (${c.poblacion || 'Sin pob.'})</option>`).join('');

}



function openNewClientModal() {

    document.getElementById('client-form').reset();

    document.getElementById('c-edit-id').value = '';

    document.getElementById('modal-client-title').innerText = '+ Nuevo Cliente';

    document.getElementById('modal-client').classList.add('active');

}



function openEditClientModal(clientId) {

    const client = state.clients.find(c => c.id === clientId);

    if (!client) return;



    document.getElementById('c-edit-id').value = client.id;

    document.getElementById('c-nombre').value = client.nombre || '';

    document.getElementById('c-nif').value = client.nif_cif || '';

    document.getElementById('c-telefono').value = client.telefono || '';

    document.getElementById('c-email').value = client.email || '';

    document.getElementById('c-direccion').value = client.direccion || '';

    document.getElementById('c-poblacion').value = client.poblacion || '';

    document.getElementById('c-notas').value = client.notas || '';



    document.getElementById('modal-client-title').innerText = `✏️ Editar Cliente #${client.id}`;

    document.getElementById('modal-client').classList.add('active');

}



async function deleteClient(clientId) {

    const c = state.clients.find(x => x.id === clientId);

    if (!c) return;

    if (!confirm(`¿Eliminar al cliente "${c.nombre}"?`)) return;

    try {

        const res = await fetch(`/api/clients/${clientId}`, { method: 'DELETE' });

        if (res.ok) {

            showToast('✅ Cliente eliminado correctamente', 'success');

            await loadClients();

            if (typeof updateDashboardStats === 'function') updateDashboardStats();

        } else {

            const err = await res.json().catch(() => ({}));

            showToast(err.detail || 'No se puede eliminar el cliente', 'error');

        }

    } catch (e) {

        showToast('Error de conexión al eliminar cliente', 'error');

    }

}



async function submitClientForm(e) {

    e.preventDefault();

    const editId = document.getElementById('c-edit-id').value;

    const payload = {

        nombre: document.getElementById('c-nombre').value.trim(),

        nif_cif: document.getElementById('c-nif').value.trim(),

        telefono: document.getElementById('c-telefono').value.trim(),

        email: document.getElementById('c-email').value.trim(),

        direccion: document.getElementById('c-direccion').value.trim(),

        poblacion: document.getElementById('c-poblacion').value.trim(),

        notas: document.getElementById('c-notas').value.trim()

    };



    const url = editId ? `/api/clients/${editId}` : '/api/clients';

    const method = editId ? 'PUT' : 'POST';



    try {

        const res = await fetch(url, {

            method,

            headers: { 'Content-Type': 'application/json' },

            body: JSON.stringify(payload)

        });

        if (res.ok) {

            closeModal('modal-client');

            showToast(editId ? 'Cliente actualizado correctamente' : 'Cliente registrado correctamente', 'success');

            await loadClients();

        } else {

            const err = await res.json().catch(() => ({}));

            showToast(err.detail || 'Error al guardar cliente', 'error');

        }

    } catch (err) {

        showToast('Error guardando cliente', 'error');

    }

}



// Alta de Cliente In-Situ dentro del modal de Presupuesto

function toggleInlineClientBox() {

    const box = document.getElementById('inline-client-box');

    box.style.display = box.style.display === 'none' ? 'block' : 'none';

}



async function saveInlineClient() {

    const nombre = document.getElementById('ic-nombre').value.trim();

    const telefono = document.getElementById('ic-telefono').value.trim();

    if (!nombre || !telefono) {

        showToast('Indica al menos Nombre y Teléfono del cliente', 'warning');

        return;

    }



    const payload = {

        nombre,

        nif_cif: document.getElementById('ic-nif').value.trim(),

        telefono,

        email: document.getElementById('ic-email')?.value.trim() || '',

        direccion: document.getElementById('ic-direccion').value.trim(),

        poblacion: document.getElementById('ic-poblacion').value.trim(),

        notas: 'Creado en obra in-situ'

    };



    try {

        const res = await fetch('/api/clients', {

            method: 'POST',

            headers: { 'Content-Type': 'application/json' },

            body: JSON.stringify(payload)

        });

        if (res.ok) {

            const created = await res.json();

            await loadClients();

            populateClientSelect(created.id);

            document.getElementById('inline-client-box').style.display = 'none';

            ['ic-nombre', 'ic-nif', 'ic-telefono', 'ic-email', 'ic-direccion', 'ic-poblacion'].forEach(id => {

                const el = document.getElementById(id);

                if (el) el.value = '';

            });

            showToast(`Cliente "${nombre}" creado y seleccionado`, 'success');

        } else {

            const err = await res.json().catch(() => ({}));

            showToast(err.detail || 'No se pudo crear el cliente rápido', 'error');

        }

    } catch (err) {

        showToast('Error creando cliente rápido', 'error');

    }

}



// -------------------------------------------------------------

// Acciones sobre Presupuestos: Estado, Duplicar, Eliminar, WhatsApp

// -------------------------------------------------------------

async function shareWhatsApp(quoteId, docType = null) {
    try {
        const query = docType ? `?doc_type=${encodeURIComponent(docType)}` : '';
        const res = await fetch(`/api/quotes/${quoteId}/whatsapp${query}`);
        if (!res.ok) {
            showToast('Error al conectar con WhatsApp', 'error');
            return;
        }
        const data = await res.json();
        const docLabel = data.doc_type === 'factura' ? 'Factura' : 'Presupuesto';
        const docNum = (data.doc_type === 'factura' ? 'Factura_' : 'Presupuesto_') + quoteId;
        const pdfUrl = data.pdf_url || `/api/quotes/${quoteId}/pdf${query}`;

        showToast('📄 Preparando documento PDF para adjuntar...', 'info');

        // Descargar o compartir el PDF oficial como archivo adjunto real
        let sharedAsNativeFile = false;
        try {
            const pdfResp = await fetch(pdfUrl);
            if (pdfResp.ok) {
                const pdfBlob = await pdfResp.blob();
                const pdfFile = new File([pdfBlob], `${docNum}.pdf`, { type: 'application/pdf' });

                // VÍA 1: Web Share API con archivos (Móviles, Tablets y Windows Share)
                // Permite adjuntar físicamente el archivo PDF en WhatsApp con 1 toque
                if (navigator.canShare && navigator.canShare({ files: [pdfFile] })) {
                    await navigator.share({
                        files: [pdfFile],
                        title: `${docLabel} #${quoteId}`,
                        text: data.preformatted_message
                    });
                    sharedAsNativeFile = true;
                    showToast('✅ WhatsApp abierto con el archivo PDF adjunto', 'success');
                    return;
                }

                // VÍA 2: Fallback para WhatsApp Web en ordenador de escritorio:
                // Descargar automáticamente el PDF en el ordenador del usuario para arrastrarlo al chat
                const blobUrl = URL.createObjectURL(pdfBlob);
                const a = document.createElement('a');
                a.href = blobUrl;
                a.download = `${docNum}.pdf`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                setTimeout(() => URL.revokeObjectURL(blobUrl), 10000);
            }
        } catch (pdfErr) {
            console.warn('No se pudo descargar el PDF automáticamente:', pdfErr);
        }

        // Abrir WhatsApp con el mensaje oficial (que ya incluye el enlace oficial de consulta al PDF)
        if (!sharedAsNativeFile && data.whatsapp_url) {
            const win = window.open(data.whatsapp_url, '_blank');
            if (!win) {
                window.location.href = data.whatsapp_url;
            }
            showToast('📎 WhatsApp abierto. El PDF se ha descargado para que lo arrastres al chat.', 'info');
        }
    } catch (err) {
        showToast('Error generando enlace de WhatsApp', 'error');
    }
}

let currentWaClientId = null;

function closeWhatsAppSelectorModal() {
    const modal = document.getElementById('modal-whatsapp-selector');
    if (modal) modal.style.display = 'none';
    currentWaClientId = null;
}

function openWhatsAppModalForClient(clientId) {
    currentWaClientId = clientId;
    const client = (state.clients || []).find(c => c.id === clientId);
    const modal = document.getElementById('modal-whatsapp-selector');
    if (!modal) {
        showToast('Modal de WhatsApp no disponible', 'error');
        return;
    }

    const nameEl = document.getElementById('wa-selector-client-name');
    const phoneEl = document.getElementById('wa-selector-client-phone');
    const listEl = document.getElementById('wa-selector-docs-list');

    const clientName = client ? client.nombre : 'Cliente Desconocido';
    const clientPhone = client && client.telefono ? client.telefono : 'Sin teléfono';

    if (nameEl) nameEl.textContent = clientName;
    if (phoneEl) phoneEl.textContent = `📞 ${clientPhone}`;

    // Filtrar presupuestos de este cliente
    const clientQuotes = (state.quotes || []).filter(q => q.cliente_id === clientId);

    if (!listEl) return;

    if (clientQuotes.length === 0) {
        listEl.innerHTML = `
            <div style="background:#fffbeb; border:1px solid #fef3c7; border-left:4px solid #f59e0b; padding:12px; border-radius:8px; font-size:0.85rem; color:#92400e;">
                Este cliente no tiene presupuestos ni facturas emitidas todavía.
            </div>
            <div style="margin-top:8px;">
                <label style="display:flex; align-items:center; gap:8px; padding:10px; border:1px solid #cbd5e1; border-radius:8px; cursor:pointer;">
                    <input type="radio" name="wa_doc_selection" value="direct_chat" checked>
                    <span>Abrir chat directo de WhatsApp con <b>${escapeHtml(clientPhone)}</b></span>
                </label>
            </div>
        `;
    } else {
        // Generar opciones para cada presupuesto y factura oficial
        let optionsHtml = '';
        clientQuotes.forEach((q, idx) => {
            const isFirst = idx === 0;
            const total = Number(q.total_factura || 0).toFixed(2);
            const num = q.numero || `PRE-${q.id}`;
            const concepto = q.concepto_averia || 'Intervención técnica';
            const numFac = q.numero_factura;
            const estado = (q.estado || '').toUpperCase();
            const hasFactura = estado === 'COBRADO' || Boolean(numFac);

            // Opción Presupuesto
            optionsHtml += `
                <label style="display:flex; align-items:flex-start; gap:10px; padding:12px; border:1px solid #e2e8f0; border-radius:10px; cursor:pointer; background:#ffffff; transition:all 0.2s;" onmouseover="this.style.borderColor='#25d366'" onmouseout="this.style.borderColor='#e2e8f0'">
                    <input type="radio" name="wa_doc_selection" data-quote-id="${q.id}" data-doc-type="presupuesto" value="${q.id}_presupuesto" ${isFirst && !hasFactura ? 'checked' : ''} style="margin-top:3px;">
                    <div style="flex:1;">
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <strong style="color:#0f172a; font-size:0.9rem;">📑 Presupuesto ${escapeHtml(num)}</strong>
                            <span style="font-weight:700; color:#2563eb; font-size:0.9rem;">${total} €</span>
                        </div>
                        <div style="font-size:0.8rem; color:#64748b; margin-top:2px;">${escapeHtml(concepto)}</div>
                        <div style="font-size:0.75rem; color:#059669; margin-top:4px;">Incluye desglose técnico y enlace PDF oficial</div>
                    </div>
                </label>
            `;

            // Opción Factura Oficial si está emitida
            if (hasFactura) {
                const labelFactura = q.es_rectificativa ? 'Factura Rectificativa' : 'Factura Oficial';
                const facNum = numFac || num;
                optionsHtml += `
                    <label style="display:flex; align-items:flex-start; gap:10px; padding:12px; border:1px solid #e2e8f0; border-radius:10px; cursor:pointer; background:#f0fdf4; border-color:#bbf7d0; transition:all 0.2s;" onmouseover="this.style.borderColor='#25d366'" onmouseout="this.style.borderColor='#bbf7d0'">
                        <input type="radio" name="wa_doc_selection" data-quote-id="${q.id}" data-doc-type="factura" value="${q.id}_factura" checked style="margin-top:3px;">
                        <div style="flex:1;">
                            <div style="display:flex; justify-content:space-between; align-items:center;">
                                <strong style="color:#166534; font-size:0.9rem;">🧾 ${labelFactura} ${escapeHtml(facNum)}</strong>
                                <span style="font-weight:700; color:#166534; font-size:0.9rem;">${total} € (COBRADO)</span>
                            </div>
                            <div style="font-size:0.8rem; color:#475569; margin-top:2px;">Ref. Presupuesto ${escapeHtml(num)} — ${escapeHtml(concepto)}</div>
                            <div style="font-size:0.75rem; color:#15803d; margin-top:4px;">Incluye justificante contable y enlace PDF oficial</div>
                        </div>
                    </label>
                `;
            }
        });

        listEl.innerHTML = optionsHtml;
    }

    modal.style.display = 'flex';
}

function executeSelectedWhatsAppDispatch() {
    const selected = document.querySelector('input[name="wa_doc_selection"]:checked');
    if (!selected) {
        showToast('Selecciona un documento para enviar', 'warning');
        return;
    }

    if (selected.value === 'direct_chat') {
        const client = (state.clients || []).find(c => c.id === currentWaClientId);
        const tel = client && client.telefono ? client.telefono.replace(/\D/g, '') : '';
        const fullTel = (tel.length === 9) ? `34${tel}` : tel;
        closeWhatsAppSelectorModal();
        if (fullTel) {
            window.open(`https://wa.me/${fullTel}`, '_blank');
        } else {
            showToast('El cliente no tiene teléfono válido', 'warning');
        }
        return;
    }

    const quoteId = parseInt(selected.getAttribute('data-quote-id'), 10);
    const docType = selected.getAttribute('data-doc-type') || 'auto';
    confirmWhatsAppDispatch(quoteId, docType);
}

async function confirmWhatsAppDispatch(quoteId, docType) {
    try {
        const query = docType ? `?doc_type=${encodeURIComponent(docType)}` : '';
        const res = await fetch(`/api/quotes/${quoteId}/whatsapp${query}`);
        if (!res.ok) {
            showToast('Error al generar enlace de WhatsApp', 'error');
            return;
        }
        const data = await res.json();
        closeWhatsAppSelectorModal();
        if (data.whatsapp_url) {
            const win = window.open(data.whatsapp_url, '_blank');
            if (!win) {
                window.location.href = data.whatsapp_url;
            }
            showToast('Abriendo WhatsApp con enlace oficial al PDF...', 'success');
        }
    } catch (err) {
        showToast('Error comunicando con WhatsApp', 'error');
    }
}



async function changeStatus(quoteId, newStatus) {

    try {

        const res = await fetch(`/api/quotes/${quoteId}/status`, {

            method: 'PATCH',

            headers: { 'Content-Type': 'application/json' },

            body: JSON.stringify({ estado: newStatus })

        });

        if (res.ok) {

            const updated = await res.json();

            if (newStatus === 'COBRADO' && updated.numero_factura) {

                showToast(`🧾 Convertido en Factura Oficial ${updated.numero_factura}`, 'success');

            } else {

                showToast(`Estado actualizado a ${newStatus}`, 'success');

            }

            await Promise.all([loadQuotes(), loadAnalytics()]);

        }

    } catch (err) {

        showToast('Error actualizando estado', 'error');

    }

}



async function duplicateQuote(quoteId) {

    try {

        const res = await fetch(`/api/quotes/${quoteId}/duplicate`, { method: 'POST' });

        if (res.ok) {

            const copy = await res.json();

            showToast(`📋 Duplicado como nuevo borrador ${copy.numero}`, 'success');

            await Promise.all([loadQuotes(), loadAnalytics()]);

        }

    } catch (err) {

        showToast('Error al duplicar presupuesto', 'error');

    }

}



async function deleteQuote(quoteId, numero) {

    try {

        const res = await fetch(`/api/quotes/${quoteId}`, { method: 'DELETE' });

        if (res.ok) {

            showToast(`🗑️ Presupuesto ${numero} eliminado`, 'warning');

            await Promise.all([loadQuotes(), loadAnalytics()]);

        }

    } catch (err) {

        showToast('Error al eliminar presupuesto', 'error');

    }

}



function exportSalesExcel() {

    showToast('📊 Generando Excel de Facturas a Clientes (.xlsx)...', 'success');

    window.location.href = '/api/export/sales-excel';

}



function exportExpensesExcel() {

    showToast('📊 Generando Excel de Facturas de Proveedores (.xlsx)...', 'success');

    window.location.href = '/api/export/expenses-excel';

}



function exportExcel() {

    showToast('📊 Generando libro fiscal Excel (.xlsx)...', 'success');

    window.location.href = '/api/export/excel';

}



function downloadBackup() {

    showToast('💾 Descargando copia de seguridad (.db)...', 'success');

    window.location.href = '/api/backup/download';

}



// -------------------------------------------------------------

// Modal Ultrasónico: Crear y Editar Presupuesto (<30s)

// -------------------------------------------------------------

function openNewQuoteModal() {

    document.getElementById('quote-form').reset();

    document.getElementById('q-edit-id').value = '';

    document.getElementById('modal-quote-title').innerText = 'Crear Presupuesto';

    document.getElementById('btn-save-quote').innerText = 'Guardar y Generar PDF';

    document.getElementById('inline-client-box').style.display = 'none';

    const optExtras = document.getElementById('quote-optional-extras');

    if (optExtras) optExtras.open = false;



    document.getElementById('materials-list').innerHTML = '';

    addMaterialRow();



    document.getElementById('q-precio-hora').value = state.config.precio_hora_default || '38';

    document.getElementById('q-recargo-val').value = state.config.recargo_urgencia_default || '45';

    document.getElementById('q-descuento').value = '0';

    document.getElementById('q-iva-select').value = String(state.config?.iva_default !== undefined ? state.config.iva_default : '0.21');

    document.getElementById('q-irpf-select').value = String(state.config?.irpf_default !== undefined ? state.config.irpf_default : '0.0');

    populateClientSelect();

    document.getElementById('q-garantia-meses').value = '6';

    if (document.getElementById('q-anticipo')) document.getElementById('q-anticipo').value = '0';



    state.currentSignatureBase64 = '';

    clearSignaturePad('signature-canvas');

    clearPhotoAttachment();

    toggleUrgency();

    calculateLiveTotals();

    renderUserFrequentConcepts();

    document.getElementById('modal-quote').classList.add('active');

}



async function openEditQuoteModal(quoteId) {

    try {

        const res = await fetch(`/api/quotes/${quoteId}`);

        if (!res.ok) return;

        const q = await res.json();



        document.getElementById('q-edit-id').value = q.id;

        document.getElementById('modal-quote-title').innerText = `✏️ Editar ${q.numero} ${q.numero_factura ? '(' + q.numero_factura + ')' : ''}`;

        document.getElementById('btn-save-quote').innerText = '💾 Guardar Cambios y Regenerar PDF';



        populateClientSelect(q.cliente_id);

        document.getElementById('q-concepto').value = q.concepto_averia || '';

        document.getElementById('q-es-urgencia').checked = Boolean(q.es_urgencia);

        document.getElementById('q-horas-mo').value = q.horas_mano_obra ?? 1;

        document.getElementById('q-precio-hora').value = q.precio_hora ?? 38;

        document.getElementById('q-recargo-val').value = q.recargo_urgencia ?? 45;

        document.getElementById('q-descuento').value = q.descuento_porcentaje ?? 0;

        const ivaVal = Number(q.iva_porcentaje ?? 0.21);

        const irpfVal = Number(q.irpf_porcentaje ?? 0.0);

        document.getElementById('q-iva-select').value = Math.abs(ivaVal - 0.10) < 0.01 ? '0.10' : '0.21';

        document.getElementById('q-irpf-select').value = irpfVal === 0 ? '0.0' : String(irpfVal);

        document.getElementById('q-garantia-meses').value = String(q.garantia_meses ?? 6);

        if (document.getElementById('q-anticipo')) {

            document.getElementById('q-anticipo').value = Number(q.anticipo_importe || 0).toFixed(2);

        }

        document.getElementById('q-notas-tecnicas').value = q.notas_tecnicas || '';



        // Cargar todas las partidas del presupuesto

        const matContainer = document.getElementById('materials-list');

        matContainer.innerHTML = '';

        const matItems = q.partidas || [];

        if (matItems.length === 0) {

            addMaterialRow();

        } else {

            matItems.forEach(item => addMaterialRow(item.descripcion, item.cantidad, item.precio_unitario));

        }



        // Firma y Foto existentes

        clearSignaturePad('signature-canvas');

        if (q.firma_base64 && q.firma_base64.length > 20) {

            state.currentSignatureBase64 = q.firma_base64;

            drawBase64OnCanvas('signature-canvas', q.firma_base64);

            state.signatureHasDrawing = true;

        } else {

            state.currentSignatureBase64 = '';

        }

        if (q.foto_base64 && q.foto_base64.length > 20) {

            state.currentPhotoBase64 = q.foto_base64;

            document.getElementById('q-foto-preview').src = q.foto_base64;

            document.getElementById('q-foto-preview-wrap').style.display = 'block';

        } else {

            clearPhotoAttachment();

        }



        const optExtras = document.getElementById('quote-optional-extras');

        if (optExtras) {

            const hasExtras = Boolean(

                (q.notas_tecnicas && q.notas_tecnicas.trim()) ||

                (q.firma_base64 && q.firma_base64.length > 20) ||

                (q.foto_base64 && q.foto_base64.length > 20)

            );

            optExtras.open = hasExtras;

        }



        toggleUrgency();

        calculateLiveTotals();

        document.getElementById('modal-quote').classList.add('active');

    } catch (err) {

        showToast('Error cargando presupuesto para editar', 'error');

    }

}



function closeModal(modalId) {

    document.getElementById(modalId).classList.remove('active');

}



function setQuickConcept(text) {

    // Deprecated: sugerencias de averías eliminadas

}



// Dictado por Voz (Web Speech API)

function startVoiceDictation() {

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!SpeechRecognition) {

        showToast('🎙️ Tu navegador no soporta dictado por voz nativo. Usa los chips rápidos.', 'warning');

        return;

    }



    const btn = document.getElementById('btn-voice-dictation');

    const recognition = new SpeechRecognition();

    recognition.lang = 'es-ES';

    recognition.interimResults = false;

    recognition.maxAlternatives = 1;



    btn.classList.add('recording');

    btn.innerText = '🔴 Escuchando...';



    recognition.onresult = (event) => {

        const transcript = event.results[0][0].transcript;

        const input = document.getElementById('q-concepto');

        input.value = input.value ? `${input.value}. ${transcript}` : transcript;

        showToast('🎙️ Descripción transcrita por voz', 'success');

    };



    recognition.onerror = () => {

        showToast('No se pudo capturar el audio', 'warning');

    };



    recognition.onend = () => {

        btn.classList.remove('recording');

        btn.innerText = '🎙️ Dictar por Voz';

    };



    recognition.start();

}



function toggleUrgency() {

    const isUrgent = document.getElementById('q-es-urgencia').checked;

    document.getElementById('group-recargo').style.display = isUrgent ? 'flex' : 'none';

    calculateLiveTotals();

}



function addMaterialRow(desc = '', cant = 1, pu = '', stock = null, catalogoId = null) {

    const container = document.getElementById('materials-list');

    const div = document.createElement('div');

    div.className = 'material-row-wrapper';



    if (stock === null && desc) {

        const match = (state.catalog || []).find(c => c.descripcion.toLowerCase() === desc.toLowerCase());

        if (match) {

            stock = parseFloat(match.stock_actual || 0);

            catalogoId = match.id;

        }

    }



    const hasStock = stock !== null;

    const isOut = hasStock && stock <= 0;

    const isLow = hasStock && !isOut && cant > stock;



    div.innerHTML = `

        <div class="material-row" data-cat-id="${catalogoId || ''}" data-stock="${hasStock ? stock : ''}">

            <input type="text" placeholder="Pieza / Material (ej. Termo 80L, Latiguillo)" class="mat-desc" value="${escapeHtml(desc || '')}" oninput="checkRowStockWarning(this); calculateLiveTotals()" onchange="checkRowStockWarning(this); calculateLiveTotals()">

            <input type="text" inputmode="decimal" placeholder="Cant." class="mat-cant" value="${cant}" oninput="this.value = this.value.replace(',', '.'); checkRowStockWarning(this); calculateLiveTotals()" onchange="this.value = this.value.replace(',', '.'); checkRowStockWarning(this); calculateLiveTotals()">

            <input type="text" inputmode="decimal" placeholder="Precio (€)" class="mat-pu" value="${pu}" oninput="this.value = this.value.replace(',', '.'); calculateLiveTotals()" onchange="this.value = this.value.replace(',', '.'); calculateLiveTotals()">

            <button type="button" class="btn-close" style="color:var(--danger); font-size:1.25rem;" onclick="this.closest('.material-row-wrapper').remove(); calculateLiveTotals();">&times;</button>

        </div>

        <div class="stock-warn-msg" style="${isOut || isLow ? 'display:block;' : 'display:none;'}">

            ${isOut ? '⚠️ Material sin existencias en almacén (se pedirá bajo pedido)' : (isLow ? `⚠️ Solo hay ${stock} uds disponibles en almacén (faltan ${Math.round((cant - stock)*100)/100} a encargar)` : '')}

        </div>

    `;

    container.appendChild(div);

    calculateLiveTotals();

}



function checkRowStockWarning(inputEl) {

    const wrapper = inputEl.closest('.material-row-wrapper');

    if (!wrapper) return;

    const row = wrapper.querySelector('.material-row');

    const desc = row.querySelector('.mat-desc')?.value.trim().toLowerCase();

    let stockStr = row.getAttribute('data-stock');

    if (!stockStr && desc) {

        const match = (state.catalog || []).find(c => c.descripcion.toLowerCase() === desc);

        if (match) {

            stockStr = String(match.stock_actual || 0);

            row.setAttribute('data-stock', stockStr);

            row.setAttribute('data-cat-id', match.id);

        }

    }

    const warnEl = wrapper.querySelector('.stock-warn-msg');

    if (!warnEl || stockStr === '' || stockStr === null) return;



    const stock = parseFloat(stockStr);

    const cant = parseDec(row.querySelector('.mat-cant')?.value, 0);

    if (stock <= 0) {

        warnEl.innerHTML = '⚠️ Material sin existencias en almacén (se pedirá bajo pedido)';

        warnEl.style.display = 'block';

    } else if (cant > stock) {

        warnEl.innerHTML = `⚠️ Solo hay ${stock} uds disponibles en almacén (faltan ${Math.round((cant - stock)*100)/100} a encargar)`;

        warnEl.style.display = 'block';

    } else {

        warnEl.style.display = 'none';

    }

}



function injectGuildKit(gremio) {

    // Deprecated: kits por gremio eliminados

}



function addFromCatalogPicker(selectEl) {

    const id = parseInt(selectEl.value);

    if (!id) return;

    const item = state.catalog.find(c => c.id === id);

    if (item) {

        const rows = document.querySelectorAll('#materials-list .material-row-wrapper');

        if (rows.length === 1 && !rows[0].querySelector('.mat-desc').value.trim()) {

            rows[0].remove();

        }

        const stock = parseFloat(item.stock_actual || 0);

        addMaterialRow(item.descripcion, item.cantidad_default, item.precio_unitario, stock, item.id);

        if (stock <= 0) {

            showToast(`⚠️ "${item.descripcion}" sin existencias en almacén. Añadido bajo pedido.`, 'warning');

        } else if (stock <= (item.stock_minimo_alerta || 5)) {

            showToast(`⚠️ Quedan solo ${stock} uds en almacén de "${item.descripcion}".`, 'warning');

        } else {

            showToast(`Añadido: ${item.descripcion} (${stock} uds en almacén)`, 'success');

        }

    }

    selectEl.value = '';

}



function calculateLiveTotals() {

    const horasMO = parseDec(document.getElementById('q-horas-mo')?.value, 0);

    const precioHora = parseDec(document.getElementById('q-precio-hora')?.value, 0);

    const isUrgent = document.getElementById('q-es-urgencia')?.checked;

    const recargoUrg = isUrgent ? parseDec(document.getElementById('q-recargo-val')?.value, 0) : 0;

    const dtoPct = Math.min(Math.max(parseDec(document.getElementById('q-descuento')?.value, 0), 0), 100);



    const subtotalMO = Math.round(horasMO * precioHora * 100) / 100;



    let subtotalMat = 0;

    document.querySelectorAll('#materials-list .material-row').forEach(row => {

        let cant = parseDec(row.querySelector('.mat-cant')?.value, 0);

        const pu = parseDec(row.querySelector('.mat-pu')?.value, 0);

        if (cant <= 0 && pu > 0) cant = 1;

        subtotalMat += Math.round(cant * pu * 100) / 100;

    });

    subtotalMat = Math.round(subtotalMat * 100) / 100;



    const subtotalBruto = Math.round((subtotalMO + subtotalMat + recargoUrg) * 100) / 100;

    const totalDescuento = Math.round(subtotalBruto * (dtoPct / 100.0) * 100) / 100;

    const baseImponible = Math.max(Math.round((subtotalBruto - totalDescuento) * 100) / 100, 0);



    const ivaPct = parseDec(document.getElementById('q-iva-select')?.value, 0.21);

    const irpfPct = parseDec(document.getElementById('q-irpf-select')?.value, 0.0);



    const totalIVA = Math.round(baseImponible * ivaPct * 100) / 100;

    const totalIRPF = Math.round(baseImponible * irpfPct * 100) / 100;

    const totalGeneral = Math.round((baseImponible + totalIVA - totalIRPF) * 100) / 100;



    const elMo = document.getElementById('live-mo');

    if (elMo) elMo.innerText = `${subtotalMO.toFixed(2)} €`;



    const elMat = document.getElementById('live-mat');

    if (elMat) elMat.innerText = `${subtotalMat.toFixed(2)} €`;



    const elUrg = document.getElementById('live-urgency');

    if (elUrg) elUrg.innerText = `${recargoUrg.toFixed(2)} €`;

    const rowUrg = document.getElementById('live-urgency-row');

    if (rowUrg) rowUrg.style.display = (isUrgent && recargoUrg > 0) ? 'flex' : 'none';



    const elDisc = document.getElementById('live-discount');

    if (elDisc) {

        elDisc.innerText = dtoPct > 0 ? `-${totalDescuento.toFixed(2)} € (${dtoPct}%)` : `0.00 € (0%)`;

    }

    const rowDisc = document.getElementById('live-discount-row');

    if (rowDisc) rowDisc.style.display = dtoPct > 0 ? 'flex' : 'none';



    const elBase = document.getElementById('live-base');

    if (elBase) elBase.innerText = `${baseImponible.toFixed(2)} €`;



    const elIva = document.getElementById('live-iva');

    if (elIva) elIva.innerText = `+${totalIVA.toFixed(2)} € (${Math.round(ivaPct * 100)}%)`;



    const elIrpf = document.getElementById('live-irpf');

    if (elIrpf) {

        elIrpf.innerText = irpfPct > 0 ? `-${totalIRPF.toFixed(2)} € (${Math.round(irpfPct * 100)}%)` : `0.00 € (0%)`;

    }

    const rowIrpf = document.getElementById('live-irpf-row');

    if (rowIrpf) rowIrpf.style.display = irpfPct > 0 ? 'flex' : 'none';



    const elTot = document.getElementById('live-total');

    if (elTot) elTot.innerText = `${totalGeneral.toFixed(2)} €`;



    const anticipoRaw = Math.max(parseDec(document.getElementById('q-anticipo')?.value, 0), 0);

    const anticipoVal = totalGeneral > 0 ? Math.min(anticipoRaw, totalGeneral) : 0;

    const pendienteVal = Math.max(Math.round((totalGeneral - anticipoVal) * 100) / 100, 0);



    const rowAdv = document.getElementById('live-advance-row');

    const elAdv = document.getElementById('live-advance');

    const rowPend = document.getElementById('live-pending-row');

    const elPend = document.getElementById('live-pending');



    if (rowAdv && elAdv && rowPend && elPend) {

        if (anticipoVal > 0) {

            rowAdv.style.display = 'flex';

            elAdv.innerText = `-${anticipoVal.toFixed(2)} €`;

            rowPend.style.display = 'flex';

            elPend.innerText = `${pendienteVal.toFixed(2)} €`;

        } else {

            rowAdv.style.display = 'none';

            rowPend.style.display = 'none';

        }

    }

}



function setQuickAdvancePct(pct) {

    const inp = document.getElementById('q-anticipo');

    if (!inp) return;

    if (pct <= 0) {

        inp.value = '0';

        calculateLiveTotals();

        return;

    }

    const totalText = document.getElementById('live-total')?.innerText || '0';

    const totalVal = parseDec(totalText.replace('€', ''), 0);

    const calcAdv = Math.round(totalVal * (pct / 100.0) * 100) / 100;

    inp.value = calcAdv.toFixed(2);

    calculateLiveTotals();

}



// -------------------------------------------------------------

// Pad de Firma HTML5 Canvas y Compresión de Foto de Evidencia

// -------------------------------------------------------------

function initSignaturePad(canvasId, onDrawCallback) {

    const canvas = document.getElementById(canvasId);

    if (!canvas) return;

    const ctx = canvas.getContext('2d');

    let drawing = false;



    ctx.strokeStyle = '#0F172A';

    ctx.lineWidth = 2.2;

    ctx.lineCap = 'round';



    const getPos = (e) => {

        const rect = canvas.getBoundingClientRect();

        const clientX = e.touches ? e.touches[0].clientX : e.clientX;

        const clientY = e.touches ? e.touches[0].clientY : e.clientY;

        return {

            x: (clientX - rect.left) * (canvas.width / rect.width),

            y: (clientY - rect.top) * (canvas.height / rect.height)

        };

    };



    const start = (e) => {

        drawing = true;

        if (onDrawCallback) onDrawCallback();

        const pos = getPos(e);

        ctx.beginPath();

        ctx.moveTo(pos.x, pos.y);

    };



    const move = (e) => {

        if (!drawing) return;

        if (e.cancelable) e.preventDefault();

        const pos = getPos(e);

        ctx.lineTo(pos.x, pos.y);

        ctx.stroke();

    };



    const end = () => { drawing = false; };



    canvas.addEventListener('mousedown', start);

    canvas.addEventListener('mousemove', move);

    window.addEventListener('mouseup', end);



    canvas.addEventListener('touchstart', start, { passive: false });

    canvas.addEventListener('touchmove', move, { passive: false });

    canvas.addEventListener('touchend', end);

}



function clearSignaturePad(canvasId) {

    const canvas = document.getElementById(canvasId);

    if (!canvas) return;

    const ctx = canvas.getContext('2d');

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (canvasId === 'signature-canvas') state.signatureHasDrawing = false;

    if (canvasId === 'preview-signature-canvas') state.previewSigHasDrawing = false;

}



function drawBase64OnCanvas(canvasId, base64Str) {

    const canvas = document.getElementById(canvasId);

    if (!canvas || !base64Str) return;

    const ctx = canvas.getContext('2d');

    const img = new Image();

    img.onload = () => {

        ctx.clearRect(0, 0, canvas.width, canvas.height);

        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

    };

    img.src = base64Str;

}



function handlePhotoUpload(event) {

    const file = event.target.files[0];

    if (!file) return;



    const reader = new FileReader();

    reader.onload = (e) => {

        const img = new Image();

        img.onload = () => {

            const maxDim = 600;

            let w = img.width;

            let h = img.height;

            if (w > maxDim || h > maxDim) {

                if (w > h) { h = Math.round((h * maxDim) / w); w = maxDim; }

                else { w = Math.round((w * maxDim) / h); h = maxDim; }

            }

            const c = document.createElement('canvas');

            c.width = w;

            c.height = h;

            c.getContext('2d').drawImage(img, 0, 0, w, h);

            state.currentPhotoBase64 = c.toDataURL('image/jpeg', 0.75);

            document.getElementById('q-foto-preview').src = state.currentPhotoBase64;

            document.getElementById('q-foto-preview-wrap').style.display = 'block';

        };

        img.src = e.target.result;

    };

    reader.readAsDataURL(file);

}



function clearPhotoAttachment() {

    state.currentPhotoBase64 = '';

    const input = document.getElementById('q-foto-input');

    if (input) input.value = '';

    const wrap = document.getElementById('q-foto-preview-wrap');

    if (wrap) wrap.style.display = 'none';

}



// -------------------------------------------------------------

// Envío del Formulario de Presupuesto (POST Nuevo / PUT Edición)

// -------------------------------------------------------------

async function submitQuoteForm(e) {

    e.preventDefault();

    const editId = document.getElementById('q-edit-id').value;

    const btn = document.getElementById('btn-save-quote');



    const clienteId = document.getElementById('q-cliente-id').value;

    const concepto = document.getElementById('q-concepto').value.trim();

    saveUserConcept(concepto);



    if (!clienteId || isNaN(parseInt(clienteId))) {

        showToast('⚠️ Debes seleccionar o crear un cliente antes de guardar', 'warning');

        return;

    }

    if (!concepto) {

        showToast('⚠️ Introduce el concepto de la intervención técnica', 'warning');

        return;

    }



    btn.disabled = true;

    btn.innerText = 'Procesando PDF...';

    const esUrgencia = document.getElementById('q-es-urgencia').checked;

    const recargoUrgencia = parseFloat(document.getElementById('q-recargo-val').value) || 0;

    const horasMO = parseFloat(document.getElementById('q-horas-mo').value) || 0;

    const precioHora = parseFloat(document.getElementById('q-precio-hora').value) || 38;

    const descuentoPct = parseFloat(document.getElementById('q-descuento').value) || 0;

    const ivaPct = parseFloat(document.getElementById('q-iva-select').value) || 0.21;

    const irpfPct = parseFloat(document.getElementById('q-irpf-select').value) || 0.0;

    const garantiaMeses = parseInt(document.getElementById('q-garantia-meses').value) || 6;

    const anticipoImporte = Math.max(parseDec(document.getElementById('q-anticipo')?.value, 0), 0);

    const notasTecnicas = document.getElementById('q-notas-tecnicas').value.trim();



    const items = [];

    document.querySelectorAll('#materials-list .material-row').forEach(row => {

        let desc = (row.querySelector('.mat-desc')?.value || '').trim();

        let cant = parseDec(row.querySelector('.mat-cant')?.value, 0);

        const pu = parseDec(row.querySelector('.mat-pu')?.value, 0);

        if (cant <= 0 && (pu > 0 || desc)) cant = 1;

        if (desc || pu > 0) {

            items.push({

                tipo: 'MATERIAL',

                descripcion: desc || 'Material / Partida',

                cantidad: cant,

                precio_unitario: pu

            });

        }

    });



    const sigCanvas = document.getElementById('signature-canvas');

    const firmaBase64 = state.signatureHasDrawing ? sigCanvas.toDataURL('image/png') : '';



    const payload = {

        cliente_id: parseInt(clienteId),

        concepto_averia: concepto,

        es_urgencia: esUrgencia,

        recargo_urgencia: recargoUrgencia,

        horas_mano_obra: horasMO,

        precio_hora: precioHora,

        descuento_porcentaje: descuentoPct,

        iva_porcentaje: ivaPct,

        irpf_porcentaje: irpfPct,

        anticipo_importe: anticipoImporte,

        garantia_meses: garantiaMeses,

        notas_tecnicas: notasTecnicas,

        firma_base64: firmaBase64,

        foto_base64: state.currentPhotoBase64 || '',

        items: items

    };



    const url = editId ? `/api/quotes/${editId}` : '/api/quotes';

    const method = editId ? 'PUT' : 'POST';



    try {

        const res = await fetch(url, {

            method,

            headers: { 'Content-Type': 'application/json' },

            body: JSON.stringify(payload)

        });



        if (res.ok) {

            const saved = await res.json();

            closeModal('modal-quote');

            showToast(editId ? `✅ ${saved.numero} actualizado` : `⚡ Presupuesto ${saved.numero} creado con éxito`, 'success');

            await Promise.all([loadQuotes(), loadAnalytics()]);

            window.open(`/api/quotes/${saved.id}/pdf`, '_blank');

        } else {

            const err = await res.json().catch(() => ({}));

            showToast(err.detail || 'Error al guardar el presupuesto', 'error');

        }

    } catch (err) {

        showToast('Error de conexión con el servidor local', 'error');

    } finally {

        btn.disabled = false;

        btn.innerText = '📄 Guardar y Generar PDF';

    }

}



// -------------------------------------------------------------

// Modal de Vista Rápida y Firma en Obra (1-Click Sign & Approve)

// -------------------------------------------------------------

async function openPreviewModal(quoteId) {

    try {

        const res = await fetch(`/api/quotes/${quoteId}`);

        if (!res.ok) return;

        const q = await res.json();

        state.previewQuoteId = q.id;

        state.previewSigHasDrawing = false;



        document.getElementById('preview-title').innerText = `${q.numero || ''} ${q.numero_factura ? '· ' + q.numero_factura : ''} — ${q.cliente_nombre || ''}`;



        const partidasHtml = (q.partidas || []).map(p => `

            <tr>

                <td><span class="badge-status status-BORRADOR">${escapeHtml(p.tipo || '')}</span> ${escapeHtml(p.descripcion || '')}</td>

                <td>${Number(p.cantidad || 0)}</td>

                <td>${Number(p.precio_unitario || 0).toFixed(2)} €</td>

                <td><b>${Number(p.subtotal || 0).toFixed(2)} €</b></td>

            </tr>

        `).join('');



        const hasSig = q.firma_base64 && q.firma_base64.length > 20;



        document.getElementById('preview-body').innerHTML = `

            <div style="display:flex; justify-content:space-between; flex-wrap:wrap; gap:10px; margin-bottom:14px;">

                <div>

                    <div><b>Cliente:</b> ${escapeHtml(q.cliente_nombre)} ${q.cliente_nif_cif ? '(' + escapeHtml(q.cliente_nif_cif) + ')' : ''}</div>

                    <div><b>Dirección:</b> ${escapeHtml(q.cliente_direccion || '-')} (${escapeHtml(q.cliente_poblacion || '-')})</div>

                    <div><b>Intervención:</b> ${escapeHtml(q.concepto_averia)}</div>

                </div>

                <div style="text-align:right;">

                    <span class="badge-status status-${escapeHtml(q.estado)}">${escapeHtml(q.estado)}</span>

                    <div style="font-size:0.8rem; color:var(--text-muted); margin-top:4px;">Garantía: ${Number(q.garantia_meses || 6)} meses</div>

                </div>

            </div>



            <div class="table-container" style="margin-bottom:14px;">

                <table class="data-table">

                    <thead>

                        <tr><th>Concepto</th><th>Cant.</th><th>P. Unit</th><th>Subtotal</th></tr>

                    </thead>

                    <tbody>${partidasHtml}</tbody>

                </table>

            </div>



            <div class="totals-live-box" style="margin-bottom:14px;">

                <div class="live-row"><span>Mano de obra:</span> <span>${((q.horas_mano_obra || 0) * (q.precio_hora || 0)).toFixed(2)} €</span></div>

                <div class="live-row"><span>Materiales:</span> <span>${(Number(q.subtotal_materiales) || 0).toFixed(2)} €</span></div>

                <div class="live-row"><span>Recargo urgencia:</span> <span>${(Number(q.recargo_urgencia) || 0).toFixed(2)} €</span></div>

                <div class="live-row"><span>Descuento:</span> <span>${(Number(q.descuento_porcentaje) || 0) > 0 ? `-${(Number(q.total_descuento) || 0).toFixed(2)} € (${Number(q.descuento_porcentaje)}%)` : '0.00 € (0%)'}</span></div>

                <div class="live-row" style="font-weight:700;"><span>Base Imponible:</span> <span>${(Number(q.base_imponible) || 0).toFixed(2)} €</span></div>

                <div class="live-row"><span>IVA (${Math.round(((q.iva_porcentaje > 1 ? q.iva_porcentaje / 100 : q.iva_porcentaje) ?? 0.21)*100)}%):</span> <span>+${(Number(q.total_iva) || 0).toFixed(2)} €</span></div>

                <div class="live-row"><span>IRPF (${Math.round(((q.irpf_porcentaje > 1 ? q.irpf_porcentaje / 100 : q.irpf_porcentaje) ?? 0.0)*100)}%):</span> <span>${(Number(q.total_irpf) || 0) > 0 ? `-${(Number(q.total_irpf) || 0).toFixed(2)} €` : '0.00 € (0%)'}</span></div>

                <div class="live-row live-total"><span>TOTAL OFICIAL:</span> <span>${(Number(q.total_factura) || 0).toFixed(2)} €</span></div>

                ${Number(q.anticipo_importe || 0) > 0 && !q.es_rectificativa ? `

                    <div class="live-row" style="color:#047857; font-weight:600;"><span>Anticipo a cuenta:</span> <span>-${Number(q.anticipo_importe || 0).toFixed(2)} €</span></div>

                    <div class="live-row" style="font-weight:700;"><span>Pendiente de abonar:</span> <span>${Number(q.pendiente_cobro ?? ((q.total_factura || 0) - (q.anticipo_importe || 0))).toFixed(2)} €</span></div>

                ` : ''}

                ${q.huella_verifactu ? `

                    <div class="live-row" style="font-size:0.76rem; color:var(--text-muted); margin-top:4px;"><span>🔐 Huella Veri*Factu SHA-256:</span> <code>${escapeHtml(q.huella_verifactu.slice(0, 24))}…</code></div>

                ` : ''}

            </div>



            ${hasSig ? `

                <div class="signature-box">

                    <b>✍️ Parte firmado por el cliente:</b><br>

                    <img src="${q.firma_base64}" alt="Firma del cliente" style="max-height:90px; background:#FFF; border-radius:6px; margin-top:6px; padding:4px;">

                </div>

            ` : `

                <div class="signature-box">

                    <div class="label-row">

                        <label><b>✍️ Recoger Firma del Cliente Ahora (Aprueba el Parte):</b></label>

                        <button type="button" class="btn-link" onclick="clearSignaturePad('preview-signature-canvas')">Borrar</button>

                    </div>

                    <canvas id="preview-signature-canvas" width="420" height="120" class="signature-canvas"></canvas>

                    <small style="display:block; margin-top:4px; font-size:0.72rem; color:var(--text-muted);">

                        🔒 <b>RGPD / LOPDGDD:</b> Responsable: ${escapeHtml(state.config?.empresa_nombre || 'Empresa')} (${escapeHtml(state.config?.empresa_cif || '')}). Finalidad: Gestión del parte de trabajo y facturación legal. Derechos en: ${escapeHtml(state.config?.empresa_email || state.config?.empresa_telefono || '-')}.

                    </small>

                    <button type="button" class="btn btn-primary btn-sm" style="margin-top:8px; width:100%;" onclick="savePreviewSignature(${q.id})">

                        ✅ Guardar Firma y Aprobar Presupuesto

                    </button>

                </div>

            `}

        `;



        const isAdmin = !state.currentUser || state.currentUser.rol === 'ADMIN';

        document.getElementById('preview-footer').innerHTML = `

            <button type="button" class="btn btn-secondary-dark" onclick="closeModal('modal-preview')">Cerrar</button>

            <a href="/api/quotes/${q.id}/pdf" target="_blank" class="btn btn-primary">Abrir PDF Oficial</a>

            <button type="button" class="btn btn-secondary" onclick="sendQuoteByEmail(${q.id})">Enviar por Correo</button>

            <button type="button" class="btn btn-action-wa" style="padding:10px 14px;" onclick="shareWhatsApp(${q.id})">Enviar por WhatsApp</button>

            ${isAdmin && q.estado === 'COBRADO' && !q.es_rectificativa ? `<button type="button" class="btn btn-secondary-dark" onclick="issueRectifyingInvoice(${q.id})">Emitir Factura Rectificativa</button>` : ''}

        `;



        document.getElementById('modal-preview').classList.add('active');



        if (!hasSig) {

            setTimeout(() => {

                initSignaturePad('preview-signature-canvas', () => { state.previewSigHasDrawing = true; });

            }, 60);

        }

    } catch (err) {

        showToast('Error abriendo vista rápida', 'error');

    }

}



async function savePreviewSignature(quoteId) {

    if (!state.previewSigHasDrawing) {

        showToast('Por favor, dibuja la firma en el recuadro antes de guardar', 'warning');

        return;

    }

    const canvas = document.getElementById('preview-signature-canvas');

    const firmaBase64 = canvas.toDataURL('image/png');



    try {

        const res = await fetch(`/api/quotes/${quoteId}/signature`, {

            method: 'POST',

            headers: { 'Content-Type': 'application/json' },

            body: JSON.stringify({ firma_base64: firmaBase64, aprobar: true })

        });

        if (res.ok) {

            showToast('✍️ Firma registrada y presupuesto APROBADO', 'success');

            closeModal('modal-preview');

            await Promise.all([loadQuotes(), loadAnalytics()]);

        }

    } catch (err) {

        showToast('Error guardando la firma digital', 'error');

    }

}



// -------------------------------------------------------------

// Guardar Configuración Fiscal

// -------------------------------------------------------------

async function saveConfig(e) {

    e.preventDefault();

    const payload = {

        empresa_nombre: document.getElementById('cfg-nombre').value.trim(),

        empresa_cif: document.getElementById('cfg-cif').value.trim(),

        empresa_telefono: document.getElementById('cfg-telefono').value.trim(),

        empresa_email: document.getElementById('cfg-email').value.trim(),

        empresa_direccion: document.getElementById('cfg-direccion').value.trim(),

        empresa_poblacion: document.getElementById('cfg-poblacion').value.trim(),

        empresa_iban: document.getElementById('cfg-iban').value.trim(),

        precio_hora_default: document.getElementById('cfg-precio-hora').value,

        recargo_urgencia_default: document.getElementById('cfg-recargo-urgencia').value,

        stock_alerta_default: document.getElementById('cfg-stock-alerta')?.value || '5',

        smtp_host: document.getElementById('cfg-smtp-host')?.value.trim() || '',

        smtp_port: document.getElementById('cfg-smtp-port')?.value.trim() || '587',

        smtp_user: document.getElementById('cfg-smtp-user')?.value.trim() || '',

        smtp_password: document.getElementById('cfg-smtp-pass')?.value || '',
        verifactu_entorno: document.getElementById('cfg-verifactu-entorno')?.value || 'test',
        gemini_api_key: document.getElementById('cfg-gemini-key')?.value.trim() || ''

    };



    try {

        const res = await fetch('/api/config', {

            method: 'POST',

            headers: { 'Content-Type': 'application/json' },

            body: JSON.stringify(payload)

        });

        if (res.ok) {

            showToast('⚙️ Configuración fiscal guardada correctamente', 'success');

            await loadConfig();

        }

    } catch (err) {

        showToast('Error guardando configuración', 'error');

    }

}











// -------------------------------------------------------------

// Lógica de Onboarding de Bienvenida Comercial

// -------------------------------------------------------------

function checkOnboardingStatus() {

    const cfg = state.config || {};

    const isPending = cfg.primera_configuracion_pendiente === "1" || 

                      !cfg.empresa_cif || 

                      cfg.empresa_cif === "B-00000000" || 

                      !cfg.empresa_telefono;

    if (isPending) {

        openOnboardingModal();

    }

}



function openOnboardingModal() {

    const modal = document.getElementById('modal-onboarding');

    if (!modal) return;

    const cfg = state.config || {};

    const inpEmp = document.getElementById('onb-empresa');

    if (inpEmp) inpEmp.value = cfg.empresa_nombre && cfg.empresa_nombre !== "Mi Empresa / Servicio Técnico" ? cfg.empresa_nombre : '';

    const inpCif = document.getElementById('onb-cif');

    if (inpCif) inpCif.value = cfg.empresa_cif && cfg.empresa_cif !== "B-00000000" ? cfg.empresa_cif : '';

    const inpTel = document.getElementById('onb-telefono');

    if (inpTel) inpTel.value = cfg.empresa_telefono || '';

    const inpPob = document.getElementById('onb-poblacion');

    if (inpPob) inpPob.value = cfg.empresa_poblacion || '';

    const inpDir = document.getElementById('onb-direccion');

    if (inpDir) inpDir.value = cfg.empresa_direccion || '';

    const inpIban = document.getElementById('onb-iban');

    if (inpIban) inpIban.value = cfg.empresa_iban || '';

    const inpHora = document.getElementById('onb-precio-hora');

    if (inpHora) inpHora.value = cfg.precio_hora_default || '38';

    const inpUrg = document.getElementById('onb-recargo-urg');

    if (inpUrg) inpUrg.value = cfg.recargo_urgencia_default || '45';



    modal.style.display = 'flex';

}



async function saveOnboardingConfig(e) {

    if (e) e.preventDefault();

    const payload = {

        empresa_nombre: document.getElementById('onb-empresa').value.trim() || 'Mi Empresa',

        empresa_cif: document.getElementById('onb-cif').value.trim() || '00000000-X',

        empresa_telefono: document.getElementById('onb-telefono').value.trim(),

        empresa_poblacion: document.getElementById('onb-poblacion').value.trim(),

        empresa_direccion: document.getElementById('onb-direccion').value.trim(),

        empresa_iban: document.getElementById('onb-iban').value.trim(),

        precio_hora_default: document.getElementById('onb-precio-hora').value || '38',

        recargo_urgencia_default: document.getElementById('onb-recargo-urg').value || '45',

        primera_configuracion_pendiente: '0'

    };



    try {

        const res = await fetch('/api/config', {

            method: 'PUT',

            headers: { 'Content-Type': 'application/json' },

            body: JSON.stringify(payload)

        });

        if (res.ok) {

            state.config = await res.json();

            document.getElementById('modal-onboarding').style.display = 'none';

            showToast('✅ Configuración de negocio guardada con éxito', 'success');

            renderDashboard();

    // checkOnboardingStatus handled by WizardController

        } else {

            showToast('Error al guardar configuración', 'error');

        }

    } catch (err) {

        showToast('Error de conexión', 'error');

    }

}





function renderDashboard() {

    if (typeof updateDashboardStats === 'function') updateDashboardStats();

    if (typeof renderFiscalDashboard === 'function') renderFiscalDashboard();

    if (typeof renderQuotesView === 'function') renderQuotesView();

}





// =============================================================

// SUB-NAVEGACIÓN: STOCK, PROVEEDORES Y GASTOS (v3.0)

// =============================================================

function switchStockSubView(subview, btnEl) {

    const views = ['inventory', 'suppliers', 'expenses'];

    views.forEach(v => {

        const el = document.getElementById(`subview-${v}`);

        if (el) el.style.display = (v === subview) ? 'block' : 'none';

        const pill = document.getElementById(`pill-subview-${v}`);

        if (pill) pill.classList.remove('active');

    });



    if (btnEl) {

        btnEl.classList.add('active');

    } else {

        const targetPill = document.getElementById(`pill-subview-${subview}`);

        if (targetPill) targetPill.classList.add('active');

    }



    if (subview === 'inventory') {

        renderCatalogTable();

        loadStockSummary();

    } else if (subview === 'suppliers') {

        loadSuppliers();

    } else if (subview === 'expenses') {

        loadExpenses();

    }

}



// -------------------------------------------------------------

// STOCK SUMMARY & ALERTAS

// -------------------------------------------------------------

async function loadStockSummary() {

    try {

        const [sumRes, alertsRes] = await Promise.all([

            fetch('/api/stock/summary'),

            fetch('/api/stock/alerts')

        ]);



        if (sumRes.ok) {

            state.stockSummary = await sumRes.json();

            const s = state.stockSummary;

            const elTotal = document.getElementById('stock-kpi-total-items');

            if (elTotal) elTotal.innerText = s.total_articulos ?? 0;

            const elUds = document.getElementById('stock-kpi-unidades');

            if (elUds) elUds.innerText = `${s.unidades_totales ?? 0} unidades en almacén`;

            const elValor = document.getElementById('stock-kpi-valor-coste');

            if (elValor) elValor.innerText = `${Number(s.valor_total_almacen_coste || 0).toFixed(2)} €`;

            const elAgotados = document.getElementById('stock-kpi-agotados');

            if (elAgotados) elAgotados.innerText = s.articulos_sin_existencias ?? 0;

        }



        if (alertsRes.ok) {

            state.stockAlerts = await alertsRes.json();

            const alertCount = state.stockAlerts.length;

            const elAlerts = document.getElementById('stock-kpi-alertas');

            if (elAlerts) elAlerts.innerText = alertCount;

            const elPill = document.getElementById('count-alerts-pill');

            if (elPill) elPill.innerText = alertCount;



            const badgeNav = document.getElementById('badge-stock-alerts-nav');

            if (badgeNav) {

                if (alertCount > 0) {

                    badgeNav.innerText = alertCount;

                    badgeNav.style.display = 'inline-block';

                } else {

                    badgeNav.style.display = 'none';

                }

            }

        }

    } catch (err) {

        console.error('Error cargando KPIs de stock:', err);

    }

}



// -------------------------------------------------------------

// AJUSTE RÁPIDO DE STOCK FÍSICO

// -------------------------------------------------------------

function openStockAdjustModal(catId) {

    const item = (state.catalog || []).find(c => Number(c.id) === Number(catId));

    if (!item) return;



    document.getElementById('adj-cat-id').value = item.id;

    document.getElementById('adj-item-title').innerText = `[${item.gremio}] ${item.descripcion}`;

    document.getElementById('adj-current-stock').innerText = item.stock_actual ?? 0;

    document.getElementById('adj-min-stock').innerText = item.stock_minimo_alerta ?? (state.config?.stock_alerta_default || 5);

    document.getElementById('adj-cantidad').value = '';

    document.getElementById('modal-stock-adjust').classList.add('active');

}



async function submitStockAdjustForm(e) {

    e.preventDefault();

    const catId = parseInt(document.getElementById('adj-cat-id').value);

    const cantidadCambio = parseFloat(document.getElementById('adj-cantidad').value);

    const motivo = document.getElementById('adj-motivo').value;



    if (!catId || isNaN(cantidadCambio) || cantidadCambio === 0) {

        showToast('Introduce una variación válida distinta de 0', 'warning');

        return;

    }



    try {

        const res = await fetch('/api/stock/adjust', {

            method: 'POST',

            headers: { 'Content-Type': 'application/json' },

            body: JSON.stringify({

                catalogo_id: catId,

                cantidad_cambio: cantidadCambio,

                motivo: motivo

            })

        });



        if (res.ok) {

            closeModal('modal-stock-adjust');

            showToast('Existencias actualizadas correctamente', 'success');

            await Promise.all([loadCatalog(), loadStockSummary()]);

            saveUserCategory(payload.gremio);

            renderUserCategories();

        } else {

            const err = await res.json();

            showToast(err.detail || 'Error al ajustar stock', 'error');

        }

    } catch (err) {

        showToast('Error de red al actualizar existencias', 'error');

    }

}



// -------------------------------------------------------------

// PROVEEDORES

// -------------------------------------------------------------

async function loadSuppliers() {

    try {

        const res = await fetch('/api/suppliers');

        if (res.ok) {

            state.suppliers = await res.json();

            window.state.suppliers = state.suppliers;

            renderSuppliersTable();

            populateSupplierSelect();

        }

    } catch (err) {

        console.error('Error cargando proveedores:', err);

    }

}



function renderSuppliersTable() {

    const tbody = document.getElementById('suppliers-table-body');

    if (!tbody) return;



    const searchTerm = (document.getElementById('suppliers-search')?.value || '').toLowerCase().trim();

    let list = state.suppliers || [];



    if (searchTerm) {

        list = list.filter(s =>

            (s.nombre || '').toLowerCase().includes(searchTerm) ||

            (s.cif || '').toLowerCase().includes(searchTerm) ||

            (s.telefono || '').toLowerCase().includes(searchTerm) ||

            (s.poblacion || '').toLowerCase().includes(searchTerm)

        );

    }



    if (list.length === 0) {

        tbody.innerHTML = `<tr><td colspan="7" class="text-center" style="padding:24px; color:var(--text-muted);">No hay proveedores registrados. Haz clic en <b>+ Nuevo Proveedor</b> para dar de alta almacenes y tiendas.</td></tr>`;

        return;

    }



    tbody.innerHTML = list.map(s => `

        <tr>

            <td class="td-supplier"><b>${escapeHtml(s.nombre)}</b></td>

            <td class="td-nowrap"><code>${escapeHtml(s.cif || s.cif_nif || '-')}</code></td>

            <td class="td-nowrap"><a href="tel:${escapeHtml(s.telefono)}" style="color:var(--accent); text-decoration:none; font-weight:700;">📞 ${escapeHtml(s.telefono || '-')}</a></td>

            <td class="td-nowrap">${s.email ? `<a href="mailto:${escapeHtml(s.email)}" style="color:var(--text-muted);">${escapeHtml(s.email)}</a>` : '-'}</td>

            <td class="td-nowrap">${escapeHtml(s.contacto || '-')}</td>

            <td class="td-nowrap">${escapeHtml(s.poblacion || '-')}</td>

            <td class="td-actions">

                <div style="display:flex; gap:6px; align-items:center; justify-content:flex-end;">

                    <button class="btn btn-secondary-dark btn-sm" onclick="openEditSupplierModal(${s.id})" title="Editar proveedor">✏️ Editar</button>

                    <button class="btn btn-danger-subtle btn-sm" onclick="deleteSupplier(${s.id})" title="Eliminar proveedor">🗑️ Borrar</button>

                </div>

            </td>

        </tr>

    `).join('');

}



function populateSupplierSelect(selectedId = null) {

    const sel = document.getElementById('exp-proveedor-id');

    if (!sel) return;

    sel.innerHTML = '<option value="">Selecciona un proveedor habitual...</option>' +

        (state.suppliers || []).map(s => `<option value="${s.id}" ${Number(selectedId) === Number(s.id) ? 'selected' : ''}>${escapeHtml(s.nombre)} ${(s.cif || s.cif_nif) ? '[' + escapeHtml(s.cif || s.cif_nif) + ']' : ''}</option>`).join('');

}



function openNewSupplierModal() {

    document.getElementById('supplier-form').reset();

    document.getElementById('sup-edit-id').value = '';

    document.getElementById('modal-supplier-title').innerText = '🏭 + Nuevo Proveedor';

    document.getElementById('modal-supplier').classList.add('active');

}



function openEditSupplierModal(supId) {

    const sup = (state.suppliers || []).find(s => Number(s.id) === Number(supId));

    if (!sup) return;



    document.getElementById('sup-edit-id').value = sup.id;

    document.getElementById('sup-nombre').value = sup.nombre || '';

    document.getElementById('sup-cif').value = sup.cif || sup.cif_nif || '';

    document.getElementById('sup-telefono').value = sup.telefono || '';

    document.getElementById('sup-email').value = sup.email || '';

    document.getElementById('sup-contacto').value = sup.contacto || '';

    document.getElementById('sup-poblacion').value = sup.poblacion || '';

    document.getElementById('sup-notas').value = sup.notas || '';

    document.getElementById('modal-supplier-title').innerText = `✏️ Editar Proveedor: ${sup.nombre}`;

    document.getElementById('modal-supplier').classList.add('active');

}



async function submitSupplierForm(e) {

    e.preventDefault();

    const editId = document.getElementById('sup-edit-id').value;

    const payload = {

        nombre: document.getElementById('sup-nombre').value.trim(),

        cif: document.getElementById('sup-cif').value.trim(),

        telefono: document.getElementById('sup-telefono').value.trim(),

        email: document.getElementById('sup-email').value.trim(),

        contacto: document.getElementById('sup-contacto').value.trim(),

        poblacion: document.getElementById('sup-poblacion').value.trim(),

        notas: document.getElementById('sup-notas').value.trim()

    };



    try {

        const url = editId ? `/api/suppliers/${editId}` : '/api/suppliers';

        const method = editId ? 'PUT' : 'POST';

        const res = await fetch(url, {

            method: method,

            headers: { 'Content-Type': 'application/json' },

            body: JSON.stringify(payload)

        });



        if (res.ok) {

            closeModal('modal-supplier');

            showToast(editId ? 'Proveedor actualizado' : 'Proveedor creado con éxito', 'success');

            await loadSuppliers();

        } else {

            showToast('Error al guardar proveedor', 'error');

        }

    } catch (err) {

        showToast('Error de red con el proveedor', 'error');

    }

}



async function deleteSupplier(supId) {

    if (!confirm('¿¿Seguro que deseas eliminar este proveedor?')) return;

    try {

        const res = await fetch(`/api/suppliers/${supId}`, { method: 'DELETE' });

        if (res.ok) {

            showToast('Proveedor eliminado', 'warning');

            await loadSuppliers();

        } else {

            showToast('No se pudo eliminar el proveedor', 'error');

        }

    } catch (err) {

        showToast('Error de red al eliminar', 'error');

    }

}



// -------------------------------------------------------------

// COMPRAS Y GASTOS (MODELO 303 Y SUMA DE STOCK)

// -------------------------------------------------------------

async function loadExpenses() {

    try {

        const gremioFilter = document.getElementById('expenses-gremio-filter')?.value || 'ALL';

        const url = gremioFilter && gremioFilter !== 'ALL' ? `/api/expenses?gremio=${gremioFilter}` : '/api/expenses';

        const res = await fetch(url);

        if (res.ok) {

            state.expenses = await res.json();

            window.state.expenses = state.expenses;

            renderExpensesTable();

        }

    } catch (err) {

        console.error('Error cargando compras y gastos:', err);

    }

}



function renderExpensesTable() {

    const tbody = document.getElementById('expenses-table-body');

    if (!tbody) return;



    const list = state.expenses || [];

    if (list.length === 0) {

        tbody.innerHTML = `<tr><td colspan="10" class="text-center" style="padding:24px; color:var(--text-muted);">No hay facturas de compra registradas. Haz clic en <b>+ Registrar Factura Compra</b> para deducir gastos e incorporar existencias.</td></tr>`;

        return;

    }



    tbody.innerHTML = list.map(e => {

        let itemsHtml = `<div style="font-weight:600;">${escapeHtml(e.concepto)}</div>`;

        if (e.items && e.items.length > 0) {

            itemsHtml = e.items.map(it => `

                <div style="font-size:0.83rem; margin-top:2px;">

                    📦 <b>${escapeHtml(it.descripcion)}</b>: <span class="badge-status status-BORRADOR">${it.cantidad} uds</span> @ <b>${Number(it.precio_coste || 0).toFixed(2)} €</b>

                </div>

            `).join('');

        }



        return `

            <tr>

                <td class="td-nowrap">${escapeHtml(e.fecha || '-')}</td>

                <td class="td-nowrap"><b>${escapeHtml(e.numero_factura)}</b></td>

                <td class="td-supplier">

                    <b>${e.proveedor_nombre ? escapeHtml(e.proveedor_nombre) : '<span style="color:var(--text-muted);">Sin Proveedor</span>'}</b><br/>

                    <small style="color:var(--text-muted);">${e.proveedor_cif ? '[' + escapeHtml(e.proveedor_cif) + ']' : ''}</small>

                </td>

                <td class="td-desc">${itemsHtml}</td>

                <td class="td-amount">${Number(e.base_imponible).toFixed(2)} €</td>

                <td class="td-amount" style="color:var(--text-muted);">${Number(e.iva_importe).toFixed(2)} € (${Math.round((e.iva_porcentaje || 0.21) * 100)}%)</td>

                <td class="td-amount"><b style="color:var(--accent);">${Number(e.total).toFixed(2)} €</b></td>

                <td class="td-nowrap"><small>${escapeHtml(e.forma_pago || 'TRANSFERENCIA')}</small></td>

                <td class="td-nowrap"><span class="badge-status ${e.estado === 'PAGADO' ? 'status-COBRADO' : 'status-ENVIADO'}">${escapeHtml(e.estado || 'PAGADO')}</span></td>

                <td class="td-actions">

                    <button class="btn btn-danger-subtle btn-sm" onclick="deleteExpense(${e.id})" title="Eliminar gasto">🗑️ Borrar</button>

                </td>

            </tr>

        `;

    }).join('');

}



function openNewExpenseModal() {

    document.getElementById('expense-form').reset();

    const titleEl = document.getElementById('modal-expense-title');

    if (titleEl) titleEl.innerHTML = '🧾 Guardar Factura de Compra de Proveedor / Vendedor';

    document.getElementById('exp-fecha').value = new Date().toISOString().split('T')[0];

    document.getElementById('exp-iva-pct').value = '0.21';

    document.getElementById('expense-materials-list').innerHTML = '';

    populateSupplierSelect();

    calcExpenseTotals();

    document.getElementById('modal-expense').classList.add('active');

}



function addExpenseMaterialRow() {

    const container = document.getElementById('expense-materials-list');

    const div = document.createElement('div');

    div.className = 'expense-item-row';



    const matCatalog = (state.catalog || []).filter(c => c.tipo === 'MATERIAL');

    const options = matCatalog.map(c => `<option value="${c.id}" data-coste="${c.precio_coste || 0}">[${escapeHtml(c.gremio || '')}] ${escapeHtml(c.descripcion || '')} (Stock actual: ${c.stock_actual || 0})</option>`).join('');



    div.innerHTML = `

        <select class="exp-mat-select" onchange="onExpenseMatSelectChange(this)" required>

            <option value="">Selecciona pieza del catálogo...</option>

            ${options}

        </select>

        <input type="number" step="1" min="1" value="1" placeholder="Uds a sumar" class="exp-mat-cant" oninput="calcExpenseTotals()" title="Cantidad que entra al almacén" required>

        <input type="number" step="0.01" min="0" placeholder="Coste unit. (€)" class="exp-mat-coste" oninput="calcExpenseTotals()" title="Coste unitario sin IVA">

        <button type="button" class="btn-close" style="color:var(--danger);" onclick="this.closest('.expense-item-row').remove(); calcExpenseTotals();">&times;</button>

    `;

    container.appendChild(div);

}



function onExpenseMatSelectChange(selectEl) {

    const row = selectEl.closest('.expense-item-row');

    const selectedOpt = selectEl.options[selectEl.selectedIndex];

    const coste = selectedOpt.getAttribute('data-coste');

    const costeInput = row.querySelector('.exp-mat-coste');

    if (costeInput && coste && parseFloat(coste) > 0) {

        costeInput.value = coste;

    }

    calcExpenseTotals();

}



function calcExpenseTotals() {

    const rows = document.querySelectorAll('.expense-item-row');

    let calculatedBase = 0;

    let hasRows = false;



    rows.forEach(r => {

        const cant = parseFloat(r.querySelector('.exp-mat-cant')?.value) || 0;

        const coste = parseFloat(r.querySelector('.exp-mat-coste')?.value) || 0;

        if (cant > 0 && coste > 0) {

            calculatedBase += (cant * coste);

            hasRows = true;

        }

    });



    const baseInput = document.getElementById('exp-base');

    if (hasRows && (!baseInput.value || parseFloat(baseInput.value) === 0 || document.activeElement !== baseInput)) {

        baseInput.value = calculatedBase.toFixed(2);

    }



    const base = parseFloat(baseInput.value) || 0;

    const ivaPct = parseFloat(document.getElementById('exp-iva-pct').value) || 0.21;

    const total = base * (1 + ivaPct);



    document.getElementById('exp-total').value = total.toFixed(2);

}



async function submitExpenseForm(e) {

    e.preventDefault();

    const rows = document.querySelectorAll('.expense-item-row');

    const items = [];



    rows.forEach(r => {

        const catId = parseInt(r.querySelector('.exp-mat-select')?.value);

        const cant = parseFloat(r.querySelector('.exp-mat-cant')?.value) || 0;

        const coste = parseFloat(r.querySelector('.exp-mat-coste')?.value) || 0;

        if (catId && cant > 0) {

            items.push({

                catalogo_id: catId,

                cantidad: cant,

                precio_coste_unitario: coste

            });

        }

    });



    const payload = {

        numero_factura: document.getElementById('exp-numero').value.trim(),

        proveedor_id: document.getElementById('exp-proveedor-id').value ? parseInt(document.getElementById('exp-proveedor-id').value) : null,

        fecha: document.getElementById('exp-fecha').value,

        concepto: document.getElementById('exp-concepto').value.trim(),

        base_imponible: parseFloat(document.getElementById('exp-base').value) || 0,

        iva_porcentaje: parseFloat(document.getElementById('exp-iva-pct').value) || 0.21,

        total: parseFloat(document.getElementById('exp-total').value) || 0,

        forma_pago: document.getElementById('exp-forma-pago').value,

        estado: document.getElementById('exp-estado').value,

        items: items

    };



    try {

        const res = await fetch('/api/expenses', {

            method: 'POST',

            headers: { 'Content-Type': 'application/json' },

            body: JSON.stringify(payload)

        });



        if (res.ok) {

            closeModal('modal-expense');

            showToast('Factura de gasto registrada y existencias sumadas al stock', 'success');

            await Promise.all([

                loadExpenses(),

                loadCatalog(),

                loadStockSummary(),

                loadAnalytics()

            ]);

        } else {

            const err = await res.json();

            showToast(err.detail || 'Error al registrar gasto', 'error');

        }

    } catch (err) {

        showToast('Error de red al guardar factura de compra', 'error');

    }

}



async function deleteExpense(expId) {

    if (!confirm('¿¿Seguro que deseas eliminar esta factura de compra?')) return;

    try {

        const res = await fetch(`/api/expenses/${expId}`, { method: 'DELETE' });

        if (res.ok) {

            showToast('Factura de gasto eliminada', 'warning');

            await Promise.all([loadExpenses(), loadAnalytics()]);

        } else {

            showToast('No se pudo eliminar el gasto', 'error');

        }

    } catch (err) {

        showToast('Error de red al eliminar', 'error');

    }

}





// =========================================================

// ASISTENTE CHATBOT TECNICO LOCAL (v3.5.0)

// =========================================================

let llmDownloadPollTimer = null;



async function refreshLlmStatusUI() {

    try {

        const res = await fetch('/api/assistant/llm-status');

        if (!res.ok) return;

        const data = await res.json();

        const btn = document.getElementById('btn-download-local-llm');

        const barWrap = document.getElementById('llm-download-bar-wrap');

        const statusTxt = document.getElementById('llm-download-status-text');

        const pctTxt = document.getElementById('llm-download-pct-text');

        const fill = document.getElementById('llm-download-progress-fill');



        const dl = data.download || {};

        const llm = data.llm || {};



        if (dl.status === 'downloading') {

            if (btn) {

                btn.disabled = true;

                btn.innerText = '⏳ Descargando...';

            }

            if (barWrap) barWrap.style.display = 'block';

            if (statusTxt) statusTxt.innerText = dl.message || 'Descargando LLM local...';

            if (pctTxt) pctTxt.innerText = `${dl.progress_pct || 0}%`;

            if (fill) fill.style.width = `${dl.progress_pct || 0}%`;

        } else if (llm.available || dl.status === 'ready') {

            if (llmDownloadPollTimer) {

                clearInterval(llmDownloadPollTimer);

                llmDownloadPollTimer = null;

            }

            if (btn) {

                btn.disabled = false;

                btn.innerText = '✅ LLM Activo';

                btn.title = `Modelo local activo: ${llm.model || dl.model || 'Qwen 2.5'}`;

            }

            if (barWrap) barWrap.style.display = 'none';

        } else if (dl.status === 'fallback_ready') {

            if (llmDownloadPollTimer) {

                clearInterval(llmDownloadPollTimer);

                llmDownloadPollTimer = null;

            }

            if (btn) {

                btn.disabled = false;

                btn.innerText = '✅ Skills Activas';

                btn.title = dl.message || 'Motor de Skills Guiadas activo';

            }

            if (barWrap) barWrap.style.display = 'none';

        }

    } catch (_) {}

}



async function triggerLocalLlmDownload() {

    const barWrap = document.getElementById('llm-download-bar-wrap');

    if (barWrap) barWrap.style.display = 'block';

    try {

        const res = await fetch('/api/assistant/setup-llm', { method: 'POST' });

        if (res.ok) {

            await refreshLlmStatusUI();

            if (llmDownloadPollTimer) clearInterval(llmDownloadPollTimer);

            llmDownloadPollTimer = setInterval(refreshLlmStatusUI, 1200);

        }

    } catch (e) {

        showToast('No se pudo iniciar la descarga del LLM local', 'warning');

    }

}



function toggleAssistantDrawer() {

    const drawer = document.getElementById('assistant-drawer');

    const backdrop = document.getElementById('assistant-backdrop');

    if (!drawer) return;

    

    const isOpen = drawer.classList.contains('active');

    if (isOpen) {

        drawer.classList.remove('active');

        if (backdrop) backdrop.classList.remove('active');

    } else {

        drawer.classList.add('active');

        if (backdrop) backdrop.classList.add('active');

        refreshLlmStatusUI();

        setTimeout(() => {

            const input = document.getElementById('assistant-input');

            if (input) input.focus();

        }, 150);

    }

}



function sendAssistantQuickPrompt(promptText) {

    const input = document.getElementById('assistant-input');

    if (input) {

        input.value = promptText;

        sendAssistantMessage();

    }

}



async function sendAssistantMessage() {

    const input = document.getElementById('assistant-input');

    if (!input) return;

    const msg = input.value.trim();

    if (!msg) return;

    

    input.value = '';

    appendAssistantMessage('user', msg);

    

    // Añadir indicador de pensando

    const messagesBox = document.getElementById('assistant-messages');

    const loadingId = 'bot-loading-' + Date.now();

    if (messagesBox) {

        const loadingDiv = document.createElement('div');

        loadingDiv.className = 'msg-bot';

        loadingDiv.id = loadingId;

        loadingDiv.innerHTML = '<div class="msg-bubble"><i>🤖 Analizando instrucción técnica...</i></div>';

        messagesBox.appendChild(loadingDiv);

        messagesBox.scrollTop = messagesBox.scrollHeight;

    }

    

    try {

        const res = await fetch('/api/assistant/chat', {

            method: 'POST',

            headers: { 'Content-Type': 'application/json' },

            body: JSON.stringify({ message: msg })

        });

        

        // Quitar loading

        const ld = document.getElementById(loadingId);

        if (ld) ld.remove();

        

        if (!res.ok) {

            throw new Error(`HTTP ${res.status}`);

        }

        

        const data = await res.json();

        appendAssistantMessage('bot', data.response || 'Sin respuesta', data.action_data, data.action_taken, data.suggestions, data.ui_action);

        await executeAssistantUiAction(data.ui_action, data.action_data, data.action_taken);

    } catch (err) {

        const ld = document.getElementById(loadingId);

        if (ld) ld.remove();

        appendAssistantMessage('bot', `⚠️ No se pudo procesar la instrucción: ${escapeHtml(err.message)}`);

    }

}



async function executeAssistantUiAction(uiAction, actionData = null, actionTaken = null) {

    // 1. Refrescar datos en vivo según la acción ejecutada en BD

    if (actionTaken === 'quote_created' || actionTaken === 'quote_status_updated') {

        if (typeof loadQuotes === 'function') await loadQuotes();

        if (typeof loadClients === 'function') await loadClients();

        if (typeof loadCatalog === 'function') await loadCatalog();

        if (typeof loadAnalytics === 'function') await loadAnalytics();

    } else if (actionTaken === 'client_created') {

        if (typeof loadClients === 'function') await loadClients();

    } else if (actionTaken === 'catalog_item_created' || actionTaken === 'stock_adjusted') {

        if (typeof loadCatalog === 'function') await loadCatalog();

        if (typeof loadStockSummary === 'function') await loadStockSummary();

    } else if (actionTaken === 'supplier_created') {

        if (typeof loadSuppliers === 'function') await loadSuppliers();

    } else if (actionTaken === 'expense_created') {

        if (typeof loadExpenses === 'function') await loadExpenses();

        if (typeof loadAnalytics === 'function') await loadAnalytics();

    } else if (actionTaken === 'user_created') {

        if (typeof loadUsersList === 'function') await loadUsersList();

    } else if (actionTaken === 'memory_saved') {

        if (typeof loadConfig === 'function') await loadConfig();

    }



    if (!uiAction || !uiAction.type) return;



    switch (uiAction.type) {

        case 'refresh_all':

            if (typeof loadAllData === 'function') await loadAllData();

            if (uiAction.tab && typeof navTo === 'function') {

                navTo(uiAction.tab);

            }

            break;

        case 'navigate_tab':

            if (uiAction.tab && typeof navTo === 'function') {

                navTo(uiAction.tab);

            }

            break;

        case 'open_quote_modal':

            if (uiAction.quote_id) {

                openQuoteFromAssistant(Number(uiAction.quote_id));

            }

            break;

        case 'share_whatsapp':
            if (uiAction.quote_id && typeof shareWhatsApp === 'function') {
                shareWhatsApp(Number(uiAction.quote_id), uiAction.doc_type);
            }
            break;

        case 'send_email':
            if (uiAction.quote_id && typeof sendQuoteByEmail === 'function') {
                sendQuoteByEmail(Number(uiAction.quote_id));
            }
            break;

        case 'download_quote_pdf':

            if (uiAction.quote_id) {

                window.open(`/api/quotes/${Number(uiAction.quote_id)}/pdf`, '_blank');

            }

            break;

        case 'open_modal':

            toggleAssistantDrawer();

            if (uiAction.modal === 'quote' && typeof openNewQuoteModal === 'function') openNewQuoteModal();

            else if (uiAction.modal === 'client' && typeof openNewClientModal === 'function') openNewClientModal();

            else if (uiAction.modal === 'expense' && typeof openNewExpenseModal === 'function') openNewExpenseModal();

            else if (uiAction.modal === 'supplier' && typeof openNewSupplierModal === 'function') openNewSupplierModal();

            break;

        case 'open_wizard':

            toggleAssistantDrawer();

            if (window.WizardController && typeof window.WizardController.open === 'function') {

                window.WizardController.open();

            }

            break;

        case 'export_sales_excel':

            if (typeof exportSalesExcel === 'function') exportSalesExcel();

            else window.location.href = '/api/export/sales-excel';

            break;

        case 'export_expenses_excel':

            if (typeof exportExpensesExcel === 'function') exportExpensesExcel();

            else window.location.href = '/api/export/expenses-excel';

            break;

        case 'export_full_excel':

            if (typeof exportExcel === 'function') exportExcel();

            else window.location.href = '/api/export/excel';

            break;

        case 'download_backup':

            if (typeof downloadBackup === 'function') downloadBackup();

            else window.location.href = '/api/backup/download';

            break;

        default:

            break;

    }

}



function appendAssistantMessage(sender, text, actionData = null, actionTaken = null, suggestions = null, uiAction = null) {

    const box = document.getElementById('assistant-messages');

    if (!box) return;

    

    const wrap = document.createElement('div');

    wrap.className = sender === 'user' ? 'msg-user' : 'msg-bot';

    

    // Defensa XSS: sanitizar texto base antes de convertir formato enriquecido

    const safeText = escapeHtml(text || '');

    const formatted = safeText

        .replace(/\n/g, '<br>')

        .replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')

        .replace(/\*(.+?)\*/g, '<i>$1</i>')

        .replace(/`(.+?)`/g, '<code>$1</code>');

    

    let extraHtml = '';

    if ((actionTaken === 'quote_created' || actionTaken === 'quote_status_updated') && actionData && actionData.quote_id) {

        const qid = Number(actionData.quote_id);

        const docLabel = actionData.numero_factura ? `Factura Oficial ${escapeHtml(actionData.numero_factura)}` : `Presupuesto #${escapeHtml(actionData.numero || qid)}`;

        extraHtml = `

            <div class="assistant-card">

                <div class="assistant-card-title">📄 ${docLabel}</div>

                <div style="font-size:0.85rem; margin-bottom:4px;"><b>Cliente:</b> ${escapeHtml(actionData.cliente || 'Cliente')}</div>

                <div style="font-size:0.85rem; margin-bottom:8px;"><b>Total con IVA:</b> ${formatCurrency(actionData.total)}</div>

                <div style="display:flex; gap:6px; flex-wrap:wrap;">

                    <button class="btn btn-primary btn-sm" style="flex:1;" onclick="openQuoteFromAssistant(${qid})">📂 Abrir / Editar</button>

                    <button class="btn btn-secondary btn-sm" style="flex:1;" onclick="window.open('/api/quotes/${qid}/pdf', '_blank')">📄 Descargar PDF</button>

                </div>

            </div>

        `;

    }



    let chipsHtml = '';

    if (suggestions && Array.isArray(suggestions) && suggestions.length > 0) {

        chipsHtml = `<div class="assistant-msg-chips" style="display:flex; flex-wrap:wrap; gap:6px; margin-top:10px;">` +

            suggestions.map(s => {

                const safeAttr = escapeHtml(s).replace(/'/g, "\\'");

                return `<button class="chip-item" style="font-size:0.75rem; padding:4px 10px; cursor:pointer;" onclick="sendAssistantQuickPrompt('${safeAttr}')">${escapeHtml(s)}</button>`;

            }).join('') +

            `</div>`;

    }

    

        let uiActionHtml = '';
    if (uiAction && uiAction.tab && uiAction.label) {
        uiActionHtml = `
            <div style="margin-top:10px;">
                <button class="btn btn-secondary btn-sm" onclick="navTo('${escapeHtml(uiAction.tab)}'); toggleAssistantDrawer();" style="display:inline-flex; align-items:center; gap:6px; font-weight:700; width:100%; justify-content:center; padding:7px 12px; background:var(--bg-card); border:1px solid var(--border); border-radius:6px; cursor:pointer;">
                    ${escapeHtml(uiAction.label)}
                </button>
            </div>
        `;
    }

    wrap.innerHTML = `<div class="msg-bubble">${formatted}${extraHtml}${uiActionHtml}${chipsHtml}</div>`;

    box.appendChild(wrap);

    box.scrollTop = box.scrollHeight;

}



function openQuoteFromAssistant(quoteId) {

    toggleAssistantDrawer();

    if (typeof navTo === 'function') {

        navTo('tab-quotes');

    } else if (typeof showTab === 'function') {

        showTab('tab-quotes');

    }

    if (typeof openEditQuoteModal === 'function') {

        openEditQuoteModal(quoteId);

    } else if (typeof editQuote === 'function') {

        editQuote(quoteId);

    }

}



// =============================================================

// V4.0: ENVÍO POR CORREO, FACTURAS RECTIFICATIVAS Y ESCUDO SAGRADO DB

// =============================================================



async function sendQuoteByEmail(quoteId) {

    try {

        const q = (state.quotes || []).find(x => Number(x.id) === Number(quoteId));

        let emailDestino = (q && q.cliente_email) ? q.cliente_email.trim() : '';



        if (!emailDestino) {

            const entered = prompt('El cliente aún no tiene correo electrónico vinculado.\nIntroduce el correo electrónico del cliente para enviarle el documento (quedará guardado automáticamente en su ficha):', '');

            if (entered === null) return;

            emailDestino = entered.trim();

            if (!emailDestino) {

                showToast('Introduce un correo electrónico válido para continuar', 'warning');

                return;

            }

        }



        const res = await fetch(`/api/quotes/${quoteId}/send-email`, {

            method: 'POST',

            headers: { 'Content-Type': 'application/json' },

            body: JSON.stringify({ email_destino: emailDestino })

        });



        if (!res.ok) {

            const err = await res.json().catch(() => ({}));

            showToast(err.detail || 'Error al preparar el envío por correo', 'error');

            return;

        }



        const data = await res.json();

        await Promise.all([loadQuotes(), loadClients()]);



        if (data.sent_via_smtp) {

            showToast(data.message || `Correo enviado con PDF adjunto a ${data.to_email}`, 'success');

        } else if (data.mailto_url) {

            // Descarga preventiva automática del PDF para facilitar adjuntarlo en el gestor local
            try {
                const pdfResp = await fetch(`/api/quotes/${quoteId}/pdf`);
                if (pdfResp.ok) {
                    const blob = await pdfResp.blob();
                    const blobUrl = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = blobUrl;
                    const docNumSafe = (q && (q.numero_factura || q.numero)) ? String(q.numero_factura || q.numero).replace(/[^A-Za-z0-9_-]/g, '_') : `Documento_${quoteId}`;
                    a.download = `${docNumSafe}.pdf`;
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    setTimeout(() => URL.revokeObjectURL(blobUrl), 10000);
                }
            } catch (e) {
                console.warn('Error descargando PDF para mailto:', e);
            }

            showToast(`📧 Gestor de correo abierto. El PDF oficial se ha descargado en tu equipo listo para adjuntar.`, 'info');

            window.location.href = data.mailto_url;

        }

    } catch (err) {

        showToast('Error al procesar el envío por correo electrónico', 'error');

    }

}



async function issueRectifyingInvoice(quoteId) {

    const q = (state.quotes || []).find(x => Number(x.id) === Number(quoteId));

    const numLabel = (q && (q.numero_factura || q.numero)) || `#${quoteId}`;

    const motivo = prompt(

        `Emitir Factura Rectificativa (Abono Oficial) para la factura ${numLabel}.\n\nIndica el motivo de la rectificación (se generará una factura negativa serie REC- vinculada fiscalmente):`,

        'Rectificación / Abono de factura por ajuste comercial o devolución'

    );

    if (motivo === null) return;



    try {

        const res = await fetch(`/api/quotes/${quoteId}/rectify`, {

            method: 'POST',

            headers: { 'Content-Type': 'application/json' },

            body: JSON.stringify({ motivo: motivo.trim() || 'Rectificación de factura oficial' })

        });

        if (res.ok) {

            const created = await res.json();

            closeModal('modal-preview');

            showToast(`Factura Rectificativa ${created.numero_factura} emitida correctamente`, 'success');

            await Promise.all([loadQuotes(), loadAnalytics()]);

            if (typeof loadBackupsList === 'function') loadBackupsList();

            window.open(`/api/quotes/${created.id}/pdf`, '_blank');

        } else {

            const err = await res.json().catch(() => ({}));

            showToast(err.detail || 'No se pudo emitir la factura rectificativa', 'error');

        }

    } catch (err) {

        showToast('Error de conexión al emitir factura rectificativa', 'error');

    }

}



async function loadBackupsList() {

    if (state.currentUser && state.currentUser.rol !== 'ADMIN') return;

    if (typeof loadSecurityAuditLogs === 'function') loadSecurityAuditLogs();

    const container = document.getElementById('db-backups-list-container');

    const pathEl = document.getElementById('db-shield-path');

    if (!container) return;



    try {

        const res = await fetch('/api/backup/list');

        if (!res.ok) return;

        const data = await res.json();

        if (pathEl && data.db_path) {

            pathEl.innerText = data.db_path;

        }

        const backups = data.backups || [];

        if (backups.length === 0) {

            container.innerHTML = `<div class="text-center" style="padding:10px; color:var(--text-muted);">Aún no hay puntos de restauración guardados.</div>`;

            return;

        }



        container.innerHTML = backups.map(b => {

            const safeFile = escapeHtml(b.filename || '').replace(/'/g, "\\'");

            return `

                <div style="display:flex; justify-content:space-between; align-items:center; padding:8px 10px; border-bottom:1px solid var(--border); gap:10px; flex-wrap:wrap; font-size:0.83rem;">

                    <div>

                        <b>${escapeHtml(b.filename)}</b>

                        <div style="color:var(--text-muted); font-size:0.76rem;">Fecha: ${escapeHtml(b.created_at)} · Tamaño: ${Number(b.size_kb || 0).toFixed(1)} KB</div>

                    </div>

                    <div style="display:flex; gap:6px;">

                        <button type="button" class="btn btn-secondary btn-sm" onclick="restoreDatabaseBackup('${safeFile}')">Restaurar Copia</button>

                    </div>

                </div>

            `;

        }).join('');

    } catch (err) {

        console.warn('No se pudo cargar el listado de copias de seguridad:', err);

    }

}



async function createManualBackupPoint() {

    try {

        const res = await fetch('/api/backup/create', { method: 'POST' });

        if (res.ok) {

            showToast('Punto de restauración creado en disco correctamente', 'success');

            await loadBackupsList();

        } else {

            const err = await res.json().catch(() => ({}));

            showToast(err.detail || 'Error al crear copia de seguridad', 'error');

        }

    } catch (err) {

        showToast('Error de conexión al crear copia de seguridad', 'error');

    }

}



async function restoreDatabaseBackup(filename) {

    if (!filename) return;

    if (!confirm(`¿Restaurar la base de datos al punto "${filename}"?\n\nAntes de restaurar, el sistema creará automáticamente una copia de seguridad del estado actual para que no se pierda ningún dato.`)) {

        return;

    }

    try {

        const res = await fetch('/api/backup/restore', {

            method: 'POST',

            headers: { 'Content-Type': 'application/json' },

            body: JSON.stringify({ filename })

        });

        if ( res.ok ) {

            showToast(`Base de datos restaurada desde ${filename}`, 'success');

            await loadAllData();

            await loadBackupsList();

        } else {

            const err = await res.json().catch(() => ({}));

            showToast(err.detail || 'Error al restaurar la copia de seguridad', 'error');

        }

    } catch (err) {

        showToast('Error de conexión al restaurar copia de seguridad', 'error');

    }

}



async function exportClientGdpr(clientId) {

    try {

        const res = await fetch(`/api/clients/${clientId}/gdpr-export`);

        if (!res.ok) {

            const err = await res.json().catch(() => ({}));

            showToast(err.detail || 'Error al exportar datos RGPD', 'error');

            return;

        }

        const data = await res.json();

        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });

        const url = URL.createObjectURL(blob);

        const a = document.createElement('a');

        a.href = url;

        a.download = `portabilidad_rgpd_cliente_${clientId}.json`;

        document.body.appendChild(a);

        a.click();

        a.remove();

        URL.revokeObjectURL(url);

        showToast('Ficha de portabilidad RGPD descargada correctamente', 'success');

        loadSecurityAuditLogs();

    } catch (err) {

        showToast('Error de red al exportar datos RGPD', 'error');

    }

}



async function anonymizeClientGdpr(clientId) {

    const c = (state.clients || []).find(x => Number(x.id) === Number(clientId));

    const nombre = c ? c.nombre : `#${clientId}`;

    if (!confirm(`¿Aplicar Derecho de Supresión / Anonimización RGPD para "${nombre}"?\n\nSi el cliente tiene facturas cobradas, se conservarán únicamente los datos fiscales obligatorios para Hacienda (Art. 66 LGT) y se eliminarán su teléfono, correo, notas y firmas en borradores.`)) {

        return;

    }

    try {

        const res = await fetch(`/api/clients/${clientId}/gdpr-anonymize`, { method: 'POST' });

        if (res.ok) {

            const data = await res.json();

            showToast(

                data.has_official_invoices

                    ? 'Datos de contacto eliminados (conservación fiscal activa para Hacienda)'

                    : 'Cliente anonimizado completamente según RGPD',

                'success'

            );

            await Promise.all([loadClients(), loadQuotes()]);

            loadSecurityAuditLogs();

        } else {

            const err = await res.json().catch(() => ({}));

            showToast(err.detail || 'No se pudo anonimizar el cliente', 'error');

        }

    } catch (err) {

        showToast('Error de conexión al aplicar anonimización RGPD', 'error');

    }

}



async function loadSecurityAuditLogs() {

    if (state.currentUser && state.currentUser.rol !== 'ADMIN') return;

    const box = document.getElementById('security-audit-log-container');

    if (!box) return;

    try {

        const res = await fetch('/api/security/audit-log?limit=40');

        if (!res.ok) return;

        const data = await res.json();

        const logs = data.logs || [];

        if (logs.length === 0) {

            box.innerHTML = `<div class="text-center" style="padding:8px; color:var(--text-muted);">Sin eventos registrados aún.</div>`;

            return;

        }

        box.innerHTML = logs.map(l => `

            <div style="display:flex; justify-content:space-between; gap:8px; padding:5px 6px; border-bottom:1px solid var(--border); flex-wrap:wrap;">

                <div><b>[${escapeHtml(l.accion)}]</b> ${escapeHtml(l.detalle)}</div>

                <div style="color:var(--text-muted); font-size:0.74rem;">${escapeHtml(l.fecha)} · ${escapeHtml(l.usuario)} (${escapeHtml(l.rol)})</div>

            </div>

        `).join('');

    } catch (_) {}

}





// =============================================================

// MODAL DE CONEXIÓN MÓVIL Y CÓDIGO QR (WIFI LOCAL Y 4G REMOTO)

// =============================================================

let activeMobileUrl = '';

let currentMobileNetworkData = null;

let currentMobileTab = 'wifi'; // 'wifi' | '4g'



async function openMobileConnectModal() {

    const modal = document.getElementById('modal-mobile-connect');

    if (!modal) return;

    modal.style.display = 'flex';



    try {

        const res = await fetch('/api/system/network-info');

        if (res.ok) {

            currentMobileNetworkData = await res.json();

        } else {

            currentMobileNetworkData = {

                local_url: window.location.origin,

                local_qr_b64: '',

                remote_tunnel_active: false

            };

        }

    } catch (_) {

        currentMobileNetworkData = {

            local_url: window.location.origin,

            local_qr_b64: '',

            remote_tunnel_active: false

        };

    }



    // Si hay túnel remoto activo, sugerir pestaña 4G por defecto, si no WiFi

    if (currentMobileNetworkData.remote_tunnel_active) {

        switchMobileConnectTab('4g');

    } else {

        switchMobileConnectTab('wifi');

    }

}



function switchMobileConnectTab(tab) {

    currentMobileTab = tab;

    const btnWifi = document.getElementById('tab-mobile-wifi');

    const btn4g = document.getElementById('tab-mobile-4g');

    const subtitle = document.getElementById('mobile-connect-subtitle');

    const qrWrap = document.getElementById('mobile-qr-canvas-wrap');

    const urlBox = document.getElementById('mobile-connect-url-box');

    const urlText = document.getElementById('mobile-connect-url-text');

    const offlineCard = document.getElementById('mobile-4g-offline-card');



    if (tab === 'wifi') {

        if (btnWifi) {

            btnWifi.style.background = '#ffffff';

            btnWifi.style.color = '#0f172a';

            btnWifi.style.boxShadow = '0 1px 3px rgba(0,0,0,0.1)';

        }

        if (btn4g) {

            btn4g.style.background = 'transparent';

            btn4g.style.color = '#64748b';

            btn4g.style.boxShadow = 'none';

        }

        if (subtitle) {

            subtitle.textContent = 'Conecta tu móvil al mismo WiFi del taller y escanea este código:';

        }

        if (offlineCard) offlineCard.style.display = 'none';

        if (qrWrap) qrWrap.style.display = 'inline-block';

        if (urlBox) urlBox.style.display = 'flex';



        const localUrl = currentMobileNetworkData?.local_url || window.location.origin;

        activeMobileUrl = localUrl;

        if (urlText) urlText.textContent = localUrl;



        if (qrWrap) {

            if (currentMobileNetworkData?.local_qr_b64) {

                qrWrap.innerHTML = `

                    <img src="${currentMobileNetworkData.local_qr_b64}" 

                         alt="QR WiFi Local" 

                         width="180" height="180" 

                         style="display:block; border-radius:6px;">

                `;

            } else {

                qrWrap.innerHTML = `

                    <img src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(localUrl)}" 

                         alt="QR WiFi Local" 

                         width="180" height="180" 

                         style="display:block; border-radius:6px;"

                         onerror="this.onerror=null; this.parentElement.innerHTML='<div style=\'padding:20px; font-size:0.8rem; color:#64748b;\'>Abre en el móvil:<br><strong style=\'color:#0f172a;\'>' + escapeHtml(activeMobileUrl) + '</strong></div>';">

                `;

            }

        }

    } else {

        // Modo 4G / 5G en la calle

        if (btn4g) {

            btn4g.style.background = '#ffffff';

            btn4g.style.color = '#0f172a';

            btn4g.style.boxShadow = '0 1px 3px rgba(0,0,0,0.1)';

        }

        if (btnWifi) {

            btnWifi.style.background = 'transparent';

            btnWifi.style.color = '#64748b';

            btnWifi.style.boxShadow = 'none';

        }



        const isRemoteActive = Boolean(currentMobileNetworkData?.remote_tunnel_active);

        if (isRemoteActive) {

            if (subtitle) {

                subtitle.textContent = '✅ Enlace 4G cifrado activo. Escanea con tu móvil desde cualquier lugar:';

            }

            if (offlineCard) offlineCard.style.display = 'none';

            if (qrWrap) qrWrap.style.display = 'inline-block';

            if (urlBox) urlBox.style.display = 'flex';



            const remoteUrl = currentMobileNetworkData.remote_tunnel_url;

            activeMobileUrl = remoteUrl;

            if (urlText) urlText.textContent = remoteUrl;



            if (qrWrap) {

                if (currentMobileNetworkData.remote_qr_b64) {

                    qrWrap.innerHTML = `

                        <img src="${currentMobileNetworkData.remote_qr_b64}" 

                             alt="QR Acceso 4G Remoto" 

                             width="180" height="180" 

                             style="display:block; border-radius:6px;">

                    `;

                } else {

                    qrWrap.innerHTML = `

                        <img src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(remoteUrl)}" 

                             alt="QR Acceso 4G Remoto" 

                             width="180" height="180" 

                             style="display:block; border-radius:6px;">

                    `;

                }

            }

        } else {

            // 4G desconectado

            if (subtitle) {

                subtitle.textContent = 'Usa OfiGremio desde cualquier lugar con conexión móvil 4G/5G:';

            }

            if (qrWrap) qrWrap.style.display = 'none';

            if (urlBox) urlBox.style.display = 'none';

            if (offlineCard) offlineCard.style.display = 'block';

        }

    }

}



function closeMobileConnectModal() {

    const modal = document.getElementById('modal-mobile-connect');

    if (modal) modal.style.display = 'none';

}



function copyMobileUrl() {

    if (!activeMobileUrl) return;

    navigator.clipboard.writeText(activeMobileUrl).then(() => {

        showToast('Enlace copiado al portapapeles', 'success');

    }).catch(() => {

        showToast(activeMobileUrl, 'info');

    });

}



// Soporte PWA beforeinstallprompt en Android

let deferredPwaPrompt = null;

window.addEventListener('beforeinstallprompt', (e) => {

    e.preventDefault();

    deferredPwaPrompt = e;

});



// =========================================================================
// GESTIÓN DE LICENCIA Y SUSCRIPCIÓN STRIPE
// =========================================================================
async function checkLicenseStatus() {
    try {
        const res = await fetch('/api/license/status');
        if (!res.ok) return;
        const data = await res.json();
        
        // Actualizar tarjeta en pestaña Configuración
        const hwidEl = document.getElementById('cfg-lic-hwid');
        const tipoEl = document.getElementById('cfg-lic-tipo');
        const diasEl = document.getElementById('cfg-lic-dias');
        const expEl = document.getElementById('cfg-lic-expira');
        const badgeEl = document.getElementById('cfg-lic-badge');
        
        if (hwidEl) hwidEl.textContent = data.hwid || '--';
        if (tipoEl) tipoEl.textContent = data.is_subscription ? 'Suscripción Mensual (15 €/mes Stripe)' : (data.payload && data.payload.tipo === 'LIFETIME' ? 'Licencia Comercial Permanente' : 'Licencia Oficial');
        if (diasEl) {
            if (data.days_remaining !== null && data.days_remaining !== undefined) {
                diasEl.textContent = data.days_remaining + ' días';
            } else {
                diasEl.textContent = 'Permanente';
            }
        }
        if (expEl) expEl.textContent = data.expires_at || 'Indefinida';
        if (badgeEl) {
            if (data.status === 'CANCELLED' || data.status === 'CANCELADA') {
                badgeEl.textContent = 'CANCELADA';
                badgeEl.style.background = '#ef4444';
            } else if (data.valid) {
                badgeEl.textContent = 'ACTIVA';
                badgeEl.style.background = '#10b981';
            } else {
                badgeEl.textContent = 'EXPIRADA / PENDIENTE';
                badgeEl.style.background = '#ef4444';
            }
        }

        const cancelBtn = document.getElementById('cfg-lic-cancel-btn');
        if (cancelBtn) {
            cancelBtn.style.display = (data.status === 'CANCELLED' || data.status === 'CANCELADA') ? 'none' : 'inline-block';
        }
        const portalBtn = document.getElementById('cfg-lic-portal-btn');
        if (portalBtn) {
            portalBtn.style.display = 'inline-block';
        }
        
        // Consultar link a portal de Stripe si existe
        const stripeRes = await fetch('/api/license/stripe-config');
        if (stripeRes.ok) {
            const stripeCfg = await stripeRes.json();
            const portalUrl = stripeCfg.customer_portal_url || stripeCfg.customer_portal_link;
            const cancelLink = document.getElementById('cfg-lic-cancel-link');
            if (portalUrl && cancelLink) {
                cancelLink.href = portalUrl;
                cancelLink.style.display = 'inline-block';
            }
        }
    } catch (err) {
        console.warn('[License] Comprobación pasiva de licencia omitida:', err);
    }
}

async function downloadStripeInvoice() {
    if (typeof showToast === 'function') {
        showToast('📄 Descargando factura de Stripe...', 'info');
    }
    try {
        const res = await fetch('/api/license/stripe-invoice');
        if (!res.ok) {
            throw new Error(`Error en el servidor al generar factura (${res.status})`);
        }
        const blob = await res.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        const now = new Date();
        const monthStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
        a.download = `Factura_Stripe_OfiGremio_${monthStr}.pdf`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
        if (typeof showToast === 'function') {
            showToast('✅ Factura de Stripe descargada con éxito', 'success');
        }
    } catch (err) {
        if (typeof showToast === 'function') {
            showToast('Error al descargar factura: ' + err.message, 'error');
        }
    }
}

async function cancelSubscriptionNow() {
    if (!confirm('¿Estás seguro de que deseas cancelar tu suscripción mensual de Stripe (15 €/mes)?')) {
        return;
    }
    if (typeof showToast === 'function') {
        showToast('Procesando cancelación de suscripción...', 'info');
    }
    try {
        const res = await fetch('/api/license/cancel-subscription', { method: 'POST' });
        const data = await res.json();
        if (data.success || data.status === 'CANCELLED' || data.status === 'CANCELADA') {
            if (typeof showToast === 'function') {
                showToast('Suscripción cancelada correctamente.', 'success');
            }
            await checkLicenseStatus();
        } else {
            if (typeof showToast === 'function') {
                showToast('Aviso: ' + (data.message || 'No se pudo cancelar'), 'warning');
            }
        }
    } catch (err) {
        if (typeof showToast === 'function') {
            showToast('Error de conexión al cancelar suscripción.', 'error');
        }
    }
}

async function syncSubscriptionNow() {
    if (typeof showToast === 'function') {
        showToast('Sincronizando con el servidor de licencias Stripe...', 'info');
    }
    try {
        const res = await fetch('/api/license/sync-now', { method: 'POST' });
        const data = await res.json();
        const syncRes = data.sync_result || {};
        
        if (syncRes.status === 'UPDATED') {
            if (typeof showToast === 'function') {
                showToast('¡Suscripción actualizada exitosamente!', 'success');
            }
            setTimeout(() => window.location.reload(), 1200);
        } else if (syncRes.status === 'UNCHANGED') {
            if (typeof showToast === 'function') {
                showToast('Licencia ya al día. Todo correcto.', 'success');
            }
            await checkLicenseStatus();
        } else if (syncRes.status === 'ERROR') {
            if (typeof showToast === 'function') {
                showToast('Aviso: ' + (syncRes.message || 'Sin conexión al servidor. Modo offline activo.'), 'warning');
            }
        } else {
            if (typeof showToast === 'function') {
                showToast(syncRes.message || 'Comprobación completada.', 'info');
            }
            await checkLicenseStatus();
        }
    } catch (err) {
        if (typeof showToast === 'function') {
            showToast('Modo sin conexión: se conserva la validez local.', 'warning');
        }
    }
}


// =========================================================================
// MÓDULO OFICIAL VERI*FACTU & GESTIÓN IA (COSTE 0€)
// =========================================================================
async function loadVerifactuStatus() {
    try {
        const res = await fetch('/api/verifactu/status');
        if (!res.ok) return;
        const data = await res.json();

        const badgeComp = document.getElementById('verifactu-badge-compliance');
        if (badgeComp) {
            badgeComp.innerText = data.cumplimiento_encadenamiento ? '🟢 Sistema Conforme AEAT' : '🟡 Verificación Pendiente';
        }

        const statsCount = document.getElementById('verifactu-stats-count');
        if (statsCount) {
            statsCount.innerText = `${data.total_facturas_emitidas || 0} emitidas · ${data.facturas_aceptadas_aeat || 0} aceptadas`;
        }

        const hashPreview = document.getElementById('verifactu-hash-preview');
        if (hashPreview) {
            hashPreview.innerText = data.ultima_huella_sha256 || 'GENESIS';
        }

        const certStatus = document.getElementById('verifactu-cert-status');
        if (certStatus) {
            if (data.certificado_instalado) {
                certStatus.innerHTML = `✅ Certificado activo: <b>${escapeHtml(data.certificado_archivo)}</b>`;
                certStatus.style.color = '#059669';
            } else {
                certStatus.innerText = 'No configurado (usando acuse simulado de pruebas sin coste).';
                certStatus.style.color = 'var(--text-muted)';
            }
        }

        const aiBadge = document.getElementById('ai-engine-badge');
        if (aiBadge) {
            const cfg = state.config || {};
            if (cfg.gemini_api_key) {
                aiBadge.innerText = '🟢 Gemini 1.5 Flash Activo (Gratuito)';
                aiBadge.style.background = '#0284c7';
            } else {
                aiBadge.innerText = '🟢 IA Integrada Local Activa (0 €)';
                aiBadge.style.background = '#059669';
            }
        }
    } catch (err) {
        console.warn('Error loading Veri*Factu status:', err);
    }
}

async function saveVerifactuConfig() {
    const entorno = document.getElementById('cfg-verifactu-entorno')?.value || 'test';
    try {
        const res = await fetch('/api/config', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ verifactu_entorno: entorno })
        });
        if (res.ok) {
            showToast('✅ Entorno Veri*Factu actualizado');
            loadVerifactuStatus();
        }
    } catch (e) {
        showToast('❌ Error guardando entorno Veri*Factu');
    }
}

async function uploadVerifactuCert() {
    const fileInput = document.getElementById('verifactu-cert-file');
    const passInput = document.getElementById('verifactu-cert-pass');
    if (!fileInput || !fileInput.files || fileInput.files.length === 0) return;

    const file = fileInput.files[0];
    const password = passInput ? passInput.value : '';

    const formData = new FormData();
    formData.append('file', file);
    formData.append('password', password);

    showToast('Subiendo certificado digital...');
    try {
        const res = await fetch('/api/verifactu/upload-cert', {
            method: 'POST',
            body: formData
        });
        const data = await res.json();
        if (res.ok && data.success) {
            showToast('✅ Certificado digital cargado correctamente');
            if (passInput) passInput.value = '';
            loadVerifactuStatus();
        } else {
            showToast('❌ ' + (data.detail || data.message || 'Error al guardar certificado'));
        }
    } catch (e) {
        showToast('❌ Error al subir certificado digital');
    }
}

async function saveGeminiKey() {
    const key = document.getElementById('cfg-gemini-key')?.value.trim() || '';
    try {
        const res = await fetch('/api/config', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ gemini_api_key: key })
        });
        if (res.ok) {
            showToast(key ? '✅ Clave de Google Gemini guardada (Coste 0 €)' : 'ℹ️ Clave eliminada. Usando IA Integrada Local.');
            loadVerifactuStatus();
        }
    } catch (e) {
        showToast('❌ Error guardando clave IA');
    }
}

function downloadVerifactuXml(quoteId) {
    window.open(`/api/quotes/${quoteId}/verifactu-xml`, '_blank');
}

async function retryVerifactuInvoice(quoteId) {
    showToast('Reenviando factura a la AEAT...');
    try {
        const res = await fetch(`/api/quotes/${quoteId}/verifactu-retry`, { method: 'POST' });
        if (res.ok) {
            showToast('✅ Factura reenviada a Hacienda');
            if (typeof loadQuotes === 'function') loadQuotes();
            loadVerifactuStatus();
        } else {
            showToast('❌ No se pudo reenviar la factura');
        }
    } catch (e) {
        showToast('❌ Error de conexión al reenviar');
    }
}
