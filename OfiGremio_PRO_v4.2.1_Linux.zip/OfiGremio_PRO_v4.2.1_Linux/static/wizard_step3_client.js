// OfiGremio Pro v3.1 — Wizard Paso 3: Primer Cliente Resiliente
window.WizardStep3 = {
    onEnter: function() {
        const pane = document.getElementById('wizard-step-3');
        if (!pane) return;

        pane.innerHTML = `
            <div style="margin-bottom:16px;">
                <h3 style="font-size:1.15rem; font-weight:700; margin-bottom:4px;">👤 Registra tu Primer Cliente</h3>
                <p style="font-size:0.85rem; color:#64748b;">Aprende cómo funciona la cartera de clientes. Quedará guardado en tu base de datos local.</p>
            </div>

            <div style="display:flex; justify-content:flex-end; margin-bottom:10px;">
                <button type="button" class="btn btn-secondary" style="font-size:0.75rem; padding:4px 8px;" onclick="WizardStep3.fillSampleClient()">
                    ✨ Usar Cliente de Ejemplo
                </button>
            </div>

            <div style="display:flex; flex-direction:column; gap:10px;">
                <div>
                    <label style="font-size:0.8rem; font-weight:600; display:block; margin-bottom:4px;">Nombre del Cliente o Comunidad *</label>
                    <input type="text" id="wiz-cli-nombre" value="Comunidad Propietarios Alcalá" placeholder="Ej. María López" style="width:100%; padding:10px; border-radius:8px; border:1px solid #cbd5e1;">
                </div>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                    <div>
                        <label style="font-size:0.8rem; font-weight:600; display:block; margin-bottom:4px;">Teléfono WhatsApp *</label>
                        <input type="tel" id="wiz-cli-telefono" value="611223344" placeholder="Ej. 655 443 322" style="width:100%; padding:10px; border-radius:8px; border:1px solid #cbd5e1;">
                    </div>
                    <div>
                        <label style="font-size:0.8rem; font-weight:600; display:block; margin-bottom:4px;">NIF / CIF (Opcional)</label>
                        <input type="text" id="wiz-cli-nif" value="H-28001122" placeholder="Ej. 12345678-X" style="width:100%; padding:10px; border-radius:8px; border:1px solid #cbd5e1;">
                    </div>
                </div>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                    <div>
                        <label style="font-size:0.8rem; font-weight:600; display:block; margin-bottom:4px;">Correo Electrónico del Cliente</label>
                        <input type="email" id="wiz-cli-email" value="comunidad@alcala45.es" placeholder="Ej. cliente@correo.com" style="width:100%; padding:10px; border-radius:8px; border:1px solid #cbd5e1;">
                    </div>
                    <div>
                        <label style="font-size:0.8rem; font-weight:600; display:block; margin-bottom:4px;">Dirección de la Intervención</label>
                        <input type="text" id="wiz-cli-direccion" value="Calle Alcalá 45" placeholder="Ej. Calle Alcalá 45" style="width:100%; padding:10px; border-radius:8px; border:1px solid #cbd5e1;">
                    </div>
                </div>
            </div>
        `;
    },

    fillSampleClient: function() {
        const inpNom = document.getElementById('wiz-cli-nombre');
        const inpTel = document.getElementById('wiz-cli-telefono');
        const inpEmail = document.getElementById('wiz-cli-email');
        const inpDir = document.getElementById('wiz-cli-direccion');
        const inpNif = document.getElementById('wiz-cli-nif');

        if (inpNom) inpNom.value = "Comunidad Propietarios Los Sauces";
        if (inpTel) inpTel.value = "688 123 456";
        if (inpEmail) inpEmail.value = "administracion@lossauces.es";
        if (inpDir) inpDir.value = "Avenida Principal 12";
        if (inpNif) inpNif.value = "H-28991100";
        showToast('Cliente de muestra cargado', 'info');
    },

    validate: async function() {
        const nom = document.getElementById('wiz-cli-nombre')?.value.trim() || 'Comunidad Propietarios Alcalá';
        const tel = document.getElementById('wiz-cli-telefono')?.value.trim() || '611223344';
        const email = document.getElementById('wiz-cli-email')?.value.trim() || '';
        const dir = document.getElementById('wiz-cli-direccion')?.value.trim() || 'Calle Alcalá 45';
        const nif = document.getElementById('wiz-cli-nif')?.value.trim() || '';

        try {
            const res = await fetch('/api/clients', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    nombre: nom,
                    telefono: tel,
                    email: email,
                    direccion: dir,
                    nif_cif: nif
                })
            });
            if (res.ok) {
                const created = await res.json();
                window.WizardController.data.client = {
                    id: created.id,
                    nombre: created.nombre,
                    telefono: created.telefono,
                    email: created.email || email,
                    direccion: created.direccion
                };
            } else {
                window.WizardController.data.client = { id: 1, nombre: nom, telefono: tel, email: email, direccion: dir };
            }
        } catch (e) {
            window.WizardController.data.client = { id: 1, nombre: nom, telefono: tel, email: email, direccion: dir };
        }
        return true;
    }
};
