// OfiGremio Pro v3.1 — Wizard Shell & Stepper Engine (Resiliente, No Bloqueante)
window.WizardController = {
    currentStep: 1,
    totalSteps: 5,
    isInitialSetup: false,
    data: {
        admin: {
            username: '',
            password: '',
            nombre: 'Administrador Principal'
        },
        business: {
            empresa_nombre: 'Mi Empresa de Servicios Técnicos',
            empresa_cif: 'B-12345678',
            empresa_telefono: '600123456',
            empresa_email: 'contacto@miempresa.es',
            empresa_direccion: '',
            empresa_poblacion: 'Madrid',
            sector: 'FONTANERIA',
            sector_custom_nombre: '',
            color_theme: '#2563eb',
            precio_hora_default: 38.0,
            recargo_urgencia_default: 45.0
        },
        payment: {
            empresa_iban: '',
            iva_default: 0.21,
            irpf_default: 0.0,
            metodo_cobro: 'BIZUM'
        },
        client: {
            id: null,
            nombre: 'Comunidad Propietarios Alcalá',
            telefono: '611223344',
            direccion: 'Calle Alcalá 45'
        },
        inventory: []
    },

    init: function() {
        console.log("🧙 [WizardController] Inicializando motor Onboarding v3.1...");
        this.renderShell();
        this._initEvents();
    },

    _initEvents: function() {
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const modal = document.getElementById('wizard-container');
                if (modal && modal.style.display === 'flex') {
                    this.skipAndGoHome();
                }
            }
        });
    },

    checkAutoStart: async function(cfgParam) {
        if (document.body.classList.contains('auth-locked')) return;
        let cfg = cfgParam || window.state?.config;
        if (!cfg || Object.keys(cfg).length === 0) {
            try {
                const res = await fetch('/api/config');
                if (res.ok) {
                    cfg = await res.json();
                    if (window.state) window.state.config = cfg;
                }
            } catch (e) {
                console.warn('[Wizard] Error obteniendo config en checkAutoStart:', e);
            }
        }
        cfg = cfg || {};

        const isPending = String(cfg.primera_configuracion_pendiente) === "1";
        if (isPending && !this._autoStartedOnce) {
            this._autoStartedOnce = true;
            sessionStorage.removeItem("ofigremio_wizard_skipped");
            localStorage.removeItem("ofigremio_wizard_dismissed");
            console.log("🧙 [WizardController] Primera configuración pendiente detectada ('1'). Abriendo asistente automáticamente...");
            setTimeout(() => this.open(), 120);
        }
    },

    open: async function() {
        this.renderShell();
        const modal = document.getElementById('wizard-container');
        if (!modal) return;

        let cfg = (window.state && window.state.config) || {};
        if (!cfg || Object.keys(cfg).length === 0) {
            try {
                const res = await fetch('/api/config');
                if (res.ok) {
                    cfg = await res.json();
                    if (window.state) window.state.config = cfg;
                }
            } catch (e) {
                cfg = {};
            }
        }

        // Pre-cargar datos actuales del negocio
        if (cfg.empresa_nombre) this.data.business.empresa_nombre = cfg.empresa_nombre;
        if (cfg.empresa_cif && cfg.empresa_cif !== 'B-00000000') this.data.business.empresa_cif = cfg.empresa_cif;
        if (cfg.empresa_telefono) this.data.business.empresa_telefono = cfg.empresa_telefono;
        if (cfg.empresa_email) this.data.business.empresa_email = cfg.empresa_email;
        if (cfg.empresa_poblacion) this.data.business.empresa_poblacion = cfg.empresa_poblacion;
        if (cfg.empresa_direccion) this.data.business.empresa_direccion = cfg.empresa_direccion;
        if (cfg.sector) this.data.business.sector = cfg.sector;
        if (cfg.sector_custom_nombre) this.data.business.sector_custom_nombre = cfg.sector_custom_nombre;
        if (cfg.precio_hora_default) this.data.business.precio_hora_default = parseFloat(cfg.precio_hora_default) || 38.0;
        if (cfg.recargo_urgencia_default) this.data.business.recargo_urgencia_default = parseFloat(cfg.recargo_urgencia_default) || 45.0;

        // Pre-cargar datos de cobro y fiscalidad
        if (cfg.empresa_iban) this.data.payment.empresa_iban = cfg.empresa_iban;
        if (cfg.iva_default !== undefined && cfg.iva_default !== null) this.data.payment.iva_default = parseFloat(cfg.iva_default);
        if (cfg.irpf_default !== undefined && cfg.irpf_default !== null) this.data.payment.irpf_default = parseFloat(cfg.irpf_default);

        if (cfg.color_theme) {
            this.data.business.color_theme = cfg.color_theme;
            document.documentElement.style.setProperty('--primary-color', cfg.color_theme);
        }

        modal.style.display = 'flex';
        this.goToStep(1);
    },

    close: function() {
        const modal = document.getElementById('wizard-container');
        if (modal) modal.style.display = 'none';
    },

    skipAndGoHome: async function() {
        if (this.isInitialSetup && !window.state?.currentUser) {
            if (this.currentStep === 1 && window.WizardStep1?.validate) {
                const ok = await window.WizardStep1.validate();
                if (!ok) return;
            } else {
                this.goToStep(1);
                if (typeof showToast === 'function') showToast('🔐 Crea primero tu usuario Administrador en el Paso 1', 'warning');
                return;
            }
        }
        sessionStorage.setItem('ofigremio_wizard_skipped', '1');
        localStorage.setItem('ofigremio_wizard_dismissed', '1');
        this.isInitialSetup = false;
        this.close();
        try {
            await fetch('/api/config', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ primera_configuracion_pendiente: "0" })
            });
            if (window.state?.config) {
                window.state.config.primera_configuracion_pendiente = "0";
            }
        } catch (e) {
            console.warn('[Wizard] Error actualizando primera_configuracion_pendiente:', e);
        }
        showToast('✓ Bienvenido a OfiGremio. Panel principal activo.', 'info');
        if (typeof loadAllData === 'function') await loadAllData();
        if (typeof renderDashboard === 'function') renderDashboard();
    },

    goToStep: function(step) {
        if (step < 1 || step > this.totalSteps) return;
        this.currentStep = step;

        for (let i = 1; i <= this.totalSteps; i++) {
            const pane = document.getElementById(`wizard-step-${i}`);
            const ind = document.getElementById(`step-ind-${i}`);
            if (pane) {
                if (i === step) pane.classList.add('active');
                else pane.classList.remove('active');
            }
            if (ind) {
                if (i === step) ind.className = 'step-indicator active';
                else if (i < step) ind.className = 'step-indicator completed';
                else ind.className = 'step-indicator';
            }
        }

        const progressFill = document.getElementById('wizard-progress');
        if (progressFill) {
            progressFill.style.width = `${(step / this.totalSteps) * 100}%`;
        }

        const btnPrev = document.getElementById('btn-wiz-prev');
        const btnNext = document.getElementById('btn-wiz-next');
        if (btnPrev) btnPrev.style.visibility = step === 1 ? 'hidden' : 'visible';
        if (btnNext) {
            btnNext.innerText = step === this.totalSteps ? '🚀 Finalizar y Entrar al Panel' : 'Siguiente ➡️';
        }

        // Hooks garantizados para cada paso
        if (step === 1 && window.WizardStep1?.onEnter) window.WizardStep1.onEnter();
        if (step === 2 && window.WizardStep2?.onEnter) window.WizardStep2.onEnter();
        if (step === 3 && window.WizardStep3?.onEnter) window.WizardStep3.onEnter();
        if (step === 4 && window.WizardStep4?.onEnter) window.WizardStep4.onEnter();
        if (step === 5 && window.WizardStep5?.onEnter) window.WizardStep5.onEnter();
    },

    nextStep: async function() {
        const btnNext = document.getElementById('btn-wiz-next');
        if (btnNext) btnNext.disabled = true;

        try {
            if (this.currentStep === 1 && window.WizardStep1?.validate) {
                const ok = await window.WizardStep1.validate();
                if (!ok) return;
            }
            if (this.currentStep === 2 && window.WizardStep2?.validate) {
                const ok = window.WizardStep2.validate();
                if (!ok) return;
            }
            if (this.currentStep === 3 && window.WizardStep3?.validate) {
                const ok = await window.WizardStep3.validate();
                if (!ok) return;
            }
            if (this.currentStep === 4 && window.WizardStep4?.validate) {
                const ok = await window.WizardStep4.validate();
                if (!ok) return;
            }

            if (this.currentStep === this.totalSteps) {
                if (window.WizardStep5?.finish) await window.WizardStep5.finish();
                else await this.completeAndClose();
            } else {
                this.goToStep(this.currentStep + 1);
            }
        } finally {
            if (btnNext) btnNext.disabled = false;
        }
    },

    prevStep: function() {
        this.goToStep(this.currentStep - 1);
    },

    renderShell: function() {
        if (document.getElementById('wizard-container')) return;
        const div = document.createElement('div');
        div.id = 'wizard-container';
        div.className = 'wizard-overlay';
        div.innerHTML = `
            <div class="wizard-modal">
                <div class="wizard-header">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <h2 style="font-size:1.25rem; font-weight:700; margin:0;">🚀 Puesta en Marcha — OfiGremio Pro</h2>
                        <div style="display:flex; align-items:center; gap:8px;">
                            <button type="button" class="btn btn-sm btn-secondary" onclick="WizardController.skipAndGoHome()" title="Ir directamente al panel principal">Saltar al Panel ✕</button>
                            <button class="btn-close" onclick="WizardController.skipAndGoHome()" title="Cerrar y continuar">&times;</button>
                        </div>
                    </div>
                    <div class="wizard-progress-bar">
                        <div id="wizard-progress" class="wizard-progress-fill"></div>
                    </div>
                    <div class="wizard-stepper">
                        <div id="step-ind-1" class="step-indicator active"><span class="step-circle">1</span> Negocio</div>
                        <div id="step-ind-2" class="step-indicator"><span class="step-circle">2</span> Cobro</div>
                        <div id="step-ind-3" class="step-indicator"><span class="step-circle">3</span> Cliente</div>
                        <div id="step-ind-4" class="step-indicator"><span class="step-circle">4</span> Catálogo</div>
                        <div id="step-ind-5" class="step-indicator"><span class="step-circle">5</span> ¡Listo!</div>
                    </div>
                </div>
                <div class="wizard-body">
                    <div id="wizard-step-1" class="wizard-step-pane active"></div>
                    <div id="wizard-step-2" class="wizard-step-pane"></div>
                    <div id="wizard-step-3" class="wizard-step-pane"></div>
                    <div id="wizard-step-4" class="wizard-step-pane"></div>
                    <div id="wizard-step-5" class="wizard-step-pane"></div>
                </div>
                <div class="wizard-footer">
                    <button id="btn-wiz-prev" type="button" class="btn btn-secondary" onclick="WizardController.prevStep()">⬅️ Anterior</button>
                    <button id="btn-wiz-next" type="button" class="btn btn-primary" onclick="WizardController.nextStep()">Siguiente ➡️</button>
                </div>
            </div>
        `;
        document.body.appendChild(div);
    },

    completeAndClose: async function() {
        sessionStorage.setItem('ofigremio_wizard_skipped', '1');
        localStorage.setItem('ofigremio_wizard_dismissed', '1');
        showToast('💾 Guardando configuración de tu negocio...', 'success');
        try {
            const b = this.data.business;
            const p = this.data.payment;
            const adm = this.data.admin || {};
            const payload = {
                empresa_nombre: b.empresa_nombre || 'Mi Empresa de Servicios Técnicos',
                empresa_cif: b.empresa_cif || 'B-12345678',
                empresa_telefono: b.empresa_telefono || '600123456',
                empresa_email: b.empresa_email || '',
                empresa_direccion: b.empresa_direccion || '',
                empresa_poblacion: b.empresa_poblacion || 'Madrid',
                empresa_iban: p.empresa_iban || '',
                sector: b.sector || 'FONTANERIA',
                sector_custom_nombre: b.sector_custom_nombre || '',
                color_theme: b.color_theme || '#2563eb',
                precio_hora_default: parseFloat(b.precio_hora_default) || 38.0,
                recargo_urgencia_default: parseFloat(b.recargo_urgencia_default) || 45.0,
                iva_default: parseFloat(p.iva_default) || 0.21,
                irpf_default: parseFloat(p.irpf_default) || 0.0,
                primera_configuracion_pendiente: "0"
            };
            if (adm.username && adm.password) {
                payload.admin_username = adm.username;
                payload.admin_password = adm.password;
                payload.admin_nombre = adm.nombre || 'Administrador Principal';
            }

            const res = await fetch('/api/wizard/complete', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (res.ok) {
                const resData = await res.json();
                if (resData.token) {
                    localStorage.setItem('ofigremio_token', resData.token);
                    localStorage.setItem('ofigremio_auth_token', resData.token);
                }
                if (resData.user) {
                    if (window.state) window.state.currentUser = resData.user;
                    document.body.classList.remove('auth-locked');
                    if (typeof applyRoleUI === 'function') applyRoleUI(resData.user);
                }
                if (window.state) {
                    window.state.config = resData.config;
                }
                this.isInitialSetup = false;
                document.documentElement.style.setProperty('--primary-color', payload.color_theme);
                this.close();
                showToast('🎉 ¡Bienvenido! Tu negocio y usuario Administrador están configurados.', 'success');
                if (typeof loadAllData === 'function') await loadAllData();
                if (typeof renderDashboard === 'function') renderDashboard();
            } else {
                const errData = await res.json().catch(() => ({}));
                showToast(`❌ ${errData.detail || 'Error al completar configuración'}`, 'error');
            }
        } catch (e) {
            console.error('Error completando wizard:', e);
            this.close();
        }
    }
};

document.addEventListener('DOMContentLoaded', () => {
    if (window.WizardController) {
        window.WizardController.init();
    }
});
